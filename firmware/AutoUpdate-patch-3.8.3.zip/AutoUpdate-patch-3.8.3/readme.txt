AnyLink update manual

1. Connect your PC to AnyLink IoT box via LAN port or builtin WiFi AP (by plugging in AnyLink WiFi AP USB driver into IoT box to enable to WiFi AP in the IoT box)
2. On your windows PC, double click AutoUpdate.exe to start the update process
3. Type 'c' to continue update when prompted with "Input choice" menu
4. Wait for the update process to finish
5. The update is successful if you see 'Success' in the result printed on the screen. If not, please try to power cycle the IoT box and try again.
6. Power cycle the IoT box if update is successful. 
