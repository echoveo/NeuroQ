1.生产测试工具
2.配置文件说明
config.json         全功能测试脚本，需要外部电路 支持，如ADC,gpio，uart等
config_self_detect.json     自检脚本
config_id.json      写号脚本

3.手工测试说明
e.g
cd /usrdata/factory_test
python main.py --cfg=config_id.json
