#!/usr/bin/python
# -*- coding: UTF-8 -*-

import os
import sys
import common
import log
import time
import restapi
import traceback
__version__ = "1.0.0"


'''
6.  usb
     各接一个u盘，读取里面的文件，求读取速度 > usb1.1标准
/sys/bus/usb/devices/usb1/1-1/1-1.1  port1
/sys/bus/usb/devices/usb1/1-1/1-1.2  port2
      usb要求高于1.5Mbytes  只需要读取

      test -f /tmp/result&&rm /tmp/result;(dd if=/media/usb1/test.dat of=/dev/null count=102400 bs=1024 iflag=direct) 2>>/tmp/result;cat /tmp/result| grep seconds|awk -F ',' '{print $3}' |awk -F 'M' '{print $1}'
      test -f /tmp/result&&rm /tmp/result;(dd if=/media/usb2/test.dat of=/dev/null count=102400 bs=1024 iflag=direct) 2>>/tmp/result;cat /tmp/result| grep seconds|awk -F ',' '{print $3}' |awk -F 'M' '{print $1}'
'''


GPIO_DIR = "/sys/class/gpio"


g_logger = None




def read_gpio(gpio_port):
    v_file = "{0}/{1}/value".format(GPIO_DIR, gpio_port)
    with open(v_file, 'r') as f:
        value = f.read().strip()
        return int(value)




def run():
    try:
        errors=0
        g_logger.info("[usb] begin test usb") 
        #检查usb1,usb2是否
        err_msg=""
        post_data={"err_msg":'',"test_report":"","test_module":"usb"}
        os.system("mkdir -p /var/volatile/tmp")
        is_usb1_mounted = common.run_cmd("mount | grep usb1")
        is_usb2_mounted = common.run_cmd("mount | grep usb2")
        if is_usb1_mounted=="":                        
            errors+=1
            err_msg += "usb1 not mounted;"
            g_logger.info(err_msg)
        else:
            if not os.path.exists("/media/usb1/test.dat"):
                os.system("dd of=/media/usb1/test.dat if=/dev/zero count=102400 bs=512 oflag=direct")
            ret_usb1 = common.run_cmd("test -f /tmp/result&&rm /tmp/result;(dd if=/media/usb1/test.dat of=/dev/null count=102400 bs=512 iflag=direct) 2>>/tmp/result;cat /tmp/result| grep seconds|awk -F ',' '{print $3}' |awk -F 'M' '{print $1}'")
            if (ret_usb1!="" and float(ret_usb1)>2.0):               
                err_msg += "usb1 speed test success,speed={0}".format(ret_usb1)
                g_logger.info(err_msg)
                #return True,"successful"
            else:
                err_msg += "usb1 speed test fail,speed={0}".format(ret_usb1)
                g_logger.info(err_msg)              
                errors+=1

        if is_usb2_mounted=="":                        
            errors+=1
            err_msg += "usb2 not mounted;"
            g_logger.info(err_msg)
        else:
            if not os.path.exists("/media/usb2/test.dat"):
                os.system("dd of=/media/usb2/test.dat if=/dev/zero count=102400 bs=512 oflag=direct")
            ret_usb2 = common.run_cmd("test -f /tmp/result&&rm /tmp/result;(dd if=/media/usb2/test.dat of=/dev/null count=102400 bs=512 iflag=direct) 2>>/tmp/result;cat /tmp/result| grep seconds|awk -F ',' '{print $3}' |awk -F 'M' '{print $1}'")
            if (ret_usb2!="" and float(ret_usb2)>2.0):               
                err_msg += "usb2 speed test success,speed={0}".format(ret_usb2)
                g_logger.info(err_msg)
                #return True,"successful"
            else:
                err_msg += "usb2 speed test fail,speed={0}".format(ret_usb2)
                g_logger.info(err_msg)              
                errors+=1

        ret_usb2 = common.run_cmd("test -f /tmp/result&&rm /tmp/result;(dd if=/media/usb2/test.dat of=/dev/null count=102400 bs=512 iflag=direct) 2>>/tmp/result;cat /tmp/result| grep seconds|awk -F ',' '{print $3}' |awk -F 'M' '{print $1}'")
        if (errors<=0):
            g_logger.info("[usb] test success") 
            post_data['test_res']=True
            post_data['test_report']=err_msg
            #return True,"successful"
        else:
            post_data['test_res']=False
            post_data['test_report']=err_msg
            g_logger.info("[usb] test fail:{0}".format(post_data)) 
            #return False,"usb port error"
        restapi.send_test_report(post_data)
        if errors<=0:
            return True,""
        else:
            return False,"[usb]test fail"
    except Exception as ept:
        exstr = traceback.format_exc()
        g_logger.info("[usb] test fail,exception={0},stack={1}".format(str(ept),exstr)) 
        #raise ept
        return False, repr(ept)


def main():
    global g_logger
    g_logger = log.initial_log("usb.log",common.get_CTX('log_level') )


