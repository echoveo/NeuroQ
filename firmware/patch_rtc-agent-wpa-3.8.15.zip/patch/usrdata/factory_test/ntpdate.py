#!/usr/bin/python

import os
import sys
import time
import commands
import xml.etree.ElementTree
import logging
import psutil
import datetime
from logging.handlers import RotatingFileHandler
logger = 0
serveraddressinit = '1.cn.pool.ntp.org'
Anylinkxmlpath = "/opt/sdmwebs/web/conf/AnyLink.xml"
Moduleconfigpath = "/opt/agent/ModuleConfig.xml"


def init_logger():
    global logger
    logger = logging.getLogger()
    rthandler = RotatingFileHandler('/PageFile/ntplog.log', mode='a', maxBytes=8*1024, backupCount=0)
    formatter = logging.Formatter('%(asctime)s %(levelname)s----%(message)s')
    rthandler.setFormatter(formatter)
    logger.addHandler(rthandler)
    logger.setLevel(logging.INFO)
    return 0


def examine_xml(xml_path):
    try:
        xml.etree.ElementTree.parse(xml_path)
    except Exception as e:
        print "examine xml failed : " + repr(e)
        logging.error('\033[35mxml is Error!\033[0m')
        return -1
    return 0


def ntp_time(ntp_server):
    try:
        (status, output) = commands.getstatusoutput('/usr/bin/ntpdate -u %s' % ntp_server)
        if 'adjust time server' in output:
            return 0
    except Exception, e:
        logger.error('ntpdate error')
        logger.error(e)
        return -1
    return -1


def mqttserveraddress():
    try:
        config_tree = xml.etree.ElementTree.parse(Moduleconfigpath)
        mqtt_node = config_tree.find('./task/TaskDriver/driver[@n="T.IDrv.Task:libkmqtt"]')
        mqtt_config = mqtt_node.get('config').split(';')
        server_address = mqtt_config[0]
        print server_address
    except Exception, e:
        print Exception, ":", e
        logger.error('bad address')
        return -1
    return server_address


def checkotheraddress():
    try:
        tree = xml.etree.ElementTree.parse(Anylinkxmlpath)
        nodes = tree.getroot()
        nodelist = nodes.find('NTP')
        for node in nodelist:
            server_address = node.text
            # print server_address
            if ntp_time(server_address) == 0:
                print 'update time success, current time is %s' % time.strftime('%Y-%m-%d %H:%M:%S')
                logging.info('update time success, current time is %s' % time.strftime('%Y-%m-%d %H:%M:%S'))
                os.system('/sbin/hwclock -w')
                return 0
    except Exception, e:
        print Exception, ":", e
        logger.error('ntp error')
        return -1


def check_time():
    examine_fault = examine_xml(Moduleconfigpath)
    if examine_fault == 0:
        serveraddress_read = mqttserveraddress()
    else:
        serveraddress_read = serveraddressinit
    if ntp_time(serveraddress_read) == 0:
        # print 'update time success, current time is %s' % time.strftime('%Y-%m-%d %H:%M:%S')
        logging.info('update time success, current time is %s' % time.strftime('%Y-%m-%d %H:%M:%S'))
        os.system('/sbin/hwclock -w')
        return 0
    else:
        # print 'no timing servers can be used ...'
        if checkotheraddress() == 0:
            return 0
        else:
            print 'no timing servers can be used ...'
            time.sleep(2)
    return -1


def check_self():
    # name = os.path.split(argv[0])[1]
    cmd = "ps -ef | grep -v grep | grep -w /opt/script/ntpdate.py "
    (status, output) = commands.getstatusoutput(cmd)
    # logger.info("(status, output) = (%s, %s)" % (status, output))
    # print "(status, output) = (%s, %s)" % (status, output)
    count = 0
    for line in str(output).split():
        if '/opt/script/ntpdate.py forever' in line:
            count += 1

    if count > 2:
        logger.info(count)
        return 0
    else:
        return -1


def main():
    init_logger()
    try_time = 0
    delay = 0
    logger.info('\033[36m_ntp start_\033[0m')
    curr_time1 = datetime.datetime.now()
    logger.info('before ntp time is %s' % curr_time1)
    if check_self() == 0:
        logger.error('ntp is exist')
        return 0
    if len(sys.argv) == 1:
        check_time()
    elif len(sys.argv) > 1 and sys.argv[1] == 'forever':
        while True:
            if check_time() == 0:
                break
            else:
                logger.error('no timing servers can be used ...')
                try_time = try_time + 1
                if try_time > 10:
                    delay = delay * 2
                    if delay > 300:
                        delay = 300
                else:
                    delay = 60
            time.sleep(delay)
    curr_time2 = datetime.datetime.now()
    logger.info('after ntp time is %s' % curr_time2)
    total_sec = (curr_time1 - curr_time2).total_seconds()
    if total_sec > 1800:
        logger.info('time is future time, restart system')
        os.system('reboot')
    return 0


if __name__ == '__main__':
    main()
    sys.exit(0)
