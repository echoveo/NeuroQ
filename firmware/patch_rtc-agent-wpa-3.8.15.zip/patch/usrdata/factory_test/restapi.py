#!/usr/bin/python
# -*- coding: UTF-8 -*-
import urllib2
import json
import time
import common
import os
import log
from var_dump import  *

'''
data={
  "dev_sn":"dev_sn_000004",
  "fields":"wifi",
  "dev_IMEI":"IMEI-00000005",
  "dev_type":"linkEdge",
  "test_res":True,
  "err_msg":"successful",
  "test_report":"usbPorts OK"
}
'''
g_test_sessionid=None   #当前测试的唯一sessionid 代表一次完整测试，所有记录有sessionid
g_logger = None

def request(api,data,log=False):
    try:
        init_log()
        cfg = common.config()
        headers = {'Content-Type':'application/json'}
        url = cfg['common']['TEST_SERVER_URL_API']+api #'http://192.168.101.10:10620/api/v1.0/testServer/send_test_report'
        
        if log:
            g_logger.info("request remote api [{}] post_data={}".format(api,data))
        request = urllib2.Request(url=url
                                ,headers=headers
                                ,data=json.dumps(data))
        response = urllib2.urlopen(request, timeout=6)
        
        ret_str = response.read()
        if log:
            g_logger.info("request remote api [{}] response={}".format(api,ret_str))
        #var_dump(ret_str)
        ret = {}
        if ret_str != "":
            ret = json.loads(ret_str)
        else:
            if log:
                g_logger.error("request remote api [{}] fail=return null".format(api))
            raise Exception,"{0} return null".format(api)
        
        if ret.has_key('code') and ret['code'] == 200 :
            if ret.has_key('errcode'):
                if log:
                    g_logger.error("request remote api [{}] fail=return error-1{}".format(api,ret))
                raise Exception,"{0} return error1[{1}]".format(api,ret)
            else:
                return ret["data"]
        else:
                if log:
                    g_logger.error("request remote api [{}] fail=return error-2{}".format(api,ret))
                raise Exception,"{0} return error2[{1}]".format(api,ret)
    except Exception as ept:
            cfg = common.config()
            svr_path = cfg['common']['TEST_SERVER_URL_API']
            log_msg = "[restapi] api[{0}{1}] exception={2}".format(svr_path,api,str(ept))
            g_logger.error(log_msg)
            return None
#服务器对时
def NTP():
    #g_logger.info("request NTP")
    linux_date = request('/testServer/NTP',{"dummy":"none"},log=True)
    #g_logger.info("request NTP ret={}".format(linux_date))
    if linux_date!=None and linux_date != "":
        common.run_cmd('date {0};hwclock -w -f /dev/rtc0'.format(linux_date))
        return True
    else:
        return False
#获取设备详细信息
def acquire_dev_identify():
    #g_logger.info("request acquire_dev_identify")
    post_data = { "dev_sn"  :common.get_devsn(),
                  "dev_IMEI":common.get_devIMEI(),
                  "dev_type":"linkEdge"}
    res = request('/testServer/acquire_dev_identify_id',post_data,log=True)
    #g_logger.info("request acquire_dev_identify_id ret={}".format(res))
    return res

#发送设备测试报告
def send_test_report(data):
    global g_test_sessionid
    if g_test_sessionid == None:
        g_test_sessionid=int(round(time.time()))
    cfg = common.config()
    #g_logger.info("request send_test_report")
    post_data = { "dev_sn"  :common.get_devsn(),
                  "dev_IMEI":common.get_devIMEI(),
                  "dev_type":"linkEdge",
                  "test_res":data['test_res'],
                  "err_msg":str(data['err_msg']),
                  "test_report":str(data['test_report']),
                  "test_sessionid":g_test_sessionid,
                  "test_mode":cfg['test_mode']
                  }
    if data.has_key('test_module'):
        post_data['test_module'] = str(data['test_module'])
    
    if cfg.has_key("comment"):
        post_data['comment'] = str(cfg["comment"])

    res = request('/testServer/send_test_report',post_data,log=True)
    #g_logger.info("request send_test_report ret={}".format(res))
    return res

def init_log():
    global g_logger
    if g_logger == None:
	    g_logger = log.initial_log("restapi.log",common.get_CTX('log_level') )

def main():
    init_log()
   