#!/usr/bin/python
# -*- coding: UTF-8 -*-

#通过ssdp查找测试服务器

import sys
from ssdp_upnp.ssdp import Server, Client

import Queue

'''
find_test_server: 查找测试服务器
'''
def find_test_server(opts=None,logger=None):
    queue = Queue.Queue()
    upnpClient=None
    if opts!=None and opts.has_key('bind_address'):
        upnpClient = Client('http', '1380', queue,opts['bind_address'])
    else:
        upnpClient = Client('http', '1380', queue,None)
    try:        
        upnpClient.start()
        (ip,port,location) = queue.get(timeout=10)
        if logger != None:
            logger.info("[ssdp find_test_server]:{},{}".format(ip,port)) 
        else:
            print "[ssdp find_test_server]:{},{}".format(ip,port)
        return True,{"ip":ip,"port":port,"location":location}
    except Exception as ept:
        if logger != None:
            logger.info( "[ssdp find_test_server] exception={0}".format(str(ept)))
        else:
            print "[ssdp find_test_server] exception={0}".format(str(ept))
        #raise ept
        return False, repr(ept)
    finally:
        try:
            upnpClient.stop()
        except Exception as ept2:
            if logger != None:
                logger.info("[ssdp find_test_server] stop upnpClient.stop() fail")
            else:
                print "[ssdp find_test_server] stop upnpClient.stop() fail"

'''
find_update_server: 查找自动更新服务器
'''
def find_update_server(opts=None,logger=None):
    queue = Queue.Queue()
    upnpClient=None
    if opts!=None and opts.has_key('bind_address'):
        upnpClient = Client('http', 'update', queue,opts['bind_address'])
    else:
        upnpClient = Client('http', 'update', queue,None)
    try:        
        upnpClient.start()
        (ip,port,location) = queue.get(timeout=10)
        if logger != None:
            logger.info("[ssdp find_update_server]:{},{},{}".format(ip,port,location)) 
        else:
            print "[ssdp find_update_server]:{},{}".format(ip,port)
        return True,{"ip":ip,"port":port,"location":"http://"+location}
    except Exception as ept:
        if logger != None:
            logger.info( "[ssdp find_update_server] exception={0}".format(str(ept)))
        else:
            print "[ssdp find_update_server] exception={0}".format(str(ept))
        #raise ept
        return False, repr(ept)
    finally:
        try:
            upnpClient.stop()
        except Exception as ept2:
            if logger != None:
                logger.info("[ssdp find_update_server] stop upnpClient.stop() fail")
            else:
                print "[ssdp find_update_server] stop upnpClient.stop() fail"                