#!/usr/bin/python
# -*- coding: UTF-8 -*-
import os
import sys
import json
import time
import psutil
import commands
import datetime
import subprocess
from var_dump import *
g_conf=None
g_context={'log_level':'DEBUG'}
g_deploy_target="/usrdata"      #测试程序安装目标磁盘节点
g_deploy_path="factory_test"    #测试程序所在目录，U盘和ec20中的目录名相同
g_factory_test_mainPY = "main.py"#程序入口文件
#读取配置文件
def config(cfg='config.json'):
    global g_conf,g_deploy_path,g_deploy_target,g_factory_test_mainPY
    if g_conf != None:
        return g_conf
    load_conf = None
    with open(cfg,'r') as load_f:
        load_conf = json.load(load_f)
        
    g_conf=load_conf
    g_conf["deploy_target"]=g_deploy_target
    g_conf['deploy_path']=g_deploy_path
    g_conf['working_path']="{0}/{1}".format(g_deploy_target,g_deploy_path)
    g_conf['mainPY']="{0}".format(g_factory_test_mainPY)
    g_conf['factory_test_running_path']="{0}/{1}/{2}".format(g_deploy_target,g_deploy_path,g_factory_test_mainPY)
    return g_conf


#执行shell命令，并带超时检查
def execute_command(cmdstring, timeout=None):
    if timeout:
        end_time = datetime.datetime.now() + datetime.timedelta(seconds=timeout)
    timeout_tmp=timeout
    #sub = subprocess.Popen(cmdstring, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,stdin=subprocess.PIPE, bufsize=4096, shell=True)
    sub = subprocess.Popen(cmdstring, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, bufsize=4096, shell=True)
 
    while True:
        if sub.poll() is not None:
            break
        time.sleep(0.1)
        
        if timeout_tmp!=None and timeout_tmp<=0.0:
            #if end_time <= datetime.datetime.now():
            print "cmd=",cmdstring ,'is timeout kill it'
            sub.kill()
            return ""   #TIME_OUT
        timeout_tmp-=0.1
    #print "[execute_command]",cmdstring
    #print "[execute_command]","sub=",sub.stdout
    if sub.stdout == None:
        return ""
    else:
        return str(sub.stdout.read()).strip()




def run_cmd(cmd,wait=True,wait_timeout=10):
    if wait==False:
        os.system(cmd)
    else:
        '''
        (status, output) = commands.getstatusoutput(cmd)
        if output != "":
            return output.strip()
        else:
            return ""
        #return os.popen(cmd, 'r').read().strip()
        '''
        return execute_command(cmdstring=cmd,timeout=wait_timeout)

'''
def killall(app_name):
    process_list = psutil.pids()
    try:
        for pid in process_list:
            process = psutil.Process(pid)
            print process
            if app_name in process.name():
                cmd = 'kill -9 %d' % pid
                os.system(cmd)
                #break
    except Exception, e:
        return False
    return True
'''
def killall(app_name):
    process_list = run_cmd('ps | grep {0} | grep -v grep'.format(app_name))
    if process_list == "" or process_list == None:
        return False
    process_list = process_list.split('\n')
    for P in process_list:
        items = P.split(' ')
        if len(items)>1 and (app_name in P):
            cmd = 'kill -9 {0}'.format(items[0])
            print '[killall]'+cmd
            os.system(cmd)
    return True 
    
def process_exists(app_name):
    process_list = run_cmd('ps | grep {0} | grep -v grep'.format(app_name))
    if process_list == "" or process_list == None:
        return False
    else:
        return True

#读取运行时上下文
def CTX():
    global g_context
    return g_context

def set_CTX(key,value):
    global g_context
    g_context[key]=value
    return g_context

def get_CTX(key):
    global g_context
    return g_context[key]

#获取设备IMEI
g_IMEI = None
def get_devIMEI():
    global g_IMEI
    if g_IMEI != None:
        return g_IMEI
    print "call get_devIMEI 2"
    os.system("chmod +x ./readIMEI")
    ret =  run_cmd("./readIMEI | grep IMEI | awk -F ':' '{print $0}'")
    #return ret
    
    print "first ret=",ret
    for i in range(1,200):  
        try:          
            if 'GSN' in ret:
                ret = run_cmd("./readIMEI | grep IMEI | awk -F ':' '{print $0}'")        
                time.sleep(0.3)
                print "in while",ret   
            elif "IMEI" in ret:
                print "second ret=",ret
                g_IMEI = ret.split(':')[1]
                if len(g_IMEI)>=15:
                    return g_IMEI
            
            ret = run_cmd("./readIMEI | grep IMEI | awk -F ':' '{print $0}'")        
        except Exception as ept:
            time.sleep(0.3)            
    

#获取设备sn
def get_devsn():
    return get_devIMEI()


#生成mac
#根据imei生成mac 
#idx:生成第几个mac 
#return: substr(IMEI,5,10)+idx
def gen_mac(idx=1):
    IMEI = get_devIMEI()
    mac = "%s:%s:%s:%s:%s:%02d" % (IMEI[5:7],IMEI[7:9],IMEI[9:11],IMEI[11:13],IMEI[13:15],idx)
    return mac


#检测网关是否通
#return true:网关通 网络正常
def ping_wifi_gateway(debug="wifi.py"):
    ping_cnt = 2
    gateway_ip = run_cmd("route -n | grep 'UG[ \t]' | awk '{print $2}'")
    if gateway_ip == "":
        return False
    else:
        #测试gateway 
        ping_cmd = "ping -I wlan0 %s -s 4096 -c %d | grep transmitted | awk '{print $4}'" % (gateway_ip,ping_cnt)
        #print debug,"ping gateway:",ping_cmd
        ping_ret = run_cmd(ping_cmd)
        #print ping_cmd,ping_ret
        #print debug,"ping gateway end"
        try:
            if int(ping_ret)>=ping_cnt-1:
                return True
            else:
                return False
        except Exception as ept:
            return False
#通过ping测试指定eth_dev速度
#返回毫秒数
def test_net_speed(eth_dev,IP,count=3):
    #ping_cmd = " ping -I bridge0 192.168.101.10 -s 60000 -c 3 | grep rtt | awk -F '=' '{print $2}' | awk -F '/' '{print $2}'"
    ping_cmd = " ping -I %s %s -s 60000 -c %d | grep rtt | awk -F '=' '{print $2}' | awk -F '/' '{print $2}'" %(eth_dev,IP,count)
    ping_ret = run_cmd(ping_cmd)
    if ping_ret == "":
        return 0.0
    else:
        try:
            ttl = float(ping_ret)
            return ttl
        except Exception as ept:
            return 0.0

def dump(obj):
    '''return a printable representation of an object for debugging'''
    newobj=obj
    if '__dict__' in dir(obj):
        newobj=obj.__dict__
        if ' object at ' in str(obj) and not newobj.has_key('__type__'):
            newobj['__type__']=str(obj)
        for attr in newobj:
            newobj[attr]=dump(newobj[attr])
    return newobj

def dump2(obj):
    var_dump(obj)

#测试初始化中
def led_init():
    killall('led_fac.py')
    print "led_init..."
    os.system('python ./led_fac.py --opts=led1,0,1:led2,0,1:led3,0,1:led4,0,1 &')

#测试通过
def led_pass():
    killall('led_fac.py')
    os.system('python ./led_fac.py --opts=led1,0,1:led2,0,1:led3,0,1:led4,0,0 &')


#发生错误
def led_err():
    killall('led_fac.py')
    os.system('python ./led_fac.py --opts=led1,0,0:led2,0,0:led3,0,0:led4,0,1 &')

#测试进行中
def led_running():
    killall('led_fac.py')
    os.system('python ./led_fac.py --opts=led1,2,1:led2,2,1:led3,2,1:led4,0,0 &')

#更新进行中
def led_update():
    killall('led_fac.py')
    os.system('python ./led_fac.py --opts=led1,5,1:led2,5,1:led3,5,1:led4,5,1 &')

def led_update_success():
    killall('led_fac.py')
    os.system('python ./led_fac.py --opts=led1,5,1:led2,0,1:led3,0,1:led4,0,0 &')

#udhcpc 并返回获取到的ip
def udhcpc(eth_dev="eth0.1"):
    ip=""
    dhcp_svr_ip=""
    ret = run_cmd('(udhcpc -i %s -qn -t 6) 2>/tmp/result.txt;cat /tmp/result.txt | grep lease |  grep -oE "([0-9]{1,3}\.){3}[0-9]{1,3}" | head -n 2'%(eth_dev))
    if ret != "":
        ip =ret.split('\n')[0]
        dhcp_svr_ip =ret.split('\n')[1]
    #ip = run_cmd('(udhcpc -i %s -qn) 2>/tmp/result.txt;cat /tmp/result.txt | grep lease |  grep -oE "([0-9]{1,3}\.){3}[0-9]{1,3}" | head -n 2'%(eth_dev))

    #dhcp_svr_ip = run_cmd('(udhcpc -i %s -qn) 2>/tmp/result.txt;cat /tmp/result.txt | grep lease |  grep -oE "([0-9]{1,3}\.){3}[0-9]{1,3}" | head -n 2'%(eth_dev))
    if ip != "":
        os.system("ifconfig {0} down".format(eth_dev))
        cmd = "ifconfig {0} {1}".format(eth_dev,ip)
        os.system(cmd)
        os.system("ifconfig {0} up".format(eth_dev) )
    return ip,dhcp_svr_ip

#获取指定网卡ip地址
def get_ip_address(eth_dev="eth0.1"):
    ip = run_cmd('ifconfig %s | grep inet |  grep -oE "([0-9]{1,3}\.){3}[0-9]{1,3}" | head -n 1'%(eth_dev))
    if ip == "" or ("error" in ip):
        return ""
    else:
        return ip

#识别网卡是否linkup
def eth_dev_islinkup(eth_dev="wlan0"):
    ret = run_cmd("ifconfig {0} | grep RUNNING".format(eth_dev))
    if ret == None or ret == "" or ("error" in ret):
        return False
    else:
        return True

#是否为自检模式
def is_self_detect_mode():
    if g_conf == None:
        raise Exception,"[common] config not load yet"
    return g_conf['test_mode']=='self_detect'

#是否为工厂功能测试模式
def is_func_detect_mode():
    if g_conf == None:
        raise Exception,"[common] config not load yet"
    return g_conf['test_mode']=='factory'

#是否为烧写号模式
def is_acq_devid_mode():
    if g_conf == None:
        raise Exception,"[common] config not load yet"
    return g_conf['test_mode']=='acquire_dev_identify'

#检查文件是否存在，并且不为空
def is_file_exists(filename):
    return run_cmd("test -s {0} && head -1 {0}".format(filename))!=""

#检查devuaid.d文件是否有效
def is_devuaid_valid(filename="/etc/devuaid.d"):
    id = run_cmd("test -s {0} && head -1 {0}".format(filename))
    if "1612856" == id:
        return False
    elif len(id)>0:
        return True


#设置出厂版本与出厂状态 /etc/factory.mode
def set_factory_mode(mode="test_running",date=None,manufacturer=None):
    file_headers = "# init :                after usb firmware downloaded\n \
# test_running :        factory test in running\n \
# test_fail :           factory test fail\n \
# test_pass :           factory test pass\n "

    fac_mode_filename = "/etc/factory.mode"
    fac_mode_filename_tmp = "/etc/factory.mode.tmp"
    if os.path.exists(fac_mode_filename_tmp):
        os.system("rm -rf {0}".format(fac_mode_filename_tmp))
    with open(fac_mode_filename_tmp, 'w') as f:
        f.write(file_headers)
        f.write("stage={0}\n".format(mode))
        if date != None:
            f.write("date={0}\n".format(date)) 
        if manufacturer != None:
            f.write("manufacturer={0}\n".format(manufacturer)) 

    os.system("cp {0} {1} -rf;sync;sync".format(fac_mode_filename_tmp,fac_mode_filename))


#todo:目前用不上
#U盘脚本文件固定在U盘根目录 factory_test目录下
#测试环境的安装目录，固定在 /usrdata/factory_test 目录下
#测试结果日志目录，固定在/usrdata/factory_test/log目录下
def deploy(src_path="/media/usb1/factory_test"):
    cfg = config()    
    deploy_path = cfg["deploy_path"]
    deploy_target = cfg["deploy_target"]
    target_path = "{0}/{1}".format(deploy_target,deploy_path)
    if target_path.strip() == "":
        raise Exception,"const deploy_path is null"
    if not os.path.exists(src_path):
        raise Exception,"{0} not exist ".format(src_path)

    os.system("rm {0}/* -rf".format(target_path))
    os.system("mkdir -p {0}".format(target_path))
    os.system("cp {0}/factory_test/* {1}".format(src_path,target_path))
    os.system("sync")



#todo:目前用不上
#执行测试程序
def run_factory_test():
    cfg = config()   
    factory_test_running_path = cfg['factory_test_running_path'] 
    working_path = cfg['working_path']
    mainPY = cfg['mainPY']
    if not os.path.exists(factory_test_running_path):
        raise Exception,"{0} not exist ".format(factory_test_running_path)
    
    #检查重入
    cmd = "ps -ef | grep {0} | grep -v 'grep'".format(mainPY)
    app_exist = run_cmd(cmd)
    if app_exist != "":
        os.system("killall {0}".format(mainPY))
    
    os.system("cd {0} && python {1}".format(working_path,mainPY))
    time.sleep(0.5)

'''
if __name__ == '__main__':
    killall("wifi.py")
    sys.exit(0)    
'''