
#!/usr/bin/python
# -*- coding: UTF-8 -*-

import time


class IeSerial(object):
    s_delay = 0.5
    s_retry = 6

    def __init__(self, ser):
        self.__ser = ser
        self.err_msg = ""

    def ie_open(self, port):
        try:
            self.__ser.port = port
            self.__ser.open()
        except BaseException:
            self.err_msg = "Failed to open " + self.__ser.portstr
            return False
        else:
            return True

    def ie_send(self, data):
        self.__ser.write(data)

    def ie_recv(self, data, offset, cnt):

        retry = 0
        res = bytearray()

        while IeSerial.s_retry >= retry:
            rds = self.__ser.inWaiting()
            if 0 == rds:
                retry += 1
                time.sleep(IeSerial.s_delay)
                continue
            else:
                res = self.__ser.read(cnt)
                data[offset:] = res[:]
                break

        return len(res)

    def flush_in_buf(self):
        self.__ser.flushInput()

    def flush_out_buf(self):
        self.__ser.flushOutput()

    def ie_close(self):
        self.__ser.close()
