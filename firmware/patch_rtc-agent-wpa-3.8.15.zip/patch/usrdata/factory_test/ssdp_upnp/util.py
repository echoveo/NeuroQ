
import socket


def get_local_IP(): 
    '''
    get local host and ip address
    '''
    try: 
        host_name = socket.gethostname() 
        host_ip = socket.gethostbyname(host_name) 
        return host_ip
    except Exception as e:
        raise 'Unable to get Hostname and IP: {}'.format(e) 