#!/usr/bin/python
# -*- coding: UTF-8 -*-

import os
import sys
import common
import log
import time
import restapi
import commands

__version__ = "1.0.1"


'''
7.  mmc *
     和u盘类似，对mmc进行写入测试，写完删除
     mmc要求高于10Mbytes   需要写入和读取 写入与读取都要高于10Mbytes

      test -f /mnt/mmc/test.dat&&rm /mnt/mmc/test.dat
      test -f /tmp/result&&rm /tmp/result;(dd of=/mnt/mmc/test.dat if=/dev/zero count=102400 bs=1024 oflag=direct) 2>>/tmp/result;cat /tmp/result| grep seconds|awk -F ',' '{print $3}' |awk -F 'M' '{print $1}'
      test -f /tmp/result&&rm /tmp/result;(dd if=/mnt/mmc/test.dat of=/dev/null count=102400 bs=1024 iflag=direct) 2>>/tmp/result;cat /tmp/result| grep seconds|awk -F ',' '{print $3}' |awk -F 'M' '{print $1}'
      rm /mnt/mmc/test.dat
'''


GPIO_DIR = "/sys/class/gpio"


g_logger = None




def read_gpio(gpio_port):
    v_file = "{0}/{1}/value".format(GPIO_DIR, gpio_port)
    with open(v_file, 'r') as f:
        value = f.read().strip()
        return int(value)


def format_mmc():
    (status, output) = commands.getstatusoutput("blkid /dev/mmcblk0 | grep 'ext1'")
    heart_beat = 0
  
    if output == '':
        g_logger.info("[mmc] mkfs.ext4 /dev/mmcblk0")
        os.system("mkfs.ext4 /dev/mmcblk0")
    os.system("mkdir -p /mnt/mmc")
    os.system("mount /dev/mmcblk0 /mnt/mmc")

def run():
    try:
        g_logger.info("[mmc] begin test mmc") 
        #如果需要，格式化mmc

        #检查mmc是否
        os.system("test -f /mnt/mmc/test.dat&&rm /mnt/mmc/test.dat")
        ret_mmc_write = common.run_cmd("test -f /tmp/result&&rm /tmp/result;(dd of=/mnt/mmc/test.dat if=/dev/zero count=102400 bs=1024 oflag=direct) 2>>/tmp/result;cat /tmp/result| grep seconds|awk -F ',' '{print $3}' |awk -F 'M' '{print $1}'")
        ret_mmc_read = common.run_cmd("test -f /tmp/result&&rm /tmp/result;(dd if=/mnt/mmc/test.dat of=/dev/null count=102400 bs=1024 iflag=direct) 2>>/tmp/result;cat /tmp/result| grep seconds|awk -F ',' '{print $3}' |awk -F 'M' '{print $1}'")
        os.system("rm /mnt/mmc/test.dat")
        
        post_data={"err_msg":'',"test_report":"","test_module":"mmc"}
        errors=0
        if (ret_mmc_write!="" and float(ret_mmc_write)>2.0) and (ret_mmc_read!="" and float(ret_mmc_read)>2.0):
            g_logger.info("mmc test success") 
            post_data['test_res']=True
            post_data['test_report']='mmc test success'
            
            #将/PageFileMMC 软件链接到 /mnt/mmc/PageFile 目录
            #os.system("mkdir -p /mnt/mmc/PageFile")
            #os.system("rm /PageFileMMC -rf;ln -s /mnt/mmc/PageFile /PageFileMMC;sync")

        else:
            post_data['test_res']=False
            post_data['test_report']='mmc test fail'
            g_logger.info("mmc test fail:{0}".format(post_data)) 
            errors+=1

        restapi.send_test_report(post_data)
        if errors<=0:
            return True,""
        else:
            return False,"[mmc]test fail"
    except Exception as ept:
        g_logger.info("[mmc] test fail,exception={0}".format(str(ept))) 
        #raise ept
        return False, repr(ept)


def main():
    global g_logger
    g_logger = log.initial_log("mmc.log",common.get_CTX('log_level') )
    format_mmc()


