#!/usr/bin/python
# -*- coding: UTF-8 -*-
#neobv.com
import os
import sys
import common
import log
import restapi
import time
__version__ = "1.0.0"

GPIO_DIR = "/sys/class/gpio"
g_gpio = ""
g_mode = "pwm"  #pwm输入
g_logger = None

def print_usage():
    print ("""
usage:
    -h, --help
    -v, --version                       return Gpio.py version
    --gpio=gpio
    eg1. python Gpio.py --gpio=gpio75:gpio79
    eg1. python Gpio.py --help
    """)



def read_gpio(gpio_port):
    v_file = "{0}/{1}/value".format(GPIO_DIR, gpio_port)
    with open(v_file, 'r') as f:
        value = f.read().strip()
        return int(value)

def get_gpio_status(gpio_port):
    global g_mode
    try:
        direction = ""
        d_file = "{0}/{1}/direction".format(GPIO_DIR, gpio_port)
        with open(d_file, 'r') as f:
            direction = f.read().strip()

        
        value = 0
        
        if g_mode != 'pwm':
            value = read_gpio(gpio_port)
            return '{}.{}'.format(direction , value)
        else:
            #pwm模式输入
            value01=[0,0]
            for t in range(1,20):
                value = read_gpio(gpio_port)
                value01[value]+=1
                time.sleep(0.3)
            if value01[0]>0 and value01[1]>0:
                return True    #返回正确
            else:
                return False
    except Exception as ept:
        #print ept
        g_logger.error("[{0}]get_gpio_status exception={1}".format(gpio_port),str(ept))
        raise ept
        return False


def run(gpio_port = "gpio23:gpio77"):
    try:
        g_logger.info("[gpio] begin test gpio") 
        gpio_list = str(gpio_port).split(':')
        gpio_dict = {}
        errors=0
        for gpio_port in gpio_list:
            if gpio_port == "":
                continue
            ret_test = get_gpio_status(gpio_port)
            if ret_test == False:
                g_logger.error("gpio[{0}] test fail!".format(gpio_port))
                errors+=1
                gpio_dict[gpio_port]="fail"
            else:
                g_logger.info("gpio[{0}] test pass!".format(gpio_port))
                gpio_dict[gpio_port]="success"
        
        post_data={"err_msg":'gpio test fail',"test_report":gpio_dict,"test_module":"gpio"}
        if errors > 0:
            post_data['test_res'] = False
        else:
            post_data["err_msg"]='gpio test success'
            post_data['test_res'] = True

        restapi.send_test_report(post_data)
        
        if errors<=0:
            return True,""
        else:
            return False,"[gpio]test fail"
    except Exception as ept:
        g_logger.info("[test_gpios] exception={0}".format(str(ept)))
        #raise ept
        return False, repr(ept)


def main():
    global g_logger
    g_logger = log.initial_log("gpio.log",common.get_CTX('log_level') )

