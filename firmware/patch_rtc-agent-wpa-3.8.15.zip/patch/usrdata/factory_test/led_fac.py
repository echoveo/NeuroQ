#!/usr/bin/python
# -*- coding: UTF-8 -*-

import os
import sys
import common
import log
import time
import restapi
import commands
import getopt

__version__ = "1.0.0"


'''
led
    红灯x2   绿灯x2
    状态说明：
+---------------------------+-------------------------+
|   led 灯状态              |      对应功能            | 
+---------------------------+-------------------------+
    NET,ERR,RUN 常亮：             测试初始化中
    两个绿灯常亮，ERR灭：           测试通过
    ERR红灯闪,两个绿灯灭：          测试失败
    两个绿灯2Hz闪，ERR灭：          测试进行中
+---------------------------+-------------------------+


echo 10 > /sys/class/gpio/export        # led-RUNNING               OUT LED
echo 11 > /sys/class/gpio/export        # led-undefined             OUT LED  MobileSignalStrength
echo 24 > /sys/class/gpio/export        # led-network-online 设备在线        OUT LED
echo 25 > /sys/class/gpio/export        # led-error  发生错误         OUT LED
echo 42 > /sys/class/gpio/export        # led-undefined             OUT LED GPIO_MobileMode
'''


GPIO_DIR = "/sys/class/gpio"
g_opts='led1,0,1:led2,0,1:led3,0,1:led4,0,1'

g_logger = None

g_leds = {#time_cnt:每200ms一次记数
    "led1":{"value":1,"hz":0,"time_cnt":0,"gpio_port":"gpio10","alias":"RUN"},
    "led2":{"value":1,"hz":0,"time_cnt":0,"gpio_port":"gpio42","alias":"undefined"},  
    "led3":{"value":1,"hz":0,"time_cnt":0,"gpio_port":"gpio24","alias":"NET"},  
    "led4":{"value":1,"hz":0,"time_cnt":0,"gpio_port":"gpio25","alias":"ERR"}
}

def init_gpio():
    os.system("echo 10 > /sys/class/gpio/export")        # led-RUNNING               OUT LED
    os.system("echo 11 > /sys/class/gpio/export")        # led-undefined             OUT LED  MobileSignalStrength
    os.system("echo 24 > /sys/class/gpio/export")        # led-network-online 设备在线        OUT LED
    os.system("echo 25 > /sys/class/gpio/export")        # led-error  发生错误         OUT LED
    os.system("echo 42 > /sys/class/gpio/export")        # led-undefined             OUT LED GPIO_MobileMode
    os.system("echo out > /sys/class/gpio/gpio10/direction")
    os.system("echo out > /sys/class/gpio/gpio11/direction")
    os.system("echo out > /sys/class/gpio/gpio24/direction")
    os.system("echo out > /sys/class/gpio/gpio25/direction")
    os.system("echo out > /sys/class/gpio/gpio42/direction")

    os.system("echo 1 > /sys/class/gpio/gpio42/value")
    os.system("echo 1 > /sys/class/gpio/gpio42/value")
    os.system("echo 1 > /sys/class/gpio/gpio42/value")
    os.system("echo 1 > /sys/class/gpio/gpio42/value")
    os.system("echo 1 > /sys/class/gpio/gpio42/value")

def read_gpio(gpio_port):    
    v_file = "{0}/{1}/value".format(GPIO_DIR, gpio_port)
    with open(v_file, 'r') as f:
        value = f.read().strip()
        return int(value)

def write_gpio(gpio_port,value):
    v_file = "{0}/{1}/value".format(GPIO_DIR, gpio_port)
    with open(v_file, 'w') as f:
        value = f.write(str(value))

def led_set(led,value,hz):
    if not g_leds.has_key('led'):
        return False
    g_leds[led]["value"]=value
    g_leds[led]["hz"]=hz

def led_init(opts):
    opts_split = opts.split(':')
    for ledopts in opts_split:
        a_opts = ledopts.split(',')
        key = a_opts[0]
        g_leds[key]["hz"]=int(a_opts[1])
        g_leds[key]["value"]=int(a_opts[2])
  

def led_restart():
    const_interval=200.0      #200ms
    while True:
        for key in g_leds:
            gpio = g_leds[key]
            gpio["time_cnt"]+=1
           
            if gpio["hz"]==0:
                write_gpio(gpio['gpio_port'],gpio['value'])
            else:
                if (gpio['time_cnt']*const_interval) >= 1000.0/gpio['hz']:
                    gpio['time_cnt']=0
                    write_gpio(gpio['gpio_port'],gpio['value'])
                    gpio['value'] = 1 if gpio['value']==0 else 0
            #print gpio
        time.sleep(const_interval/1000.0)

def run():
    try:
        led_restart()
    except Exception as ept:
        g_logger.info("[led] test fail,exception={0}".format(str(ept))) 
        raise ept
        return False, repr(ept)


def main():
    global g_logger
    g_logger = log.initial_log("led.log",common.get_CTX('log_level') )


def print_usage():
    print ("""
usage:
    --help. -h
    --opts=led1,{hz},{value}:led2,{hz},{value}
    eg1. python led_fac.py --opts=led1,3,1:led2,0,1 
    """)

def argv_parser(argv):
    global  g_opts
    try:
        opts_list, args = getopt.getopt(argv[1:], 'ho:', ["help",  "opts="])
        for o, a in opts_list:
            if o in ("-h", "--help"):
                print_usage()
                exit(0)
            elif o in ("-o", "--opts"):
                g_opts = str(a).strip()
                led_init(g_opts)
        return True, ""
    except Exception, ept:
        return False, repr(ept)
#led需要在后台运行，所以独立进程执行
if __name__ == '__main__':
    a_res, a_err = argv_parser(sys.argv)
    if not a_res:
        sys.stderr.write(a_err)
        exit(1)
    main()
    run()
    sys.exit(0)