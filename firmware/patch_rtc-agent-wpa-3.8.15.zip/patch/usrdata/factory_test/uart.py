#!/usr/bin/python
# -*- coding: UTF-8 -*-
'''
测试需求
3.serial
   两个串口对接，自行测试，和老化一样的逻辑
   3.1 两个串口中，HS0可232,485切换,  HS1另一个不可切换
   3.2 485功能测试     HS0和HS1对接
        先把HS0，通过gpio26 输入为1，切换到485模式，HS0进入rs485 
   3.3 232功能测试
        把HS0,通过gpio26输入为0，切换到232模式，232   RX<-->TX
'''

import sys
import getopt
import os
import serial
import time
import common
import log
from IeSerial import IeSerial
import threading
import restapi



par = {'O': serial.PARITY_ODD, 'N': serial.PARITY_NONE, 'E': serial.PARITY_EVEN}
stp = {'1': serial.STOPBITS_ONE, '2': serial.STOPBITS_TWO}
bys = {'5': serial.FIVEBITS, '6': serial.SIXBITS, '7': serial.SEVENBITS, '8': serial.EIGHTBITS}



gpio_port = "gpio26"  #
cycle = 2   # 循环次数
interval = 0.1    # sec， 间隔

port = ""
baud = 9600
parity = par['N']
data_bits = bys['8']
stop_bits = stp['1']

is_master=True
is_neobv=False
thread_var_test_rets=[]
thread_var_test_rets_lock = threading.Lock()

g_logger = None

def thread_it(func, *args):
    """将函数打包进线程"""
    t = threading.Thread(target=func, args=args)
    #t.setDaemon(True)
    #t.start()
    return t

def init_gpio():
    os.system('echo 26 > /sys/class/gpio/export 2&>1')                   # 串口485和232模式切换：0-232； 1-485         OUT 
    os.system('echo out > /sys/class/gpio/gpio26/direction')        # 串口485和232模式切换：0-232； 1-485         OUT 

def set_gpio_value(gpio="gpio26", value=1):
    cmd = "cd /sys/class/gpio/{} && echo {} > value".format(gpio, value)
    os.system(cmd)


def crc16(data, cnt):
    crc_16 = 0xffff
    for i in range(0, cnt):
        crc_16 ^= data[i]
        for j in range(0, 8):
            if 1 == (crc_16 & 0x01):
                crc_16 = (crc_16 >> 1) ^ 0xA001
            else:
                crc_16 = crc_16 >> 1
    return crc_16


def pack_ping():
    bys = bytearray()
    bys.append(0x55)
    bys += 'ping'.encode()
   
    bys.append(0xaa) 
    
    return bytes(bys)

def pack_pong():
    bys = bytearray()
    bys.append(0x55)
    bys += 'pong'.encode() 
    bys.append(0xaa) 
    
    return bytes(bys)

def detect_reply(data, cnt):
    index = 0
    size = 6
    if size > cnt:
        return False,None

    if 0x55 != data[0]:
        return False,None
    index += 1
    content = data[1:5]
    content = str(content)
    if 0xaa != data[5]:
        return False,None
    
    if content != 'ping' and content != 'pong':
        return False,None
    
    return True,content

def test_uart(gpio_port, cycle, interval, port, baud,  parity, data_bits, stop_bits, is_master):
    ser = serial.Serial(port=None, baudrate=baud, parity=parity, bytesize=data_bits, stopbits=stop_bits, timeout=2)
    
    set_gpio_value(gpio_port, 1)    #gpio26设置高电平进入485模式
    time.sleep(0.1)
    ie_ser = IeSerial(ser)
    if not ie_ser.ie_open(port):
        return False, ie_ser.err_msg
    req_ping = pack_ping()
    req_pong = pack_pong()
    rty = 0
    rty_ok = 0  # 成功的次数
    rty_fail = 0  # 失败的次数
    #print '{},is_master='.format(port),is_master,'\n'
    if is_master==True:
        time.sleep(0.1)    #waiting for slave in stable
    while rty < cycle:
        rty += 1

        if is_master==True:
            ie_ser.ie_send(req_ping)
            print '{}'.format(port),'send ping\n'


        recv = bytearray(256)
        num = ie_ser.ie_recv(recv, 0, 256)
        print "recv=",recv,num
        a_ret, a_content = detect_reply(recv, num)
        if a_ret == True :
            print '{}'.format(port),'recv:',recv,'\n'
            if a_content == 'pong' and is_master==True:
                rty_ok += 1
            elif a_content == 'ping' and is_master==False:  
                ie_ser.ie_send(req_pong)
                print '{}'.format(port),'response pong\n'
                rty_ok += 1  
        else:
            rty_fail += 1

        time.sleep(interval)

    ie_ser.ie_close()

    if rty_ok >= rty_fail:
        return True, "successful"
    else:
        return False, "fail(T:{0}, F:{1})".format(str(rty_ok), str(rty_fail))

#rs232串口测试
g_ser_232=None
def test_uart232(gpio_port, cycle, interval, port, baud,  parity, data_bits, stop_bits, is_master):
    global g_ser_232
    #if g_ser_232 == None:
    ser_232= serial.Serial(port=None, baudrate=baud, parity=parity, bytesize=data_bits, stopbits=stop_bits, timeout=2)
    
    ie_ser = IeSerial(ser_232)
    if not ie_ser.ie_open(port):
        print "open rs232 fail"
        return False, ie_ser.err_msg
    req_ping = pack_ping()
    rty = 0
    rty_ok = 0  # 成功的次数
    rty_fail = 0  # 失败的次数
    print '{},rs232mode'.format(port),'\n'
    set_gpio_value(gpio_port, 0)    #gpio26设置低电平
    if is_master==True:
        time.sleep(0.1)    #waiting for slave in stable
    while rty < cycle:
        rty += 1       
        if is_master==True:
            ie_ser.ie_send(req_ping)
            print '{}'.format(port),'send ping\n'
            rty_ok += 1

        recv = bytearray(256)
        num = ie_ser.ie_recv(recv, 0, 256)
        a_ret, a_content = detect_reply(recv, num)
        if a_ret == True :
            print '{}'.format(port),'recv:',recv,'\n'
            if a_content == 'ping' and is_master==False:  
                rty_ok += 1  
        else:
            if is_master==False:
                rty_fail += 1

        time.sleep(interval)

    ie_ser.ie_close()

    if rty_ok >= rty_fail:
        return True, "successful"
    else:
        return False, "fail(T:{0}, F:{1})".format(str(rty_ok), str(rty_fail))


#master  主动发送ping 接收slaver的pong #slaver  被动接收pong回ping
#485测试函数
def test(args=None):
    global  gpio_port, cycle, interval, port, baud, \
    parity, data_bits, stop_bits, is_master, thread_var_test_rets, thread_var_test_rets_lock
    test_port=port
    test_is_master=is_master
    test_is_threading=False
    if args != None:
        test_port=args[0]
        test_is_master=args[1]
        test_is_threading=True
    rets = test_uart(gpio_port, cycle, interval, test_port, baud,  parity, data_bits, stop_bits, is_master=test_is_master)
    if test_is_threading:
        thread_var_test_rets_lock.acquire()
        try:
            thread_var_test_rets.append({test_port:rets})
        finally:
            thread_var_test_rets_lock.release()
    else:
        return rets

#232线程函数
def test_rs232(args=None):
    global  gpio_port, cycle, interval, port, baud, \
    parity, data_bits, stop_bits, is_master, thread_var_test_rets, thread_var_test_rets_lock
    test_port=port
    test_is_master=is_master
    test_is_threading=False
    if args != None:
        test_port=args[0]
        test_is_master=args[1]
        test_is_threading=True
    rets = test_uart232(gpio_port, cycle, interval, test_port, baud,  parity, data_bits, stop_bits, is_master=test_is_master)
    if test_is_threading:
        thread_var_test_rets_lock.acquire()
        try:
            thread_var_test_rets.append({'rs232':rets})
        finally:
            thread_var_test_rets_lock.release()
    else:
        return rets

#根据ec20的需求进行测试，需要要启动线程
def run():
    #启动ttyHS0 master,ttyHS1 slaver
    #print "ec20_test"
    try:
	
        g_logger.info("[uart] begin test rs485") 
        global thread_var_test_rets
        thread_array=[]
        thread_array.append(thread_it(test,['/dev/ttyHS0',True])) 
        thread_array.append(thread_it(test,['/dev/ttyHS1',False])) 
        for h in thread_array:
            h.start()
        for h in thread_array:    
            h.join()
       
        g_logger.info("[uart] begin test rs232") 
        #启动rs232测试
        thread_array=[]
        thread_array.append(thread_it(test_rs232,['/dev/ttyHS0',True])) 
        thread_array.append(thread_it(test_rs232,['/dev/ttyHS0',False])) 
        for h in thread_array:
            h.start()
        for h in thread_array:    
            h.join()
        #print "thread ret:",thread_var_test_rets
        errors=0
        post_data={"err_msg":'',"test_report":"uart port test success","test_res":True,"test_module":"uart"}
        for item in thread_var_test_rets:
            if item.values()[0][0] != True:
                g_logger.info("[uart] test fail:{0}".format(thread_var_test_rets))
                post_data['test_res']=False
                post_data['test_report']='uart port test fail'
                errors += 1
                break
        
        if errors>0:
            g_logger.info("[uart] test fail:{0}".format(thread_var_test_rets))
        else:
            g_logger.info("[uart] test success:{0}".format(thread_var_test_rets))
        restapi.send_test_report(post_data)

        if errors<=0:
            return True,""
        else:
            return False,"[mmc]test fail"
    except Exception as ept:
        g_logger.info("[uart] exception={0}".format(str(ept)))
        #raise ept
        return False, repr(ept)
    #return True,thread_var_test_rets
    

def main():
    global g_logger
    g_logger = log.initial_log("uart.log",common.get_CTX('log_level') )