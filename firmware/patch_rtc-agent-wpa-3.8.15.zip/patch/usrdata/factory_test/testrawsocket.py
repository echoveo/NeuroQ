#!/usr/bin/python
# -*- coding: UTF-8 -*-
import os
import sys
import time
import getopt
import commands
import re
import restapi
import traceback

from rawsocketpy import RawSocket

def server():
    recv_max_len = 1024*1024*100
    #print "server start."
    sock = RawSocket('eth0.1', 0xEEFA, no_recv_protocol=False,recv_timeout=6)
    recv_len=0
    dt_begin = time.time()
    for i in range(1024*1024):         
        recv_data = sock.recv()
        len_tmp = len(recv_data.data.decode('utf-8'))
        #print "recv:len=",len_tmp
        recv_len += len_tmp
        if (recv_len > recv_max_len):
            print "recv_len>{}".format(recv_max_len)
            break
        if  time.time()-dt_begin>10.0:
            #max wait 10s
            break
    dt_end = time.time()
    print "server stop."
    print "times=",dt_end-dt_begin
    print "speed={}".format(recv_len/(dt_end-dt_begin))

def client():
    ascii="1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
    buffer_1k=""
    for i in range(0,512):
        buffer_1k += ascii
        if len(buffer_1k)>=4096:
            break;
    buffer_1k = buffer_1k[0:1048]
    print "client start."
    sock = RawSocket('eth0.2', 0xEEFA,sock=None, no_recv_protocol=False,recv_timeout=None)
    for i in range(1024*60):
        for j in range(1024):
            sock.send(buffer_1k)        
        #print('Boo has been sent')
        time.sleep(0.001)
    print "client stop."




def argv_parser(argv):
    try:
        opts_list, args = getopt.getopt(argv[1:], 'hsc', ["help", "server","client"])
        for o, a in opts_list:
            if o in ("-h", "--help"):
                
                exit(0)
            elif o in ("-s", "--server"):
                print "server mode..."
                server()
                exit(0)
            elif o in ("-c", "--client"):
                print "client mode..."
                client()
           
        

        return True, ""
    except Exception, ept:
        return False, repr(ept)

############################## main block ##############################

if __name__ == '__main__':
    a_res, a_err = argv_parser(sys.argv)
   
    print "exit."
    sys.exit(0)