#!/usr/bin/python
# -*- coding: UTF-8 -*-
import urllib2
import json
import common
import os
import log
import restapi
import traceback

g_logger = None

def acquire_dev_identify():
    for i in range(1,6):
        (ret,msg) = _acquire_dev_identify()
        if ret == True:
            return ret,msg
        else:
            g_logger.error("[acquire_dev_identify] fails try it again,try_times={0}".format(i))
    return False,"[acquire_dev_identify] fail"

#获取设备 devuaid,mac等信息
def _acquire_dev_identify():
    g_logger.info('begin acquire_dev_identify')    
    try:
        res = restapi.acquire_dev_identify()
        if res["dev_devuaid_file"] == "":
            raise Exception,"response dev_devuaid_file is empty"
        if res["dev_eth_mac1"] == "":
            raise Exception,"response eth mac is empty"
        if res["dev_wifi_mac1"] == "":
            raise Exception,"response dev_wifi_mac1 is empty"
        if res["dev_wifi_mac2"] == "":
            raise Exception,"response dev_wifi_mac2 is empty"
        g_logger.info('acquire_dev_identify successful,response={}'.format(res))
        #write devuaid
        with open('/etc/devuaid.d', 'w') as fd:
            fd.write(res["dev_devuaid_file"])
            
        #write wifi mac
        wifi_mac_bin_filepath="/lib/firmware/wlan/qca_cld/wlan_mac.bin"
        mac1 = res["dev_wifi_mac1"].replace(":","").upper()
        mac2 = res["dev_wifi_mac2"].replace(":","").upper()
        os.system("mkdir -p /lib/firmware/wlan/qca_cld")
        os.system("rm {} -rf".format(wifi_mac_bin_filepath))
        with open(wifi_mac_bin_filepath,'w') as fd:
            fd.write("Intf0MacAddress=%s\n" % (mac1))
            fd.write("Intf1MacAddress=%s\n" % (mac2))
            fd.write("END\n")   

        #write eth mac
        with open("/etc/mac",'w') as fd:
            dev_eth_mac1 = "{0}:{1}:{2}:{3}:{4}:{5}".format(res["dev_eth_mac1"][0:2],
                                                            res["dev_eth_mac1"][2:4],
                                                            res["dev_eth_mac1"][4:6],
                                                            res["dev_eth_mac1"][6:8],
                                                            res["dev_eth_mac1"][8:10],
                                                            res["dev_eth_mac1"][10:12])
            fd.write(dev_eth_mac1)
        
        return True,""
        
    except Exception as e:       
        #common.dump2(e)
        g_logger.error('[acquire_dev_identify] fail, exception: ' + str(e)+";trace="+traceback.format_exc())
        return False,"[[acquire_dev_identify]] test fail"
   

def get_devuaid():
    if os.path.exists('/etc/devuaid.id'):
        with open('/etc/devuaid.id',r) as fd:
            lines = fd.readlines()
            if len(lines)>1:
                return lines[0]
    return None

def main():
    global g_logger
    g_logger = log.initial_log("identify.log",common.get_CTX('log_level') )