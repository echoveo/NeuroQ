#!/usr/bin/python
# -*- coding: UTF-8 -*-

#通过ssdp查找测试服务器

from ssdpy import SSDPClient
def find_test_server(opts=None,logger=None):
    try:
        client = SSDPClient()
        devices = client.m_search("ssdp:all")
        for device in devices:
            print "found ssdp:",device
			#logger.info("[ssdp]found usn:{}".format(device.get("usn")))
        return devices
    except Exception as ept:
        logger.info("[find_test_server] exception={0}".format(str(ept)))
        #raise ept
        return False, repr(ept)