#!/usr/bin/python
# -*- coding: UTF-8 -*-

import os
import xml.etree.ElementTree as ET


class AnyLinkXml(object):
    """
    AnyLink.xml file manager
    """

    __TAG_ANYLINK = "AnyLink"
    __TAG_NETWORKINFO = "NetworkInfo"
    __TAG_WIFI = "Wifi"
    __TAG_WIFI_STAT = "W_Modestatus"
    __TAG_MODE = "Mode"
    __ATTR_MUTI = "muti"

    def __init__(self, path):
        self.__path = path
        self.__tree = ET.parse(self.__path)
        self.__root = self.__tree.getroot()

    def get_net_multi(self):
        multi = ""
        net_ele = self.__root.find(self.__TAG_NETWORKINFO)
        if (net_ele is not None) and net_ele.attrib.has_key(self.__ATTR_MUTI):
            multi = net_ele.attrib[self.__ATTR_MUTI]

        return multi

    def get_net_mode(self):
        mode = ""
        net_ele = self.__root.find(self.__TAG_NETWORKINFO)
        if net_ele is not None:
            mode = net_ele.findtext(self.__TAG_MODE)
            if mode is None:
                return ""

        return mode

    def get_wifi_stat(self):
        stat = ""
        net_ele = self.__root.find(self.__TAG_WIFI)
        if net_ele is not None:
            stat = net_ele.findtext(self.__TAG_WIFI_STAT)
            if stat is None:
                return ""

        return stat

    def xml_write(self):
        """
        Write new content into xml file
        """
        self.__tree.write(self.__path, encoding="utf-8", xml_declaration="true")


class CommonXml(object):

    __TAG_DATA = "Data"
    __TAG_HARDWARE = "HardwareModel"
    __TAG_SOFT = "SoftVersion"

    def __init__(self, path):
        self.__path = path
        self.__tree = ET.parse(self.__path)
        self.__root = self.__tree.getroot()

    def get_anylink_ver(self):
        ver = self.__root.findtext(self.__TAG_HARDWARE)
        if ver is None:
            return ""
        return ver

    def get_web_ver(self):
        ver = self.__root.findtext(self.__TAG_SOFT)
        if ver is None:
            return ""
        # return ver.split("-")[-1]
        return ver

    def xml_write(self):
        """
        Write new content into xml file
        """
        self.__tree.write(self.__path, encoding="utf-8", xml_declaration="true")


