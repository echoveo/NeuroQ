#!/bin/sh
sync
python main.py
