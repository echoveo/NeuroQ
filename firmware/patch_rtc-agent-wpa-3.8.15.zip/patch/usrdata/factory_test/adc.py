#!/usr/bin/python
# -*- coding: UTF-8 -*-

import os
import sys
import getopt
import time
import math
import common
import log
import restapi

__VERSION = "0.0.8"
__APP_NAME = 'adc'
g_devpath = "/sys/devices/qpnp-vadc-8/mpp4_vadc"
g_opts = "50000"
g_logger = None

def print_usage():
    print ("""
usage:
    --help. -h
    --devpath=/sys/devices/qpnp-vadc-8/mpp4_vadc 
    --opts=other_params | -o other_params
    eg1. python Adc.py --devpath=/sys/devices/qpnp-vadc-8/mpp4_vadc 
    """)


def argv_parser(argv):
    global g_ethernet, g_opts
    try:
        opts_list, args = getopt.getopt(argv[1:], 'hd:o:', ["help", "devpath=", "opts="])
        for o, a in opts_list:
            if o in ("-h", "--help"):
                print_usage()
                exit(0)
            elif o in ("-d", "--devpath"):
                g_devpath = str(a).strip()
            elif o in ("-o", "--opts"):
                g_opts = str(a).strip()
        return True, ""
    except Exception, ept:
        return False, repr(ept)



def readADCVal():
    global g_devpath
    cmd = "cat {0}".format(g_devpath)
    res = common.run_cmd(cmd)
    if res == "":
        return False, "{} is not exist !\n".format(g_devpath)
    ret_array = res.split(" ",1)
    res = ret_array[0].split(":",1)[1]
    if res!=None and res.isdigit():
        return True,math.ceil(int(res)/1000)   
    else:
        return False, "ADC val invalid {0} !\n".format(res)


#1.1 adc1 测试电池电压 gpio-2设置为1 进入电池电压采样模式，返回 2800 < val <2900算正确
def testADC_battery():
    global g_devpath, g_opts
    os.system('echo 2 > /sys/class/gpio/export 2&>1')
    os.system('echo out > /sys/class/gpio/gpio2/direction')
    os.system('echo 1 > /sys/class/gpio/gpio2/value')
    time.sleep(0.2)
    array_opts = g_opts.split(',') # g_opts=battery,2800,2900 
    ret,adc_val = readADCVal()
    print "{0}(battery)=".format(g_devpath),ret,adc_val
    if ret :
        if adc_val >= int(array_opts[1]) and adc_val <= array_opts[2] :
                return True,'successful'
        else:
            return False,'adc_val is {},not int range[{},{}]'.format(adc_val,array_opts[1],array_opts[2])
    else:
        return False,'read adc_val fail! '

# adc校准也测试
def adc_calibration():
    global g_devpath, g_opts
    os.system('echo 2 > /sys/class/gpio/export 2&>1')
    os.system('echo out > /sys/class/gpio/gpio2/direction')
    os.system('echo 0 > /sys/class/gpio/gpio2/value')
    adc_limit=2
    array_opts = g_opts.split(',') # g_opts=1,2,3,4,5,6 代表3个测试范围
    
    #是否为电池测试模式
    if array_opts[0]=='battery':
        return testADC_battery()

    adc_range0=[int(array_opts[0]),int(array_opts[1])]
    adc_range1=[int(array_opts[2]),int(array_opts[3])]
    adc_range2=[int(array_opts[4]),int(array_opts[5])]
    adc_result={'range0':[0,0],'range1':[0,0],'range2':[0,0]}       #adc曲线拐点值
    for i in range(1,30):
        time.sleep(0.2)    #waiting for ADC in stable
        ret,adc_val = readADCVal()
        print "{0}=".format(g_devpath),ret,adc_val
        if ret :
            if adc_val >= adc_range0[0] and adc_val <= adc_range0[1] :
                 adc_result['range0'][0]+=1
                 adc_result['range0'][1]+=adc_val
            if adc_val >= adc_range1[0] and adc_val <= adc_range1[1] :
                 adc_result['range1'][0]+=1
                 adc_result['range1'][1]+=adc_val
            if adc_val >= adc_range2[0] and adc_val <= adc_range2[1] :
                 adc_result['range2'][0]+=1
                 adc_result['range2'][1]+=adc_val   
    print "{0} result=".format(g_devpath),adc_result
    for ra in adc_result.keys():
        if adc_result[ra][0] >= adc_limit:
            adc_result[ra][1] = math.ceil(adc_result[ra][1]/adc_result[ra][0])  #求平均
        else:
            return False,'ADC {} invalid'.format(ra)
    #写入ADC校准结果
    adc_range_filename='adc0_range'
    if 'mpp4_vadc' in g_devpath:
        adc_range_filename='adc0_range'
    elif 'mpp6_vadc' in g_devpath:
        adc_range_filename='adc1_range'
    cmd = "echo '{},{},{}'>/etc/{}".format(adc_result['range0'][1],adc_result['range1'][1],adc_result['range2'][1],adc_range_filename)
    os.system(cmd)

    return True,[adc_result['range0'][1],adc_result['range1'][1],adc_result['range2'][1]]

#nouse
def check_ADC():
    global g_devpath, g_opts
    try:
        cmd = "cat {0}".format(g_devpath)
        res = common.run_cmd(cmd)
        if res == "":
            return False, "{} is not exist !\n".format(g_devpath)
        ret_array = res.split(" ",1)
        res = ret_array[0].split(":",1)[1]
        if int(res) > int(g_opts):
            return True, res
        else:
            return False, "ADC val {0} < {1} !\n".format(res,g_opts)
        return True, res
       
    except Exception, ept:
        return False, repr(ept)

def run(opts="35,68,82,118,3100,3900"):
    global g_devpath,g_opts
    try:
        g_logger.info("[adc]begin test adc")
        g_opts=opts
        errors = 0
        test_result={}
        test_result['adc0']=None
        test_result['adc1']=None
        test_result['battery']=None
        g_devpath = "/sys/devices/qpnp-vadc-8/mpp4_vadc"
        (ret,msg) = adc_calibration()
        if ret == False:
            errors+=1        
            g_logger.error("[adc]{0} test fail".format(g_devpath))
        test_result['adc0']=msg
        g_devpath = "/sys/devices/qpnp-vadc-8/mpp6_vadc"
        (ret,msg) = adc_calibration()
        if ret == False:
            errors+=1
            g_logger.error("[adc]{0} test fail".format(g_devpath))
        test_result['adc1']=msg
        '''        
        g_opts="battery,2800,2900"
        g_devpath = "/sys/devices/qpnp-vadc-8/mpp6_vadc"
        (ret,msg) = adc_calibration()
        if ret == False:
            errors+=1
            g_logger.error("[adc-battery]{0} test fail".format(g_devpath))
        test_result['battery']=msg
        '''
        post_data={"err_msg":'',"test_report":"","test_module":"adc"}
        if errors>0:
            post_data['test_res']=False
            g_logger.error("[adc]test fail")
        else:
            post_data['test_res']=True
        
        post_data['test_report'] = str(test_result)

        restapi.send_test_report(post_data)
        
        if errors<=0:
            return True,""
        else:
            return False,"[adc]test fail"
    except Exception as ept:
        g_logger.info("[{0}] test fail,exception={1}".format(__APP_NAME,str(ept))) 
        raise ept
        return False, repr(ept)
def main():
    global g_logger
    g_logger = log.initial_log("adc.log",common.get_CTX('log_level') )


