#!/usr/bin/python
# -*- coding: UTF-8 -*-
import common
import log 
import getopt
import traceback
import sys
import time
import os
import wifi
import restapi
import identify
import gpio
import usb
import uart
import adc
import mmc
import ethernet
import ver

import ssdp_find_server2
import temperature
APPNAME="factoryTest"
APP_VERSION="1.0.2"
g_logger = None
cfg_file="config.json"
g_module = None #单独测试某个模块





def print_usage():
    print ("""
usage:
    --help. -h
    --debug=DEBUG | INFO | ERROR | WARNING 
    eg1. python main.py --debug=INFO  --cfg=config_self_detect.json
    """)



def argv_parser(argv):
    global cfg_file,g_module
    try:
        opts_list, args = getopt.getopt(argv[1:], 'hd:c:sm:', ["help", "debug=","cfg=", "ssdp","module="])
        for o, a in opts_list:
            if o in ("-h", "--help"):
                print_usage()
                exit(0)
            elif o in ("-m", "--module"):
                g_module = str(a).strip()

            elif o in ("-s", "--ssdp"):
                print "test ssdp begin..."
                (ssdp_ret,ssdp_info) = ssdp_find_server2.find_test_server(opts=None,logger=None)
                time.sleep(1)
                (ssdp_ret,ssdp_info) = ssdp_find_server2.find_test_server(opts=None,logger=None)
                print "test ssdp end"
                exit(0)
            elif o in ("-d", "--debug"):
                common.set_CTX('log_level',str(a).strip())
            elif o in ("-c", "--cfg"):
                cfg_file = str(a).strip()
        

        return True, ""
    except Exception, ept:
        return False, repr(ept)

def stop_anylink():
    common.killall("watchdogd.py")
    common.killall("watchdog.py")
    common.killall('dnsmasq')
    common.killall("SetLEDStatus.py")
    common.killall("pppd_control.sh")
    common.killall('Reset.py')
    common.killall('gpio21_ssh.py')
    common.killall('AutoAPMode.py')
    common.killall('health_dialogue.py')
    common.killall('wpa_module.py')
    common.killall('agentd')
    common.killall('agentbasic')

def log_timestamp():
    g_logger.info("time={0}".format(time.time()))


'''
检查ssdp后，如果网络中存在http_update://ip:port/download/xxxxx.zip 这样的ssdp服务，执行更新
'''
def do_update(opts,logger):
    download_path="/mnt/mmc/tmp/update"
    logger.info("[do_update] start ...")
    logger.info("[do_update] opts={0}".format(opts))
    try:
        os.system("mkdir -p {0}".format(download_path))
        os.system("rm -f {0}/*".format(download_path))
        wget_cmd = "wget -P {0} {1}".format(download_path,opts['location'])
        os.system(wget_cmd)
        download_files = os.listdir(download_path)
        if len(download_files) >= 1:
            download_file = "{0}/{1}".format(download_path,download_files[0])
            logger.info("[do_update] download file ={0}".format(download_files))
            logger.info("[do_update] begin update...")
            logger.info("[do_update] do unzip...")
            common.led_update()
            os.system("cd {0} && unzip -o {1}".format(download_path,download_files[0]))
            os.system("cd {0} && chmod -R 777 {0}/*".format(download_path))
            os.system("chmod +x {0}/update.sh".format(download_path))
            os.system("cd {0} && sh ./update.sh".format(download_path))
            logger.info("[do_update] update finished")
            common.led_update_success()
            sys.exit(0)
        else:
            logger.info("[do_update] download update files fail!")
    except Exception as ept:
        exstr = traceback.format_exc()
        log_msg = "[do_update] exception={0},stack={1}".format(str(ept),exstr)
        logger.error(log_msg)
        common.led_err()
    logger.info("[do_update] end")
def ssdp_discover(logger):

    ssdp_ret=False
    ssdp_info=None
    ssdp_ret_update=False   #自动更新
    ssdp_info_update=None   #自动更新
    #is_network_valid = False
    #网络检测，当前 网络条件下是否可以获取到ssdp结果
    logger.info('[ssdp_discover] find ssdp in global mode 0')
    wifi_ip_address = common.get_ip_address(eth_dev="wlan0")
    eth01_ip_address = common.get_ip_address(eth_dev="eth0.1")
    eth02_ip_address = common.get_ip_address(eth_dev="eth0.2")
    if eth02_ip_address != "":
        (ssdp_ret,ssdp_info) = ssdp_find_server2.find_test_server(opts={"bind_address":eth02_ip_address},logger=logger)
        if ssdp_ret:
            (ssdp_ret_update,ssdp_info_update) = ssdp_find_server2.find_update_server(opts={"bind_address":eth02_ip_address},logger=logger)
        
    if eth01_ip_address != "":
        (ssdp_ret,ssdp_info) = ssdp_find_server2.find_test_server(opts={"bind_address":eth01_ip_address},logger=logger)
        if ssdp_ret:
            (ssdp_ret_update,ssdp_info_update) = ssdp_find_server2.find_update_server(opts={"bind_address":eth01_ip_address},logger=logger)
    
    if wifi_ip_address != "":
        (ssdp_ret,ssdp_info) = ssdp_find_server2.find_test_server(opts={"bind_address":wifi_ip_address},logger=logger)
        if ssdp_ret:
            (ssdp_ret_update,ssdp_info_update) = ssdp_find_server2.find_update_server(opts={"bind_address":wifi_ip_address},logger=logger)
    

    if ssdp_ret == False:
        wifi_ip_address = common.get_ip_address(eth_dev="wlan0")
        if common.eth_dev_islinkup(eth_dev="wlan0") and wifi_ip_address != "":
            logger.info('[ssdp_discover] find ssdp in wifi mode 1')
            (ssdp_ret,ssdp_info) = ssdp_find_server2.find_test_server(opts={"bind_address":wifi_ip_address},logger=logger)
            if ssdp_ret:
                (ssdp_ret_update,ssdp_info_update) = ssdp_find_server2.find_update_server(opts={"bind_address":wifi_ip_address},logger=logger)
        else:
            logger.info('[ssdp_discover] start wifi wifi.py')
            common.killall("wifi.py")
            common.run_cmd(cmd="python ./wifi.py 2&>1 &",wait=False)  

    if ssdp_ret == False:
        #无线没有连接 检查有线的连接是否正常
        if common.eth_dev_islinkup(eth_dev="eth0") :
            bridge0_ip_address = common.get_ip_address(eth_dev="bridge0")
            if common.run_cmd("brctl show | grep eth0") != "" and bridge0_ip_address != "":
                #网络处于bridge0(eth0)模式
                #is_network_valid = True
                logger.info('[ssdp_discover] find ssdp in ethernet bridge mode')
                (ssdp_ret,ssdp_info) = ssdp_find_server2.find_test_server(opts={"bind_address":bridge0_ip_address},logger=logger)
                if ssdp_ret:
                    (ssdp_ret_update,ssdp_info_update) = ssdp_find_server2.find_update_server(opts={"bind_address":bridge0_ip_address},logger=logger)
           
            if ssdp_ret == False:
                #获取不到ssdp结果，切换以太网进入vlan+dhcpc模式 并重新获取ssdp
                logger.info('[ssdp_discover] find ssdp in ethernet vlan mode')
                ethernet.main()
                ethernet.init_vlan()
                ethernet.eth_auto_dhcp()
                time.sleep(3)   #等待3秒，好让dhcpc获取ip地址，然后重新扫描测试服务器
                
                wifi_ip_address = common.get_ip_address(eth_dev="wlan0")
                eth01_ip_address = common.get_ip_address(eth_dev="eth0.1")
                eth02_ip_address = common.get_ip_address(eth_dev="eth0.2")
                if eth02_ip_address != "":
                    (ssdp_ret,ssdp_info) = ssdp_find_server2.find_test_server(opts={"bind_address":eth02_ip_address},logger=logger)
                    if ssdp_ret:
                        (ssdp_ret_update,ssdp_info_update) = ssdp_find_server2.find_update_server(opts={"bind_address":eth02_ip_address},logger=logger)
                
                if eth01_ip_address != "":
                    (ssdp_ret,ssdp_info) = ssdp_find_server2.find_test_server(opts={"bind_address":eth01_ip_address},logger=logger)
                    if ssdp_ret:
                        (ssdp_ret_update,ssdp_info_update) = ssdp_find_server2.find_update_server(opts={"bind_address":eth01_ip_address},logger=logger)
                
                if wifi_ip_address != "":
                    (ssdp_ret,ssdp_info) = ssdp_find_server2.find_test_server(opts={"bind_address":wifi_ip_address},logger=logger)
                    if ssdp_ret:
                        (ssdp_ret_update,ssdp_info_update) = ssdp_find_server2.find_update_server(opts={"bind_address":wifi_ip_address},logger=logger)
                
    
    if ssdp_ret == False:
        #如果当前网络还是无法获取ssdp,重新通过配置文件强制连接配置里的wifiap进行偿试
        logger.info('[ssdp_discover] find ssdp in wifi mode 2')
        #common.killall("wifi.py")
        #common.run_cmd(cmd="python ./wifi.py 2&>1 &",wait=False)  
        for _i in xrange(30):
            time.sleep(1)
            wifi_ip_address = common.get_ip_address(eth_dev="wlan0")
            eth01_ip_address = common.get_ip_address(eth_dev="eth0.1")
            eth02_ip_address = common.get_ip_address(eth_dev="eth0.2")
            if eth02_ip_address != "":
                (ssdp_ret,ssdp_info) = ssdp_find_server2.find_test_server(opts={"bind_address":eth02_ip_address},logger=logger)
                if ssdp_ret:
                    (ssdp_ret_update,ssdp_info_update) = ssdp_find_server2.find_update_server(opts={"bind_address":eth02_ip_address},logger=logger)
            
            if eth01_ip_address != "":
                (ssdp_ret,ssdp_info) = ssdp_find_server2.find_test_server(opts={"bind_address":eth01_ip_address},logger=logger)
                if ssdp_ret:
                    (ssdp_ret_update,ssdp_info_update) = ssdp_find_server2.find_update_server(opts={"bind_address":eth01_ip_address},logger=logger)
            
            if wifi_ip_address != "":
                (ssdp_ret,ssdp_info) = ssdp_find_server2.find_test_server(opts={"bind_address":wifi_ip_address},logger=logger)
                if ssdp_ret:
                    (ssdp_ret_update,ssdp_info_update) = ssdp_find_server2.find_update_server(opts={"bind_address":wifi_ip_address},logger=logger)

            if ssdp_ret == True:
                break
            '''
            if common.ping_wifi_gateway() == True:
                wifi_ip_address = common.get_ip_address(eth_dev="wlan0")
                if wifi_ip_address != "":
                    (ssdp_ret,ssdp_info) = ssdp_find_server2.find_test_server(opts={"bind_address":wifi_ip_address},logger=logger)
                break
            '''
    #检查最终获取结果
    if ssdp_ret_update:
        do_update(opts=ssdp_info_update,logger=logger)

    if ssdp_ret:
        cfg = common.config()
        cfg['common']['TEST_SERVER_URL_API']="http://{0}:{1}/api/v1.0".format(ssdp_info["ip"],ssdp_info['port'])
        logger.info("ssdp get server={}".format(cfg['common']['TEST_SERVER_URL_API']))
        
        return True
    else:
        logger.info('[ssdp_discover] find ssdp fail')
        return False
    
#命令行模式，单独测试某个模块
def test_module(module):
    global g_logger
    g_logger.info("[main]test module={}. begin<<<<<<<<".format(module))
    
    if module == "gpio":
        gpio.main()
        gpio.run(gpio_port = "gpio23:gpio77")
    elif module == "adc":
        adc.main()
        adc.run()
    elif module == "uart":
        uart.main()
        uart.run()
    elif module == "usb":
        usb.main()
        usb.run()
    elif module == "mmc":
        mmc.main()
        mmc.run()
    elif module == "ethernet":
        ethernet.main()
        ethernet.run()
    elif module == "wifi":
        #wifi.main()
        wifi.run()
    elif module=="temperature":
        temperature.main()
        temperature.run()
    g_logger.info("[main]test module={}. end<<<<<<<<".format(module))
    return True,"cmd line module test mode..."

def init_path():
    os.system("mkdir -p /var/volatile/tmp")

def main(logger):
    global g_logger,g_module
    try:
        is_network_valid_flag=False
        g_logger = logger
        
        g_logger.info("[main] ==================================================================================")
        g_logger.info("[main] =                            begin...                                            =")
        log_timestamp()
        g_logger.info("[main] cmdline={} {}".format(str(sys.argv[0]),str(sys.argv[1:])))
        g_logger.info("[main] version={}".format(APP_VERSION))

        g_logger.info("[main] ==================================================================================")
        stage='common'
        common.killall("led_ctrl.py")   #将出厂状态，检查逻辑的进程关闭
        init_path()
        errors = 0
        log_timestamp()
        cfg = common.config(cfg_file)
        g_logger.info("[main] config.version={}".format(cfg['version']))
        g_logger.info("[main] detect mode=[{}]".format(cfg['test_mode']))
        if common.is_self_detect_mode() or common.is_acq_devid_mode():
            common.led_init()
            common.led_running()            
        else:
            common.led_init()
                
        
        stop_anylink()
        
        if g_module != None:            
            return test_module(g_module)
        
        ssdp_ret = ssdp_discover(logger=g_logger)

		#ssdp_find_server.find_test_server(opts=None,logger=g_logger)        
        #初始化restAPI

        restapi.main()
        #print "{} running ...".format(APPNAME)
        g_logger.info("[main]config={0}".format(cfg))
        
        #init wifi network for test
        if cfg["wifi"]["enable"] == True:
            stage='wifi-init'
            restart_wifi_flag=False
            if common.is_self_detect_mode() == True and common.ping_wifi_gateway() == False:
                #如果是自检模式，wifi如果没有连通，需要自动设置wifi
                restart_wifi_flag = True
            elif common.is_self_detect_mode() == False:
                #如果从usb启动的工厂测试模式，需要使用u盘里的配置来启动wifi
                restart_wifi_flag = True

            if common.is_acq_devid_mode() and ssdp_ret:
                restart_wifi_flag = False

            if restart_wifi_flag and not common.process_exists("wifi.py"):
                common.killall("wifi.py")
                common.run_cmd(cmd="python ./wifi.py 2&>1 &",wait=False)  
                time.sleep(3)   #等待wifi驱动加载


        #通过ssdp查找服务器
        '''
        (ssdp_ret,ssdp_info) = ssdp_find_server2.find_test_server(opts=None,logger=g_logger)
        if ssdp_ret:
            cfg = common.config()
            cfg['common']['TEST_SERVER_URL_API']="http://{0}:{1}/api/v1.0".format(ssdp_info["ip"],ssdp_info['port'])
            g_logger.info("ssdp get server={}".format(cfg['common']['TEST_SERVER_URL_API']))
        '''
        log_timestamp()
        #NTP
        NTP_TRY_TIMES=5
        stage='NTP'
        if ssdp_ret == True:
            NTP_TRY_TIMES=60
        else:
            NTP_TRY_TIMES=60    #等待wifi网络稳定
        for _i in xrange(NTP_TRY_TIMES):
            time.sleep(1)            
            if restapi.NTP() == True: 
                break
        
        log_timestamp()
        #写号 devuaid,eth_mac,wifi_mac1,wifi_mac2
        stage='identify'
        identify.main()
        (test_ret,msg) = identify.acquire_dev_identify()

        if test_ret == False:            
            errors += 1

        if common.is_self_detect_mode() == True:
            #如果是自检模式，其实没所谓一定要网络通 把写号的错误清0  这一行代码一写要紧跟着写号调用，不要随意换位置 ******** todo 
            errors = 0  
        
        #    if common.is_acq_devid_mode():
        #        raise Exception,"in test_mode=[acquire_dev_identify mode], and acquire device id fail!!"

        #if common.is_self_detect_mode() or common.is_acq_devid_mode():
        #无论在任何测试模式下，设备的mac,devuaid.d都不能为空，否则报错，并停止测试
        if     not common.is_devuaid_valid("/etc/devuaid.d") \
            or not common.is_file_exists("/etc/mac") \
            or not common.is_file_exists("/lib/firmware/wlan/qca_cld/wlan_mac.bin"):
            raise Exception,"[main]device id is empty!! stop test"

        if common.is_acq_devid_mode() == True:
            common.led_pass()
            g_logger.info("[main] acquire_dev_identify success! exit app!")
            return  True

        post_data={"err_msg":'[main] {0}'.format(cfg_file),"test_report":"version=[{}]".format(cfg['version']),"test_res":True,"test_module":"config_version"}
        restapi.send_test_report(post_data)


        #get versions
        log_timestamp()
        stage='ver'
        ver.main()
        (test_ret,msg) = ver.run()
        if test_ret == False:
            errors+=1

        


        log_timestamp()
        if cfg["wifi"]["enable"] == True:
            stage='wifi-ping'
            (test_ret,msg) = wifi.run()
            if test_ret == False:
                errors+=1

        #usb
        log_timestamp()
        if cfg["usb"]["enable"] == True:
            stage='usb'
            usb.main()
            (test_ret,msg) = usb.run()
            if test_ret == False:
                errors+=1

        common.led_running()
        #uart
        log_timestamp()
        if cfg["uart"]["enable"] == True:
            stage='uart'
            uart.main()
            (test_ret,msg) = uart.run()
            if test_ret == False:
                errors+=1

        #ethernet
        log_timestamp()
        if cfg['ethernet']["enable"] == True:
            stage='ethernet'
            ethernet.main()
            (test_ret,msg) = ethernet.run()
            if test_ret == False:
                errors+=1

        #gpio
        log_timestamp()
        if cfg["gpio"]["enable"] == True:
            stage='gpio'
            gpio.main()
            (test_ret,msg) = gpio.run(gpio_port = "gpio23:gpio77")
            if test_ret == False:
                errors+=1
        
        #adc
        log_timestamp()
        if cfg["adc"]["enable"] == True:
            stage='adc'
            adc.main()
            (test_ret,msg) = adc.run()
            if test_ret == False:
                errors+=1

        #mmc
        log_timestamp()
        if cfg["mmc"]["enable"] == True:
            stage='mmc'
            mmc.main()
            (test_ret,msg) = mmc.run()
            if test_ret == False:
                errors+=1

        #temperature
        if "temperature" in cfg and cfg["temperature"]["enable"]==True:
            temperature.main()
            temperature.run()

        if errors > 0:
            common.led_err()
            g_logger.info("[main]test fail errors={0}".format(errors))
            if common.is_func_detect_mode() == True:
                #工厂全检模式时，设置出厂错误标志
                p_manufacturer = "null"
                if "manufacturer" in cfg:
                    p_manufacturer = cfg["manufacturer"]
                common.set_factory_mode(mode="test_fail",date=time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),manufacturer=p_manufacturer)
        else:    
            common.led_pass()
            if common.is_self_detect_mode() == True:
                common.led_running()    #自检模式正常时也是双闪
            if common.is_func_detect_mode() == True:
                #工厂全检模式时，设置出厂完成标志
                p_manufacturer = "null"
                if "manufacturer" in cfg:
                    p_manufacturer = cfg["manufacturer"]
                common.set_factory_mode(mode="test_pass",date=time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),manufacturer=p_manufacturer)

            g_logger.info("[main]test pass!")
        log_timestamp()
    except Exception as ept:
        exstr = traceback.format_exc()
        common.led_err()
        log_msg = "[main] stage={0} exception={1},stack={2}".format(stage,str(ept),exstr)
        g_logger.error(log_msg)
        post_data={"err_msg":'[main] test exception',"test_report":log_msg,"test_res":False,"test_module":"main"}
        restapi.send_test_report(post_data)
    finally:
        #release resource
        g_logger.info("[main] finally release resource")
        common.killall("wifi.py")
        common.killall("udhcpc")
        os.system("sync")
# ############################# main block ##############################

if __name__ == '__main__':
    common.set_CTX('log_level',"DEBUG")
    #common.run_cmd('echo "sleep 15";sleep 15;echo "max wait 15"')
    a_res, a_err = argv_parser(sys.argv)
    if not a_res:
        sys.stderr.write(a_err)
        print "{} exit abnormal!".format(APPNAME)
        exit(1)
    logger = log.initial_log("factoryTest.log",common.get_CTX('log_level') )
    
    if main(logger):
        print "{} exit abnormal!".format(APPNAME)
        sys.exit(1)
    else:
        print "{} exit normal!".format(APPNAME)
        sys.exit(0)