#!/usr/bin/python
# -*- coding: UTF-8 -*-

import os
import json
from daxml import CommonXml
import sys
import common
import log
import time
import restapi
import traceback
__version__ = "1.0.0"

_VER = "ver"
_SDMWEBS_VER = "web"
_SCRIPT_VER = "script"
_MAC = "mac"
_VER_TAG = "^HardwareModel[ ]*="
_SDMWEBS_TAG = "^SoftVersion[ ]*="
_CONF = "/opt/sdmwebs/web/cgi-bin/config/global_var.py"
_SCRIPT_VER_FILE = "/opt/script/script_version.txt"
_COMMON_XML = "/opt/sdmwebs/web/conf/Common.xml"

res_dic = {
    _VER: "",
    _SDMWEBS_VER: "",
    _SCRIPT_VER: "",
    _MAC: ""
}

xml=None

def file_grep_line(conf, text):
    cmd = 'grep "' + text + '" ' + conf
    res = os.popen(cmd)
    line = res.read().rstrip(" \n\r")
    res.close()

    return line


def get_sdmwebs_ver():
    if os.path.isfile(_COMMON_XML):
        return xml.get_web_ver()
    line = file_grep_line(_CONF, _SDMWEBS_TAG)
    return line.strip().split("=")[1].strip(" \"'").split("-")[1]


def get_ver():
    if os.path.isfile(_COMMON_XML):
        return xml.get_anylink_ver()
    line = file_grep_line(_CONF, _VER_TAG)
    return line.strip().split("=")[1].strip(" \"'")


def get_script_ver():
    if os.path.isfile(_SCRIPT_VER_FILE):
        with open(_SCRIPT_VER_FILE) as f:
            return f.read().strip(" \n\r")
    return ""


def get_anylink_agent_ver():
	# 获取 Agent版本
	agentVersion = ''
	p = os.popen('/opt/agent/agentbasic -v', 'r')
	agentData = p.read().split(' ')
	agentVersion = "V"+agentData[1]+"."+agentData[3][0:-1]
	return agentVersion

def get_mac_address():
    cmd = "ifconfig eth0 | grep HWaddr | awk  '{print $5}'"
    res = os.popen(cmd)
    res = res.read().strip(" \n\r")
    return res


def run():
    try:    
        g_logger.info("[ver] begin test get device versions")

        res_dic[_VER] = get_ver()
        res_dic[_SDMWEBS_VER] = get_sdmwebs_ver()
        res_dic[_SCRIPT_VER] = get_script_ver()        
        res_dic['agent_ver']=get_anylink_agent_ver()
        errors=0
        post_data={"err_msg":'',"test_report":"","test_module":"ver","test_res":True}
        
        if res_dic[_SDMWEBS_VER] == "":
            post_data['test_res']=False
            errors+=1
        if res_dic[_SCRIPT_VER] == "":
            post_data['test_res']=False            
            errors+=1
        if res_dic[_VER] == "":
            post_data['test_res']=False
            errors+=1
        if res_dic['agent_ver'] == "":
            post_data['test_res']=False
            errors+=1
        
        post_data['test_report']=json.dumps(res_dic)
        restapi.send_test_report(post_data)
        if errors>0:
            g_logger.info("[ver] test fail:{0}".format(post_data)) 
            return False,"ver no pass"
        else:
            g_logger.info("[ver] test success:{0}".format(post_data))
            return True,""
        
        
    except Exception as ept:
        exstr = traceback.format_exc()

        g_logger.info("[ver] exception={0},stack={1}".format(str(ept),exstr))
        #raise ept
        return False, repr(ept)

def main():
    global g_logger,xml
    g_logger = log.initial_log("ver.log",common.get_CTX('log_level') )
    if os.path.isfile(_COMMON_XML):
        xml = CommonXml(_COMMON_XML)
'''
if __name__ == "__main__":
    if os.path.isfile(_COMMON_XML):
        xml = CommonXml(_COMMON_XML)
    res_dic[_VER] = get_ver()
    res_dic[_SDMWEBS_VER] = get_sdmwebs_ver()
    res_dic[_SCRIPT_VER] = get_script_ver()
    res_dic[_MAC] = get_mac_address()
    res_dic['agent_ver']=get_anylink_agent_ver()
    print (json.dumps(res_dic))
'''
