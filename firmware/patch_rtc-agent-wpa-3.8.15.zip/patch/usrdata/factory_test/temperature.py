#!/usr/bin/python
# -*- coding: UTF-8 -*-
'''
cat /sys/devices/virtual/thermal/thermal_zone1/temp
cat /sys/devices/virtual/thermal/thermal_zone4/temp
cat /sys/devices/virtual/thermal/thermal_zone6/temp
zone1:pmic temperature
zone4:xo temperature
zone6:pa temperature
读取板子温度值，记录在日志并上报到服务器，老化用
'''

import urllib2
import json
import common
import os
import log
import restapi
import traceback
import time
import wifi
import gc

__VERSION = "0.0.3"
g_logger = None

def read_temps():
    temp1 = common.run_cmd("cat /sys/devices/virtual/thermal/thermal_zone1/temp")
    temp4 = common.run_cmd("cat /sys/devices/virtual/thermal/thermal_zone4/temp")
    temp6 = common.run_cmd("cat /sys/devices/virtual/thermal/thermal_zone6/temp")
    if temp1 == None or temp1=="":
        temp1=-1
    if temp4 == None or temp4=="":
        temp4=-1
    if temp6 == None or temp6=="":
        temp6=-1
    return temp1,temp4,temp6

def run():
    try:
        errors=0
        g_logger.info("[temperature] begin test ...") 
        cfg = common.config()
        cfg_temp = cfg['temperature']
        #if cfg_temp['enable']==False:
        #    return False,"[temperature] errors:config.json temperature.enable=false"
        g_logger.info("[temperature] stop wifi") 
        wifi.stop_wifi()

        post_data={"err_msg":'',"test_res":True,"test_report":"","test_module":"temperature"}
        loop_times=0
        loop_idx=0
        while loop_times<=cfg_temp["loop_times"]:
            loop_idx+=1
            g_logger.info("[temperature] restart wifi ...") 
            if wifi.start_wifi(sync_flag=True) == True:
                g_logger.info("[temperature] restart wifi success") 
                (temp1,temp4,temp6) = read_temps()
                msg = "[temperature] t={0};[{1},{2},{3}],idx={4}".format(time.time(),temp1,temp4,temp6,loop_idx)
                g_logger.info(msg)
                post_data["test_report"]=json.dumps({"t1":temp1,"t4":temp4,"t6":temp6,"idx":loop_idx})
                restapi.send_test_report(post_data)
                g_logger.info("[temperature] stop wifi") 
                wifi.stop_wifi()
            else:
                g_logger.info("[temperature] restart wifi fail") 
            time.sleep(cfg_temp["interval"])
            gc.collect()
        g_logger.info("[temperature] end test ...") 
        return True,"successful"
    except Exception as ept:
        exstr = traceback.format_exc()
        g_logger.info("[temperature] test fail,exception={0},stack={1}".format(str(ept),exstr)) 
        #raise ept
        return False, repr(ept)

def main():
    global g_logger
    g_logger = log.initial_log("temperature.log",common.get_CTX('log_level') )