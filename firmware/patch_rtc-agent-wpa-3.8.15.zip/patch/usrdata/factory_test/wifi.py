#!/usr/bin/python
# -*- coding: UTF-8 -*-
import os
import sys
import time
import commands
import re
import restapi
import traceback


'''
v1.3.1 
Added by Chenxi Shi on 2019-12-2 (last modified 2019-12-2)
Add a function that returns if connection is failed because of authentication
# This function launch a subprocess '/usr/sbin/wpa_cli' with param '-i wlan0'
# The result is saved in file /opt/script/WiFi/wpa_error.txt
# Results: 'not scanned' | 'psk err' | 'other' | 'success' | '/usr/sbin/wpa_cli boot error'
'''
import subprocess
import pty
import select

import log
import common

__VERSION = "0.0.2"

ssid_conf_list = []
scan_ap_info_list = []
bssid_dir = {}
frequency_select = '0'

logger=None

class WpaCli:
    def __init__(self):
        self.master_fd, self.slave_fd = pty.openpty()
        self.last_error = -999
        try:
            self.proc = subprocess.Popen(['/usr/sbin/wpa_cli', '-i', 'wlan0'],
            stdin=subprocess.PIPE, stdout=self.slave_fd, stderr=None, close_fds=True)
        except Exception as e:
            logger.error(str(e), exc_info=True)
            self.last_error = -99
            logger.error("wpa_cli boot error")
            #with open('/opt/script/WiFi/wpa_error.txt', 'w') as f:
            #    f.write('/usr/sbin/wpa_cli boot error')
            #    f.flush()

    def get_error_message(self):
        buf = ''
        while 1:  # read until 'end'
            ready, _, _ = select.select([self.master_fd], [], [], 0.1)
            if ready:
                temp = os.read(self.master_fd, 512)
                if not temp or len(temp) == 0:
                    break
                buf += temp
            else:
                break
        if '4-Way Handshake failed' in buf:  # psk error
            self.last_error = -1
            return -1
        else:
            self.last_error = 0
            return 0  # don't care status below
        # if 'CTRL-EVENT-CONNECTED' in buf: # connect success
        # return 0
        # if 'CTRL-EVENT-SCAN-RESULTS' in buf: # no devices nearby
        # return 1

    def save_error_to_file(self):
        logger.error('psk err' if self.last_error == -1 else 'other')
        #with open('/opt/script/WiFi/wpa_error.txt', 'w') as f:
        #    f.write('psk err' if self.last_error == -1 else 'other')
        #    f.flush()

    def destroy(self):
        global logger
        try:
            self.proc.stdin.write('quit\n')
        except Exception as e:
            logger.error('except when /usr/sbin/wpa_cli terminated: ' + str(e))
        finally:
            try:
                self.proc.terminate()
                self.proc.poll()
            except Exception as e:
                logger.error('except when /usr/sbin/wpa_cli terminated: ' + str(e))


############################### functions ##############################
def init_logger():

    global logger
    logger = log.initial_log('wifi-B.log',common.get_CTX('log_level'))
    return 0


def running_wpa():
    import psutil
    while True:
        process_name = []
        process_list = psutil.pids()
        try:
            for pid in process_list:
                process = psutil.Process(pid)
                process_name.append(process.name())
            break
        except Exception, e:
            time.sleep(5)
            continue
    if 'wpa_supplicant' in process_name:
        return 0
    else:
        return -1


def start_wpa_supplicant():
    cfg = common.config()
    os.system("killall wpa_module.py")
    os.system("killall wpa_supplicant")
    if os.path.exists("/var/run/wpa_supplicant/wlan0"):
        os.system("rm -rf /var/run/wpa_supplicant/wlan0")
    if running_wpa() != 0:
        logger.info('start wpa_supplicant ...')
        # 如果是FC20 不支持-Dwext
        #os.system('/usr/sbin/wpa_supplicant -Dwext -B -iwlan0 -c/opt/script/WiFi/wpa_supplicant.conf')
        #os.system('/usr/sbin/wpa_supplicant -B -iwlan0 -c{0}/wpa_supplicant.conf'.format(cfg['working_path']))
        os.system('/usr/sbin/wpa_supplicant -iwlan0 -c{0}/wpa_supplicant.conf &'.format(cfg['working_path']))
        time.sleep(3)  #wait wpa_supplicant create UNIX socket /var/run/wpa_supplicant/wlan0
    else:
        logger.info('wpa_supplicant reload configure...')
        (status, res) = commands.getstatusoutput('/usr/sbin/wpa_cli -i wlan0 reconfigure')
        if res != 'OK':
            logger.error("wpa_supplicant reload configure fail:%s" % res)
            return -1
        time.sleep(5)


def wlan_dhcp_cfg():
    os.system("udhcpc -i wlan0 -s /etc/udhcpc.d/50default &")



##conect use bssid
def set_bssid_and_connect():
    global ssid_conf_list
    global bssid_dir
    try:
        network_id = 0
        for ssid in ssid_conf_list:
#set bssid
            for bssid in bssid_dir[ssid]:
                connect_status = False
                os.system('/bin/killall udhcpc;/bin/killall udhcpc')
                (status, res) = commands.getstatusoutput('/usr/sbin/wpa_cli -i wlan0 set_network %d ssid "''"' % (network_id))
                if res != 'OK':
                    logger.error("connect essid fail:%s" % res)
                    return -1
                (status, res) = commands.getstatusoutput('/usr/sbin/wpa_cli -i wlan0 bssid %d %s' % (network_id,bssid))
                if res != 'OK':
                    logger.error("set bssid fail:%s" % res)
                    return -1
#connect
                logger.info("try to connect ssid :%s, bssid:%s" % (ssid,bssid))
                (status, res) = commands.getstatusoutput('/usr/sbin/wpa_cli -i wlan0 select_network %d ' % (network_id))
                if 'OK' != res:
                    logger.error("select network fail:%s" % res)
                    return -1
                (status, res) = commands.getstatusoutput('/usr/sbin/wpa_cli -i wlan0 disable_network %d && /usr/sbin/wpa_cli -i wlan0 enable_network %d' % (network_id,network_id))
                if 'OK\nOK' != res:
                    logger.error("restart network fail:%s" % res)
                    return -1
#check connect results
                cli = WpaCli()  # added by chenxi shi
                for i in xrange(10):
                    with open('/sys/class/net/wlan0/operstate', 'r') as fd:
                        operstate = fd.read()
                    if not 'up' in operstate:
                        if -1 == cli.get_error_message():  # wifi password error # added by chenxi shi
                            logger.info('authentication failed: password error')
                            cli.save_error_to_file()
                            break
                        else:
                            cli.save_error_to_file()
                        time.sleep(2)
                        continue
                    else:
                        logger.info('authentication success')
                        with open('/opt/script/WiFi/wpa_error.txt', 'w') as f:
                            f.write('success')  # add by chenxi shi
                            f.flush()
                            connect_status = True
                        #os.system('/sbin/udhcpc -i wlan0 &')
                        wlan_dhcp_cfg()
                        os.system('/usr/sbin/wpa_cli -i wlan0 status')
                        time.sleep(3)
                        break
                cli.destroy()  # added by chenxi shi
                if(connect_status != True):
                    logger.info('connect AP failed')
                    continue
#check netstate
                if common.ping_wifi_gateway()==True: 
                    logger.info('check net_state is connected')
                    return True
                else:
                    logger.info('connect AP success ,check ping_wifi_gateway(ping gateway) not connected')
            network_id = network_id + 1
    except Exception, e:
        logger.info('set_bssid_and_connect,ex:%s' % repr(e))
        return -1


class ap_info:
    def __init__(self,essid,bssid,siglevel,frequency):
        self.essid = essid
        self.bssid = bssid
        self.siglevel = siglevel
        self.frequency = float(frequency)/1000000000

    def get_essid(self):
        return self.essid

    def get_bssid(self):
        return self.bssid

    def get_siglevel(self):
        return self.siglevel

    def get_frequency(self):
        return self.frequency

    def display(self):
        logger.info('ap_info ssid :%s,  bssid:%s,  Signallevel:%s,  frequency:%f GHZ' % (self.essid,self.bssid,self.siglevel,self.frequency))


##list order by signal strength
def get_bssid_dir():
    global ssid_conf_list
    global scan_ap_info_list
    global bssid_dir
    global frequency_select
    try:
        bssid_dir = {}
        bssid_dir = bssid_dir.fromkeys(ssid_conf_list)
        for ssid in ssid_conf_list:
            bssid_list = []
            siglevel_dir = {}
            siglevel_dir_2G = {}
            siglevel_dir_5G = {}
            logger.info('matching for ssid:%s' % ssid)
#2G preferred/5G preferred
            if frequency_select == '1' or frequency_select == '2':
                #get {bssid:strength} dir
                for ap_info in scan_ap_info_list:
                    if ssid == ap_info.get_essid():
                        ap_info.display()
                        if int(ap_info.get_frequency()) == 2:
                            siglevel_dir_2G.update({ap_info.get_bssid():int(ap_info.get_siglevel())})
                        elif int(ap_info.get_frequency()) == 5:
                            siglevel_dir_5G.update({ap_info.get_bssid():int(ap_info.get_siglevel())})
                #be sorted
                results_2G = sorted(siglevel_dir_2G.items(), key=lambda x:x[1], reverse=True)
                results_5G = sorted(siglevel_dir_5G.items(), key=lambda x:x[1], reverse=True)
                if frequency_select == '1':
                    logger.info('frequency_select is 2.4G preferred,2.4G bssid list:%s,5G bssid_list:%s' % (results_2G,results_5G))
                    bssid_list = [res[0] for res in results_2G] + [res[0] for res in results_5G]
                elif frequency_select == '2':
                    logger.info('frequency_select is 5G preferred,5G bssid_list:%s,2.4G bssid list:%s' % (results_5G,results_2G))
                    bssid_list = [res[0] for res in results_5G] + [res[0] for res in results_2G]

#nothing to do/2.4G only/5G only
            else:
                #get {bssid:strength} dir
                for ap_info in scan_ap_info_list:
                    if ssid == ap_info.get_essid():
                        ap_info.display()
                        if frequency_select == '3' and int(ap_info.get_frequency()) == 5:
                            logger.info("frequency_select is 2.4G only,this info is abandoned")
                            continue
                        elif frequency_select == '4' and int(ap_info.get_frequency()) == 2:
                            logger.info("frequency_select is 5G only,this info is abandoned")
                            continue
                        siglevel_dir.update({ap_info.get_bssid():int(ap_info.get_siglevel())})
                #be sorted
                results = sorted(siglevel_dir.items(), key=lambda x:x[1], reverse=True)
                bssid_list = [res[0] for res in results]
            bssid_dir[ssid] = bssid_list

        logger.info('get scan bssid_list according conf ssid_list:%s' % bssid_dir)
    except Exception, e:
        return -1



def get_frequency_select_conf():
    global frequency_select
#frequency_select
#"0:nothing to do/    1:2.4G preferred/     2:5G preferred/    3:2.4G only/    4:5G only"
    try:
        with open('/opt/script/WiFi/frequency_select.conf', 'r') as fd:
            frequency_select = fd.read()
    except Exception, e:
        logger.error('Get frequency_select fail from frequency_select.conf' )     
        return -1

def get_ssid_conf():
    global ssid_conf_list
    cfg = common.config()
    try:
        while(True):
            ssid_conf_list = []
            fn_wpa_supplicant = '{0}/wpa_supplicant.conf'.format(cfg['working_path'])
            print "wpa_supplicant path=",fn_wpa_supplicant
            with open(fn_wpa_supplicant, 'r') as fd:
                for line in fd.readlines():
                    if 'ssid="' in line:
                        ssid = line[line.index('ssid="') + 6:]
                        ssid = ssid[:ssid.index('"')]
                        ssid_conf_list.append(ssid)
                        
                        os.system('iwlist wlan0 scanning essid %s' % ssid) #find hide ssid
                if(len(ssid_conf_list)!=0):
                    return ssid_conf_list
                else:
                    return -1
    except Exception, e:
        return -1


def get_ssid_scan():
    from pythonwifi.iwlibs import Wireless, Iwrange, getNICnames
    global scan_ap_info_list
    scan_ap_info_list = []
    wifi = Wireless('wlan0')
    all_ssid = []
    try:
        iwrange = Iwrange(wifi.ifname)
    except IOError, (error_number, error_string):
        return -1
    try:
        results = wifi.scan()
    except IOError, (error_number, error_string):
        return -1
    if (len(results) == 0):
        return -1
    try:
        (num_channels, frequencies) = wifi.getChannelInfo()
        for ap in results:
            all_ssid.append(ap.essid)
            scan_ap_info_list.append(ap_info(ap.essid,ap.bssid,ap.quality.getSignallevel(),ap.frequency.getFrequency()))
            logger.info('get scan ap_info :%s,  bssid:%s,  Signallevel:%s,  frequency:%f GHz' % (ap.essid,ap.bssid,ap.quality.getSignallevel(),float(ap.frequency.getFrequency())/1000000000))
        return all_ssid
    except Exception, e:
        return -1


def get_link_info(ifname):
    import socket, fcntl, struct
    from pythonwifi.iwlibs import Wireless
    try:
        wifi = Wireless('wlan0')
        logger.info('ssid is %s,bssid is %s, @ %s' % (wifi.getEssid(),wifi.getAPaddr(), wifi.getFrequency()))
    except Exception, e:
        return -1
    try:
        with open('/proc/net/wireless', 'r') as fd:
            for line in fd.readlines():
                if 'wlan0:' in line:
                    level = line.split()[3]
                    logger.info('signal level is %s' % level)
    except Exception, e:
        return -1
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        ifaddr = fcntl.ioctl(sock.fileno(), 0x8915, struct.pack('256s', ifname[:15]))
        logger.info('lease of %s obtained' % socket.inet_ntoa(ifaddr[20:24]))
    except Exception, e:
        return -1
    return 0

# 停止wifi 关闭驱动和电源
def stop_wifi():
    os.system('/etc/init.d/wlan stop')
    return 0

# 设置访问外网转发
def set_ip_forward():
    os.system('iptables -F')
    os.system('iptables -t nat -F')
    os.system('echo 1 > /proc/sys/net/ipv4/ip_forward')
    os.system('iptables -t nat -A POSTROUTING -o wlan0 -j MASQUERADE')
    return 0

def load_wifi_driver():
    retry = 5
    n = 0
    while n < retry:
        try:
            time.sleep(2)
            os.system('/etc/init.d/wlan start')
            time.sleep(5)
            (status, output) = commands.getstatusoutput('/sbin/ifconfig -a | grep "wlan0"')    
            if output == '':
                logger.info('load_wifi_driver fail retry times=%d' % n)
            else:
                logger.info('load_wifi_driversuccess')
                return True
            n += 1
        except Exception as ept:
            n += 1
            logger.error('load_wifi_driver fail, error msg: %s' % repr(ept))
            time.sleep(3)
        else:
            return False
    return False

def set_wifi_mac():
    wifi_mac_bin_filepath="/lib/firmware/wlan/qca_cld/wlan_mac.bin"
    if os.path.exists(wifi_mac_bin_filepath):
        return True
    mac1 = common.gen_mac(1).replace(":","").upper()
    mac2 = common.gen_mac(2).replace(":","").upper()

    os.system("mkdir -p /lib/firmware/wlan/qca_cld")
    os.system("rm {} -rf".format(wifi_mac_bin_filepath))
    with open(wifi_mac_bin_filepath,'w') as wifimac_f:
        wifimac_f.write("Intf0MacAddress=%s\n" % (mac1))
        wifimac_f.write("Intf1MacAddress=%s\n" % (mac2))
        wifimac_f.write("END\n")   
    return True

#测试入口
def run():
    g_logger = log.initial_log("wifi-F.log",common.get_CTX('log_level') )
    try:
        g_logger.info("[wifi] begin test") 
        cfg = common.config()
        cfg_wifi = cfg['wifi']
        errors=0
        

        post_data={"err_msg":'',"test_report":"","test_module":"wifi"}
        
        if common.is_self_detect_mode() == True:
            return run_self_detect()

        if common.ping_wifi_gateway(debug='wifi.run') == True:
            post_data["test_res"] = True
            post_data["test_report"] = "[wifi]ping gateway success"
        else:
            post_data["test_res"] = False
            post_data["test_report"] = "[wifi]ping gateway fail"
            errors+=1

        #检查wifi 信号强度
        #get user conf from wpa_supplicant.conf
        if cfg_wifi.has_key('wifi_scan') and cfg_wifi["wifi_scan"]:
            g_logger.info("[wifi] wifi scan test")
            signal_level_check_errors=1 #信号检查情况
            conf_ssids = get_ssid_conf()
            (scan_ssids,ssid_dict) = wifi_scan(interface="wlan0")
            g_logger.info("[wifi]wpa_supplicant.conf={}".format(str(conf_ssids))) 
            g_logger.info("[wifi]wifi scan result={}".format(str(scan_ssids))) 
            if conf_ssids != None and conf_ssids != -1 and scan_ssids!=None and len(scan_ssids)>0:
                for usercfg_ssid in conf_ssids:
                    if ssid_dict.has_key(usercfg_ssid):
                        scan_ssid = ssid_dict[usercfg_ssid]
                        if cfg_wifi["signal_range_low"] <= scan_ssid['Signal level'] and cfg_wifi["signal_range_high"] >= scan_ssid['Signal level']:
                            signal_level_check_errors = 0
                            _msg_1 = "[wifi]signal level check success,ssid={} signal level={}dBm".format(usercfg_ssid,scan_ssid['Signal level'])
                            g_logger.info(_msg_1)                    
                        else:
                            _msg_2 = "[wifi]signal level check fail,ssid={} signal level={}dBm".format(usercfg_ssid,scan_ssid['Signal level'])
                            signal_level_check_errors += 1
                            post_data["test_res"] = False
                            post_data["test_report"] = _msg_2
                            g_logger.error(_msg_2)                            
                            errors+=1
                    else:
                        continue
            else:
                g_logger.info("[wifi]wifi scan test fail") 

        restapi.send_test_report(post_data)
        if errors<=0:
            return True,""
        else:
            return False,"[wifi]test fail"
    except Exception as ept:
        exstr = traceback.format_exc()

        g_logger.info("[wifi] exception={0},stack={1}".format(str(ept),exstr))
        #raise ept
        return False, repr(ept)



def wifi_scan(interface="wlan0"):
    ''' write wifi info to a json file'''

    cmd = 'iwlist ' + interface + ' scanning > .log'
    os.system(cmd)
    l = []
    with open('.log', 'r') as f:
        l = f.readlines()
    l = parse_wifi_info(l)
    d={}
    if l!=None and len(l)>0:
        for ssid in l:
            d[ssid['SSID']]=ssid
    return l,d

def parse_wifi_info(_list):
    
    li = list()
    d = dict()
    ssids = dict()
    #print "************************************find ssid=",str(_list)
    try:
        for l in _list:
            data = l.strip()
            #print "**********",data
            if data.startswith('Cell'):
                d = dict()
                
            elif data.startswith('ESSID'):
                ssid = data[data.index(':') + 2:-1]
                if ssids.has_key(ssid):
                    continue
                ssids[ssid] = True
                d['SSID'] = ssid
                
                li.append(d)
            elif data.startswith('Encryption key'):
                buf = data[data.index(':') + 1:]
                d['Encryption key'] = buf
            elif data.startswith('Quality='):
                buf = data[data.index('Signal level=') + 13:data.index('Signal level=') + 13+4]
                d['Signal level'] = int(buf)
            elif data.startswith('Channel:'):
                buf = data[data.index(':') + 1:]
                d['Channel'] = int(buf)
            elif data.startswith('Protocol:'):
                buf = data[data.index(':') + 1:]
                d['Protocol'] = buf
    except Exception as e:
        raise Exception,e
    return li

#自检模式下调用自检时，通过条件：
# 1. 能scan到ssid
def run_self_detect():
    g_logger = log.initial_log("wifi-S.log",common.get_CTX('log_level') )
    try:
        errors=0
        
        post_data={"err_msg":'',"test_report":"","test_module":"wifi"}
        (ssid_list,ssid_dict) = wifi_scan(interface="wlan0")
        g_logger.info("[wifi]wifi scan result={}".format(str(ssid_list))) 
        if ssid_list != None and len(ssid_list) > 0:
            post_data["test_res"] = True
            post_data["test_report"] = "[wifi]scan success:"+str(ssid_list)
        else:
            post_data["test_res"] = False
            post_data["test_report"] = "[wifi]scan success fail,return empty"
            errors+=1
        restapi.send_test_report(post_data)
        if errors<=0:
            return True,""
        else:
            return False,"[wifi]test fail"
    except Exception as ept:
        exstr = traceback.format_exc()

        g_logger.info("[wifi] exception={0},stack={1}".format(str(ept),exstr))
        #raise ept
        return False, repr(ept)


def stop_wifi():
    common.killall('wifi.py')
    os.system("ifconfig wlan0 down")

#启动wifi连接
#sync_flag=True 表示等待到wifi进程完全连接上ap为止,等待时间为300秒，看for xrange的大小
def start_wifi(sync_flag=False):
    if not common.process_exists('wifi.py'):
        common.run_cmd(cmd="python ./wifi.py 2&>1 &",wait=False) 
    
    if sync_flag == True:
        for _i in xrange(10):
            print "wait wifi connect..."
            time.sleep(30)
            wifi_ip_address = common.get_ip_address(eth_dev="wlan0")
            if wifi_ip_address!="":
                print "wait wifi connect success"
                return True
            
    else:
        return True



def main():
    import gc
    import commands
    init_logger()
    logger.info('\033[32FC20 wifi module_\033[0m')
    set_wifi_mac()  #使用本机的IMEI生成mac1 mac2
    os.system("/etc/init.d/wlan stop")
    (status, output) = commands.getstatusoutput('/sbin/ifconfig -a | grep "wlan0"')
    if output == '':
        # if wlan0 not exist;load wifi driver
       if load_wifi_driver() == False:
           logger.info('load wifi driver fail! exit')
           return -1
           
    (status, output) = commands.getstatusoutput('/sbin/ifconfig | grep "wlan0"')
    if output == '':
        os.system('/sbin/ifconfig wlan0 up')
        time.sleep(0.1)
    (status, output) = commands.getstatusoutput('/usr/sbin/iw dev wlan0 set power_save off')
    if status != 0:
        logger.info('set power_save off fail: %s' % output)
    else:
        logger.info('set power_save off')
    time.sleep(0.1)   #等待网卡稳定
    while True:
        gc.collect()

        ssid_in_range = False
#get user conf
        conf_ssid = get_ssid_conf()
#get ap scan results
        scan_ssid = get_ssid_scan()
        if conf_ssid != -1 and scan_ssid != -1:
            for ssid in conf_ssid:
                if ssid in scan_ssid:
                    ssid_in_range = True
                    break
        else:
            with open('/opt/script/WiFi/wpa_error.txt', 'w') as f:  # save not scanned # added by chenxi shi
                f.write('not scanned')
                f.flush()
            time.sleep(3)
            continue

        if ssid_in_range:
            logger.info('\033[33mreconnect to wireless router...\033[0m')
            start_wpa_supplicant()
            get_frequency_select_conf()
            get_bssid_dir()
            res = set_bssid_and_connect()
            if res == True:
                set_ip_forward()
                get_link_info('wlan0')
                time.sleep(1)
                while True:
                    if common.ping_wifi_gateway()==True: 
                        time.sleep(10)
                        continue
                    else:
                        logger.info('network is not connected in uaual check')
                        time.sleep(1)
                        break
            else:
                time.sleep(1)
        else:
            logger.info('ssid is not in scanning range ...') # added by chenxi shi
            with open('/opt/script/WiFi/wpa_error.txt', 'w') as f:  # save not scanned # added by chenxi shi
                f.write('not scanned')
                f.flush()
            time.sleep(3)
    return 0


############################## main block ##############################

if __name__ == '__main__':
    main()
    sys.exit(0)
