#!/usr/bin/python
# -*- coding: UTF-8 -*-
import os
import sys
import time
import logging
from logging.handlers import RotatingFileHandler

log = None

def initial_log(log_name, level):
    global log
    if log != None:
        return log
    """定义一个RotatingFileHandler，最多备份2个日志文件，每个日志文件最大8K"""
    log = logging.getLogger()
    
    handler = RotatingFileHandler("/usrdata/{}".format(log_name), mode='a', maxBytes=1024 * 800, backupCount=2)
    formatter = logging.Formatter('%(asctime)s-%(levelname)s: %(message)s')
    handler.setFormatter(formatter)
    ch = logging.StreamHandler()
    ch.setFormatter(formatter)
    log.addHandler(handler)
    log.addHandler(ch)
    log_level = logging.DEBUG
    if level == 'DEBUG':
        log_level = logging.DEBUG
    if level == 'WARNING':
        log_level = logging.WARNING
    if level == 'ERROR':
        log_level = logging.ERROR
    if level == 'INFO':
        log_level = logging.INFO
    if log_level is not None:
        log.setLevel(log_level)
    else:
        log.setLevel(logging.WARNING)
    return log