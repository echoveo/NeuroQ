#!/usr/bin/python
# -*- coding: UTF-8 -*-

import os
import sys
import common
import log
import time
import restapi
import commands

__version__ = "1.0.0"
__APP_NAME = "ethernet"

'''
    eth0.1 eth0.2分别接在router1，router2上，采用静态ip
    通过ping -s 60000 测试速率
'''


GPIO_DIR = "/sys/class/gpio"


g_logger = None




def read_gpio(gpio_port):
    v_file = "{0}/{1}/value".format(GPIO_DIR, gpio_port)
    with open(v_file, 'r') as f:
        value = f.read().strip()
        return int(value)

##发现emac处于suspend状态时，重新上电
def powerup_qcom_emac(log=None):
    g_logger.info('powerup_qcom_emac enter')
    (status, output) = commands.getstatusoutput("cat /sys/devices/7c40000.qcom,emac/power/runtime_status")
    if output != "active":
        g_logger.info('powerup_qcom_emac runtime_status is powerdown , active it')
        os.system("echo 'on' >| /sys/devices/7c40000.qcom,emac/power/control")     
        time.sleep(3)
    g_logger.info('powerup_qcom_emac leave')

def powerauto_qcom_emac():
    g_logger.info('[{0}]powerauto_qcom_emac enter'.format(__APP_NAME))
    (status, output) = commands.getstatusoutput("/sys/devices/7c40000.qcom,emac/power/control")
    if output != "auto":
        g_logger.info('[{0}]powerauto_qcom_emac runtime_control not equal auto ,set it to auto'.format(__APP_NAME))
        os.system("echo 'auto' >| /sys/devices/7c40000.qcom,emac/power/control")     
        time.sleep(1)
    g_logger.info('[{0}]powerauto_qcom_emac leave'.format(__APP_NAME))  
#   配置qca8337 vlan模式，LW eth0.1=Lan eth0.2=Wan
#
#
def init_vlan():
    cfg = common.config()
    powerup_qcom_emac()
    os.system("echo \"c LW\">/sys/kernel/debug/qca8337/vlan")
    os.system("vconfig add eth0 1")
    os.system("vconfig add eth0 2")
    os.system("vconfig set_flag eth0.1 1 1")
    os.system("vconfig set_flag eth0.2 1 1")
    os.system("ifconfig eth0 0.0.0.0")
    #os.system("ifconfig eth0.1 0.0.0.0")
    os.system("ifconfig eth0.1 down")
    os.system("ifconfig eth0.2 down")
    os.system("brctl delif bridge0 eth0")
    os.system("brctl delif bridge0 eth0.2")
    os.system("brctl delif bridge0 eth0.1")
    os.system("ifconfig bridge0 down")
    os.system("brctl delbr bridge0")
    e_mac1 = common.gen_mac(4).upper()
    e_mac2 = common.gen_mac(5).upper()
    os.system("ifconfig eth0.1 hw ether {0}".format(e_mac1))
    os.system("ifconfig eth0.2 hw ether {0}".format(e_mac2))
    os.system("ifconfig eth0.1 up")
    os.system("ifconfig eth0.2 up")
    powerauto_qcom_emac()
       
    return True

def eth_auto_dhcp():
    #os.system("udhcpc -i eth0.1 -s /etc/udhcpc.d/50default &")
    #os.system("udhcpc -i eth0.2 -s /etc/udhcpc.d/50default &")
    test_eth_dev(dhcponly=True)

def eth_loopback_test():
    cfg = common.config()
    cfg_eth = cfg['ethernet']
    common.killall("testrawsocket.py")
    os.system("ifconfig eth0.1 down;ifconfig eth0.1 192.168.101.204")
    os.system("ifconfig eth0.2 down;ifconfig eth0.2 192.168.101.205")
    
    time.sleep(0.2)
    #common.killall("testrawsocket.py")
    os.system("ifconfig eth0.1 up")
    os.system("ifconfig eth0.2 up")
    time.sleep(0.3)
    common.run_cmd(cmd="python ./testrawsocket.py --client &",wait=False)
    speed = common.run_cmd(cmd="python ./testrawsocket.py --server | grep speed |awk -F '=' '{print $2}'",wait=True,wait_timeout=30)
    print "[ethernet] speed={}".format(speed)
    common.killall("testrawsocket.py")
    post_data={"err_msg":'loopback test',"test_report":"","test_module":"ethernet"}
   
        
    errors = 0
    if speed != None and speed != "":
        f_speed = float(speed)
        post_data['test_report'] = "loopback speed={}".format(f_speed)
        if f_speed >= float(cfg_eth['loopback_speed']):
            post_data['test_res'] = True
        else:
            errors += 1
            post_data['test_res'] = False
        
    else:
        errors += 1
        post_data['test_report'] = "loopback test fail! speed=invalid"
        post_data['test_res'] = False        
    
    restapi.send_test_report(post_data)
    if errors>0:
        return  False,str(post_data['test_report'])
    else:
        return  True,str(post_data['test_report'])

def test_eth_dev(dhcponly=False):
    #检测网速
    errors = 0
    speed_test_rets={}
    cfg = common.config()
    cfg_eth = cfg['ethernet']
    for port in cfg_eth['ports']:
        if dhcponly==False and port['enable'] == False and port['dev'] != '':
            continue
        ip=""
        ping_ip=""
        speed_test_rets[port['dev']]={"ping_ip":ping_ip}
        if port.has_key('ip') and port.has_key('netmask'):
            os.system("ifconfig {} {} netmask {}".format(port['dev'],port['ip'],port['netmask']))
            os.system("ifconfig {} down".format(port['dev']))
            os.system("ifconfig {} up".format(port['dev']))
            #ping_ip=port['ping_ip']
            ip = port['ip']
            msg = '[{0}]{1} use static ip,ip={2}'.format(__APP_NAME,port['dev'],port['ip'])
            speed_test_rets[port['dev']]['msg']=msg
            g_logger.info(msg) 
        else:
            #os.system("udhcpc -i {} -s /etc/udhcpc.d/50default &".format(port['dev']))
            (ip,dhcp_svr_ip) = common.udhcpc(eth_dev=port['dev'])

            if ip != "" and dhcp_svr_ip !="":
                msg = '[{0}]{1} dhcp success,ip={2},gateway={3}'.format(__APP_NAME,port['dev'],ip,dhcp_svr_ip)
                g_logger.info(msg) 
                #os.system("ifconfig {} {} netmask {}".format(port['dev'],ip,'255.255.255.0'))
                #os.system("ifconfig {} down".format(port['dev']))
                #os.system("ifconfig {} up".format(port['dev']))
                speed_test_rets[port['dev']]['msg']=msg
                ping_ip=dhcp_svr_ip
            else:
                msg = '[{0}]{1} dhcp fail'.format(__APP_NAME,port['dev'])
                g_logger.info(msg) 
                speed_test_rets[port['dev']]['err_msg']=msg
                errors+=1
        if port.has_key('ping_ip'):
            ping_ip=port['ping_ip']

        if ip!="" and ping_ip!="" and dhcponly==False:
            speed_test_rets[port['dev']]['ping_ip']=ping_ip
            ping_time_ms = common.test_net_speed(port['dev'],ping_ip)
            speed_test_rets[port['dev']]['ping_time'] = ping_time_ms
            if ping_time_ms <= port['max_ping_times'] and ping_time_ms>0.0:
                speed_test_rets[port['dev']]['ret']=True
                g_logger.info("[{0}] dev={1};test success,ping_times_ms={2}".format(__APP_NAME,port['dev'],ping_time_ms)) 
            else:
                speed_test_rets[port['dev']]['ret']=False
                errors += 1
                g_logger.error("[{0}] dev={1};test fail,ping_times_ms={2}".format(__APP_NAME,port['dev'],ping_time_ms))
        else:
            speed_test_rets[port['dev']]['ret']=False
    
    post_data={"err_msg":'',"test_report":"","test_module":"ethernet"}
    if errors>0:
        post_data['err_msg']="ping or dhcp errors"
        post_data['test_res'] = False
    else:
        post_data['test_res'] = True

    post_data['test_report'] = str(speed_test_rets)

    if dhcponly==False:
        restapi.send_test_report(post_data)
    
    if errors<=0:
        return True,""
    else:
        return False,"[{0}]test fail".format(__APP_NAME)
def run():
    try:
        g_logger.info("[{0}] begin test ethernet".format(__APP_NAME)) 
        cfg = common.config()
        #打开eth0.1 eth0.2
        init_vlan()
        cfg = common.config()
        cfg_eth = cfg['ethernet']
        if cfg_eth['loopback']:
            return eth_loopback_test()
        else:
            return test_eth_dev()
        '''
        #检测网速
        errors = 0
        speed_test_rets={}
        for port in cfg['ethernet']['ports']:
            if port['enable'] == False and port['dev'] != '':
                continue
            speed_test_rets[port['dev']]={"ping_ip":port['ping_ip']}
            ping_time_ms = common.test_net_speed(port['dev'],port['ping_ip'])
            speed_test_rets[port['dev']]['ping_time'] = ping_time_ms
            if ping_time_ms <= port['max_ping_times'] and ping_time_ms>0.0:
                speed_test_rets[port['dev']]['ret']=True
                g_logger.info("[{0}] dev={1};test success,ping_times_ms={2}".format(__APP_NAME,port['dev'],ping_time_ms)) 
            else:
                speed_test_rets[port['dev']]['ret']=False
                errors += 1
                g_logger.error("[{0}] dev={1};test fail,ping_times_ms={2}".format(__APP_NAME,port['dev'],ping_time_ms)) 
        
        post_data={"err_msg":'',"test_report":"","test_module":"ethernet"}
        if errors>0:
            post_data['err_msg']="ping errors"
            post_data['test_res'] = False
        else:
            post_data['test_res'] = True

        post_data['test_report'] = str(speed_test_rets)
        restapi.send_test_report(post_data)
       
        if errors<=0:
            return True,""
        else:
            return False,"[{0}]test fail".format(__APP_NAME)
       '''
    except Exception as ept:
        g_logger.info("[{0}] test fail,exception={1}".format(__APP_NAME,str(ept))) 
        #raise ept
        return False, repr(ept)

def init_mac():
    e_mac=None
    if os.path.exists("/etc/mac"):
        e_mac = common.run_cmd("cat /etc/mac")
    else:
        e_mac = common.gen_mac(3).upper()
    os.system( "ifconfig eth0 down")
    os.system("ifconfig eth0 hw ether {0}".format(e_mac))
    os.system("ifconfig eth0 up")
    
def main():
    global g_logger
    g_logger = log.initial_log("ethernet.log",common.get_CTX('log_level') )
    init_mac()
    


'''
 "ethernet":{     
        "enable":true,   
        "ports":[
            {
                "enable":true,
                "dev":"eth0.1",
                "ip":"192.168.101.204",
                "netmask":"255.255.255.0",
                "ping_ip":"192.168.101.10",
                "max_ping_times":12.0
            },
            {
                "enable":true,
                "dev":"eth0.2",
                "ping_ip":"192.168.21.1",可以为空
                "max_ping_times":12.0
            }
        ]
    },
'''