#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'yjbao'

import httplib
import urllib
import cgi
import json
import sys
import vpn_global_var
import vpn_xml 
import vpn_logger
from vpn_file import vpn_file_line_update
from vpn_file import vpn_get_file
from vpn_agent import get_agent_id
reload(sys)
sys.setdefaultencoding('utf8')
print "Content-Type: text/html charset=utf-8 \n"

server_log = vpn_logger.VpnLog("server", vpn_global_var.vpn_log_conf_path)
xml = vpn_xml.VpnXml(vpn_global_var.vpn_xml_path)
anylink_xml = vpn_xml.AnyLinkXml(vpn_global_var.anylink_xml_path)
web_log  = vpn_logger.VpnLog("web", vpn_global_var.vpn_log_conf_path)

def get_cgi_server_addr():
    """ Get vpn server ip and port request 
        req: string """

    form = cgi.FieldStorage()
    if not form.has_key(vpn_global_var.vpn_req_server):
        server_log.write_error("Invalid server address request")
        return False

    return True

def parse_server_addr_reply(reply):
    """ Parse the reply of server address http get 
        reply: string """

    json_res = json.loads(reply)
    status = json_res["status"]
    server_addr = ""

    if not status == "100":
        server_log.write_error("Server address http get reply [status]:%s" % status)
        return None

    if not json_res.has_key("data"):
        server_log.write_error("This device is not registered for VPN")
        return None

    ip = json_res["data"]["vpn_ip"]
    port = json_res["data"]["vpn_port"]

    server_addr = ip + ":" + str(port)
    return server_addr

def server_addr_http_get(url_ip, url_port, req, agent_id):
    """ Send server address http get 
        url_ip: string 
        req: string 
        agent_id: string """

    url = req + "?agentID=" + agent_id
    result = ""
    http_client = None

    try:
        http_client = httplib.HTTPConnection(url_ip, url_port, timeout = 30)
        http_client.request("GET", url)

        response = http_client.getresponse()
        result = response.read()

        if not result:
            server_log.write_error("Server address http get error.[status]:%d [reason]:%s" \
                %(response.status, response.reason))

    except Exception, e:
        server_log.write_error("Server address http get exception: " + repr(e))

    finally:
        if http_client:
            http_client.close()

    #reply = parse_server_addr_reply(result)

    return result

def get_old_server():
    """ Get old server address """

    return xml.get_ele_text(vpn_global_var.vpnxml_tag_server)

def write_xml_server(server_addr):
    """ Set server ip address and port in the xml file 
        server_addr: string """

    xml.set_ele_text(vpn_global_var.vpnxml_tag_server, server_addr)
    xml.write_xml()



if __name__ == '__main__':


    if not get_cgi_server_addr():
        # web_log.write_error("Invalid server address request")
        web_log.write_error("获取失败：无效的请求")
        sys.exit(1)

    agent_id = get_agent_id(name = vpn_global_var.vpn_agentid_path)

    if not agent_id:
        # web_log.write_error("No agentID")
        web_log.write_error("获取失败：序列号错误")
        sys.exit(1)

    cloud_addr = anylink_xml.get_cloud_addr()
    api_port = anylink_xml.get_api_port()
    if "" == cloud_addr or 0 == api_port:
        web_log.write_error("Failed to get cloud address or API port")
        web_log.write_error("云平台地址获取失败")
        sys.exit(1)

    result = server_addr_http_get(cloud_addr, \
                                  api_port, \
                                  vpn_global_var.vpn_http_server, \
                                  agent_id)
    
    if not result:
        # web_log.write_error("Server address http get failed")
        web_log.write_error("获取失败：网络连接问题")
        sys.exit(1)

    reply = parse_server_addr_reply(result)

    if not reply:
        web_log.write_error("获取失败：返回信息错误")
        sys.exit(1)

    name = vpn_get_file(vpn_global_var.vpn_keys_directory, ".conf$")

    if not name:
        # web_log.write_error("Lack of vpn config file")
        web_log.write_error("获取失败：文件错误")
        sys.exit(1)

    old = "^remote "
    new = "remote " + reply.split(':')[0] + " " + reply.split(':')[1]
    file = vpn_global_var.vpn_keys_directory + name

    if not vpn_file_line_update(file, old, new):
        # web_log.write_error("Update vpn config file failed")
        web_log.write_error("获取失败：更新失败")
        sys.exit(1)
 

    write_xml_server(reply)

    # web_log.write_info("Update vpn server successfully. Please Reboot!")
    web_log.write_info("更新成功，请重新启动设备!")




