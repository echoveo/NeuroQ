#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'yjbao'

# xml 
vpn_xml_directory = "../../conf/"
#vpn_xml_directory = "E:\\VSProject\\Python\\Python\\VPN\\"
vpn_xml_name = "VPN.xml"
anylink_xml_name = "AnyLink.xml"
common_xml = "Common.xml"
vpn_xml_path = vpn_xml_directory + vpn_xml_name
anylink_xml_path = vpn_xml_directory + anylink_xml_name
common_xml_path = vpn_xml_directory + common_xml
vpnxml_tag_vpn = "vpn"
vpnxml_attr_n = "n"
vpnxml_attr_ver = "ver"
vpnxml_tag_server = "server"
vpnxml_tag_vpnip = "vpn_ip"
vpnxml_tag_lanip = "lan_ip"
vpnxml_tag_plcip = "plc_ip"
vpnxml_tag_protocol = "protocol"
vpnxml_tag_lanold = "lan_old"
anylinkxml_tag_lan = "LAN"
anylinkxml_attr_ip = "ip"
vpn_version_txt = "vpn_version.txt"


# openvpn and bridge-utils
vpn_exec_directory = "/usr/sbin/"
vpn_usr_directory = "/opt/vpn/"
vpn_keys_directory = "/opt/vpn/keys/"
vpn_ftp_directory = "/opt/vpn/keys/ftp/"
vpn_openvpn_name = "openvpn"
vpn_brctl_name = "brctl"
vpn_vpnlog_name = "openvpn.log"
vpn_conf_name = "client.conf"
vpn_openvpn_path = vpn_exec_directory + vpn_openvpn_name
vpn_brctl_path = vpn_exec_directory + vpn_brctl_name
vpn_vpnlog_path = vpn_usr_directory + vpn_vpnlog_name
vpn_conf_path = vpn_keys_directory + vpn_conf_name

# python and shell
vpn_python_directory = "./"
vpn_bridge_sh_name = "bridge"
vpn_bridge_del_name = "bridge_del"
vpn_bridge_ip_name = "bridge_ifconfig"
vpn_bridge_del_path = vpn_python_directory + vpn_bridge_del_name
vpn_bridge_ip_path = vpn_python_directory + vpn_bridge_ip_name
vpn_bridge_sh_path = vpn_python_directory + vpn_bridge_sh_name

# api
vpn_cloud_addr = "s1.anylinkcloud.com"
vpn_cloud_port = 8600
vpn_http_ipcheck = "/openVPN/verifyAndSaveIp"
vpn_http_server = "/openVPN/getVpn"
vpn_api_cert = "/openVPN/v2/alCertificateInfo"

# anylink web request
vpn_req_bridge = "VPN_bridge"
vpn_req_server = "VPN_server"
# agent
vpn_agentid_dir = "/etc/"
vpn_agentid_name = "devuaid.d"
vpn_agentid_path = vpn_agentid_dir + vpn_agentid_name
vpn_agent_ip = "127.0.0.1"
vpn_agent_port = 10001

# log
vpn_log_conf_directory = "./"
vpn_log_conf_name = "vpn_logging.conf"
vpn_log_conf_path = vpn_log_conf_directory + vpn_log_conf_name
# vpn_log_conf_path = "E:\\VSProject\\Python\\Python\\VPN\\vpn_logging.conf"

# web config
vpn_web_conf_dir = "../config/"
vpn_web_file_var = "global_var.py"
vpn_wev_var_path = vpn_web_conf_dir + vpn_web_file_var

# global variables
vpn_net_dev_br0 = "br0"
vpn_net_dev_br0_1 = "br0:1"
vpn_net_dev_tap0 = "tap0"
vpn_net_dev_eth0 = "eth0"
vpn_net_dev_eth1 = "eth1"

# certifications
vpn_certs_ca = "ca.crt"
vpn_certs_ta = "ta.key"
vpn_suff_crt = ".crt"
vpn_suff_key = ".key"
vpn_cert_anylink = "anylink"

