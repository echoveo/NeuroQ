#!/usr/bin/python
# -*- coding: UTF-8 -*-
# __author__ = 'yjbao'

import xml.etree.ElementTree as ET


class VpnXml(object):
    def __init__(self, path):
        self.xml_path = path
        self.xml_tree = ET.parse(path)
        self.xml_root = self.xml_tree.getroot()

    def get_ele_text(self, tag):
        return self.xml_root.findtext(tag, "")

    def get_ele_attr(self, tag, atti):
        ele = self.xml_root.find(tag)

        if ele:
            return ele.get(atti, "")
        else:
            return ""

    def set_ele_text(self, tag, value):
        ele = self.xml_root.find(tag)
        ele.text = value

    def set_ele_attr(self, tag, atti, value):
        ele = self.xml_root.find(tag)
        ele.set(atti, value)

    def set_root_attr(self, atti, value):
        self.xml_root.set(atti, value)

    def write_xml(self):
        self.xml_tree.write(self.xml_path, encoding="utf-8", xml_declaration=True)


class CommonXml(VpnXml):

    TAG_DATA = "Data"
    TAG_CLOUD_ADDR = "CloudAddress"
    TAG_API_PORT = "ApiPort"

    def __init__(self, path):
        super(CommonXml, self).__init__(path)

    def get_cloud_addr(self):
        return self.xml_root.findtext(CommonXml.TAG_CLOUD_ADDR, "")

    def get_api_port(self):
        port = self.xml_root.findtext(CommonXml.TAG_API_PORT, "")
        if "" == port:
            return 0
        else:
            return int(port)


class AnyLinkXml(VpnXml):

    TAG_ANYLINK = "AnyLink"
    TAG_CLOUD_INFO = "CloudInfo"
    TAG_API_PORT = "./CloudInfo/API_port"
    TAG_CLOUD_ADDR = "./CloudInfo/Address"

    def __init__(self, path):
        super(AnyLinkXml, self).__init__(path)

    def get_cloud_addr(self):
        return self.xml_root.findtext(AnyLinkXml.TAG_CLOUD_ADDR, "")

    def get_api_port(self):
        port = self.xml_root.findtext(AnyLinkXml.TAG_API_PORT, "")
        if "" == port:
            return 0
        else:
            return int(port)


if __name__ == "__main__":
    axml = AnyLinkXml("/opt/sdmwebs/web/conf/AnyLink.xml")
    print axml.xml_root.tag
    print axml.get_cloud_addr()
    print axml.get_api_port()
