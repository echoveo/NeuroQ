#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'yjbao'


from ftplib import FTP
from ftplib import parse227
from ftplib import parse229
import socket


class VFTP(FTP, object):

    def __init__(self, host='', user='', passwd='', acct='',
                 timeout=None):
        if timeout is None:
            super(VFTP, self).__init__(host, user, passwd, acct)
        else:
            super(VFTP, self).__init__(host, user, passwd, acct, timeout)

    def makepasv(self):
        if self.af == socket.AF_INET:
            host, port = parse227(self.sendcmd('PASV'))
            host = self.host
        else:
            host, port = parse229(self.sendcmd('EPSV'), self.sock.getpeername())
        return host, port


