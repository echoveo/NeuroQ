#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'yjbao'

import httplib
import urllib
import json
import sys
import cgi
import os
import vpn_global_var
import vpn_logger
from vpn_agent import get_agent_id
from vpn_net import is_netdevice_exist
from vpn_net import get_ip_address
import vpn_xml
from config import global_var

reload(sys)
sys.setdefaultencoding('utf8')

br_log = vpn_logger.VpnLog("bridge", vpn_global_var.vpn_log_conf_path)
ip_log = vpn_logger.VpnLog("ipchk", vpn_global_var.vpn_log_conf_path)
web_log = vpn_logger.VpnLog("web", vpn_global_var.vpn_log_conf_path)
xml = vpn_xml.VpnXml(vpn_global_var.vpn_xml_path)
anylink_xml = vpn_xml.AnyLinkXml(vpn_global_var.anylink_xml_path)


### ip check

def get_cgi_bridge():
    """ Get local and plc ip address """

    ip_dic = {}

    form = cgi.FieldStorage()
    if not form.has_key("VPN_bridge"):
        ip_log.write_error("Invalid bridge request")
        return None

    ips = form.getvalue("VPN_bridge").strip().split(",", 1)
    lan_ip = ips[0]
    plc_ip = ips[1]

    if (lan_ip == ""):
        ip_log.write_error("Fail: Lack of local ip address")
        return None

    ip_dic["lan"] = lan_ip
    ip_dic["plc"] = plc_ip

    return ip_dic


def get_xml_vpn_ip():
    """ Get vpn ip address in the xml file 
        xml_path: string """

    return xml.get_ele_text(vpn_global_var.vpnxml_tag_vpnip).strip()


def get_vpn_dev_ip(device=vpn_global_var.vpn_net_dev_tap0, flag=1):
    """ Get openvpn ip address 
        device: string 
        flag: number """

    if flag:
        return get_xml_vpn_ip()
    else:
        return get_ip_address(device)


def get_xml_server_addr():
    """ Get server ip address and port in the xml file """

    server_dic = {}

    server = xml.get_ele_text(vpn_global_var.vpnxml_tag_server).split(":")

    server_dic["ip"] = server[0]
    server_dic["port"] = server[1]

    return server_dic


def vpn_ip_http_post(url_ip, req, agent_id):
    """ Send vpn ip http post 
        url_ip: string 
        req: string 
        agent_id: string"""

    server_dic = get_xml_server_addr()
    vpn_ip = get_vpn_dev_ip()
    obj = dict()
    obj["agentID"] = int(agent_id)
    obj["vpnIP"] = server_dic["ip"]
    obj["vpnPort"] = int(server_dic["port"])
    obj["ip_vpnip"] = vpn_ip
    json_data = json.dumps(obj)
    result = ""

    try:
        params = urllib.urlencode(json_data)
        headers = {"Content-type": "application/x-www-form-urlencoded", "Accept": "text/plain"}

        http_client = httplib.HTTPConnection(url_ip, timeout=30)
        http_client.request("POST", req, params, headers)

        response = http_client.getresponse()
        result = response.read()

        if not result:
            ip_log.write_error("Vpn ip http post error.[status]:%d [reason]:%s" \
                               % (response.status, response.reason))

    except Exception, e:
        ip_log.write_error("Vpn ip http post exception: " + e)

    finally:
        if http_client:
            http_client.close()

    return result


def pack_ipcheck_req(agent_id, vpn_ip, lan_ip, plc_ip):
    """ Get a Json formatted string request 
        agent_id: string 
        vpn_ip: string 
        lan_ip: string 
        plc_ip: string """

    obj = {}

    server_dic = get_xml_server_addr()
    obj["agentID"] = int(agent_id)
    obj["vpnIP"] = server_dic["ip"]
    obj["vpnPort"] = int(server_dic["port"])
    obj["ip_anylink"] = lan_ip
    obj["ip_plc"] = plc_ip
    obj["ip_vpnip"] = vpn_ip
    json_data = json.dumps(obj)

    return json_data


def ip_check_http_post(url_ip, url_port, req, agent_id, vpn_ip, lan_ip, plc_ip):
    """ Send ip check http post 
        url_ip: string 
        url_port: number 
        req: string 
        agent_id: string 
        lan_ip: string 
        plc_ip: string """

    params = pack_ipcheck_req(agent_id, vpn_ip, lan_ip, plc_ip)

    result = ""
    http_client = None

    try:
        # params = urllib.urlencode(json_data)
        # headers = {"Content-type": "application/x-www-form-urlencoded", "Accept": "text/plain"}

        http_client = httplib.HTTPConnection(url_ip, url_port, timeout=30)
        http_client.request("POST", req, params)

        response = http_client.getresponse()
        result = response.read()

        if not result:
            ip_log.write_error("Ip check post error.[status]:%d [reason]:%s" \
                               % (response.status, response.reason))

    except Exception, e:
        ip_log.write_error("Ip check http post exception: " + repr(e))

    finally:
        if http_client:
            http_client.close()

    return result


def parse_ip_check_reply(reply):
    """ Parse the reply of ip check http post 
        reply: string 
        res: string """

    json_res = json.loads(reply)
    status = json_res["status"]
    res = ""

    # ip_log.write_info(str(json_res))

    if not status == "100":
        # web_log.write_error("IP check http post reply [status]:%s" % status)
        # web_log.write_error("IP校验失败，[status]:%s" % status)
        res = "IP校验失败，[status]:%s" % status
        return (False, res)

    data = json_res["data"]

    if data != "":
        # web_log.write_error(data.strip())
        res = data + json_res["msg"]
        return (False, res)

    if json_res.has_key("msg"):
        res = json_res["msg"].strip()
        return (True, res)

    return (True, res)


def parse_vpn_ip_reply(reply):
    """ Parse the reply of vpn ip http post
        reply: string """

    pass


def write_xml_checkip(lan_ip, plc_ip):
    """ Write local and plc ip address into xml file 
        lan_ip: string 
        plc_ip: string """

    xml.set_ele_text(vpn_global_var.vpnxml_tag_lanip, lan_ip)
    xml.set_ele_text(vpn_global_var.vpnxml_tag_plcip, plc_ip)
    xml.write_xml()


### bridge

def vpn_net_bridge(bridgesh, net_br, net_dev1, dev_ip1, net_dev2, dev_ip2):
    """ Bridge two net devices 
        bridgesh: string
        net_br: string 
        net_dev1: string 
        net_dev2: string 
        dev_ip1: string 
        dev_ip2: string """

    if not (is_netdevice_exist(net_dev1) and is_netdevice_exist(net_dev2)):
        br_log.write_error("Lack of net devices for bridging")
        return False

    cmd = bridgesh + " "
    cmd += net_br + " " + net_dev1 + " " + dev_ip1 + " " + net_dev2 + " " + dev_ip2 + " "
    cmd += "| grep result: | awk -F ':' '{print$2}'"

    res = os.popen(cmd)
    code = res.read().strip()
    res.close()

    if not code:
        br_log.write_error("Failed to execute bridge shell")
        return False

    return True


def vpn_bridge_ip(bridgesh, net_br, net_dev1, dev_ip1, net_dev2, dev_ip2):
    """ Bridge two net devices 
        bridgesh: string
        net_br: string 
        net_dev1: string 
        net_dev2: string 
        dev_ip1: string 
        dev_ip2: string """

    if not (is_netdevice_exist(net_dev1) and is_netdevice_exist(net_dev2)):
        br_log.write_error("Lack of net devices for bridging")
        return False

    cmd = bridgesh + " "
    cmd += net_br + " " + net_dev1 + " " + dev_ip1 + " " + net_dev2 + " " + dev_ip2 + " "
    cmd += "| grep result: | awk -F ':' '{print$2}'"

    res = os.popen(cmd)
    code = res.read().strip()
    res.close()

    if not code:
        br_log.write_error("Failed to execute bridge_ifconfig shell")
        return False

    return True


def vpn_bridge(lan_ip, vpn_ip):
    """ start the bridge script for the request 
        lan_ip: string 
        vpn_ip: string """

    vpn_eth = vpn_global_var.vpn_net_dev_eth0
    if (global_var.net_muti == "YES"):
        vpn_eth = vpn_global_var.vpn_net_dev_eth1

    flag = is_netdevice_exist(vpn_global_var.vpn_net_dev_br0)

    if flag:
        if not vpn_bridge_ip(vpn_global_var.vpn_bridge_ip_path, \
                             vpn_global_var.vpn_net_dev_br0, \
                             vpn_global_var.vpn_net_dev_tap0, \
                             vpn_ip, \
                             vpn_eth, \
                             lan_ip):
            return False
    else:
        if not vpn_net_bridge(vpn_global_var.vpn_bridge_sh_path, \
                              vpn_global_var.vpn_net_dev_br0, \
                              vpn_global_var.vpn_net_dev_tap0, \
                              vpn_ip, \
                              vpn_eth, \
                              lan_ip):
            return False

    br_ip1 = get_ip_address(vpn_global_var.vpn_net_dev_br0)
    br_ip2 = get_ip_address(vpn_global_var.vpn_net_dev_br0_1)

    if (br_ip1 != lan_ip or br_ip2 != vpn_ip) \
            and (br_ip1 != vpn_ip or br_ip2 != lan_ip):
        br_log.write_error("Invalid bridged ip address")
        return False

    return True


def vpn_detect_status(name):
    """ Detect if the program is running 
        name: string """

    cmd = "ps -ef | grep " + name
    cmd += " | grep -v 'grep'"

    res = os.popen(cmd)
    stat = res.read()
    res.close()

    if not stat:
        return False

    return True


if __name__ == '__main__':

    print "Content-Type: text/html charset=utf-8 \n"

    ip_dic = get_cgi_bridge()

    if not ip_dic:
        # web_log.write_error("Invalid bridge request")
        web_log.write_error("保存失败：无效的请求")
        sys.exit(1)

    write_xml_checkip(ip_dic["lan"], ip_dic["plc"])

    agent_id = get_agent_id(name=vpn_global_var.vpn_agentid_path)

    if not agent_id:
        # web_log.write_error("No agentID")
        web_log.write_error("保存失败：序列号错误")
        sys.exit(1)

    vpn_ip = get_vpn_dev_ip()

    # if not vpn_ip:
    #    # web_log.write_error("Invalid vpn ip address")
    #    web_log.write_error("保存失败：无效的ip地址")
    #    sys.exit(1)

    cloud_addr = anylink_xml.get_cloud_addr()
    api_port = anylink_xml.get_api_port()
    if "" == cloud_addr or 0 == api_port:
        web_log.write_error("Failed to get cloud address or API port")
        web_log.write_error("云平台地址获取失败")
        sys.exit(1)

    result = ip_check_http_post(cloud_addr, \
                                api_port, \
                                vpn_global_var.vpn_http_ipcheck, \
                                agent_id, \
                                vpn_ip, \
                                ip_dic["lan"], \
                                ip_dic["plc"])

    if not result:
        # web_log.write_error("Ip check http post failed")
        web_log.write_error("保存失败：网络连接问题")
        sys.exit(1)

    reply = ""
    (res, reply) = parse_ip_check_reply(result)

    if not res:
        web_log.write_error(reply)
        sys.exit(1)

    if not vpn_detect_status(vpn_global_var.vpn_openvpn_name):
        # web_log.write_info("Valid IP addresses. OpenVPN is not started.")
        if not reply:
            web_log.write_info("保存成功：IP校验成功！")
        else:
            web_log.write_warn("保存成功：" + reply)
        sys.exit(1)

    if not vpn_bridge(ip_dic["lan"], vpn_ip):
        # web_log.write_error("Vpn bridge failed")
        web_log.write_error("保存失败：程序错误")
        sys.exit(1)

    # web_log.write_info("Vpn tunnel is established successfully")
    if not reply:
        web_log.write_info("保存成功，设置IP成功！")
    else:
        web_log.write_warn("设置成功：" + reply)
