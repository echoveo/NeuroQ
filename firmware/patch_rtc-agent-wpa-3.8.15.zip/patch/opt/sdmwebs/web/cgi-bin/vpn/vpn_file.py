#!/usr/bin/python
# -*- coding: UTF-8 -*-
# __author__ = 'yjbao'

import os


def vpn_file_line_idx(file, text):
    """
    Get the line number
    :param file: file name
    :param text: pattern
    :return: line number
    """

    cmd = 'grep -n "' + text + '" ' + file + ' '
    cmd += " | awk -F ':' '{print$1}'"

    res = os.popen(cmd)
    line = res.read().strip()
    res.close()

    if not line:
        return None

    return int(line)


def vpn_file_line_update(path, old, new, count=1):
    """
    Replace the line with new context
    :param path: file path
    :param old: old pattern
    :param new: new string
    :param count: count replacements
    :return: result(bool)
    """
    line = vpn_file_line_idx(path, old)

    if not line:
        return False

    cmd = 'sed -i "' + str(line) + 's/.*/' + new + '/" ' + path

    res = os.popen(cmd)
    code = res.read().strip()
    res.close()

    if code == "":
        return True

    return False

    # ptn = re.compile(old)
    #
    # tar_file = open(path, 'r')
    # tar_old = tar_file.read()
    # tar_file.close()
    #
    # tar_new = re.sub(ptn, new, tar_old, count, flags=re.M)
    # # if tar_new == tar_old:
    # #    return False
    # tar_file = open(path, 'w')
    # tar_file.write(tar_new)
    # tar_file.close()


def vpn_get_file(path, key):
    """
    Get the file name in the path according to the key
    :param path: root directory
    :param key: key word
    :return: file name
    """
    """ 
        path: string
        key: string """

    cmd = "ls " + path
    cmd += ' | grep "' + key + '"'

    res = os.popen(cmd)
    name = res.read().strip()

    return name

    # for root, subs, files in os.walk(path):
    #     for f in files:
    #         if -1 != f.find(key):
    #             return os.path.join(root, f)
    #
    # return "
