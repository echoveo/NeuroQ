#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'yjbao'


import os
import time
import vpn_logger
import vpn_global_var
import vpn_xml
from vpn_agent import get_agent_id
from vpn_bridge import ip_check_http_post
from vpn_bridge import parse_ip_check_reply
from vpn_file import vpn_get_file
from vpn_file import vpn_file_line_idx
from vpn_net import get_ip_address
from vpn_bridge import vpn_bridge

vpn_log = vpn_logger.VpnLog("vpn", vpn_global_var.vpn_log_conf_path)
xml = vpn_xml.VpnXml(vpn_global_var.vpn_xml_path)
anylink_xml = vpn_xml.AnyLinkXml(vpn_global_var.anylink_xml_path)

def vpn_get_vpn_name():
    """ Get the vpn client name """

    cmd = "ls " + vpn_global_var.vpn_keys_directory 
    cmd += ' | grep ".crt$" | grep -v "ca.crt"'

    res = os.popen(cmd)
    name = res.read().strip()

    return name

def openvpn_write_name(name):
    
    xml.set_root_attr(vpn_global_var.vpnxml_attr_n, name)
    xml.write_xml()

def openvpn_write_ip(ip):

    xml.set_ele_text(vpn_global_var.vpnxml_tag_vpnip, ip)
    xml.write_xml()

def openvpn_xml_ips():

    dic = {}
    dic["lan"] = xml.get_ele_text(vpn_global_var.vpnxml_tag_lanip).strip()
    dic["vpn"] = xml.get_ele_text(vpn_global_var.vpnxml_tag_vpnip).strip()
    dic["plc"] = xml.get_ele_text(vpn_global_var.vpnxml_tag_plcip).strip()
    
    return dic

def openvpn_xml_lanip():
    
    return xml.get_ele_text(vpn_global_var.vpnxml_tag_lanip).strip()

def openvpn_xml_vpnip():
    
    return xml.get_ele_text(vpn_global_var.vpnxml_tag_vpnip).strip()

def openvpn_xml_plcip():
    
    return xml.get_ele_text(vpn_global_var.vpnxml_tag_plcip).strip()

def detect_tap_device():
    """ Detect tap0 device individually 
        return: bool """

    cmd = "cat /proc/net/dev | grep tap0 | awk -F ':' '{print$1}'"
    res = os.popen(cmd)
    str = res.read();
    res.close()

    if not str.strip():
        return False

    return True

def openvpn_ip():

    ip = ""

    detect_count = 11
    num = 1
    while (num < detect_count):
        # detect tap0 device
        if detect_tap_device():
            break;
        time.sleep(num)
        num += 1
        
    if (num >= detect_count):
        vpn_log.write_error("There is no tap0 device!")
        openvpn_write_ip(ip)
        return False

    # wait
    #time.sleep(3)
    
    detect_count = 5
    num = 0
    while (num < detect_count):
        # get valid vpn ip address
        ip = get_ip_address(vpn_global_var.vpn_net_dev_tap0)
        if ip.strip():
            break
        num += 1
        time.sleep(3)


    if (num >= detect_count):
        vpn_log.write_error("Invalid tap0 ip address!")
        openvpn_write_ip(ip)
        return False

    openvpn_write_ip(ip)
    vpn_log.write_info("OpenVPN start")
    return True

def openvpn_bridge():
    
    agent_id = get_agent_id(name = vpn_global_var.vpn_agentid_path)

    if not agent_id:
        return False

    ip_dic = {}

    ip_dic = openvpn_xml_ips()

    vpn_ip = ip_dic["vpn"]
    lan_ip = ip_dic["lan"]
    plc_ip = ip_dic["plc"]

    # lan_ip = openvpn_xml_lanip()
    # vpn_ip = openvpn_xml_vpnip()

    # if (not lan_ip) or (not vpn_ip):
    #    vpn_log.write_error("OpenVPN bridging lacking of ip addresses")
    #    return False

    cloud_addr = anylink_xml.get_cloud_addr()
    api_port = anylink_xml.get_api_port()
    if "" == cloud_addr or 0 == api_port:
        vpn_log.write_error("Failed to get cloud address or API port")
        return False

    result = ip_check_http_post(cloud_addr, \
                                api_port, \
                                vpn_global_var.vpn_http_ipcheck, \
                                agent_id, \
                                vpn_ip, \
                                lan_ip, \
                                plc_ip)

    if not result:
        return False

    reply = ""
    (res, reply) = parse_ip_check_reply(result)

    if not res:
        if reply.find("Anylink IP 地址已经被占用") != -1:
            vpn_log.write_error(reply)
            return False

    if reply:
        vpn_log.write_warn(reply)

    if not vpn_ip:
        vpn_log.write_error("OpenVPN bridge lacking of device")
        return False

    if vpn_bridge(lan_ip, vpn_ip):
        vpn_log.write_info("OpenVPN bridge succeeded")
        return True

    return False


def openvpn_start():

    vpn_log.write_info("OpenVPN connecting ...")

    openvpn_write_ip("")

    name = vpn_get_vpn_name()

    if not name:
        vpn_log.write_error("Lack of vpn client certification")
    
    openvpn_write_name(name.split('.')[0])   

    client = vpn_get_file(vpn_global_var.vpn_keys_directory, ".conf$")

    if not client:
        vpn_log.write_error("Lack of vpn client config")

    cmd = "echo 1 > /proc/sys/net/ipv4/ip_forward"
    os.system(cmd)

    try:
        pid = os.fork()

        if 0 == pid:
            cmd = vpn_global_var.vpn_openvpn_path + " " + vpn_global_var.vpn_keys_directory + client
            #cmd += " &>/dev/null"
            #cmd += ' | grep -i "Initialization Sequence Completed"'
            os.popen(cmd)

        else:
            time.sleep(10)
            openvpn_ip()
            openvpn_bridge()


    except Exception, e:
        vpn_log.write_error("OpenVPN start fork exception")

if __name__ == '__main__':

    openvpn_start()
    #openvpn_ip()






