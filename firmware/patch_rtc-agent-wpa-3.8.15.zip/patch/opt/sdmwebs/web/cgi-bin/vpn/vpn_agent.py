#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'yjbao'

import os
import json
import socket
import time
import vpn_logger
import vpn_global_var

agent_log = vpn_logger.VpnLog("agent", vpn_global_var.vpn_log_conf_path)

def get_agent_reply(ip, port, control_cmd):
    """ Get agent response
        ip: string 
        port: number 
        control_cmd: json string """

    addr = (ip, port)
    timeout = 5
    buffer = 1024
    recv_data = ""
    socket.setdefaulttimeout(10)
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    try:
        client.connect(addr)

    except socket.error, arg:
        (errno, err_msg) = arg
        agent_log.write_error("Loading: %s, coding=%d" % (err_msg, errno))
        return None

    try:
        client.send(control_cmd + chr(0x0d) + chr(0x0a))

    except:
        agent_log.write_error("Failed to send data with socket")
        return None

    try:
        client.settimeout(timeout)
        
        while (1):
            temp = client.recv(buffer)
            recv_data += temp
            if len(temp) < buffer:
                break;

    except socket.timeout:
        agent_log.write_error("Receive data timeout: %ds" % timeout)
        client.close()
        return None

    client.close()
    
    return recv_data

def parse_agentid_json(jsonstr):
    """ Parse agent id data replied from agent 
        jsonstr: string """
        
    return json.loads(jsonstr)["resps"]


def pack_agentid_req():
    """ Get a Json formatted string request """

    cmd_dic = {"aid":0, "id":0, "dn":"", "vn":"agent", "vid":0, "cmds":[{"arg":"agentid"}]}

    return json.dumps(cmd_dic)


def get_agent_id(name, ip = "", port = "", mode = 0):
    """ Get agent id
        ip: string 
        port: number 
        control_cmd: json string """

    agent_id = ""

    if mode == 0:
        if not os.path.isfile(name):
            agent_log.write_error("File with agentID is not exist")
            return agent_id

        f = open(name, 'r')
        str = f.readline()
        f.close()
        agent_id = str.strip()

        return agent_id


    agent_reply = ""
    num = 0
    control_cmd = pack_agentid_req()
    while (not agent_reply) and (num < 3):
        agent_reply = get_agent_reply(ip, port, control_cmd)

        if agent_reply:
            resps_list = parse_agentid_json(agent_reply)

            try:
                resps_rs = resps_list[0].get("rs")
                if (resps_rs == 0):
                    if resps_list[0].has_key("aid"):
                        resps_id = resps_list[0].get("aid")
                        agent_id = resps_id
                        return agent_id
                    else:
                        agent_log.write_error("Lack of agent ID")
                else:
                    agent_log.write_error("Fail to get agent id [%d]" % int(resps_rs))
            
            except:
                agent_log.write_error("Invalid Json reply or parsing Json failed")

        num += 1
        time.sleep(1)

    return agent_id

if __name__ == '__main__':

    #id = get_agent_id(vpn_global_var.vpn_agent_ip, \
    #                  vpn_global_var.vpn_agent_port)

    id = get_agent_id(name = vpn_global_var.vpn_agentid_path)

    if id:
        agent_log.write_info("AgentID: " + id);
    



    
    