#!/usr/bin/python
# -*- coding: UTF-8 -*-
# __author__ = 'yjbao'

import os
import sys
import shutil
import time
import vpn_logger
import vpn_global_var as G
import vpn_xml
from vpn_cert import get_certs
from vpn_file import *
from vpn_net import *
# from vpn_file import vpn_get_file
# from vpn_file import vpn_file_line_update
from config import global_var


class VPNClient(object):

    def __init__(self, server_ip="",
                 server_port="",
                 proto="",
                 anylink_ip="",
                 api_ip="",
                 api_port="",
                 token=""):
        self.__server_ip = server_ip
        self.__server_port = server_port
        self.__proto = proto
        self.__anylink_ip = anylink_ip
        self.__api_ip = api_ip
        self.__api_port = api_port
        self.__token = token

        self.__log = vpn_logger.VpnLog("vpn", G.vpn_log_conf_path)
        self.__xml = vpn_xml.VpnXml(G.vpn_xml_path)

        self.__agent_id = ""
        self.__old_server = ""
        self.__old_proto = ""
        self.__lan_ip = ""
        self.__conf = ""

    # def __detect_br_device(self):
    #     """ Detect br0 device individually
    #         return: bool """
    #
    #     cmd = "cat /proc/net/dev | grep br0 | awk -F ':' '{print$1}'"
    #     res = os.popen(cmd)
    #     str = res.read()
    #     res.close()
    #
    #     if not str.strip():
    #         return False
    #
    #     return True

    def __openvpn_write_name(self, name):
        self.__xml.set_root_attr(G.vpnxml_attr_n, name)
        self.__xml.write_xml()

    def __openvpn_write_ip(self, ip):
        self.__xml.set_ele_text(G.vpnxml_tag_vpnip, ip)
        self.__xml.write_xml()

    def __openvpn_write_server(self, server_addr):
        self.__xml.set_ele_text(G.vpnxml_tag_server, server_addr)
        self.__xml.write_xml()

    def __openvpn_write_lanip(self, lan_ip):
        self.__xml.set_ele_text(G.vpnxml_tag_lanip, lan_ip)
        self.__xml.write_xml()

    def __openvpn_write_lanold(self, lan_old):
        self.__xml.set_ele_text(G.vpnxml_tag_lanold, lan_old)
        self.__xml.write_xml()

    def __openvpn_write_proto(self, proto):
        self.__xml.set_ele_text(G.vpnxml_tag_protocol, proto)
        self.__xml.write_xml()

    def __get_agent_id(self, name):
        """
        Read agent ID
        :param name: file name
        :return: result(bool), error string
        """
        self.__log.write_info("Start to get agent id")
        if not os.path.isfile(name):
            return False, "Lack of agent id"

        f = open(name, 'r')
        res = f.readline()
        f.close()
        self.__agent_id = res.strip()

        return True, ""

    def __get_vpn_info(self):
        """
        Get information of VPN connection
        :return: dict, error string
        """
        self.__log.write_info("Start to get old vpn information")
        self.__old_server = self.__xml.get_ele_text(G.vpnxml_tag_server).strip()
        self.__old_proto = self.__xml.get_ele_text(G.vpnxml_tag_protocol).strip()
        # anylink_xml = vpn_xml.VpnXml(G.anylink_xml_path)
        vpn_eth = G.vpn_net_dev_eth0
        if global_var.net_muti == "YES":
            vpn_eth = G.vpn_net_dev_eth1
        ip_lan = get_ip_address(vpn_eth)
        if "" == ip_lan:
            return False, "Failed to get ip address of LAN"
        # dic[_LAN_IP] = anylink_xml.get_ele_attr(G.anylinkxml_tag_lan,
        #                                         G.anylinkxml_attr_ip)
        # if "" == dic[_LAN_IP]:
        self.__lan_ip = ip_lan
        return True, ""

    def __detect_certs(self):
        """
        Detect if there are certifications
        :return: result(bool)
        """
        for root, dirs, files in os.walk(G.vpn_keys_directory):
            for f in files:
                if -1 != f.find(G.vpn_certs_ca):
                    return True
            break

        return False

    def __update_certs(self):
        """
        Update certifications of VPN
        :return: result(bool), error string
        """
        self.__log.write_info("Start to update certifications(%s)" % self.__api_ip)
        res, err = get_certs(self.__server_ip, self.__server_port, self.__proto,
                             self.__api_ip, self.__api_port, self.__agent_id, self.__token)
        if not res:
            return False, err

        # if not os.path.isfile(G.vpn_conf_path):
        #     try:
        #         shutil.copyfile(G.vpn_conf_name, G.vpn_conf_path)
        #     except Exception:
        #         try:
        #             shutil.copyfile("/opt/sdmwebs/web/cgi-bin/vpn/" + G.vpn_conf_name, G.vpn_conf_path)
        #         except Exception:
        #             return False, "Lack of client.conf"

        return True, ""

    def __get_vpn_conf(self):
        """
        Get name of VPN configuration file
        :return: file name, error string
        """
        self.__conf = vpn_get_file(G.vpn_keys_directory, ".conf$")
        if not self.__conf:
            try:
                shutil.copyfile(G.vpn_conf_name, G.vpn_conf_path)
            except Exception:
                try:
                    shutil.copyfile("/opt/sdmwebs/web/cgi-bin/vpn/" + G.vpn_conf_name, G.vpn_conf_path)
                except Exception:
                    return False, "Lack of vpn client config"
            self.__conf = G.vpn_conf_name

        return True, ""

    def __update_info(self):
        """
        Update vpn configuration file
        :return: result(bool), error string
        """
        self.__log.write_info("Start to update configuration file")
        last_proto = self.__old_proto
        last_server = self.__old_server
        conf_file = ""

        new_server = self.__server_ip + ":" + self.__server_port
        if last_server.lower() != new_server.lower():
            old = "^remote "
            new = "remote " + self.__server_ip + " " + self.__server_port
            conf_file = G.vpn_keys_directory + self.__conf
            if not vpn_file_line_update(conf_file, old, new):
                return False, "Failed to update vpn server address"

        if last_proto.lower() != self.__proto.lower():
            old = "^proto "
            new = "proto " + self.__proto
            if not vpn_file_line_update(conf_file, old, new):
                return False, "Failed to update vpn protocol"

        return True, ""

    def __vpn_net_bridge(self, bridgesh, net_br, net_dev1, dev_ip1, net_dev2, dev_ip2):
        """
        Bridge two net devices
        :param bridgesh: shell script name
        :param net_br: bridge net device
        :param net_dev1: net device1
        :param dev_ip1:  ip address
        :param net_dev2: net device2
        :param dev_ip2: ip address
        :return: result(bool), string
        """

        if not (is_netdevice_exist(net_dev1) and is_netdevice_exist(net_dev2)):
            # br_log.write_error("Lack of net devices for bridging")
            return False, "Lack of net devices for bridging"

        cmd = bridgesh + " "
        cmd += net_br + " " + net_dev1 + " " + dev_ip1 + " " + net_dev2 + " " + dev_ip2 + " "
        cmd += "| grep result: | awk -F ':' '{print$2}'"

        res = os.popen(cmd)
        code = res.read().strip()
        res.close()

        if not code:
            # br_log.write_error("Failed to execute bridge shell")
            return False, "Failed to execute bridge shell script"

        return True, ""

    def __vpn_bridge_ip(self, bridgesh, net_br, net_dev1, dev_ip1, net_dev2, dev_ip2):
        """
        Bridge two net devices when bridge net device has existed
        :param bridgesh: shell script name
        :param net_br: bridge net device
        :param net_dev1: net device1
        :param dev_ip1:  ip address
        :param net_dev2: net device2
        :param dev_ip2: ip address
        :return: result(bool), string
        """
        """ Bridge two net devices
            bridgesh: string
            net_br: string
            net_dev1: string
            net_dev2: string
            dev_ip1: string
            dev_ip2: string """

        if not (is_netdevice_exist(net_dev1) and is_netdevice_exist(net_dev2)):
            # br_log.write_error("Lack of net devices for bridging")
            return False, "Lack of net devices for bridging"

        cmd = bridgesh + " "
        cmd += net_br + " " + net_dev1 + " " + dev_ip1 + " " + net_dev2 + " " + dev_ip2 + " "
        cmd += "| grep result: | awk -F ':' '{print$2}'"

        res = os.popen(cmd)
        code = res.read().strip()
        res.close()

        if not code:
            # br_log.write_error("Failed to execute bridge_ifconfig shell")
            return False, "Failed to execute bridge_ifconfig shell script"

        return True, ""

    def __vpn_bridge(self, lan_ip, vpn_ip):
        """
        start the bridge script for the request
        :param lan_ip:
        :param vpn_ip:
        :return: result(bool), error string
        """
        vpn_eth = G.vpn_net_dev_eth0
        if global_var.net_muti == "YES":
            vpn_eth = G.vpn_net_dev_eth1

        flag = is_netdevice_exist(G.vpn_net_dev_br0)

        if flag:
            res, err = self.__vpn_bridge_ip(G.vpn_bridge_ip_path,
                                            G.vpn_net_dev_br0,
                                            G.vpn_net_dev_tap0,
                                            vpn_ip,
                                            vpn_eth,
                                            lan_ip)
            if not res:
                return False, err
        else:
            res, err = self.__vpn_net_bridge(G.vpn_bridge_sh_path,
                                             G.vpn_net_dev_br0,
                                             G.vpn_net_dev_tap0,
                                             vpn_ip,
                                             vpn_eth,
                                             lan_ip)
            if not res:
                return False, err

        br_ip1 = get_ip_address(G.vpn_net_dev_br0)
        br_ip2 = get_ip_address(G.vpn_net_dev_br0_1)

        if (br_ip1 != lan_ip or br_ip2 != vpn_ip) \
                and (br_ip1 != vpn_ip or br_ip2 != lan_ip):
            # br_log.write_error("Invalid bridged ip address")
            return False, "Invalid bridged ip address"

        return True, err

    def __openvpn_ip(self):
        ip = ""

        detect_count = 11
        num = 1
        while num < detect_count:
            # detect tap0 device
            if detect_tap_device():
                break
            time.sleep(num)
            num += 1

        if num >= detect_count:
            # vpn_log.write_error("There is no tap0 device!")
            self.__openvpn_write_ip(ip)
            return False, "There is no tap0 device"

        # wait
        # time.sleep(3)

        detect_count = 5
        num = 0
        while num < detect_count:
            # get valid vpn ip address
            ip = get_ip_address(G.vpn_net_dev_tap0).strip()
            if ip:
                break
            num += 1
            time.sleep(3)

        if num >= detect_count:
            # vpn_log.write_error("Invalid tap0 ip address!")
            self.__openvpn_write_ip(ip)
            return False, "Invalid tap0 ip address"

        self.__openvpn_write_ip(ip)
        # vpn_log.write_info("OpenVPN start")
        return True, ""

    def __openvpn_bridge(self):
        lan_ip = self.__anylink_ip
        vpn_ip = self.__xml.get_ele_text(G.vpnxml_tag_vpnip).strip()

        # if (not lan_ip) or (not vpn_ip):
        #    vpn_log.write_error("OpenVPN bridging lacking of ip addresses")
        #    return False

        res, err = self.__vpn_bridge(lan_ip, vpn_ip)
        if not res:
            return False, err

        # vpn_log.write_info("OpenVPN bridge succeeded")
        return True, ""

    def __openvpn_start(self):
        """
        Start OpenVPN
        :return: result(bool), error string
        """
        cmd = "echo 1 > /proc/sys/net/ipv4/ip_forward"
        os.system(cmd)

        try:
            pid = os.fork()

            if 0 == pid:
                cmd = G.vpn_openvpn_path + " " + G.vpn_keys_directory + self.__conf
                # print cmd
                # cmd += " &>/dev/null"
                # cmd += ' | grep -i "Initialization Sequence Completed"'
                os.popen(cmd)
                sys.exit(0)

            else:
                time.sleep(10)
                res, err = self.__openvpn_ip()
                if not res:
                    return False, err
                self.__log.write_info("OpenVPN start(%s, %s, %s)" %
                                      (self.__server_ip, self.__server_port, self.__proto))
                res, err = self.__openvpn_bridge()
                if not res:
                    return False, err
                self.__log.write_info("OpenVPN bridge succeeded")

        except Exception, e:
            # vpn_log.write_error("OpenVPN start fork exception: " + repr(e))
            return False, "OpenVPN start fork exception: " + repr(e)

        return True, ""

    def start(self):
        eno = 0

        self.__log.write_info("========== Start ==========")

        # get agent id
        eno -= 1
        res, err = self.__get_agent_id(G.vpn_agentid_path)
        if not res:
            self.__log.write_error(err)
            return eno

        # get vpn information
        eno -= 1
        res, err = self.__get_vpn_info()
        if not res:
            self.__log.write_error(err)
            return eno

        # detect vpn server domain
        eno -= 1
        if -1 == self.__old_server.find(self.__server_ip) or not self.__detect_certs():
            res, err = self.__update_certs()
            if not res:
                self.__log.write_error(err)
                return eno
        self.__openvpn_write_server(self.__server_ip + ":" + self.__server_port)

        # update vpn configuration
        eno -= 1
        res, err = self.__get_vpn_conf()
        if not res:
            self.__log.write_error(err)
            return eno
        self.__openvpn_write_name(self.__conf.split('.')[0])

        eno -= 1
        res, err = self.__update_info()
        if not res:
            self.__log.write_error(err)
            return eno
        self.__openvpn_write_lanip(self.__anylink_ip)
        self.__openvpn_write_proto(self.__proto)
        self.__openvpn_write_lanold(self.__lan_ip)

        eno -= 1
        res, err = self.__openvpn_start()
        if not res:
            self.__log.write_error(err)
            return eno

        self.__log.write_info("========== End ==========")
        return 0

    def stop(self):
        progress = G.vpn_openvpn_name

        cmd = "ps -ef | grep '" + progress + "' | grep -v 'grep' | awk '{print$1}'"

        res = os.popen(cmd)
        pid = res.read()
        res.close()

        if not pid.strip():
            self.__log.write_warn("OpenVPN is not running")
        else:
            cmd = "kill -9 " + pid.strip()

            res = os.system(cmd)

            if res != 0:
                self.__log.write_error("OpenVPN stop failed")
                return -1

            self.__log.write_info("OpenVPN is stopped")

        ver = 1
        if os.path.isfile(G.vpn_version_txt):
            with open(G.vpn_version_txt) as f:
                ver = int(f.read().strip(" \n\r").split(".")[0])

        if is_netdevice_exist(G.vpn_net_dev_br0) and 1 < ver:
            vpn_eth = G.vpn_net_dev_eth0
            if global_var.net_muti == "YES":
                vpn_eth = G.vpn_net_dev_eth1
            xml = vpn_xml.VpnXml(G.vpn_xml_path)
            lan_ip = xml.get_ele_text(G.vpnxml_tag_lanold)
            cmd = G.vpn_bridge_del_path + " "
            cmd += G.vpn_net_dev_br0 + " " + vpn_eth + " " + lan_ip
            os.system(cmd)

        return 0
