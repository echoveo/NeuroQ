#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'yjbao'

import os
import shutil
import httplib
import json
import vpn_logger
import vpn_global_var as G
from vpn_ftp import VFTP as FTP

cert_log = vpn_logger.VpnLog("cert", G.vpn_log_conf_path)
_PATH = "url"
_KEY = "key"
_CRT = "crt"
_CA_PATH = "caurl"
_CA = "ca"
_TA = "ta"
_FTP_USR = "fuser"
_FTP_PWD = "fpasd"
_ERR = "error"


def ftp_info(api_addr, api_port, req, agent_id, vpn_ip, vpn_port, proto, token):
    url = req + "?token=%s&serialnumber=%s&vpn_ip=%s&vpn_port=%d&protocol=%s" % \
          (token, agent_id, vpn_ip, int(vpn_port), proto)
    http_client = None
    reply = dict()

    try:
        http_client = httplib.HTTPConnection(api_addr, int(api_port), timeout=30)
        http_client.request("GET", url)

        response = http_client.getresponse()
        result = response.read()

        if not result:
            return None, \
                   "Server address http get error.[status]:%d [reason]:%s" % (response.status, response.reason)
            # cert_log.write_error("Server address http get error.[status]:%d [reason]:%s"
            #                      % (response.status, response.reason))

    except Exception, e:
        # server_log.write_error("Server address http get exception: " + repr(e))
        return None, "Server address http get exception: " + repr(e)

    finally:
        if http_client:
            http_client.close()



    json_res = json.loads(result)
    try:
        status = json_res["status"].encode("utf-8")
        if "100" != status:
            return None, "Get certification API: status[%s] - %s" % (status, json_res["msg"].encode("utf-8"))

        if _ERR in json_res["data"]:
            return None, json_res["data"][_ERR].encode("utf-8")
        # if _PATH in json_res["data"]:
        reply[_PATH] = json_res["data"][_PATH].encode("utf-8")
        # if _KEY in json_res["data"]:
        reply[_KEY] = json_res["data"][_KEY].encode("utf-8")
        # if _CRT_PATH in json_res["data"]:
        reply[_CA_PATH] = json_res["data"][_CA_PATH].encode("utf-8")
        # if _CRT in json_res["data"]:
        reply[_CRT] = json_res["data"][_CRT].encode("utf-8")
        # if _TA in json_res["data"]:
        reply[_TA] = json_res["data"][_TA].encode("utf-8")
        # if _CA in json_res["data"]:
        reply[_CA] = json_res["data"][_CA].encode("utf-8")
        # if _FTP_USR in json_res["data"]:
        reply[_FTP_USR] = json_res["data"][_FTP_USR].encode("utf-8")
        # if _FTP_PWD in json_res["data"]:
        reply[_FTP_PWD] = json_res["data"][_FTP_PWD].encode("utf-8")
    except Exception, e:
        return None, "Get certification: Invalid reply - " + repr(e)

    return reply, ""


def download_file(ftp, local_file, remote_file):
    fd = open(local_file, "wb")
    ftp.retrbinary("RETR %s" % remote_file, fd.write)
    fd.close()


def get_certs(server, vpn_port, proto, api_addr, api_port, agent_id, token):

    data, err = ftp_info(api_addr, api_port, G.vpn_api_cert, agent_id, server, vpn_port, proto, token)
    if data is None:
        return False, err

    ftp = FTP()

    try:
        ftp.connect(server)
    except Exception, e:
        return False, "Failed to connect to ftp server(%s) - %s" % (server, repr(e))

    try:
        ftp.login(data[_FTP_USR], data[_FTP_PWD])
    except Exception, e:
        return False, "Failed to login to ftp server(%s) - %s" % (server, repr(e))

    entries = ftp.nlst()
    if "OpenVPN" not in entries:
        return False, "There is no 'OpenVPN' directory in the ftp server"

    if not os.path.exists(G.vpn_ftp_directory.rstrip("/")):
        os.mkdir(G.vpn_ftp_directory.rstrip("/"))
    else:
        shutil.rmtree(G.vpn_ftp_directory.rstrip("/"))
        os.mkdir(G.vpn_ftp_directory.rstrip("/"))

    # try:
    #     ftp.cwd(data[_CA_PATH])
    # except Exception, e:
    #     return False, "Failed to change directory: %s - %s" % (data[_PATH], repr(e))

    files = ftp.nlst(data[_CA_PATH])
    ca_crt = data[_CA_PATH] + G.vpn_certs_ca
    if ca_crt in files:
        f = G.vpn_ftp_directory + G.vpn_certs_ca
        download_file(ftp, f, ca_crt)
    else:
        return False, "Failed to download 'ca.crt' from the ftp server"

    ta_key = data[_CA_PATH] + G.vpn_certs_ta
    if ta_key in files:
        f = G.vpn_ftp_directory + G.vpn_certs_ta
        download_file(ftp, f, ta_key)
    else:
        return False, "Failed to download 'ta.key' from the ftp server"

    files = ftp.nlst(data[_PATH])
    crt_file = G.vpn_cert_anylink + "_" + agent_id + G.vpn_suff_crt
    anylink_crt = data[_PATH] + crt_file
    if anylink_crt in files:
        f = G.vpn_ftp_directory + G.vpn_cert_anylink + G.vpn_suff_crt
        download_file(ftp, f, anylink_crt)
    else:
        return False, "Failed to download '%s' from the ftp server" % crt_file

    key_file = G.vpn_cert_anylink + "_" + agent_id + G.vpn_suff_key
    anylink_key = data[_PATH] + key_file
    if anylink_key in files:
        f = G.vpn_ftp_directory + G.vpn_cert_anylink + G.vpn_suff_key
        download_file(ftp, f, anylink_key)
    else:
        return False, "Failed to download '%s' from the ftp server" % key_file

    ftp.quit()

    shutil.copyfile(G.vpn_ftp_directory + G.vpn_certs_ca,
                    G.vpn_keys_directory + G.vpn_certs_ca)
    shutil.copyfile(G.vpn_ftp_directory + G.vpn_certs_ta,
                    G.vpn_keys_directory + G.vpn_certs_ta)
    shutil.copyfile(G.vpn_ftp_directory + G.vpn_cert_anylink + G.vpn_suff_crt,
                    G.vpn_keys_directory + G.vpn_cert_anylink + G.vpn_suff_crt)
    shutil.copyfile(G.vpn_ftp_directory + G.vpn_cert_anylink + G.vpn_suff_key,
                    G.vpn_keys_directory + G.vpn_cert_anylink + G.vpn_suff_key)

    return True, ""


if __name__ == "__main__":

    res, err = get_certs("vsm.anylinkcloud.com", "2001", "udp",
                         "192.168.100.44", "8800", "123", "975f804c-4a77-4231-b300-79f990cbdebe")
    print err


