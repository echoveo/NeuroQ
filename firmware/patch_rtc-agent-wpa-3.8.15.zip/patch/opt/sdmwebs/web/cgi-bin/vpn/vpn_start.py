#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'yjbao'

import sys
import os
from vpn_logger import VpnLog
import vpn_global_var as G
from VPNClient import VPNClient
from vpn_start_v1 import openvpn_start

if __name__ == '__main__':
    eno = -100
    vpn_log = VpnLog("params", G.vpn_log_conf_path)

    eno -= 1
    args_cnt = len(sys.argv)
    ver = 1
    if os.path.isfile(G.vpn_version_txt):
        with open(G.vpn_version_txt) as f:
            ver = int(f.read().strip(" \n\r").split(".")[0])

    if 1 == ver:
        openvpn_start()
    elif 2 == ver:
        if 8 > args_cnt:
            vpn_log.write_error("Too few script parameters")
            sys.exit(eno)

        server_ip = sys.argv[1].strip()
        server_port = sys.argv[2].strip()
        protocol = sys.argv[3].strip()
        anylink_ip = sys.argv[4].strip()
        api_ip = sys.argv[5].strip()
        api_port = sys.argv[6].strip()
        token = sys.argv[7].strip()

        vpn_log.write_info(">> python %s %s %s %s %s %s %s %s " % (sys.argv[0],
                                                                   server_ip,
                                                                   server_port,
                                                                   protocol,
                                                                   anylink_ip,
                                                                   api_ip,
                                                                   api_port,
                                                                   token))
        eno = VPNClient(server_ip, server_port, protocol, anylink_ip, api_ip, api_port, token).start()
        sys.exit(eno)
    else:
        vpn_log.write_info("VPN is None")

