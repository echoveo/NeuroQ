#!/usr/bin/python
# -*- coding: UTF-8 -*-
# __author__ = 'yjbao'


import os


def get_net_devices():
    """ Get the list of network devices
        return:  list """

    cmd = "cat /proc/net/dev | grep -v Inter | grep -v face | awk -F ':' '{print$1}'"
    res = os.popen(cmd)
    outlines = res.readlines()
    res.close()
    devs_list = []
    for dev in outlines:
        dev = dev.strip()
        devs_list.append(dev)

    return devs_list


def is_netdevice_exist(device):
    """ Detect the device whether or not exists
        device: string
        return: bool """

    devs_list = get_net_devices()
    if device in devs_list:
        return True

    return False
def get_ip_address(device):
    """
    Get ip address of net device
    :param device: net device
    :return: ip address
    """
    cmd = "ifconfig " + device + " | grep \"inet addr\" | awk -F ':' '{print$2}' | awk '{print$1}'"
    res = os.popen(cmd)
    return res.read().strip()

def get_dev_ip_dic():
    """ Get devices' ip addresses in the devices list 
        return: dictionary"""   

    devs_list = get_net_devices()
    ip_dic = {}
    for device in devs_list:
        ip = get_ip_address(device)
        ip_dic[device] = ip

    return ip_dic

def detect_tap_device():
    """ Detect tap0 device individually
        return: bool """

    cmd = "cat /proc/net/dev | grep tap0 | awk -F ':' '{print$1}'"
    res = os.popen(cmd)
    str = res.read()
    res.close()

    if not str.strip():
        return False

    return True

