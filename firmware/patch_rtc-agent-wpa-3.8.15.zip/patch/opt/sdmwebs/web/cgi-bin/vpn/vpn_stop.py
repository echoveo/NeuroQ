#!/usr/bin/python
# -*- coding: UTF-8 -*-
# __author__ = 'yjbao'


import sys
from VPNClient import VPNClient


if __name__ == '__main__':

    eno = VPNClient().stop()
    sys.exit(eno)

