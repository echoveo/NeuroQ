#!/usr/bin/python
# -*- coding: UTF-8 -*-
import time
import os
import xml.etree.ElementTree as ET


def write(treeNode, path):
    # version_node = treeNode.find("Version")
    # version_node.text = str(int(version_node.text) + 1)
    treeNode.write(path, encoding='utf-8')
    os.system("sync")


def init_save(treeNode, rootNode, path, nextVersion):
    # version_node = ET.Element('Version')
    # version_node.text = nextVersion
    # rootNode.insert(0, version_node)
    treeNode.write(path, encoding='utf-8')
    os.system("sync")