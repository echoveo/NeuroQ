#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xhZhang'

import Cookie
import os
import sys
import xml.etree.ElementTree as ET
from rexml import updateVersion


class reusexml:
    '''使用xml'''
    xml_tree = None
    filepath = ''

    def __init__(self, filepath):
        '''获取cookie'''
        if 'HTTP_COOKIE' in os.environ:
            cookie_string = os.environ.get('HTTP_COOKIE')
            c = Cookie.SimpleCookie()
            c.load(cookie_string)
            data = c['AnyLinkLan'].value

        if os.path.exists(filepath):
            self.xml_tree = ET.parse(filepath)
            self.filepath = filepath
        else:
            if data == "English":
                print filepath + "Not exist"
            else:
                print filepath + "不存在"
            sys.exit(0)

    def getElement(self, tag):
        node = self.xml_tree.find(tag)
        return node

    def createElement(self, ftag, stag, val=None):
        element = ET.Element(stag)
        if val != None:
            element.text = val
        ftag.append(element)

    def getTagVal(self, tag):
        '''获取xml中tag的值'''
        node = self.xml_tree.find(tag)
        if node is not None:
            return node.text
        else:
            return -1

    def setTagVal(self, tag, val):
        '''获取cookie'''
        if 'HTTP_COOKIE' in os.environ:
            cookie_string = os.environ.get('HTTP_COOKIE')
            c = Cookie.SimpleCookie()
            c.load(cookie_string)
            data = c['AnyLinkLan'].value
        '''设置xml中tag的值'''
        node = self.xml_tree.find(tag)
        if node is not None:
            node.text = val
        else:
            if data == "English":
                print "Unfound node" + tag
            else:
                print "未找到节点" + tag

    def savexml(self):
        '''保存xml'''
        updateVersion.write(self.xml_tree, self.filepath)
        # self.xml_tree.write(self.filepath,
        #                     encoding='utf-8',
        #                     xml_declaration='true')

    def displayxml(self):
        '''展示xml'''
        ET.dump(self.xml_tree)


class XMLBase(object):
    def __init__(self, path):
        self.__path = path
        self.__tree = ET.parse(self.__path)
        self.__root = self.__tree.getroot()

    def write_xml(self):
        # TODO backup
        self.__tree.write(self.__path,
                          encoding="utf-8",
                          xml_declaration='true')

    def find_node(self, tag):
        return self.__tree.find(tag)

    def findall_node(self, tag):
        return self.__tree.findall(tag)

    def get_node_attr(self, tag, attrib):
        return self.__tree.find(tag).get(attrib)

    def get_root_attr(self, attrib):
        return self.__root.get(attrib)

    def set_root_attr(self, attrib, val):
        self.__root.set(attrib, val)

    def add_element(self, elementname):
        pass


if __name__ == "__main__":
    a = XMLBase('C:\Users\LiuHao\Desktop\config.xml')
    # print a.get_node_text('agent')
    print a.get_root_attr('id')
