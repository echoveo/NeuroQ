#!/usr/bin/python
# -*- coding: UTF-8  -*-
__author__ = 'kali'

import cgi
import cgitb
import os
import sys
import xml.etree.ElementTree as ET
import commands
import traceback
import json
from Log import Loginfo
from config import global_var




reload(sys)
cgitb.enable()
sys.setdefaultencoding('utf8')

print "Content-Type: text/html charset=utf-8 \n"

fileitem = None
cgi_session_id = None
cgi_update_cmd = ''

g_update_tmp_path = "/mnt/mmc/update/fromwebui"


def run_cmd(cmd):   
    (status, output) = commands.getstatusoutput(cmd)
    if output != "":
        return output.strip()
    else:
        return ""


# Generator to buffer file chunks
def fbuffer(f, chunk_size=10000):
    while True:
        chunk = f.read(chunk_size)
        if not chunk: break
        yield chunk

def get_cgi_data():
    global cgi_update_cmd,cgi_session_id,fileitem
    form = cgi.FieldStorage()
    
    cgi_update_cmd = form.getvalue('update_cmd','')
    cgi_session_id = form.getvalue('upload_session',"")
    if cgi_update_cmd== 'upload':
        fileitem = form['filename_patch']
    #form['filename_patch']

def get_cgi_file():
    '''获取界面数据'''
    global fileitem,cgi_session_id
    
    # 检测文件是否上传
    if fileitem.filename:
        # 去掉文件路径，获取文件名称
        
        os.system("mkdir -p %s" % (g_update_tmp_path))
        os.system("rm -rf %s/*" % (g_update_tmp_path))
        # 去掉文件路径，获取文件名称
        fn = os.path.basename(fileitem.filename)
        #open("%s/%s" % (g_update_tmp_path,fn), 'wb').write(fileitem.file.read())
        f = open("%s/%s" % (g_update_tmp_path,fn), 'wb', 10000)

        # Read the file in chunks
        for chunk in fbuffer(fileitem.file):
            f.write(chunk)
        f.close()
        #return True,"OKOK"
        (check_result,check_msg) = check_file(fn)
        if check_result == True:
            os.system("echo %s > %s/upload_session" % (cgi_session_id,g_update_tmp_path))
        
        return check_result,check_msg
        
        # message = '文件"' + fn + '" 上传成功！'

    else:
        message = 'file content is empty'
        return False,message
    return False,"unknow errors"






def find_exists_file(find_path,find_filename='install.sh'):
    files = os.listdir(find_path)
    #print "find_filename=",find_filename
    #print files

    for filename in files:
        s_path = os.path.join(find_path,filename)
        #print 'process:',filename
        if os.path.isfile(s_path) and find_filename in s_path:
            found_flag = True
            return True,s_path
        if os.path.isdir(s_path):
            #print "into new path",s_path
            (ret,ret_path) = find_exists_file(s_path,find_filename)
            if ret:
                return (ret,ret_path)
    return False,""


def check_file(filename):
    found_result = False
    #unzip
    
    run_cmd("cd %s && unzip -o %s;rm -f %s " % (g_update_tmp_path,filename,filename))
    
    (found_result,found_full_filename) = find_exists_file(g_update_tmp_path,find_filename='changelist')
    if found_result == True:        
        s_changelist = run_cmd("cat %s" % (found_full_filename))
        return True,s_changelist
    else:
        # Check is OTA package?
        (found_result,found_full_filename) = find_exists_file(g_update_tmp_path,find_filename='info.json')
        if found_result == True:
            return True,run_cmd("cat %s" % (found_full_filename))
        else:
            return False,"Patch invalid or unzip fail!Pls try again."

def check_session(upload_session):
    current_upload_session = run_cmd("cat  %s/upload_session" % (g_update_tmp_path))
    if current_upload_session == upload_session:
        #session相同，可以执行更新
        return True      
    else:
        return False

#upload_session = session13434523423
#upload_session是前端提供的，和最近一次上传的更新包对应的唯一id
def install_patch(upload_session,log):
    if not check_session(upload_session):
        return False,"session invalid"
    #session相同，可以执行更新

    if is_OTA_package(upload_session,log):
        return install_OTA_package(upload_session,log)

    (found_result,found_full_filename) = find_exists_file(g_update_tmp_path)
    if found_result == True:
        (unzip_path,filename) = os.path.split(found_full_filename)
        install_result = run_cmd("cd %s;dos2unix install.sh;chmod +x ./install.sh;./install.sh" % (unzip_path))
        if "UPDATE_SUCCESS" in install_result:
            return True,install_result
        else:
            return False,install_result #"update patch fail: %s" % (install_result)
    else:
        return False,"install.sh not found"
   


'''
支持OTA包的更新
'''
def is_OTA_package(upload_session,log):
     
    (found_result,found_full_filename) = find_exists_file(g_update_tmp_path,"info.json")
    #print "is_OTA_package found_result,found_full_filename",found_result,found_full_filename
    if not found_result:
        return False
    load_info_json = None
    (found_result,found_full_filename) = find_exists_file(g_update_tmp_path,"info.json")
    with open(found_full_filename,'r') as load_f:
        load_info_json = json.load(load_f)
    if load_info_json["fileType"] == "OTA":
        return True
    else:
        return False
   

def install_OTA_package(upload_session,log):
    load_info_json = None
    (found_result,found_full_filename) = find_exists_file(g_update_tmp_path,"info.json")
    with open(found_full_filename,'r') as load_f:
        load_info_json = json.load(load_f)
    #load_info_json["newVersion"]
    #step 1: Find the .zip file and unzip it.
    (found_result,found_full_zip_filename) = find_exists_file(g_update_tmp_path,".zip")    
    if not found_result:
        return False,".zip not exists!"
    
    (unzip_path,zip_filename) = os.path.split(found_full_zip_filename)
    (found_md5_py,md5_py_filename)  = find_exists_file(g_update_tmp_path,"md5.py")
    if found_md5_py:
        md5_1 = run_cmd("cd %s&&python md5.py %s" %(unzip_path,zip_filename))
        md5_2 = run_cmd("cat %s/md5" %(unzip_path))
        if md5_1 != md5_2:
            return False,"md5 check fail! %s != %s" %(md5_1,md5_2)
    #step 2: unzip
    run_cmd("cd %s && unzip -o %s" % (unzip_path,zip_filename))
    (found_result,update_py_filename) = find_exists_file(g_update_tmp_path,"update.py") 
    if not found_result:
        return False,"update.py not exists"
    #step 3: run update
    os.system("rm -f /tmp/install.result")
    cmd_update = "cd %s && python update.py ./" % (unzip_path)
    log.write_info("run %s" % (cmd_update)) 
    #(status, output) = commands.getstatusoutput(cmd_update)
    os.system(cmd_update)
    log.write_info("run update.py ./ end")
    #if status != 0:
    #    return False,output
    #else:        
    if os.path.exists("/tmp/install.result"):
        return True,run_cmd("/bin/tail -n 100 /tmp/install.result")
    else:
        return False,"install fail:run python update.py fail"

if __name__ == '__main__':
    err=""
    log = Loginfo.Loginfo()

    try:
        if len(sys.argv)>=2:
            dbg_param = sys.argv[1]
            if dbg_param=='p1':
                print "test mode"
                (err,msg) = find_exists_file(g_update_tmp_path,find_filename='changelist')
                print err,msg
                log.write_error(msg)
                sys.exit(0)
            else:
                print "test install"
                (err_code,err_msg) = install_patch(run_cmd("cat /mnt/mmc/update/fromwebui/upload_session"),log)
                if err_code == False:
                    err = "_FAIL_:install patch fail! %s" % (err_msg)
                    log.write_error(err)
                    print err
                    #sys.exit(1)
                else:
                    log.write_info('install package successful:\r\n%s' %(err_msg))
                    print err_msg
                    print "__SUCCESS__"
                sys.exit(0)
        get_cgi_data()
        if cgi_update_cmd == 'upload':
            (err_code,err_msg) = get_cgi_file()
            if err_code == False:
                err = "_FAIL_:upload file fail! %s" % (err_msg)
                log.write_error(err)
                print err
                #sys.exit(1)
            else:
                changelist = err_msg
                #log.write_error(changelist)
                print changelist
                print "__SUCCESS__"
                sys.exit(0)
        
        elif cgi_update_cmd == 'install':
            (err_code,err_msg) = install_patch(cgi_session_id,log)
            if err_code == False:
                err = "_FAIL_:install patch fail! %s" % (err_msg)
                log.write_error(err)
                print err
                #sys.exit(1)
            else:
                log.write_info('install package successful:\r\n%s' %(err_msg))
                #print err_msg
                print "__SUCCESS__"
        
    except Exception as ept:
        exstr = traceback.format_exc()
        log_msg = "[FirmwareUpdate] exception={0},stack={1}".format(str(ept),exstr)
        
        print "_FAIL_:excepiton:",log_msg
        log.write_error(log_msg)
        #raise e
    #sys.exit(0)
    #print "successful"
   

