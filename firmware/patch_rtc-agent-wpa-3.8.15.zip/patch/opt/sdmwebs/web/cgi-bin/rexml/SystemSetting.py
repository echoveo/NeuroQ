#!/usr/bin/python
# -*- coding: UTF-8  -*-
__author__ = 'kali'

import cgi
import cgitb
import os
import sys
import xml.etree.ElementTree as ET
import commands
import traceback
import json
from Log import Loginfo
from config import global_var
from rexml import updateVersion



reload(sys)
cgitb.enable()
sys.setdefaultencoding('utf8')

print "Content-Type: text/html charset=utf-8 \n"

cgi_serial_port1 = "RS232"

def run_cmd(cmd):   
    (status, output) = commands.getstatusoutput(cmd)
    if output != "":
        return output.strip()
    else:
        return ""

def get_cgi_data():
    global cgi_serial_port1
    form = cgi.FieldStorage()
    cgi_serial_port1 = form.getvalue('SerialPort1','RS232')
   
def save_serialport_config():

    anylink_tree = ET.parse(global_var.AnyLinkconfig_path)
    root = anylink_tree.getroot()
    system_setting_node = root.find('SystemSetting')

    if system_setting_node == None:
        system_setting_node = ET.Element('SystemSetting')
        serial_port1_node = ET.Element('SerialPort1')
        system_setting_node.append(serial_port1_node)
        root.append(system_setting_node)

    serial_port1_node = root.find('SystemSetting/SerialPort1')
    serial_port1_node.text = cgi_serial_port1
    
    # ET.dump(anylink_tree)
    updateVersion.write(anylink_tree, global_var.AnyLinkconfig_path)

    if cgi_serial_port1 == "RS232":
        run_cmd("echo 0 > /sys/class/gpio/gpio26/value")
    elif cgi_serial_port1 == "RS485":
        run_cmd("echo 1 > /sys/class/gpio/gpio26/value")

def debug_port(serial_port1):
    global cgi_serial_port1
    cgi_serial_port1 = serial_port1

if __name__ == '__main__':
    err=""
    log = Loginfo.Loginfo()

    try:
        if len(sys.argv)>=2:
            dbg_param = sys.argv[1]
            if dbg_param=='debug':
                print "test mode"
                debug_port(sys.argv[2])
                save_serialport_config()

                sys.exit(0)

        get_cgi_data()
        save_serialport_config()
        print "__SUCCESS__"
        
    except Exception as ept:
        exstr = traceback.format_exc()
        log_msg = "[SystemSetting] exception={0},stack={1}".format(str(ept),exstr)
        
        print "_FAIL_:excepiton:",log_msg
        log.write_error(log_msg)
       

