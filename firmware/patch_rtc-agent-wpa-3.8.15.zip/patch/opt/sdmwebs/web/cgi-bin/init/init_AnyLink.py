#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xhzhang'

import xml.etree.ElementTree as ET
from config import global_var
from subprocess import Popen, PIPE
from rexml import updateVersion
import os
import re

# import os

# def getConfig():
#     p = os.popen('/opt/agent/agentbasic -v', 'r')
#     data = p.read().split(' ')
#     agentVersion = "V"+data[1]+"."+data[3][0:-1]
#     AgentVersion = agentVersion
#     global_var.AgentVersion = AgentVersion
#     print '**********'
#     fp = open('/etc/devuaid.d','rb')
#     SerialNumber = fp.readlines()[0]
#     global_var.SerialNumber = SerialNumber
#     fp.close()
#     print '*-*-*-*'
#     hostname = 'id' + SerialNumber[3:]
#     global_var.hostname = hostname


# add by fyj
def common_to_global():
    '''将Common.xml中的信息同步到global_var.py中'''

    common_tree = ET.parse(global_var.common_path)
    root_node = common_tree.getroot()
    common_dict = dict()

    for child_node in root_node.iter():
        node_tag = child_node.tag
        node_text = child_node.text.strip()
        common_dict[node_tag] = node_text

    global_var.HardwareName = common_dict['HardwareName']
    global_var.HardwareModel = common_dict['HardwareModel']
    global_var.SoftVersion = common_dict['SoftVersion']
    global_var.AnyLinkType = common_dict['AnyLinkType']
    global_var.AgentVersion = common_dict['AgentVersion']
    global_var.SerialNumber = common_dict['SerialNumber']
    global_var.agent_proto = common_dict['Protocol']
    global_var.cloud_address = common_dict['CloudAddress']
    global_var.http_port = common_dict['HttpPort']
    global_var.api_port = common_dict['ApiPort']
    global_var.mqtt_publish_server = common_dict['MqttAddress']
    global_var.mqtt_publish_port = common_dict['MqttPubPort']
    global_var.mqtt_sub_server = common_dict['MqttAddress']
    global_var.mqtt_sub_port = common_dict['MqttSubPort']
    global_var.mqtt_tls = common_dict['MqttTls']
    global_var.mqtt_config = global_var.mqtt_publish_server + ';' + global_var.mqtt_publish_port + ';' + \
        global_var.mqtt_sub_server + ';' + global_var.mqtt_sub_port + ';' + global_var.mqtt_keepalive + ';' + \
        global_var.mqtt_qos + ';' + global_var.mqtt_retain + ';' + global_var.mqtt_isEncrypt + ';' + \
        global_var.mqtt_username + ';' + global_var.mqtt_password + \
        ';;' + global_var.mqtt_tls + ';'


# add end


def init_anylink():
    '''初始化AnyLink.xml文件'''
    # add by fyj
    common_to_global()
    # add end
    # old_anylink_tree = ET.parse(global_var.AnyLinkconfig_path)
    # version_node = old_anylink_tree.find("Version")
    # next_version = str(int(version_node.text) + 1)

    anylink = ET.Element('AnyLink')
    anylink_tree = ET.ElementTree(anylink)
    '''获取agent版本号和序列号'''
    # p = os.popen('/opt/agent/agentbasic -v', 'r')
    # data = p.read().split(' ')
    # AgentVersion = "V"+data[1]+"."+data[3][0:-1]
    # fp = open('/etc/devuaid.d','rb')
    # SerialNumber = fp.readlines()[0]
    # fp.close()
    # Hostname = 'id' + SerialNumber[3:7]

    # add by fyj
    AgentVersion = global_var.AgentVersion
    SerialNumber = global_var.SerialNumber
    Hostname = 'id' + SerialNumber[3:7]
    # add
    # WebServer
    webserver = ET.Element('WebServer')
    webserver.text = 'ON'
    anylink.append(webserver)
    # BasicInfo
    basicinfo = ET.Element('BasicInfo')
    anylink.append(basicinfo)
    hardwaremodel = ET.Element('HardwareModel')
    hardwaremodel.text = global_var.HardwareModel
    hardwarename = ET.Element('HardwareName')
    hardwarename.text = global_var.HardwareName
    agentversion = ET.Element('AgentVersion')
    agentversion.text = AgentVersion
    anylinkType = ET.Element('AnyLinkType')
    anylinkType.text = global_var.AnyLinkType
    softversion = ET.Element('SoftVersion')
    softversion.text = global_var.SoftVersion
    serialnumber = ET.Element('SerialNumber')
    serialnumber.text = SerialNumber
    basicinfo.append(hardwaremodel)
    basicinfo.append(hardwarename)
    basicinfo.append(agentversion)
    basicinfo.append(anylinkType)
    basicinfo.append(softversion)
    basicinfo.append(serialnumber)
    # ZigbeeInfo
    zigbeeinfo = ET.Element('ZigbeeInfo')
    anylink.append(zigbeeinfo)
    zigbeetype = ET.Element('Type')
    zigbeetype.text = global_var.zigbee_type
    zigbeetnetnumber = ET.Element('NetNumber')
    zigbeetnetnumber.text = global_var.zigbee_netnumber
    zigbeenetaddress = ET.Element('NetAddress')
    zigbeenetaddress.text = global_var.zigbee_netaddress
    zigbeephyschannel = ET.Element('Physchannel')
    zigbeephyschannel.text = global_var.zigbee_physchannel
    zigbeeinfo.append(zigbeetype)
    zigbeeinfo.append(zigbeetnetnumber)
    zigbeeinfo.append(zigbeenetaddress)
    zigbeeinfo.append(zigbeephyschannel)
    # Lorainfo
    loraInfo = ET.Element('LoraInfo')
    anylink.append(loraInfo)
    lora_baudrate = ET.Element('g_baudrate')
    lora_baudrate.text = global_var.lora_baudrate
    lora_parity = ET.Element('g_parity')
    lora_parity.text = global_var.lora_parity
    lora_RF_freq = ET.Element('g_RF_freq')
    lora_RF_freq.text = global_var.lora_RF_freq
    lora_RF_factor = ET.Element('g_RF_factor')
    lora_RF_factor.text = global_var.lora_RF_factor
    lora_RF_mode = ET.Element('g_RF_mode')
    lora_RF_mode.text = global_var.lora_RF_mode
    lora_RF_BW = ET.Element('g_RF_BW')
    lora_RF_BW.text = global_var.lora_RF_BW
    lora_ID_H = ET.Element('g_ID_H')
    lora_ID_H.text = global_var.lora_ID_H
    lora_ID_L = ET.Element('g_ID_L')
    lora_ID_L.text = global_var.lora_ID_L
    lora_net_ID = ET.Element('g_net_ID')
    lora_net_ID.text = global_var.lora_net_ID
    lora_power = ET.Element('g_power')
    lora_power.text = global_var.lora_power
    loraInfo.append(lora_baudrate)
    loraInfo.append(lora_parity)
    loraInfo.append(lora_RF_freq)
    loraInfo.append(lora_RF_factor)
    loraInfo.append(lora_RF_mode)
    loraInfo.append(lora_RF_BW)
    loraInfo.append(lora_ID_H)
    loraInfo.append(lora_ID_L)
    loraInfo.append(lora_net_ID)
    loraInfo.append(lora_power)
    # Hardware status info
    hardwarestatus = ET.Element('HardwareStatus')
    anylink.append(hardwarestatus)
    zigbee_status = ET.Element('Zigbee')
    zigbee_status.text = u'良好'
    tg_status = ET.Element('TG')
    tg_status.text = u'良好'
    device_status = ET.Element('Device')
    device_status.text = u'良好'
    hardwarestatus.append(zigbee_status)
    hardwarestatus.append(tg_status)
    hardwarestatus.append(device_status)
    # Network
    networkinfo = ET.SubElement(anylink,
                                'NetworkInfo',
                                attrib={
                                    'hostname': Hostname,
                                    'muti': global_var.net_muti
                                })
    mode = ET.SubElement(networkinfo, 'Mode')
    mode.text = global_var.network_mode
    model = ET.SubElement(networkinfo, 'Model')
    model.text = global_var.network_model
    ET.SubElement(networkinfo,
                  'WAN',
                  attrib={
                      'mac': '',
                      'dhcp': global_var.network_wan_dhcp,
                      'ip': global_var.network_wan_ip,
                      'mask': global_var.network_wan_mask,
                      'gateway': global_var.network_wan_gateway,
                      'dns': global_var.network_wan_dns
                  })
    ET.SubElement(networkinfo,
                  'LAN',
                  attrib={
                      'mac': '',
                      'dhcp': global_var.network_lan_dhcp,
                      'ip': global_var.network_lan_ip,
                      'mask': global_var.network_lan_mask,
                      'gateway': global_var.network_lan_gateway,
                      'dns': global_var.network_lan_dns
                  })
    # vpn
    vpn = ET.SubElement(anylink,
                        'VPN',
                        attrib={'display': global_var.vpn_display})
    # wifiinfo
    wifiinfo = ET.Element('Wifi')
    anylink.append(wifiinfo)
    wifimodestatus = ET.Element('W_Modestatus')
    wifissid = ET.Element('W_SSID')
    wifipass = ET.Element('W_Password')
    wifistatus = ET.Element('W_Status')
    wifiip = ET.Element('W_IP')
    wifimac = ET.Element('W_MAC')
    wifistrong = ET.Element('W_STRONG')
    wifidhcp = ET.Element('W_DHCP')
    wifigateway = ET.Element('W_GATEWAY')
    wifimask = ET.Element('W_NETMASK')
    wifimodestatus.text = global_var.wifi_modestatus
    wifissid.text = global_var.wifi_ssid
    wifipass.text = global_var.wifi_password
    wifistatus.text = global_var.wifi_status
    wifiip.text = global_var.wifi_ip
    wifimac.text = ''
    wifidhcp.text = global_var.wifi_dhcp
    wifigateway.text = global_var.wifi_gateway
    wifistrong.text = global_var.wifi_strong
    wifimask.text = global_var.wifi_mask

    # remote wifi
    remote_node = ET.Element('W_Remote')
    list_node = ET.Element('W_List')

    remote_node.append(list_node)
    wifiinfo.append(remote_node)

    wifiinfo.append(wifimodestatus)
    wifiinfo.append(wifissid)
    wifiinfo.append(wifipass)
    wifiinfo.append(wifistatus)
    wifiinfo.append(wifiip)
    wifiinfo.append(wifimac)
    wifiinfo.append(wifidhcp)
    wifiinfo.append(wifigateway)
    wifiinfo.append(wifistrong)
    wifiinfo.append(wifimask)
    # Cloudinfo
    cloudinfo = ET.Element('CloudInfo')
    anylink.append(cloudinfo)
    cloudaddress = ET.Element('Address')
    cloudaddress.text = global_var.cloud_address
    httpPort = ET.Element('Http_port')
    httpPort.text = global_var.http_port
    apiPort = ET.Element('API_port')
    apiPort.text = global_var.api_port
    cloudinfo.append(cloudaddress)
    cloudinfo.append(httpPort)
    cloudinfo.append(apiPort)
    # Logininfo
    # logininfo = ET.Element('LoginInfo')
    # anylink.append(logininfo)
    # loginuser = ET.Element('UserName')
    # loginuser.text = global_var.username
    # loginpass = ET.Element('Password')
    # loginpass.text = global_var.password
    # loginstatus = ET.Element('Status')
    # loginstatus.text = global_var.loginstatus
    # logininfo.append(loginuser)
    # logininfo.append(loginpass)
    # logininfo.append(loginstatus)

    # apninfo
    apninfo = ET.Element('ApnInfo')
    anylink.append(apninfo)
    isAuto = ET.Element('IsAuto')
    isAuto.text = '0'
    apnApn = ET.Element('Apn')
    apnApn.text = ''
    apnProxy = ET.Element('Proxy')
    apnProxy.text = ''
    apnPort = ET.Element('Port')
    apnPort.text = ''
    apnUsername = ET.Element('Username')
    apnUsername.text = ''
    apnPassword = ET.Element('Password')
    apnPassword.text = ''
    apninfo.append(isAuto)
    apninfo.append(apnApn)
    apninfo.append(apnProxy)
    apninfo.append(apnPort)
    apninfo.append(apnUsername)
    apninfo.append(apnPassword)
    # TimeZoneinfo
    timezoneinfo = ET.Element('TimeZoneInfo')
    anylink.append(timezoneinfo)
    timezone = ET.Element('TimeZone')
    timezone.text = global_var.timezone
    timezoneinfo.append(timezone)
    # AgentConfiginfo
    agentConfiginfo = ET.Element('AgentConfig')
    anylink.append(agentConfiginfo)
    agentMode = ET.Element('AgentMode')
    agentMode.text = global_var.agent_mode
    uploadType = ET.Element('UploadType')
    uploadType.text = global_var.agent_uploadtype
    regRetryCount = ET.Element('RegRetryCount')
    regRetryCount.text = global_var.agent_regretrycount
    queueSize = ET.Element('QueueSize')
    queueSize.text = global_var.agent_queuesize
    proto = ET.Element('Protocol')
    proto.text = global_var.agent_proto
    logpath = ET.Element('LogPath')
    logpath.text = global_var.agent_logpath
    alarmmode = ET.Element('AlarmMode')
    alarmmode.text = global_var.agent_alarmmode
    agentdbenable = ET.Element('DBEnable')
    agentdbenable.text = global_var.agent_dbenable
    agentdbsize = ET.Element('DBSize')
    agentdbsize.text = global_var.agent_dbthread
    agentdbscan = ET.Element('DBScanTime')
    agentdbscan.text = global_var.agent_dbscantime
    # 新增mqtt配置项
    agentBadDataMode = ET.Element('BadDataMode')
    agentBadDataMode.text = global_var.badDataMode  # baddatamode 默认为0
    agentForceUploadTime = ET.Element('ForceUploadTime')
    agentForceUploadTime.text = global_var.agent_force_upload_time

    agentDiscardInvalidData = ET.Element('DiscardInvalidData')
    agentDiscardInvalidData.text = global_var.agent_discard_invalid_data

    agentConfiginfo.append(agentMode)
    agentConfiginfo.append(uploadType)
    agentConfiginfo.append(regRetryCount)
    agentConfiginfo.append(queueSize)
    agentConfiginfo.append(proto)
    agentConfiginfo.append(logpath)
    agentConfiginfo.append(alarmmode)
    agentConfiginfo.append(agentdbenable)
    agentConfiginfo.append(agentdbsize)
    agentConfiginfo.append(agentdbscan)
    agentConfiginfo.append(agentBadDataMode)
    agentConfiginfo.append(agentForceUploadTime)
    agentConfiginfo.append(agentDiscardInvalidData)

    # router
    router = ET.SubElement(anylink, 'Router', attrib={
                           'enable': global_var.router_enable})

    router_ip = ET.Element('IPAddr')
    router_ip.text = global_var.router_ip
    router_mask = ET.Element('SubNetMask')
    router_mask.text = global_var.router_mask
    router_dhcp = ET.Element('EnableDHCPServer')
    router_dhcp.text = global_var.router_dhcp

    router_dhcp_config = ET.Element('DHCPConfig')
    router_dhcp_start = ET.Element('StartIP')
    router_dhcp_start.text = global_var.router_dhcp_start
    router_dhcp_end = ET.Element('EndIP')
    router_dhcp_end.text = global_var.router_dhcp_end
    router_dhcp_config.append(router_dhcp_start)
    router_dhcp_config.append(router_dhcp_end)
    router.append(router_ip)
    router.append(router_mask)
    router.append(router_dhcp)
    router.append(router_dhcp_config)
    # updateVersion.init_save(anylink_tree, anylink,
    #                         global_var.AnyLinkconfig_path, next_version)
    NTP_node = ET.Element('NTP')
    anylink.append(NTP_node)
    ntp_server1 = ET.Element('NTPServerAddress')

    ntp_server1.text = global_var.ntp_server1
    NTP_node.append(ntp_server1)
    ntp_server2 = ET.Element('NTPServerAddress')
    ntp_server2.text = global_var.ntp_server2
    NTP_node.append(ntp_server2)
    updateVersion.write(anylink_tree, global_var.AnyLinkconfig_path)
    # anylink_tree.write(global_var.AnyLinkconfig_path,encoding='utf-8',xml_declaration='true')


#hold reset button for 5 seconds reset lanip(router ip) to 192.168.101.204
def set_xml_node_text(tree,path,text):
    node = tree.find(path)
    if node is not None:
        node.text = text
        
def reset_lan_ip_to_default():
    tree = ET.parse(global_var.AnyLinkconfig_path)
    set_xml_node_text(tree,"Router/IPAddr",global_var.router_ip)
    set_xml_node_text(tree,"Router/SubNetMask",global_var.router_mask)
    set_xml_node_text(tree,"Router/EnableDHCPServer","1")    
    set_xml_node_text(tree,"Router/DHCPConfig/StartIP",global_var.router_dhcp_start)
    set_xml_node_text(tree,"Router/DHCPConfig/EndIP",global_var.router_dhcp_end)    
    tree.write(global_var.AnyLinkconfig_path, encoding="utf-8",xml_declaration=True)
    os.system("sync")
    os.system("cd /opt/script/ && python SetEthernetConfig.py >/dev/null 2>&1 &")
    return True


if __name__ == '__main__':
    # getConfig()
    init_anylink()
