#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'yjbao'

import xml.etree.ElementTree as ET
from config import global_var
from rexml import updateVersion


def init_Login():
    """
    Init Login.xml file
    """
    # old_login_tree = ET.parse(global_var.Login_path)
    # version_node = old_login_tree.find("Version")
    # next_version = str(int(version_node.text) + 1)

    login = ET.Element('Login')
    login_tree = ET.ElementTree(login)

    #Logininfo
    #logininfo = ET.Element('LoginInfo')
    #login.append(logininfo)
    #loginuser = ET.Element('UserName')
    #loginuser.text = global_var.username
    #loginpass = ET.Element('Password')
    #loginpass.text = global_var.password
    #loginstatus = ET.Element('Status')
    #loginstatus.text = global_var.loginstatus
    #logininfo.append(loginuser)
    #logininfo.append(loginpass)
    #logininfo.append(loginstatus)

    #modified begin by fyj, 增加用户角色
    logininfo = ET.Element('LoginInfo')
    login.append(logininfo)
    loginuser = ET.Element('UserName')
    loginuser.text = global_var.adminUsername
    loginpass = ET.Element('Password')
    loginpass.text = global_var.adminPassword
    loginstatus = ET.Element('Status')
    loginstatus.text = global_var.adminLoginstatus
    logininfo.append(loginuser)
    logininfo.append(loginpass)
    logininfo.append(loginstatus)

    logininfo2 = ET.Element('LoginInfo')
    login.append(logininfo2)
    loginuser2 = ET.Element('UserName')
    loginuser2.text = global_var.username
    loginpass2 = ET.Element('Password')
    loginpass2.text = global_var.password
    loginstatus2 = ET.Element('Status')
    loginstatus2.text = global_var.loginstatus
    logininfo2.append(loginuser2)
    logininfo2.append(loginpass2)
    logininfo2.append(loginstatus2)
    #modified end

    # updateVersion.init_save(login_tree, login, global_var.Login_path,
    #                         next_version)
    updateVersion.write(login_tree, global_var.Login_path)
    # login_tree.write(global_var.Login_path,
    #                  encoding='utf-8',
    #                  xml_declaration='true')
