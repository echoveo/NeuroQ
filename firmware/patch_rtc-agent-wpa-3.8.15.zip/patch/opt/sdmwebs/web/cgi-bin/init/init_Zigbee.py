#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xhzhang'

import xml.etree.ElementTree as ET
from config import global_var
from rexml import updateVersion
import serial


def command_to_zigbee(command):
    ''''''
    back_data = '0'
    fd = serial.Serial(global_var.zigbee_port,
                       baudrate=115200,
                       bytesize=8,
                       parity='N',
                       stopbits=1,
                       timeout=1)
    if fd:
        while 1:
            fd.write(command + chr(0x0d) + chr(0x0a))
            data = fd.readall()
            if "OK" in data:
                back_data = '1'
                break
    fd.close()
    return back_data


def set_init_status(element_name):
    '''设置初始化是否成功状态'''
    initstatus_tree = ET.parse(global_var.InitStatus_path)

    element_node = initstatus_tree.find(element_name)
    if element_node != 'None':
        element_node.text = '1'
    updateVersion.write(initstatus_tree, global_var.InitStatus_path)
    # initstatus_tree.write(global_var.InitStatus_path, encoding='utf-8', xml_declaration='true')


def init_zigbee():
    '''初始化zigbee'''
    init_zigbee_type = command_to_zigbee('AT+TYP=' + global_var.zigbee_type)
    init_zigbee_netnum = command_to_zigbee('AT+PID=' +
                                           global_var.zigbee_netnumber)
    init_zigbee_netadd = command_to_zigbee('AT+NID=' +
                                           global_var.zigbee_netaddress)
    init_zigbee_phycha = command_to_zigbee('AT+CHA=' +
                                           global_var.zigbee_physchannel)
    if init_zigbee_type == '1' and init_zigbee_netnum == '1' and init_zigbee_netadd == '1' and init_zigbee_phycha == '1':
        save_status = command_to_zigbee('AT+SAV')
        if save_status == '1':
            set_init_status('ZigbeeStatus')