#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xhzhang'

import xml.etree.ElementTree as ET
from rexml import updateVersion
from config import global_var


def init_status():
    '''创建初始化状态文件InitStatus.xml,初始化状态初值均为0'''

    # old_init_tree = ET.parse(global_var.InitStatus_path)
    # version_node = old_init_tree.find("Version")
    # next_version = str(int(version_node.text) + 1)

    initstatus = ET.Element('InitStatus')
    initstatus_tree = ET.ElementTree(initstatus)

    #初始化网关基本信息
    anylinkstatus = ET.Element('AnylinkStatus')
    anylinkstatus.text = '0'
    #初始化通道，设备，数据项信息
    conigstatus = ET.Element('ConfigStatus')
    conigstatus.text = '0'
    #初始化云端地址信息
    cloudstatus = ET.Element('CloudStatus')
    cloudstatus.text = '0'
    #初始化网络信息
    networkstatus = ET.Element('NetworkStatus')
    networkstatus.text = '0'
    #初始化登陆信息
    loginstatus = ET.Element('LoginStatus')
    loginstatus.text = '0'
    #初始化zigbee信息
    zigbeestatus = ET.Element('ZigbeeStatus')
    zigbeestatus.text = '0'
    #初始化时区信息
    timezonestatus = ET.Element('TimezoneStatus')
    timezonestatus.text = '0'
    #将tag链接到InitStatus节点
    initstatus.append(conigstatus)
    initstatus.append(anylinkstatus)
    initstatus.append(cloudstatus)
    initstatus.append(networkstatus)
    initstatus.append(loginstatus)
    initstatus.append(zigbeestatus)
    initstatus.append(timezonestatus)
    # updateVersion.init_save(initstatus_tree, initstatus,
    #                         global_var.InitStatus_path, next_version)
    updateVersion.write(initstatus_tree, global_var.InitStatus_path)

    # initstatus_tree.write(global_var.InitStatus_path,
    #                       encoding='utf-8',
    #                       xml_declaration='true')
