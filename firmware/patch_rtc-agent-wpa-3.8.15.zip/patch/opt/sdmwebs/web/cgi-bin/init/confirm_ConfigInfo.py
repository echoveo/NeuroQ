#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xhzhang'

import xml.etree.ElementTree as ET
from config import global_var
import set_initStatus

def confirm_configinfo():
    '''确认通道，设备，数据项初始化结果'''
    agent_tree = ET.parse(global_var.itemconfig_path)
    idinfo_tree = ET.parse(global_var.idconfig_path)

    channel_status = False
    channel_node_list = agent_tree.findall('model')
    channel_num = len(channel_node_list)
    if channel_num == 1:
        for channel_node in channel_node_list:
            if channel_node.get('n',default = None) == 'ra-model':
               channel_status = True
    #print channel_status

    taskdriver_status = False
    driver_control_status = driver_zigbee_status = driver_ra_status = False

    taskdriver_node_list = agent_tree.findall('task/TaskDriver')
    for taskdriver_node in taskdriver_node_list:
        driver_name =  taskdriver_node.find('driver').get('n',default = None)
        if driver_name == 'T.IDrv.Task:libcontrol':
            driver_control_status = True
        elif driver_name == 'T.IDrv.Task:libzigbee':
            driver_zigbee_status = True
        elif driver_name == 'T.IDrv.Task:libtremoteplc':
            driver_ra_status = True

    if driver_control_status == True  and driver_zigbee_status == True and driver_ra_status ==True:
       taskdriver_status = True


    channel_id = idinfo_tree.find('ChannelID').text
    device_id = idinfo_tree.find('DeviceID').text
    item_id = idinfo_tree.find('ItemID').text
    driver_id = idinfo_tree.find('DriverID').text
    rule_id = idinfo_tree.find('RuleID').text
    id_status = False

    if channel_id == '1' and device_id == '1' and driver_id == '1' and rule_id == '1':
        id_status = True

    if channel_status == True and taskdriver_status == True and id_status == True:
        set_initStatus.set_status('ConfigStatus')
