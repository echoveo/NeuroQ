#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xhzhang'

import os
from config import global_var
import set_initStatus
def init_dns():
    '''初始化network'''
    default_dns = global_var.network_wan_dns
    save_dns_cmd = 'eeprom net set dns ' + default_dns
    os.system(save_dns_cmd)