#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xhzhang'

import xml.etree.ElementTree as ET
from config import global_var
from rexml import updateVersion


# add by fyj
def common_to_global():
    '''将Common.xml中的信息同步到global_var.py中'''

    common_tree = ET.parse(global_var.common_path)
    root_node = common_tree.getroot()
    common_dict = dict()

    for child_node in root_node.iter():
        node_tag = child_node.tag
        node_text = child_node.text.strip()
        common_dict[node_tag] = node_text

    global_var.HardwareName = common_dict['HardwareName']
    global_var.HardwareModel = common_dict['HardwareModel']
    global_var.SoftVersion = common_dict['SoftVersion']
    global_var.AnyLinkType = common_dict['AnyLinkType']
    global_var.AgentVersion = common_dict['AgentVersion']
    global_var.SerialNumber = common_dict['SerialNumber']
    global_var.agent_proto = common_dict['Protocol']
    global_var.cloud_address = common_dict['CloudAddress']
    global_var.http_port = common_dict['HttpPort']
    global_var.api_port = common_dict['ApiPort']
    global_var.mqtt_publish_server = common_dict['MqttAddress']
    global_var.mqtt_publish_port = common_dict['MqttPubPort']
    global_var.mqtt_sub_server = common_dict['MqttAddress']
    global_var.mqtt_sub_port = common_dict['MqttSubPort']
    global_var.mqtt_tls = common_dict['MqttTls']
    global_var.mqtt_config = global_var.mqtt_publish_server + ';' + global_var.mqtt_publish_port + ';' + \
                global_var.mqtt_sub_server + ';' + global_var.mqtt_sub_port + ';' + global_var.mqtt_keepalive + ';' + \
                global_var.mqtt_qos + ';' + global_var.mqtt_retain + ';' + global_var.mqtt_isEncrypt + ';' + \
                global_var.mqtt_username + ';'  + global_var.mqtt_password + ';;' + global_var.mqtt_tls + ';'


# add end


def init_agent_cloudserver(cloudserver):
    '''初始化AgentConfig.xml'''

    # add by fyj
    common_to_global()
    # add end
    # try:
    #     old_agent_tree = ET.parse(global_var.agent_cloud_path)
    #     version_node = old_agent_tree.find("Version")
    #     next_version = str(int(version_node.text) + 1)
    # except Exception as e:
    #     next_version = '1'

    # anylink_tree = ET.parse(global_var.AnyLinkconfig_path)
    # SerialNumber = anylink_tree.find('BasicInfo/SerialNumber').text
    SerialNumber = global_var.SerialNumber

    Products_id = SerialNumber
    agent_cloudserver = ET.Element('AgentConfig')
    agent_cloudserver_tree = ET.ElementTree(agent_cloudserver)

    agent_name = ET.Element('AgentName')
    agent_name.text = 'Agent-' + Products_id

    agent_version = ET.Element('Version')
    # AgentVersion = anylink_tree.find('BasicInfo/AgentVersion').text
    AgentVersion = global_var.AgentVersion
    agent_version.text = AgentVersion

    agent_debug = ET.Element('Debug')
    agent_debug.text = global_var.agent_loglevel

    agent_acqu = ET.Element('acqu')
    agent_acqu.text = '10'

    agent_pingrate = ET.Element('PingRate')
    agent_pingrate.text = global_var.agent_pingrate

    agent_agentMode = ET.Element('AgentMode')
    agent_agentMode.text = global_var.agent_mode

    agent_uploadtype = ET.Element('UploadType')
    agent_uploadtype.text = global_var.agent_uploadtype

    agent_regretrycount = ET.Element('RegRetryCount')
    agent_regretrycount.text = global_var.agent_regretrycount

    agent_queuesize = ET.Element('QueueSize')
    agent_queuesize.text = global_var.agent_queuesize

    agent_proto = ET.Element('Protocol')
    agent_proto.text = global_var.agent_proto

    agent_logpath = ET.Element('LogPath')
    agent_logpath.text = global_var.agent_logpath

    agent_alarmmode = ET.Element('AlarmMode')
    agent_alarmmode.text = global_var.agent_alarmmode

    agent_drmserver = ET.Element('DRMServer')
    agent_drmserver.text = cloudserver + '/regagent'

    agent_drmdataserver = ET.Element('DRMDataServer')
    agent_drmdataserver.text = cloudserver + '/at'

    agent_drmpingserver = ET.Element('DRMPingServer')
    agent_drmpingserver.text = cloudserver + '/regagainagent'

    agent_badDataMode = ET.Element('BadDataMode')
    agent_badDataMode.text = global_var.badDataMode

    agent_ForceUploadTime = ET.Element('ForceUploadTime')
    agent_ForceUploadTime.text = global_var.agent_force_upload_time
 
    agent_DiscardInvalidData = ET.Element('DiscardInvalidData')
    agent_DiscardInvalidData.text = global_var.agent_discard_invalid_data

    agent_cloudserver.append(agent_name)
    agent_cloudserver.append(agent_version)
    agent_cloudserver.append(agent_debug)
    agent_cloudserver.append(agent_acqu)
    agent_cloudserver.append(agent_pingrate)
    agent_cloudserver.append(agent_agentMode)
    agent_cloudserver.append(agent_uploadtype)
    agent_cloudserver.append(agent_regretrycount)
    agent_cloudserver.append(agent_queuesize)
    agent_cloudserver.append(agent_proto)
    agent_cloudserver.append(agent_logpath)
    agent_cloudserver.append(agent_alarmmode)
    agent_cloudserver.append(agent_badDataMode)
    agent_cloudserver.append(agent_ForceUploadTime)
    agent_cloudserver.append(agent_DiscardInvalidData)
    if global_var.agent_mode == '0':
        agent_cloudserver.append(agent_drmserver)
        agent_cloudserver.append(agent_drmdataserver)
        agent_cloudserver.append(agent_drmpingserver)
    # updateVersion.init_save(agent_cloudserver_tree, agent_cloudserver,
    #                         global_var.agent_cloud_path, next_version)
    updateVersion.write(agent_cloudserver_tree, global_var.agent_cloud_path)
    # agent_cloudserver_tree.write(global_var.agent_cloud_path,
    #                              xml_declaration='true')
