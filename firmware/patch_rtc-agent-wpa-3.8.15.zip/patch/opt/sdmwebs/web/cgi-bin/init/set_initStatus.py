#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xhzhang'

import xml.etree.ElementTree as ET
from config import global_var
from rexml import updateVersion


def set_status(element_name):
    '''设置初始化是否成功状态'''
    initstatus_tree = ET.parse(global_var.InitStatus_path)

    element_node = initstatus_tree.find(element_name)
    if element_node != 'None':
        element_node.text = '1'
    updateVersion.write(initstatus_tree, global_var.InitStatus_path)
    # initstatus_tree.write(global_var.InitStatus_path,
    #                       encoding='utf-8',
    #                       xml_declaration='true')
