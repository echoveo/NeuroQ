#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xhzhang'

import os
from config import global_var
def init_networkmode():
    '''初始化network'''
    network_mode = global_var.network_mode
    script_path = '/opt/script/'
    init_script = script_path + '/S91init-' + network_mode

    start_path = '/etc/init.d'
    old_script = start_path + '/S91*'


    os.system('wr rm -rf ' + old_script)
    os.system('wr cp ' + init_script + ' ' + start_path)
    os.system('wr chmod 700 ' + start_path + '/S91init-' + network_mode)