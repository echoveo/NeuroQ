#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xhzhang'

import xml.etree.ElementTree as ET
from config import global_var
from rexml import updateVersion


def init_IDinfo():
    '''初始化IDinfo.xml'''
    # old_id_tree = ET.parse(global_var.idconfig_path)
    # version_node = old_id_tree.find("Version")
    # next_version = str(int(version_node.text) + 1)

    idall = ET.Element('IDALL')
    idall_tree = ET.ElementTree(idall)
    channel_id = ET.Element('ChannelID')
    channel_id.text = '1'
    device_id = ET.Element('DeviceID')
    device_id.text = '1'
    dataitem_id = ET.Element('ItemID')
    dataitem_id.text = '24'
    driver_id = ET.Element('DriverID')
    driver_id.text = '1'
    rule_id = ET.Element('RuleID')
    rule_id.text = '1'
    siemens_remote = ET.Element('SiemRemote')
    #siemens_remote.text = '0'
    idall.append(channel_id)
    idall.append(device_id)
    idall.append(dataitem_id)
    idall.append(driver_id)
    idall.append(rule_id)
    idall.append(siemens_remote)
    # updateVersion.init_save(idall_tree, idall, global_var.idconfig_path,
    #                         next_version)
    updateVersion.write(idall_tree, global_var.idconfig_path)
    # idall_tree.write(global_var.idconfig_path,
    #                  encoding='utf-8',
    #                  xml_declaration='true')
