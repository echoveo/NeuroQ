#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xhzhang'

import xml.etree.ElementTree as ET
from config import global_var
import set_initStatus

def confirm_anylink():
    '''确认其他初始化结果'''
    anylink_tree = ET.parse(global_var.AnyLinkconfig_path)
    basicinfo_node = anylink_tree.find('BasicInfo')
    hardware_node = anylink_tree.find('HardwareStatus')
    if basicinfo_node != 'None' and hardware_node != 'None':
        set_initStatus.set_status('AnylinkStatus')
    cloudinfo = anylink_tree.find('CloudInfo/Address').text
    if cloudinfo == global_var.cloud_address:
        set_initStatus.set_status('CloudStatus')
    #login_username = anylink_tree.find('LoginInfo/UserName').text
    #login_password = anylink_tree.find('LoginInfo/Password').text
    #login_status = anylink_tree.find('LoginInfo/Status').text
    #if login_username == global_var.username and login_password == global_var.password and login_status == '0':
    #    set_initStatus.set_status('LoginStatus')
    timezone = anylink_tree.find('TimeZoneInfo/TimeZone').text
    if timezone == global_var.timezone:
        set_initStatus.set_status('TimezoneStatus')