#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xhzhang'

import os
import sys
import xml.etree.ElementTree as ET

import confirm_AnyLink
import confirm_ConfigInfo
import confirm_Login
import init_AgentConfig
import init_AnyLink
import init_Config
import init_IDinfo
import init_IP
import init_Login
import init_backup
import init_dns
import init_initStaus
from agent import GiveToAgent
from config import global_var

print "Content-Type: text/html charset=utf-8 \n\n"


# add by fyj
def common_to_global():
    '''将Common.xml中的信息同步到global_var.py中'''

    common_tree = ET.parse(global_var.common_path)
    root_node = common_tree.getroot()
    common_dict = dict()

    for child_node in root_node.iter():
        node_tag = child_node.tag
        node_text = child_node.text.strip()
        common_dict[node_tag] = node_text

    global_var.HardwareName = common_dict['HardwareName']
    global_var.HardwareModel = common_dict['HardwareModel']
    global_var.SoftVersion = common_dict['SoftVersion']
    global_var.AnyLinkType = common_dict['AnyLinkType']
    global_var.AgentVersion = common_dict['AgentVersion']
    global_var.SerialNumber = common_dict['SerialNumber']
    global_var.agent_proto = common_dict['Protocol']
    global_var.cloud_address = common_dict['CloudAddress']
    global_var.http_port = common_dict['HttpPort']
    global_var.api_port = common_dict['ApiPort']
    global_var.mqtt_publish_server = common_dict['MqttAddress']
    global_var.mqtt_publish_port = common_dict['MqttPubPort']
    global_var.mqtt_sub_server = common_dict['MqttAddress']
    global_var.mqtt_sub_port = common_dict['MqttSubPort']
    global_var.mqtt_tls = common_dict['MqttTls']
    global_var.mqtt_config = global_var.mqtt_publish_server + ';' + global_var.mqtt_publish_port + ';' + \
                             global_var.mqtt_sub_server + ';' + global_var.mqtt_sub_port + ';' + global_var.mqtt_keepalive + ';' + \
                             global_var.mqtt_qos + ';' + global_var.mqtt_retain + ';' + global_var.mqtt_isEncrypt + ';' + \
                             global_var.mqtt_username + ';' + global_var.mqtt_password + ';;' + global_var.mqtt_tls + ';'


# add end

if __name__ == '__main__':
    if len(sys.argv) > 1:
        if sys.argv[1] == "reset_lan_ip":
            init_AnyLink.reset_lan_ip_to_default()
            sys.exit(0)

        # check_self(sys.argv)
    # add by fyj
    common_to_global()
    # add end
    init_initStaus.init_status()
    init_AnyLink.init_anylink()
    init_Login.init_Login()
    init_Config.init_config()
    init_AgentConfig.init_agent_cloudserver('http://' +
                                            global_var.cloud_address + ":" +
                                            global_var.http_port)
    init_IDinfo.init_IDinfo()
    confirm_AnyLink.confirm_anylink()
    confirm_Login.confirm_Login()
    confirm_ConfigInfo.confirm_configinfo()
    init_IP.init_network()
    init_dns.init_dns()
    # init_backup.init_bak()
    init_IP.save_macAddress_config()
    # add by fyj
    os.system("wr rm -rf /etc/localtime")
    # add end
    GiveToAgent.give_agent_config()

    # init_default_gateway.init_default_gateway()
    # init_networkmode.init_networkmode()
    # init_Zigbee.init_zigbee()
