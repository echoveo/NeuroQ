#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'yjbao'

import xml.etree.ElementTree as ET
from config import global_var
import set_initStatus

def confirm_Login():
    """
    confirm log information in the 'Login.xml'
    """
    #login_tree = ET.parse(global_var.Login_path)
    #login_username = login_tree.find('LoginInfo/UserName').text
    #login_password = login_tree.find('LoginInfo/Password').text
    #login_status = login_tree.find('LoginInfo/Status').text
    #if login_username == global_var.username and login_password == global_var.password and login_status == '0':
        #set_initStatus.set_status('LoginStatus')
    
    #modified begin by fyj, 增加用户角色
    set_initStatus.set_status('LoginStatus')
    #modified end
    