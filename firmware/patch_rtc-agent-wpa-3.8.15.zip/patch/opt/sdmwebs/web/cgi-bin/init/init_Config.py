#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xhzhang'

import xml.etree.ElementTree as ET
from config import global_var
from rexml import updateVersion
import os


def addCommDataItem(parentNode, freq, idd, n, rw, report, typee, vtype, addr,
                    config):
    DataItems = ET.Element('dataItem')
    DataItems.set('freq', freq)
    DataItems.set('id', idd)
    DataItems.set('n', n)
    DataItems.set('rw', rw)
    DataItems.set('report', report)
    DataItems.set('type', typee)
    DataItems.set('vtype', vtype)
    DataItems.set('addr', addr)
    DataItems.set('config', config)
    parentNode.append(DataItems)


# add by fyj
def common_to_global():
    '''将Common.xml中的信息同步到global_var.py中'''

    common_tree = ET.parse(global_var.common_path)
    root_node = common_tree.getroot()
    common_dict = dict()

    for child_node in root_node.iter():
        node_tag = child_node.tag
        node_text = child_node.text.strip()
        common_dict[node_tag] = node_text

    global_var.HardwareName = common_dict['HardwareName']
    global_var.HardwareModel = common_dict['HardwareModel']
    global_var.SoftVersion = common_dict['SoftVersion']
    global_var.AnyLinkType = common_dict['AnyLinkType']
    global_var.AgentVersion = common_dict['AgentVersion']
    global_var.SerialNumber = common_dict['SerialNumber']
    global_var.agent_proto = common_dict['Protocol']
    global_var.cloud_address = common_dict['CloudAddress']
    global_var.http_port = common_dict['HttpPort']
    global_var.api_port = common_dict['ApiPort']
    global_var.mqtt_publish_server = common_dict['MqttAddress']
    global_var.mqtt_publish_port = common_dict['MqttPubPort']
    global_var.mqtt_sub_server = common_dict['MqttAddress']
    global_var.mqtt_sub_port = common_dict['MqttSubPort']
    global_var.mqtt_tls = common_dict['MqttTls']
    global_var.RaExtraDataitem = common_dict['RaExtraDataitem']
    global_var.mqtt_config = global_var.mqtt_publish_server + ';' + global_var.mqtt_publish_port + ';' + \
                global_var.mqtt_sub_server + ';' + global_var.mqtt_sub_port + ';' + global_var.mqtt_keepalive + ';' + \
                global_var.mqtt_qos + ';' + global_var.mqtt_retain + ';' + global_var.mqtt_isEncrypt + ';' + \
                global_var.mqtt_username + ';'  + global_var.mqtt_password + ';;' + global_var.mqtt_tls + ';'


# add end


def init_config():
    '''初始化config.xml'''

    #add by fyj
    common_to_global()
    #add end
    # old_config_tree = ET.parse(global_var.itemconfig_path)
    # version_node = old_config_tree.find("Version")
    # next_version = str(int(version_node.text) + 1)

    # anylink_tree = ET.parse(global_var.AnyLinkconfig_path)
    # SerialNumber = anylink_tree.find('BasicInfo/SerialNumber').text
    SerialNumber = global_var.SerialNumber
    Products_id = SerialNumber
    Products_type = global_var.Product_type
    Products_address = global_var.zigbee_netaddress
    webVersion = global_var.SoftVersion
    scriptVersion = ''
    if os.path.exists("/opt/script/script_version.txt"):
        with open('/opt/script/script_version.txt', 'rb') as f:
            scriptVersion = f.read().strip()

    agent = ET.Element('agent')
    agent.set('n', 'Agent-' + Products_id)
    agent.set('id', Products_id)
    agent.set('flag', 'SET-TASKS')
    agent.set('port', '-1')
    agent.set('timezone', 'UTC')
    agent.set('sdmwebs', webVersion)
    agent.set('script', scriptVersion)
    agent_tree = ET.ElementTree(agent)

    #modified by chenwei
    #add model
    model = ET.Element('model')
    model.set('n', 'ra-model')
    agent.append(model)

    device = ET.Element('device')
    device.set('n', 'ra-device')
    device.set('id', '1023')
    device.set('ip', '127.0.0.1')
    model.append(device)

    DeviceDriver = ET.Element('driver')
    DeviceDriver.set('n', 'T.IDrv.Task:libtremoteplc')

    # scriptTree = ET.parse('/opt/script/ScriptConfig.xml')
    # WifiIf = 'wlan0'
    # scriptWifiNode = scriptTree.find('WiFi')
    # WifiIfNode = scriptWifiNode.find('WifiIf')
    # WifiIf = WifiIfNode.text
    # redmine 问题#3447

    DeviceDriver.set('config', '1')
    device.append(DeviceDriver)

    CommDataItems = ET.Element('commDataItems')
    DeviceDriver.append(CommDataItems)

    addCommDataItem(CommDataItems, '120000', '1', 'CSQ', '0', '1', 'a', '', '',
                    '')
    if global_var.RaExtraDataitem == '0':
        pass
    elif global_var.RaExtraDataitem == '1':
        addCommDataItem(CommDataItems, '120000', '2', 'NET-TYPE', '0', '1',
                        's', '', '', '')
        addCommDataItem(CommDataItems, '120000', '3', 'WAN-IP', '0', '1', 's',
                        '', '', '')
        addCommDataItem(CommDataItems, '120000', '4', 'WAN-MAC', '0', '1', 's',
                        '', '', '')
        addCommDataItem(CommDataItems, '120000', '5', 'WIFI-LIST', '0', '1',
                        's', '', '', '')
        addCommDataItem(CommDataItems, '120000', '6', 'WIFI-IP', '0', '1', 's',
                        '', '', '')
        addCommDataItem(CommDataItems, '120000', '7', 'WIFI-MAC', '0', '1',
                        's', '', '', '')
        addCommDataItem(CommDataItems, '120000', '8', 'WIFI-SSID', '0', '1',
                        's', '', '', '')
        addCommDataItem(CommDataItems, '120000', '9', 'WIFI-STRONG', '0', '1',
                        's', '', '', '')
        addCommDataItem(CommDataItems, '120000', '10', 'WIFI-DHCP', '0', '1',
                        's', '', '', '')
        addCommDataItem(CommDataItems, '120000', '11', 'UPTIME', '0', '1', 's',
                        '', '', '')
        addCommDataItem(CommDataItems, '120000', '12', 'WIFI-BSSID', '0', '1',
                        's', '', '', '')
        addCommDataItem(CommDataItems, '120000', '13', 'USB-DEVS', '0', '1',
                        's', '', '', '')
        addCommDataItem(CommDataItems, '120000', '14', 'GPS-MCC', '0', '1',
                        's', '', '', '')
        addCommDataItem(CommDataItems, '120000', '15', 'GPS-MNC', '0', '1',
                        's', '', '', '')
        addCommDataItem(CommDataItems, '120000', '16', 'GPS-LAC', '0', '1',
                        'a', '', '', '')
        addCommDataItem(CommDataItems, '120000', '17', 'GPS-CID', '0', '1',
                        'a', '', '', '')
        addCommDataItem(CommDataItems, '120000', '18', 'MEMORY', '0', '1', 's',
                        '', '', '')
        addCommDataItem(CommDataItems, '120000', '19', 'STORAGE', '0', '1',
                        's', '', '', '')
        addCommDataItem(CommDataItems, '120000', '20', 'GPS-LONGITUDE', '0',
                        '1', 's', '', '', '')
        addCommDataItem(CommDataItems, '120000', '21', 'GPS-LATITUDE', '0',
                        '1', 's', '', '', '')
        addCommDataItem(CommDataItems, '120000', '22', 'WIFI-TYPE', '0', '1',
                        's', '', '', '')
        addCommDataItem(CommDataItems, '120000', '23', 'WIFI-HIDDEN', '0', '1',
                        's', '', '', '')

    task = ET.Element('task')
    agent.append(task)

    #生成控制任务
    #添加控制任务驱动
    task_control = ET.Element('TaskDriver')
    task_control_driver = ET.Element('driver')
    task_control_driver.set('n', 'T.IDrv.Task:libcontrol')
    task_control_driver.set('config', global_var.agent_control_port)
    task_control.append(task_control_driver)
    task.append(task_control)

    #添加RA任务驱动
    task_ra = ET.Element('TaskDriver')
    task.append(task_ra)
    task_ra_driver = ET.Element('driver')
    task_ra_driver.set('n', 'T.IDrv.Task:libtremoteplc')
    task_ra_driver.set('config', '1')
    task_ra.append(task_ra_driver)

    #添加Zigbee任务驱动
    task_zigbee = ET.Element('TaskDriver')
    task.append(task_zigbee)
    task_zigbee_driver = ET.Element('driver')
    task_zigbee_driver.set('n', 'T.IDrv.Task:libzigbee')
    task_zigbee_driver.set(
        'config', global_var.zigbee_port + ';115200;8;N;1;0;' + Products_type +
        ';' + Products_address + ';0;localhost;' +
        global_var.agent_control_port + ';6;60;' + global_var.agent_cache)
    task_zigbee.append(task_zigbee_driver)

    #添加mqtt任务驱动
    if global_var.agent_proto == 'mqtt':
        task_mqtt = ET.Element('TaskDriver')
        task.append(task_mqtt)
        task_mqtt_driver = ET.Element('driver')
        task_mqtt_driver.set('n', 'T.IDrv.Task:libkmqtt')
        task_mqtt_driver.set('config', global_var.mqtt_config)
        task_mqtt.append(task_mqtt_driver)

    # updateVersion.init_save(agent_tree, agent, global_var.itemconfig_path,
    #                         next_version)
    updateVersion.write(agent_tree, global_var.itemconfig_path)
    # agent_tree.write(global_var.itemconfig_path, encoding='utf-8')


def InitalCMDConfig(agent):
    "add by bzyang"
    if global_var.network_mode == '4G':
        #add task driver
        task = ET.Element('task')
        task_ra = ET.Element('TaskDriver')
        task.append(task_ra)
        task_ra_driver = ET.Element('driver')
        task_ra_driver.set('n', 'T.IDrv.Task:libTCmd')
        task_ra_driver.set('config', 'shell')
        task_ra.append(task_ra_driver)
        agent.append(task)

        #add model
        model = ET.Element('model')
        model.set('n', 'CMDsfFRFv')
        agent.append(model)

        device = ET.Element('device')
        device.set('n', 'SIM')
        device.set('id', '1024')
        device.set('ip', '127.0.0.1')
        model.append(device)

        DeviceDriver = ET.Element('driver')
        DeviceDriver.set('n', 'T.IDrv.Task:libTCmd')
        DeviceDriver.set('config', 'sim')
        device.append(DeviceDriver)

        CommDataItems = ET.Element('commDataItems')
        DeviceDriver.append(CommDataItems)

        DataItems = ET.Element('dataItem')
        DataItems.set('freq', '86400000')
        DataItems.set('id', '1')
        DataItems.set('n', 'CSQ')
        DataItems.set('rw', '1')
        DataItems.set('report', '1')
        DataItems.set('type', 's')
        DataItems.set('config', 'AT+CSQ')
        CommDataItems.append(DataItems)
        task = ET.Element('task')
        agent.append(task)
