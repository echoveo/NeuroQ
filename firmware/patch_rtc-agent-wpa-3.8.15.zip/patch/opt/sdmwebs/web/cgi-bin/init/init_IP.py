#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xhzhang'

import os
import commands
from config import global_var
import set_initStatus
from subprocess import Popen, PIPE
from rexml import updateVersion
import xml.etree.ElementTree as ET
import re

# def init_bridge0():
#     ''''初始化bridge0 仅将AnyLink.xml中ip恢复出厂的192.168.100.126'''
#     cmd_ip = 'eeprom net set ip ' + global_var.network_wan_ip
#     # cmd_mac = 'eeprom net set mac ' + global_var.network_wan_mac
#     cmd_mask = 'eeprom net set netmask ' + global_var.network_wan_mask
#     cmd_gateway = 'eeprom net set gateway ' + global_var.network_wan_gateway

#     ip_status = os.system(cmd_ip)
#     # mac_status = os.system(cmd_mac)
#     mask_status = os.system(cmd_mask)
#     gateway_status = os.system(cmd_gateway)

#     if ip_status == 0 and mask_status == 0 and gateway_status == 0:
#         return 0


def init_network():
    # status_eth0 = 1
    # status_eth1 = 1

    # status_eth0 = init_eth0()
    # if global_var.net_muti == 'YES':
    #     status_eth1 = init_eth1()
    # else:
    #     status_eth1 = 0
    # if status_eth0 == 0 and status_eth1 == 0:
    set_initStatus.set_status('NetworkStatus')


# add by fyj
def getIfconfig():
    p = Popen(['/sbin/ifconfig'], stdout=PIPE)
    data = p.stdout.read().split('\n\n')
    return [i for i in data if i and i.startswith('eth0')]


def parseIfconfig():
    dic = {}
    data = getIfconfig()

    for devs in data:
        lines = devs.split('\n')
        fisrtLine = lines[0].strip()
        l = re.split('\s+', fisrtLine)
        devname = l[0]
        macaddr = l[-1]
        dic[devname] = [macaddr]
    return dic


def save_macAddress_config():
    '''save macAddress into Anylink file'''
    dic = parseIfconfig()
    if 'eth0' in dic:
        wan_mac = (dic['eth0'][0])
    else:
        print('not exist')

    anylink_tree = ET.parse(global_var.AnyLinkconfig_path)
    wan_mac_node = anylink_tree.find('NetworkInfo/WAN')
    wan_mac_node.set('mac', wan_mac)
    updateVersion.write(anylink_tree, global_var.AnyLinkconfig_path)
    # anylink_tree.write(global_var.AnyLinkconfig_path,
    #                    encoding='utf-8',
    #                    xml_declaration='true')


# add end
