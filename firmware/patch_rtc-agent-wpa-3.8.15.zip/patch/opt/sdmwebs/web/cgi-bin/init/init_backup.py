#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'yjbao'

import os
from config import global_var

def copy_file(src, dst):
    """
    Copy the 'src' file to the 'dst' file
    """

    if not os.path.isfile(dst):
        cmd = "cp -f " + src + " " + dst
        res = os.popen(cmd)
        res.close()

def init_bak():
    copy_file(global_var.Login_path, global_var.Login_bak_path)




