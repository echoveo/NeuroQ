#!/usr/bin/python
# -*- coding: UTF-8 -*-
'''
userlogin.py
通过jwt实现登录token的功能，并记录到前端的cookie中去
'''
__author__ = 'kali'
import xml.etree.ElementTree as ET
from config import global_var
from CGI import GetCgi
from rexml import updateVersion
import os
import json
from subprocess import Popen, PIPE
import Cookie
import cgi
import sys
import commands
import time
print "Content-Type: application/json charset=utf-8 \n"

g_raw_json = None
g_jwt_secret = "hjgvlofs1e4RsRf2"
g_filename_pwd = "/opt/script/login.json"
def run_cmd(cmd):   
    (status, output) = commands.getstatusoutput(cmd)
    if output != "":
        return output.strip()
    else:
        return ""
def response_error(code,msg):
    return json.dumps({"errcode":code,"msg":msg})

def response_excepiton(msg):
    return json.dumps({"errcode":501,"msg":'excepiton:%s'%(msg)})

def response_data(data):
    return json.dumps({"code":200,"data":data})

def write_to_pwdfile(pwdinfo):
    with open(g_filename_pwd,'w') as fd_w:
        fd_w.write(json.dumps(pwdinfo))


    

def loadpwd_from_file():
    pwdinfo = None
    '''
    pwdinfo =   [{  
                    "UserName":"admin",
                    "Password":"md5value","Status":0},
                 {
                    "UserName":"anylink",
                    "Password":"anylink","Status":0
                 }]
    '''
    if not os.path.exists(g_filename_pwd):
        #写入默认的内容
        write_to_pwdfile( [{  "UserName":"admin",
                            "Password":"21232f297a57a5a743894a0e4a801fc3","Status":0},
                            {"UserName":"anylink",
                            "Password":"88f016cb37fa0090991ecca14747409c","Status":0
                        }])
    with open(g_filename_pwd,'r') as load_f:
        pwdinfo = json.load(load_f)
    '''
   
    '''
    return pwdinfo

#检查用户权限 
#返回:{ret:0,userinfo:用户信息} ret=0 表示操作成功  ret非0为错误码  1001 表示用户名或者密码不存在，1009其它错误
#校验失败用户校验通过
def userinfo_auth(UserName,Password):
    pwdinfo = loadpwd_from_file()
    if pwdinfo == None:
        return {"ret":1009,"errmsg":"msg load userinfo fail! system error!!"}
    for userinfo in pwdinfo:
        if userinfo["UserName"] == UserName and userinfo["Password"] == Password:
            return {"ret":0,"userinfo":userinfo}
    
    return {"ret":1001,"errmsg":"UserName or PassWord invalid!"}

def userinfo_update(UserName,Password):
    pwdinfo = loadpwd_from_file()
    if pwdinfo == None:
        return {"ret":1009,"errmsg":"msg load userinfo fail! system error!!"}
    for userinfo in pwdinfo:
        if userinfo["UserName"] == UserName :
            userinfo["Password"] = Password

    write_to_pwdfile(pwdinfo)

def get_cgi_data():
    global g_raw_json
    try:
        post_json = sys.stdin.read()
        form = cgi.FieldStorage()
        g_raw_json = json.loads(post_json)
      
    except Exception as ept:
        print 'post_data=%s' % post_data
        print 'call api excepiton: %s' % repr(ept)
        
#如果传入token 就只做decode 验证,
#如果传入username,password 就生成token

'''
if __name__ == '__main__':
    try:
        jwt_token = jwt.Jwt.encode({'UserName': 'aa','iss':'NeuroQ','exp':int(time.time())+86400*15}, g_jwt_secret, 3600*8)
        print "jwt_token=%s"%jwt_token
        get_cgi_data()
        
        if 'token' in g_raw_json:
            jwt_token =  g_raw_json['token']
            #decoded = jwt.decode(jwt_token, g_jwt_secret, issuer="NeuroQ", algorithms=["HS256"])
            decoded = jwt.Jwt.decode(jwt_token, g_jwt_secret)
            print response_data({"decoded":decoded})
            sys.exit(0)

        if 'username' in g_raw_json and 'password' in g_raw_json:
            username = g_raw_json['username']
            password =  g_raw_json['password']
            ret = userinfo_auth(username,password)
            if ret['ret'] == 0:
                #jwt_token = jwt.encode({'UserName': username,'iss':'NeuroQ','exp':int(time.time())+86400*15}, g_jwt_secret, algorithm='HS256')
                jwt_token = jwt.Jwt.encode({'UserName': username,'iss':'NeuroQ','exp':int(time.time())+86400*15}, g_jwt_secret, 3600*8)
                #decoded = jwt.decode(jwt_token, g_jwt_secret, issuer="NeuroQ", algorithms=["HS256"])
                print response_data({"jwt_token":jwt_token})
            else:
                print response_error(403,ret['errmsg'])
        else:
            print response_error(403,"username or password is empty")

    #except jwt.ExpiredSignatureError:
    #    print response_error(405,"token is expired.")
    except Exception as ept:
        raise ept
        print response_excepiton(repr(ept))
'''
if __name__ == '__main__':
    try:
        get_cgi_data()
        
        if 'token' in g_raw_json:
            token =  g_raw_json['token']
            #decoded = jwt.decode(jwt_token, g_jwt_secret, issuer="NeuroQ", algorithms=["HS256"])
            #decoded = jwt.Jwt.decode(jwt_token, g_jwt_secret)
            session_token = run_cmd("cat /tmp/webtoken.tmp")
            if session_token == token:
                print response_data("successful")
            else:
                print response_error(403,"invalid token")
            sys.exit(0)

        if 'username' in g_raw_json and 'password' in g_raw_json:
            username = g_raw_json['username']
            password =  g_raw_json['password']
            ret = userinfo_auth(username,password)
            if ret['ret'] == 0:
                #jwt_token = jwt.encode({'UserName': username,'iss':'NeuroQ','exp':int(time.time())+86400*15}, g_jwt_secret, algorithm='HS256')
                #jwt_token = jwt.Jwt.encode({'UserName': username,'iss':'NeuroQ','exp':int(time.time())+86400*15}, g_jwt_secret, 3600*8)
                #decoded = jwt.decode(jwt_token, g_jwt_secret, issuer="NeuroQ", algorithms=["HS256"])
                token = int(time.time())
                os.system("echo %s > /tmp/webtoken.tmp"%(token));
                print response_data({"token":token})
            else:
                print response_error(403,ret['errmsg'])
        else:
            print response_error(403,"username or password is empty")

    except Exception as ept:
        raise ept
        print response_excepiton(repr(ept))
    
    
   
