#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xhzhang'
import xml.etree.ElementTree as ET
from config import global_var
from rexml import updateVersion
import os
from subprocess import Popen, PIPE
import Cookie
import cgi
print "Content-Type: text/html charset=utf-8 \n"

address = ''
mask = ''
dhcp_enable = ''
startIP = ''
endIP = ''


def get_cgi_data():
    global address, mask, dhcp_enable, startIP, endIP

    form = cgi.FieldStorage()
    address = form.getvalue('router-address', '')
    mask = form.getvalue('router-mask', '')
    dhcp_enable = form.getvalue('router-dhcp', '')
    startIP = form.getvalue('router-dhcp-startIP', '')
    endIP = form.getvalue('router-dhcp-endIP', '')

    if address is None:
        address = ''
    if mask is None:
        mask = ''
    if startIP is None:
        startIP = ''
    if endIP is None:
        endIP = ''
    if dhcp_enable is None:
        dhcp_enable = '0'


def set_router():
    if 'HTTP_COOKIE' in os.environ:
        cookie_string = os.environ.get('HTTP_COOKIE')
        c = Cookie.SimpleCookie()
        c.load(cookie_string)
        data = c['AnyLinkLan'].value
    anylink_tree = ET.parse(global_var.AnyLinkconfig_path)
    router_node = anylink_tree.find('Router')
    router_node.set("enable", "YES")
    router_node.find("IPAddr").text = address
    router_node.find("SubNetMask").text = mask
    router_node.find("EnableDHCPServer").text = dhcp_enable
    router_node.find("DHCPConfig/StartIP").text = startIP
    router_node.find("DHCPConfig/EndIP").text = endIP
    updateVersion.write(anylink_tree, global_var.AnyLinkconfig_path)
    if data == "English":
        print 'The Network set successfully'
    else:
        print '路由模式设置成功'


if __name__ == '__main__':
    get_cgi_data()
    set_router()
