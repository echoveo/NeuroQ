#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xhzhang'

import cgi, os
import xml.etree.ElementTree as ET
from config import global_var
from Log import Loginfo
from rexml import updateVersion
import sys
import os, Cookie
reload(sys)
sys.setdefaultencoding('utf-8')

print "Content-Type: text/html charset=utf-8 \n"

change_mode = ''


def get_cgi_data():
    global change_mode
    form = cgi.FieldStorage()
    change_mode = form.getvalue('modetype')


def get_current_mode():
    #current_network_mode = change_mode
    anylink_tree = ET.parse(global_var.AnyLinkconfig_path)
    anylink = anylink_tree.getroot()
    current_network_mode = anylink.find('NetworkInfo/Mode')
    return current_network_mode.text

    #cmd_find_gatewat = 'find /etc/init.d -name S91init-gateway'
    #cmd_find_3g = 'find /etc/init.d -name S91init-3G'
    #flag_gateway = os.popen('find /etc/init.d -name S91init-gateway').read()
    #flag_3g = os.popen('find /etc/init.d -name S91init-3G').read()
    #if flag_gateway == '/etc/init.d/S91init-gateway\n':
    #    current_network_mode = 'gateway'
    #if flag_3g == '/etc/init.d/S91init-3G\n':
    #   current_network_mode = '3G'


def modify_anylink_mode(mode):
    '''获取cookie'''
    if 'HTTP_COOKIE' in os.environ:
        cookie_string = os.environ.get('HTTP_COOKIE')
        c = Cookie.SimpleCookie()
        c.load(cookie_string)
        data = c['AnyLinkLan'].value
    '''修改Anylink.xml'''
    anylink_tree = ET.parse(global_var.AnyLinkconfig_path)
    anylink = anylink_tree.getroot()
    network_mode_node = anylink.find('NetworkInfo/Mode')
    if network_mode_node is not None:
        network_mode_node.text = mode
    else:
        if data == "English":
            log.write_error('No Mode node')
        else:
            log.write_error('没有Mode节点')
    updateVersion.write(anylink_tree, global_var.AnyLinkconfig_path)
    # anylink_tree.write(global_var.AnyLinkconfig_path,
    #                    encoding='utf-8',
    #                    xml_declaration='true')


def switch_tg_gateway():
    '''获取cookie'''
    if 'HTTP_COOKIE' in os.environ:
        cookie_string = os.environ.get('HTTP_COOKIE')
        c = Cookie.SimpleCookie()
        c.load(cookie_string)
        data = c['AnyLinkLan'].value

    current_mode = get_current_mode()
    if data == "English":
        if current_mode == change_mode:
            log.write_info(
                'The current way of networking is consistent with the way that needs to be modified, without any processing!'
            )
        else:
            modify_anylink_mode(change_mode)
            log.write_info('Network mode[%s]changes to[%s]successfully!' %
                           (current_mode, change_mode))
    else:
        if current_mode == change_mode:
            log.write_info('当前联网方式与需要修改的方式一致，不做任何处理！')
        else:
            modify_anylink_mode(change_mode)
            log.write_info('联网方式由[%s]改为[%s]成功!' % (current_mode, change_mode))

        #delete_old_mode_cmd = 'wr rm -rf /etc/init.d/S91init-' + current_mode
        #config_new_mode_cmd = 'wr cp /opt/script/S91init-' + change_mode +' /etc/init.d'
        #chmod_new_cmd = 'wr chmod 755 /etc/init.d/S91init-' + change_mode

        #status1 = os.system(delete_old_mode_cmd)
        #status2 = os.system(config_new_mode_cmd)
        #status3 = os.system(chmod_new_cmd)

        #if status1 == 0 and status2 == 0 and status3 == 0:


if __name__ == '__main__':
    log = Loginfo.Loginfo()
    get_cgi_data()
    switch_tg_gateway()