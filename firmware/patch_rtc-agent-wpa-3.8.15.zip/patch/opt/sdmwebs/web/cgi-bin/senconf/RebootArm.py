#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xhzhang'

from os import system, popen
import sys
import os
import xml.etree.ElementTree as ET
from config import global_var
from rexml import updateVersion

print "Content-Type: text/html charset=utf-8 \n\n"

#def set_logout_status():
#    '''logout,set 0 to status of login'''
#    anylink_tree = ET.parse(global_var.AnyLinkconfig_path)
#    anylink = anylink_tree.getroot()

#    logininfo_node = anylink_tree.find('LoginInfo')
#    logininfo_node_list = logininfo_node.getchildren()
#    for node in logininfo_node_list:
#        if node.tag == 'Status':
#            node.text = '0'
#            break
#    # ET.dump(anylink_tree)
#    anylink_tree.write(global_var.AnyLinkconfig_path, encoding='utf-8', xml_declaration='true')


def set_logout_status():
    '''logout,set 0 to status of login'''
    login_tree = ET.parse(global_var.Login_path)
    login = login_tree.getroot()

    logininfo_node = login_tree.find('LoginInfo')
    logininfo_node_list = logininfo_node.getchildren()
    for node in logininfo_node_list:
        if node.tag == 'Status':
            node.text = '0'
            break
    updateVersion.write(login_tree, global_var.Login_path)
    # login_tree.write(global_var.Login_path,
    #                  encoding='utf-8',
    #                  xml_declaration='true')


def reboot():
    reboot_cmd = '/sbin/reboot'

    os.system(reboot_cmd)


def destructor():
    system('ifconfig ra0 down')
    system(
        'ps -ef|grep udhcpc |grep -v \'grep\'|awk \'{print $1}\'|xargs kill -9  &>/dev/null'
    )
    system('rmmod -f /opt/script/rt5370sta.ko')


if __name__ == '__main__':
    set_logout_status()
    # destructor()
    reboot()