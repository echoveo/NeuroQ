#!/usr/bin/python
# -*- coding: UTF-8 -*-
import os, cgi
import sys
import Cookie
import subprocess
import datetime
import time
import restapi
print "Content-Type: text/html charset=utf-8 \n"


def execute_command(cmdstring, timeout=None):
    if timeout:
        end_time = datetime.datetime.now() + datetime.timedelta(seconds=timeout)
    timeout_tmp=timeout
    #sub = subprocess.Popen(cmdstring, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,stdin=subprocess.PIPE, bufsize=4096, shell=True)
    sub = subprocess.Popen(cmdstring, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, bufsize=4096, shell=True)
 
    while True:
        if sub.poll() is not None:
            break
        time.sleep(0.1)
        
        if timeout_tmp!=None and timeout_tmp<=0.0:
            #if end_time <= datetime.datetime.now():
            print "cmd=",cmdstring ,'is timeout kill it'
            sub.kill()
            return ""   #TIME_OUT
        timeout_tmp-=0.1
    #print "[execute_command]",cmdstring
    #print "[execute_command]","sub=",sub.stdout
    if sub.stdout == None:
        return ""
    else:
        return str(sub.stdout.read()).strip()
def run_cmd(cmd,wait=True,wait_timeout=10):
    if wait==False:
        os.system(cmd)
    else:
        return execute_command(cmdstring=cmd,timeout=wait_timeout)

if __name__ == '__main__':
    web_ret = None
    WAN_MAC = None
    try:
        web_ret = restapi.request("/hw_autodetect?device=ethernet")
        #print web_ret
    except Exception as ept:
        #print ept
        pass
    if web_ret != None:
        WAN_MAC = web_ret['info']['WAN-MAC']
    else:
        WAN_MAC = run_cmd("ifconfig eth0.2 | grep HWaddr | awk  '{print $5}'")
    WiFi_MAC = run_cmd("cat /lib/firmware/wlan/qca_cld/wlan_mac.bin | grep 'Intf0MacAddress=' | awk -F '=' '{print $2}'")
    WiFi_MAC = WiFi_MAC[0:2]+":"+WiFi_MAC[2:4]+":"+WiFi_MAC[4:6]+":"+WiFi_MAC[6:8]+":"+WiFi_MAC[8:10]+":"+WiFi_MAC[10:12]
    print "{\"WAN_MAC\":\"%s\",\"WiFi_MAC\":\"%s\"}" % (WAN_MAC,WiFi_MAC)