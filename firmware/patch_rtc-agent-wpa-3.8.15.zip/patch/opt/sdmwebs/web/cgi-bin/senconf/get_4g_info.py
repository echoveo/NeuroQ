#!/usr/bin/python
# -*- coding: utf-8 -*-
import serial
import json
import os
import xml.etree.ElementTree as ET
from config import global_var
from Log import Loginfo
import commands
print "Content-Type: text/html charset=utf-8 \n"

def run_cmd(cmd):   
    (status, output) = commands.getstatusoutput(cmd)
    if output != "":
        return output.strip()
    else:
        return ""

def get_info():
    res_data = {"ccid": '', "signal":"","status":"","RX-TX":"","SPN":""}
    
    ccid = run_cmd("/opt/script/pppd/ec20_data_call --at_iccid | grep '+QCCID:' | awk '{print $2}'")
    if ccid != None and len(ccid)>10 :
        res_data["ccid"] = ccid
        res_data["status"] =  run_cmd("/opt/script/pppd/ec20_data_call --net status ")
        csq = run_cmd("/opt/script/pppd/ec20_data_call --at_csq | grep \"+CSQ:\" | awk '{print $2}'")
        if "," in csq:
            res_data["signal"] = "%d dBm" % ( (113-2*int(csq.split(',')[0])) )
        str_bytes = run_cmd("/opt/script/pppd/ec20_data_call --at \"AT+QGDCNT?\" | grep \"+QGDCNT:\" | awk '{print $2}'")
        if "," in str_bytes:
            res_data["RX-TX"] = "send:%s bytes | receive:%s bytes" % ( str_bytes.split(',')[0],str_bytes.split(',')[1] )
        res_data["SPN"] = run_cmd("/opt/script/pppd/ec20_data_call --at \"AT+QSPN\" | grep \"+QSPN:\" | awk '{print $2 $3 $4 $5 $6 $7 $8}' ")
    #/opt/script/pppd/ec20_data_call --at_iccid | grep '+QCCID:' | awk '{print $2}'
    #/opt/script/pppd/ec20_data_call --net status  
    #/opt/script/pppd/ec20_data_call --at "AT+QSPN" | grep "+QSPN:" | awk '{print $2}'     QSPN:
    #/opt/script/pppd/ec20_data_call --at "AT+QGDCNT?" | grep "+QGDCNT:" | awk '{print $2}'  send,receive bytes
    #/opt/script/pppd/ec20_data_call --at_csq | grep "+CSQ:" | awk '{print $2}'  signal strength
  
    return json.dumps(res_data)




if __name__ == "__main__":
    print get_info()
