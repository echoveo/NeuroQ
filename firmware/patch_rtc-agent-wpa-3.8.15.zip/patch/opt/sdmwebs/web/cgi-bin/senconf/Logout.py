#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xhzhang'

import xml.etree.ElementTree as ET
from config import global_var
from rexml import updateVersion

print "Content-Type: text/html charset=utf-8 \n"


def set_logout_status():
    '''logout,set 0 to status of login'''
    login_tree = ET.parse(global_var.Login_path)
    login = login_tree.getroot()

    logininfo_node = login_tree.find('LoginInfo')
    logininfo_node_list = logininfo_node.getchildren()
    for node in logininfo_node_list:
        if node.tag == 'Status':
            node.text = '0'
            break
    # ET.dump(anylink_tree)
    updateVersion.write(login_tree, global_var.Login_path)
    # login_tree.write(global_var.Login_path,
    #                  encoding='utf-8',
    #                  xml_declaration='true')


if __name__ == '__main__':
    set_logout_status()