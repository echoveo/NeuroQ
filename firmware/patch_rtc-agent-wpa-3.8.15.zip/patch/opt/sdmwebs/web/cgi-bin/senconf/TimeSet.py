#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xhzhang'

import xml.etree.ElementTree as ET
from config import global_var
import os, cgi
import Cookie
import datetime,time

print "Content-Type: text/html charset=utf-8 \n\n"

date = ''
timezone = timezone_a = cmd = ''
basepath = "/usr/share/zoneinfo"

def get_cgi_data():
    '''get cgi time data'''
    global date, timezone, timezone_a, cmd
    form = cgi.FieldStorage()
    date = form.getvalue('YMDHMS', '%Y-%m-%d %H:%M:%S')
    timezone = form.getvalue('TimeZone', '')
    cmd = form.getvalue('cmd',"")
    timezone_a = '0'


def write_timezone_anylink():
    '''把当前设置的时区写入AnyLink.xml'''
    anylink_tree = ET.parse(global_var.AnyLinkconfig_path)
    anylink = anylink_tree.getroot()
    timezone_node = anylink_tree.find('TimeZoneInfo/TimeZone')
    timezone_node.text = timezone
    anylink_tree.write(global_var.AnyLinkconfig_path, encoding='utf-8', xml_declaration='true')


def set_date():
    '''set date time'''
    '''获取cookie'''
    if 'HTTP_COOKIE' in os.environ:
        cookie_string=os.environ.get('HTTP_COOKIE')
        c=Cookie.SimpleCookie()
        c.load(cookie_string)
        data=c['AnyLinkLan'].value

    '''set date time'''
    cmd_set = './stime ' + timezone_a + ' "' + date + '"'
    cmd_hwclock = '/sbin/hwclock -w -f /dev/rtc1'
    print cmd_set
    print cmd_hwclock
    excute_set_status = os.system(cmd_set)
    excute_hwclock_status = os.system(cmd_hwclock)
    print excute_set_status,excute_hwclock_status
    if data == "English":
        if excute_set_status == 0 and excute_hwclock_status == 0:
            print 'Modify success'
            write_timezone_anylink()
        else:
            print 'Modify fail'
    else:
        if excute_set_status == 0 and excute_hwclock_status == 0:
            print '修改成功'
            write_timezone_anylink()
        else:
            print '修改失败'

def set_time():
    '''设置时间，考虑所有时区'''
    try:
        if date != '%Y-%m-%d %H:%M:%S':
            # 获取当前系统时间的UTC偏移量
            current_time = datetime.datetime.now()
            utc_offset = (current_time - datetime.datetime.utcnow()).total_seconds() / 3600
            
            # 将输入的时间转换为UTC时间
            local_date = datetime.datetime.strptime(date, '%Y-%m-%d %H:%M:%S')
            utc_date = local_date - datetime.timedelta(hours=utc_offset)
            utc_date_str = utc_date.strftime('%Y-%m-%d %H:%M:%S')
            
            cmd_set = 'date -s ' + '"' + utc_date_str + '"'
            excute_set_status = os.system(cmd_set)
            cmd_hwclock = '/sbin/hwclock -w -f /dev/rtc1'
            excute_hwclock_status = os.system(cmd_hwclock)
	    cmd_set = '/sbin/hwclock -f /dev/rtc1 --utc --hctosys'
            os.system(cmd_set)
            if excute_set_status == 0 and excute_hwclock_status == 0:           
                print "OK"
            else:
                print "ERROR"
        else:
            print "OK"
    except Exception as e:
        print "ERROR"
def set_zone():
    '''设置时区'''
    basepath = "/usr/share/zoneinfo"
    realPath = basepath + timezone   
    try:
        os.system("rm -rf /etc/localtime")
        os.system("ln -sf "+realPath+" /etc/localtime")
        write_timezone_anylink()
    except Exception as e:
        print "ERROR"

if __name__ == '__main__':
    get_cgi_data()
    if cmd == 'timeZone':
        set_zone()
    elif cmd == 'time':
        set_time()    
