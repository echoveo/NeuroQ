#!/usr/bin/python
# -*- coding: UTF-8 -*-

print "Content-Type: text/html charset=utf-8 \n"

if __name__ == '__main__':
    path = '../vpn/vpn_version.txt'
    vpnVersion = '1.0.0'
    with open(path, 'r') as f:
        vpnVersion = f.read().strip()
    print vpnVersion