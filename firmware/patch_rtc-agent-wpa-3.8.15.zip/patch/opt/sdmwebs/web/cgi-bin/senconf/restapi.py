#!/usr/bin/python
# -*- coding: UTF-8 -*-
import urllib2
import json
import time
import os



def request(api,data=None,method='GET'):
    #try:
    headers = {'Content-Type':'application/json'}
    url = "http://127.0.0.1:8080"+api #'http://192.168.101.10:10620/api/v1.0/testServer/send_test_report'
    
    request = None
    if method == 'POST':
        request = urllib2.Request(url=url
                            ,headers=headers
                            ,data=json.dumps(data))
    else:
        request = urllib2.Request(url=url)
    response = urllib2.urlopen(request, timeout=60)
    
    ret_str = response.read()
    
    ret = {}
    if ret_str != "":
        ret = json.loads(ret_str)
    else:           
        raise Exception,"{0} return null".format(api)
    if ret.has_key('code') and ret['code'] == 200 :
        if ret.has_key('errcode'):             
            raise Exception,"{0} return error1[{1}]".format(api,ret)
        else:
            return ret["data"]
    else:               
        raise Exception,"{0} return error2[{1}]".format(api,ret)
    #except Exception as ept:          
    #        return None