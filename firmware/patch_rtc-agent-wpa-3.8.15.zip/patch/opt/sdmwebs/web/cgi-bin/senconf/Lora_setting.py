#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'bzyang'

import serial
from CGI import GetCgi
import xml.etree.ElementTree as ET
from config import global_var
from rexml import updateVersion
import sys, cgi
reload(sys)
sys.setdefaultencoding('utf-8')

print "Content-Type: text/html charset=utf-8 \n"

g_baudrate = g_parity = g_RF_freq = g_RF_factor = g_RF_mode = g_RF_BW = g_ID_H = ''
g_ID_L = g_net_ID = g_power = ''


def get_cgi_data():
    global g_baudrate, g_parity, g_RF_freq, g_RF_factor, g_RF_mode, g_RF_BW, g_ID_H, g_ID_L, g_net_ID, g_power
    form = cgi.FieldStorage()
    g_baudrate = form.getvalue('g_baudrate', '')
    g_parity = form.getvalue('g_parity', '')
    g_RF_freq = form.getvalue('g_RF_freq', '')
    g_RF_factor = form.getvalue('g_RF_factor', '')
    g_RF_mode = form.getvalue('g_RF_mode', '')
    g_RF_BW = form.getvalue('g_RF_BW', '')
    g_ID_H = form.getvalue('g_ID_H', '')
    g_ID_L = form.getvalue('g_ID_L', '')
    g_net_ID = form.getvalue('g_net_ID', '')
    g_power = form.getvalue('g_power', '')


def hexShow(argv):
    result = ''
    print "%s" % hLen
    for i in xrange(hLen):
        hvol = ord(argv[i])
        hhex = '%02x' % hvol
        result += hhex + ' '
    print 'hexShow:', result


def read_command(com, baud, par):
    #Length: 23, Data: AF AF 00 00 AF 80 02 0C    00 00 00 00 00 00 00 00 00 00 00 00    9B 0D 0A
    try:
        t = serial.Serial(port=com, baudrate=baud, parity=par, timeout=1)
    except Exception, e:
        print Exception, ":", e
        return
    print t.portstr
    readstr = (0xAF, 0xAF, 0x00, 0x00, 0xAF, 0x80, 0x02, 0x0C, 0x00, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
               0x9B, 0x0D, 0x0A)
    n = t.write(readstr)
    if (23 != n):
        print "COM口不存在!\n"
        return

    #Length: 23, Data: AF AF 00 00 AF 00 02 0C     04 00 6C 80 00 0B 00 07 00 00 00 07     24 0D 0A
    str = t.read(23)
    if (None == str):
        print "无MiNi设备!\n"
        return
    hexShow(str)
    if ((len(str) != 23)):
        print "COM被占用或没有识别Anylink MiNi!"
        return
    if ((ord(str[0]) != 0xAF) or (ord(str[7]) != 0x0C)):
        print "保存数据格式不对!"
        return

    baudrate = {
        0x01: 1200,
        0x02: 2400,
        0x03: 4800,
        0x04: 9600,
        0x05: 19200,
        0x06: 38400,
        0x07: 57600
    }
    parity = {0x00: "NONE", 0x01: "ODD", 0x02: "EVEN"}
    RF_factor = {7: 128, 8: 256, 9: 512, 10: 1024, 11: 2048, 12: 4096}
    RF_mode = {0: "��ģʽ", 1: "�͹���ģʽ", 2: "����ģʽ"}
    RF_bw = {6: "62.5K", 7: "125K", 8: "250K", 9: "500K"}
    power = {
        1: "4db",
        2: "7db",
        3: "10db",
        4: "13db",
        5: "14db",
        6: "17db",
        7: "20db"
    }

    configureStr = str[8:20]
    print "baudrate: %d" % baudrate[ord(configureStr[0])]
    print "parity: %s" % parity[ord(configureStr[1])]
    freq = ord(configureStr[2])
    freq = freq * (2**8) + ord(configureStr[3])
    freq = freq * (2**8) + ord(configureStr[4])
    print "%x" % freq
    print "RF_frequency:%d" % ((freq * 61.035) / 1000000)
    print "RF_factor: %d" % (RF_factor[ord(configureStr[5])])
    print "RF_mode: %s" % (RF_mode[ord(configureStr[6])])
    print "RF_bw: %s" % (RF_bw[ord(configureStr[7])])
    print "Customer ID_H: %d" % (ord(configureStr[8]))
    print "Customer ID_L: %d" % (ord(configureStr[9]))
    print "Net ID: %d" % (ord(configureStr[10]))
    print "Power: %s" % (power[ord(configureStr[11])])

    print "read success!"


def save_lora_config():
    '''将lora信息保存到AnyLink.xml中'''
    filepath = global_var.AnyLinkconfig_path
    anylink_tree = ET.parse(filepath)
    anylink_tree.find('LoraInfo/g_baudrate').text = g_baudrate
    anylink_tree.find('LoraInfo/g_parity').text = g_parity
    anylink_tree.find('LoraInfo/g_RF_freq').text = g_RF_freq
    anylink_tree.find('LoraInfo/g_RF_factor').text = g_RF_factor
    anylink_tree.find('LoraInfo/g_RF_mode').text = g_RF_mode
    anylink_tree.find('LoraInfo/g_RF_BW').text = g_RF_BW
    anylink_tree.find('LoraInfo/g_ID_H').text = g_ID_H
    anylink_tree.find('LoraInfo/g_ID_L').text = g_ID_L
    anylink_tree.find('LoraInfo/g_net_ID').text = g_net_ID
    anylink_tree.find('LoraInfo/g_power').text = g_power
    #ET.dump(anylink_tree)
    updateVersion.write(anylink_tree, filepath)
    # anylink_tree.write(filepath, encoding='utf-8', xml_declaration='true')


def write_command(com, baud, par, configureStr):
    #configure=("baudrate", "parity", "RF_freq", "RF_factor", "RF_mode", "RF_BW", "ID_H", "ID_L", "net_ID", "power")
    #Length: 23, Data: AF AF 00 00 AF 80 01 0C    04 00 6C 40 12 0B 00 07 00 00 00 07   75 0D 0A
    baudrate = {
        "1200": 0x01,
        "2400": 0x02,
        "4800": 0x03,
        "9600": 0x04,
        "19200": 0x05,
        "38400": 0x06,
        "57600": 0x07
    }
    parity = {"NONE": 0x00, "ODD": 0x01, "EVEN": 0x02}
    RF_factor = {
        "128": 7,
        "256": 8,
        "512": 9,
        "1024": 10,
        "2048": 11,
        "4096": 12
    }
    RF_mode = {"normal": 0, "save": 1}
    RF_bw = {"62.5K": 6, "125K": 7, "250K": 8, "500K": 9}
    power = {
        "4db": 1,
        "7db": 2,
        "10db": 3,
        "13db": 4,
        "14db": 5,
        "17db": 6,
        "20db": 7
    }
    writeStr = [0xAF, 0xAF, 0x00, 0x00, 0xAF, 0x80, 0x01, 0x0C]
    writeStr.append(baudrate[configureStr[0]])
    writeStr.append(parity[configureStr[1]])
    freq = float(configureStr[2])
    freq = int((freq * 1000000) / 61.035)
    freqByte1 = 0xFF & freq
    freqByte2 = 0xFF & (freq / (2**8))
    freqByte3 = 0xFF & (freq / (2**16))
    writeStr.append(freqByte3)
    writeStr.append(freqByte2)
    writeStr.append(freqByte1)
    writeStr.append(RF_factor[configureStr[3]])
    writeStr.append(RF_mode[configureStr[4]])
    writeStr.append(RF_bw[configureStr[5]])
    writeStr.append(int(configureStr[6]))
    writeStr.append(int(configureStr[7]))
    writeStr.append(int(configureStr[8]))
    writeStr.append(power[(configureStr[9])])

    temp = 0
    for i in range(len(writeStr)):
        temp += writeStr[i]
    temp = int(temp % 256)
    temp = temp & 0xFF
    writeStr.append(temp)
    writeStr.append(0x0D)
    writeStr.append(0x0A)
    '''hexStr = ""
    for i in range(len(writeStr)):
        hexStr += "%02x "%writeStr[i]
    print hexStr'''

    try:
        #print "open com %s %s %s"%(com, baud, par)
        t = serial.Serial(port=com, baudrate=baud, parity=par, timeout=1)
        if not t.isOpen():
            print "open com failed"
    except Exception, e:
        print Exception, ":", e
        return

    n = 0
    for i in range(23):
        #print "%02x "%writeStr[i],
        t.write(chr(writeStr[i]))
        n = n + 1
    #print n
    if (23 != n):
        print "send write_command failed!\n"
        return
    #print "waiting response..."

    #Length: 23, Data: AF AF 00 00 AF 00 01 0C      04 00 6C 40 12 0B 00 07 00 00 00 07      F5 0D 0A
    str = t.read(23)
    if (0 == len(str)):
        print "无MiNi设备!\n"
        return
    #hexShow(str)
    if ((len(str) != 23)):
        print "COM被占用或没有识别Anylink MiNi"
        return
    for i in range(8, 20):
        if (ord(str[i]) != writeStr[i]):
            print "保存数据格式不对!"
            return
    save_lora_config()
    print "配置成功"


if __name__ == "__main__":
    #read_command("com5", 9600, serial.PARITY_NONE)
    get_cgi_data()
    configureStr = (g_baudrate, g_parity, g_RF_freq, g_RF_factor, g_RF_mode,
                    g_RF_BW, g_ID_H, g_ID_L, g_net_ID, g_power)
    #print configureStr
    write_command("/dev/ttyO5", g_baudrate, serial.PARITY_NONE, configureStr)
