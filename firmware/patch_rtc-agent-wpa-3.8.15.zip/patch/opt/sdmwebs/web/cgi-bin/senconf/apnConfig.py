#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xmzhao'

import cgi
import sys
import xml.etree.ElementTree as ET

reload(sys)
import os, Cookie
import serial
from rexml import updateVersion

sys.setdefaultencoding('utf-8')

print "Content-Type: text/html charset=utf-8 \n"

Conf_PATH = '/opt/sdmwebs/web/conf/operatorinfo.xml'

IMSI = ''
apn = apnUsrName = apnPassword = apnOperator = apnCmd = apnImsi = ''


def get_cgi_data():
    ''' get data '''
    global apn, apnUsrName, apnPassword, apnOperator, apnCmd, apnImsi
    form = cgi.FieldStorage()
    apn = form.getvalue('apn', '')
    apnUsrName = form.getvalue('apnUsrName', '')
    apnPassword = form.getvalue('apnPassword', '')
    apnOperator = form.getvalue('apnOperator', '')
    apnCmd = form.getvalue('apnCmd', '')
    apnImsi = form.getvalue('apnImsi', '')


def getIMSI():
    '''获取当前4g卡的imsi'''
    global IMSI
    fd = serial.Serial('/dev/ttyUSB2', 115200, 8, 'E', 1, timeout=1)
    fd.write('AT+CIMI\r\n')
    data = fd.readall()
    if data and 'OK' in data:
        fd.close()
        re = data[data.index('\r\n'):]
        IMSI = re[:7].strip()
        return IMSI
    else:
        fd.close()
        return ''


def IMSIinList(currentIMSI):
    '''判断xml中是否已有当前卡的imsi'''
    IMSIList = []
    operator_tree = ET.parse(Conf_PATH)
    operator_InfoList = operator_tree.findall(
        'operator_Remote/operator_List/operator_Info')
    for operator_Info in operator_InfoList:
        if "|" in operator_Info.find('imsi').text:
            imsiArray = operator_Info.find('imsi').text.split('|')
            for imsi in imsiArray:
                IMSIList.append(imsi)
        else:
            IMSIList.append(operator_Info.find('imsi').text)
    if currentIMSI in IMSIList:
        return True
    else:
        return False


def save_xml():
    global IMSI
    '''save data to xml file'''
    if 'HTTP_COOKIE' in os.environ:
        cookie_string = os.environ.get('HTTP_COOKIE')
        c = Cookie.SimpleCookie()
        c.load(cookie_string)
        data = c['AnyLinkLan'].value

    operator_tree = ET.parse(Conf_PATH)
    operator_InfoList = operator_tree.find('operator_Remote/operator_List')
    operator_Info = ET.Element('operator_Info')
    name = ET.Element('name')
    imsinode = ET.Element('imsi')
    usr = ET.Element('usr')
    passwd = ET.Element('passwd')
    apnnode = ET.Element('apn')
    name.text = apnOperator
    imsinode.text = IMSI
    usr.text = apnUsrName
    passwd.text = apnPassword
    apnnode.text = apn

    operator_Info.append(name)
    operator_Info.append(imsinode)
    operator_Info.append(usr)
    operator_Info.append(passwd)
    operator_Info.append(apnnode)
    operator_InfoList.append(operator_Info)
    updateVersion.write(operator_tree, Conf_PATH)
    # operator_tree.write(Conf_PATH, encoding='utf-8')

    if data == "English":
        print 'Set success!'
    else:
        print '设置成功！'


def deleteApn():
    operator_tree = ET.parse(Conf_PATH)
    operator_List = operator_tree.find('operator_Remote/operator_List')
    operator_InfoList = operator_tree.findall(
        'operator_Remote/operator_List/operator_Info')
    for operator_Info in operator_InfoList:
        if operator_Info.find('imsi').text == apnImsi:
            operator_List.remove(operator_Info)
    updateVersion.write(operator_tree, Conf_PATH)
    # operator_tree.write(Conf_PATH, encoding='utf-8')


if __name__ == '__main__':
    if 'HTTP_COOKIE' in os.environ:
        cookie_string = os.environ.get('HTTP_COOKIE')
        c = Cookie.SimpleCookie()
        c.load(cookie_string)
        data = c['AnyLinkLan'].value

    get_cgi_data()
    if apnCmd == 'delete':
        deleteApn()
    elif apnCmd == 'detection':
        if IMSIinList(getIMSI()):
            if data == "English":
                print 'This 4G card is already in the configuration list and does not need to be configured.'
            else:
                print '此卡已在配置列表中，无需配置'
        else:
            if data == "English":
                print 'This 4G card needs to be configured.'
            else:
                print '这张4G卡需要配置apn'
    elif apnCmd == 'add':
        if IMSIinList(getIMSI()):
            if data == "English":
                print 'This 4G card is already in the configuration list and does not need to be configured.'
            else:
                print '此卡已在配置列表中，无需配置'
        else:
            save_xml()
