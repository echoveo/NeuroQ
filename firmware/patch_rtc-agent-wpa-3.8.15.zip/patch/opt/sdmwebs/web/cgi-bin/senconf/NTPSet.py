#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xhzhang'

import xml.etree.ElementTree as ET
from config import global_var
import os, cgi
import Cookie

print "Content-Type: text/html charset=utf-8 \n\n"

ntp_server1 = ''
ntp_server2 = ''
server_no = 1


def get_cgi_data():
    '''get cgi data'''
    global ntp_server1, ntp_server2, server_no
    form = cgi.FieldStorage()
    ntp_server1 = form.getvalue('ntpServer1', '1.pool.ntp.org')
    ntp_server2 = form.getvalue('ntpServer2', '2.pool.ntp.org')
    server_no = int(form.getvalue('serverNo', 1))


def setNTPServer():
    anylink_tree = ET.parse(global_var.AnyLinkconfig_path)
    ntp_server_list = anylink_tree.findall("NTP/NTPServerAddress")
    if server_no == 1:
        ntp_server_list[0].text = ntp_server1
    elif server_no == 2:
        ntp_server_list[1].text = ntp_server2
    anylink_tree.write(global_var.AnyLinkconfig_path, encoding='utf-8')
    print 'OK'


if __name__ == '__main__':
    get_cgi_data()
    setNTPServer()
