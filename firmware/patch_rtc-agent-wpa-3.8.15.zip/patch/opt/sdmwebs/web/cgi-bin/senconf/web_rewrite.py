#!/usr/bin/python
# -*- coding: UTF-8 -*-
'''
web_rewrite.py
实现一个rewrite 功能，将 get或者post请求转发到 
http://127.0.0.1:8080/中去
8080端口由 /opt/scrite/webSvr.py提供实现
'''
__author__ = 'kali'
import xml.etree.ElementTree as ET
from config import global_var
from CGI import GetCgi
from rexml import updateVersion
import os
import json
from subprocess import Popen, PIPE
import Cookie
import cgi
import sys
import commands
import restapi
print "Content-Type: application/json charset=utf-8 \n"


def run_cmd(cmd):   
    (status, output) = commands.getstatusoutput(cmd)
    if output != "":
        return output.strip()
    else:
        return ""

def get_cgi_data():
    post_data = ""
    try:
        post_data = sys.stdin.read()
        form = cgi.FieldStorage()
        params = json.loads(post_data)
        if params['method'] == 'GET' or params['method'] == 'get':
            print json.dumps(restapi.request(params['url']))
        else:
            print json.dumps(restapi.request(params['url'],json.loads(params['data']),'POST'))
    except Exception as ept:
        print 'post_data=%s' % post_data
        print 'call api excepiton: %s' % repr(ept)
        


if __name__ == '__main__':
    get_cgi_data()
   
