#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xhzhang'
import xml.etree.ElementTree as ET
from config import global_var
from CGI import GetCgi
from rexml import updateVersion
import os
from subprocess import Popen, PIPE
import Cookie
import cgi
print "Content-Type: text/html charset=utf-8 \n"

hostname = ''
ip = mac = mask = gateway = DNS = ''
DHCPMode = ''


def get_cgi_data():
    global hostname, type, DNS
    global ip, mac, mask, gateway, DHCPMode

    form = cgi.FieldStorage()
    hostname = form.getvalue('hostname', '')
    type = form.getvalue('type', '')
    DNS = form.getvalue('dnsId', '')
    ip = form.getvalue('IPAddress', '')
    # mac = cgi.FieldStorage().getvalue('MACAddress','')
    mask = form.getvalue('SubnetMask', '')
    gateway = form.getvalue('GatewayAddress', '')
    DHCPMode = form.getvalue('DHCPMode', '')
    if DNS is None:
        DNS = ''
    if ip is None:
        ip = ''
    if mac is None:
        mac = ''
    if mask is None:
        mask = ''
    if gateway is None:
        gateway = ''
    print hostname, type, DNS, ip, mac, mask, gateway, DHCPMode

#set_dns ,todo 应该是没有调用到的 20220207 kali
def set_dns():
    '''获取cookie'''
    if 'HTTP_COOKIE' in os.environ:
        cookie_string = os.environ.get('HTTP_COOKIE')
        c = Cookie.SimpleCookie()
        c.load(cookie_string)
        data = c['AnyLinkLan'].value
    '''设置dns'''
    dns_status = os.system('eeprom net set dns ' + DNS)
    if dns_status == 0:
        os.system('echo "nameserver %s " > /etc/resolv.conf ' % (DNS))
        if DNS != "114.114.114.114":
            os.system('echo "nameserver 114.114.114.114" >> /etc/resolv.conf ')
        if data == "English":
            print 'DNS Settings successful'
        else:
            print 'DNS设置成功'
    else:
        if data == "English":
            print 'DNS setting failed'
        else:
            print 'DNS设置失败'


def set_wan():
    '''获取cookie'''
    if 'HTTP_COOKIE' in os.environ:
        cookie_string = os.environ.get('HTTP_COOKIE')
        c = Cookie.SimpleCookie()
        c.load(cookie_string)
        data = c['AnyLinkLan'].value
    '''设置wan(eth0)'''
    # dhcp_status = ip_status = mac_status = mask_status = gateway_status = 1

    # save_gateway = 'echo gateway = ' + gateway + ' >/opt/sdmwebs/web/conf/gateway.dat'
    # if DHCPMode == 'YES':
    #     #dhcp_status = os.system('udhcpc -i eth0')
    #     dhcp_status = 0
    # else:
    #     ip_status = os.system('eeprom net set ip ' + ip)
    #     mask_status = os.system('eeprom net set netmask ' + mask)
    #     gateway_status = os.system('eeprom net set gateway ' + gateway)
    #     route_status = os.system('route add default gw ' + gateway + ' eth0')
    #     set_dns()
    # if (ip_status == 0 and  mask_status == 0 and gateway_status == 0):
    #     os.system(save_gateway)
    #     if data == "English":
    #         print 'The WAN port is set successfully'
    #     else:
    #         print 'WAN口设置成功'
    # elif dhcp_status == 0:
    #     print '动态获取设置成功，重启后生效'
    # else:
    #     if data == "English":
    #         print 'WAN port Settings failed'
    #     else:
    #         print 'WAN口设置失败'
    if data == "English":
        print 'The Network set successfully'
    else:
        print '网络设置成功'


def set_lan():
    '''获取cookie'''
    if 'HTTP_COOKIE' in os.environ:
        cookie_string = os.environ.get('HTTP_COOKIE')
        c = Cookie.SimpleCookie()
        c.load(cookie_string)
        data = c['AnyLinkLan'].value
    '''设置lan(eth1)'''
    dhcp_status = ip_status = mac_status = gw_status = 1
    lan_exist = os.system('ifconfig -a|grep eth1 >/dev/null')
    lan_status = os.system('ifconfig |grep eth1 >/dev/null')
    if lan_exist == 0:  # 表示LAN模块存在
        ''''''
        if lan_status != 0:  #表示LAN口不是active状态
            os.system('ifconfig eth1 up')

        if DHCPMode == 'YES':
            #dhcp_status = os.system('udhcpc -i eth1')
            dhcp_status = 0
        else:
            # ip_status = os.system('ifconfig eth1 ' + ip + ' netmask ' + mask)
            # gw_status = os.system('route add default gw ' + gateway + ' eth1')
            # set_dns()
            ip_status = 0
            gw_status = 0
            print ip_status
            print mac_status
        if (ip_status == 0 and (gw_status == 0 or gw_status == 256)):
            if data == "English":
                print 'The LAN port is set successfully'
            else:
                print 'LAN口设置成功'
        elif dhcp_status == 0:
            print '动态获取设置成功，重启后生效'
        else:
            if data == "English":
                print 'LAN port Settings failed'
            else:
                print 'LAN口设置失败'
    else:
        if data == "English":
            print 'The LAN module does not exist'
        else:
            print 'LAN模块不存在'


def save_card(node, dhcp, ip, mac, mask, gateway, dns):
    #print node,dhcp,ip,mask,gateway,dns
    node.set('dhcp', dhcp)
    node.set('ip', ip)
    # node.set('mac', mac)
    node.set('mask', mask)
    node.set('gateway', gateway)
    node.set('dns', dns)


def set_cards(cardtype):
    if cardtype == 'WAN':
        set_wan()
    else:
        set_lan()


def config_cards(root, cardtype):
    '''保存网卡信息'''
    node = root.find(cardtype)
    save_card(node, DHCPMode, ip, mac, mask, gateway, DNS)


def config_base(root):
    '''保存hostname信息'''
    root.set('hostname', hostname)
    try:
        with open(global_var.SMB_CONF_PATH, 'r') as fp:
            data = fp.read()
            s = data[data.index('netbios name'):]
            s = s[:s.index('\n')]
            #print 's', s
            data = data.replace(s, 'netbios name=' + hostname)
            open(global_var.SMB_CONF_PATH, 'w').write(data)
    except Exception as e:
        print e


if __name__ == '__main__':
    get_cgi_data()
    anylink_tree = ET.parse(global_var.AnyLinkconfig_path)
    network_node = anylink_tree.find('NetworkInfo')
    config_base(network_node)
    config_cards(network_node, type.upper())
    router_node = anylink_tree.find('Router')
    router_node.set("enable", "NO")
    updateVersion.write(anylink_tree, global_var.AnyLinkconfig_path)
    # anylink_tree.write(global_var.AnyLinkconfig_path,
    #                    encoding='utf-8',
    #                    xml_declaration='true')
    set_cards(type.upper())
