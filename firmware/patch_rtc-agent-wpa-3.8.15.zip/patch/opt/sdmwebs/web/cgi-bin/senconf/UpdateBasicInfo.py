#!/usr/bin/python
# -*- coding: UTF-8 -*-

from config import global_var
from rexml import updateVersion
import os
import xml.etree.ElementTree as ET
import json

print "Content-Type: text/html charset=utf-8 \n"

if __name__ == '__main__':
    # 获取script版本 如无文件则为空
    res_data = {"scriptver": "", "iccid": "", "imei": ""}
    if os.path.exists("/opt/script/script_version.txt"):
        with open('/opt/script/script_version.txt', 'rb') as f:
            res_data["scriptver"] = f.read().strip()
            # print f.read().strip()
    else:
        res_data["scriptver"] = ""
    # 获取iccid 如无文件则为空
    if os.path.exists("/tmp/iccid"):
        with open('/tmp/iccid', 'rb') as f:
            res_data["iccid"] = f.read().strip()
            # print f.read().strip()
    else:
        res_data["iccid"] = ""
    # 获取imei 如无文件则为空
    if os.path.exists("/tmp/imei"):
        with open('/tmp/imei', 'rb') as f:
            res_data["imei"] = f.read().strip()
            # print f.read().strip()
    else:
        res_data["imei"] = ""
    print json.dumps(res_data)
    # 获取 Agent版本
    agentVersion = ''
    p = os.popen('/opt/agent/agentbasic -v', 'r')
    agentData = p.read().split(' ')
    if len(agentData) > 3:
        agentVersion = "V" + agentData[1] + "." + agentData[3][0:-1]

    # 获取网关序列号
    serialNumber = ''
    with open('/etc/devuaid.d', 'rb') as fp:
        serialNumber = fp.readlines()[0].strip()

    # 将Agent版本和网关序列号更新至Common.xml
    commonxmlPath = global_var.common_path
    commonTree = ET.parse(commonxmlPath)

    AgentVersion_node = commonTree.find('AgentVersion')
    SerialNumber_node = commonTree.find('SerialNumber')

    if (len(agentVersion) > 0 and AgentVersion_node.text != agentVersion) or (
            len(serialNumber) > 0 and SerialNumber_node.text != serialNumber):
        AgentVersion_node.text = agentVersion
        SerialNumber_node.text = serialNumber
        updateVersion.write(commonTree, commonxmlPath)
    # commonTree.write(commonxmlPath, xml_declaration='true')

    # 将Agent版本和网关序列号更新至AnyLink.xml
    anylinkxmlPath = global_var.AnyLinkconfig_path
    anylinkTree = ET.parse(anylinkxmlPath)
    AgentVersion_node = anylinkTree.find('BasicInfo/AgentVersion')
    SerialNumber_node = anylinkTree.find('BasicInfo/SerialNumber')

    if (len(agentVersion) > 0 and AgentVersion_node.text != agentVersion) or (
            len(serialNumber) > 0 and SerialNumber_node.text != serialNumber):
        AgentVersion_node.text = agentVersion
        SerialNumber_node.text = serialNumber
        updateVersion.write(anylinkTree, anylinkxmlPath)
    # anylinkTree.write(anylinkxmlPath, xml_declaration='true')
