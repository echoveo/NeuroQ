#!/usr/bin/python
# -*- coding: UTF-8 -*-

from CGI import GetCgi
from config import global_var
from Log import Loginfo
import xml.etree.ElementTree as ET
from xml.etree.ElementTree import SubElement as SE
from rexml import updateVersion
import sys, cgi
import os, Cookie
reload(sys)
sys.setdefaultencoding('utf-8')

print "Content-Type: text/html charset=utf-8 \n"

cmd = modbusId = modbusVtype = modbusAddr = driver_name = driver_config = ''
cookie_value = ''


def get_cgi_data():
    '''获取cookie'''
    if 'HTTP_COOKIE' in os.environ:
        cookie_string = os.environ.get('HTTP_COOKIE')
        c = Cookie.SimpleCookie()
        c.load(cookie_string)
        data = c['AnyLinkLan'].value

    global cmd, modbusId, modbusVtype, modbusAddr, driver_name, driver_config, cookie_value
    form = cgi.FieldStorage()
    cmd = form.getvalue('Operation', '')
    if cmd == 'Save':
        modbusId = form.getvalue('Alter_ModBus_ID_Form', '')
        modbusVtype = form.getvalue('Alter_ModBus_Vtype_Form', '')
        modbusAddr = form.getvalue('Alter_ModBus_Addr_Form', '')
    elif cmd == 'Start':
        driver_name = form.getvalue('Start_ModBus_Name_Form', '')
        driver_config = form.getvalue('Start_ModBus_Config_Form', '')
    else:
        if data == 'English':
            print 'Removed driver'
        else:
            print "删除驱动"
    print modbusId, modbusVtype, modbusAddr


def add_dataitem():
    '''添加modbus发布数据项信息'''
    global modbusId, modbusVtype, modbusAddr
    if modbusVtype == '-1':
        modbusVtype = ""
    agent_tree = ET.parse(global_var.itemconfig_path)
    dataitem_node_list = agent_tree.iter('dataItem')
    for dataitem_node in dataitem_node_list:
        if not dataitem_node.get('addr', default=None):
            '''作添加操作'''
            if dataitem_node.attrib['id'] == modbusId:
                dataitem_node.set('vtype', modbusVtype)
                dataitem_node.set('addr', modbusAddr)
                # dataitem_node_list.append(dataitem_node)
        else:
            ''''做修改操作'''
            if dataitem_node.attrib['id'] == modbusId:
                dataitem_node.set('vtype', modbusVtype)
                dataitem_node.set('addr', modbusAddr)
                break
    updateVersion.write(agent_tree, global_var.itemconfig_path)
    # agent_tree.write(global_var.itemconfig_path, encoding='utf-8')


def add_modbus_info():
    '''添加modbus驱动信息'''
    global driver_name, driver_config
    modbus_node = None
    config_tree = ET.parse(global_var.itemconfig_path)
    task_node = config_tree.find('task')
    task_list = task_node.findall('TaskDriver/driver')
    for task in task_list:
        if task.get('n') == driver_name:
            modbus_node = task
            break
    if modbus_node is None:
        '''作添加操作'''
        modbus_node = ET.Element("driver", {
            'n': driver_name,
            'config': driver_config
        })
        modbus_task_node = ET.Element('TaskDriver')
        task_node.append(modbus_task_node)
        modbus_task_node.append(modbus_node)
    else:
        ''''做修改操作'''
        for task in task_list:
            if task.get('n') == driver_name:
                task.set('config', driver_config)
                break
    updateVersion.write(config_tree, global_var.itemconfig_path)
    # config_tree.write(global_var.itemconfig_path,
    #                   encoding='utf-8',
    #                   xml_declaration='true')


def delete_modbus_info():
    '''删除modbus驱动信息'''
    config_tree = ET.parse(global_var.itemconfig_path)
    task_root = config_tree.find('task')
    task_list = task_root.findall('TaskDriver')
    for task in task_list:
        if task.find('driver').get('n') == 'T.IDrv.Task:libtmodbus':
            task_root.remove(task)
            break
    updateVersion.write(config_tree, global_var.itemconfig_path)
    # config_tree.write(global_var.itemconfig_path,
    #                   encoding='utf-8',
    #                   xml_declaration='true')


if __name__ == "__main__":
    ''''''
    get_cgi_data()
    '''获取cookie'''
    if 'HTTP_COOKIE' in os.environ:
        cookie_string = os.environ.get('HTTP_COOKIE')
        c = Cookie.SimpleCookie()
        c.load(cookie_string)
        data = c['AnyLinkLan'].value
    if cmd == 'Start':
        add_modbus_info()
        if data == 'English':
            print "Added driver"
        else:
            print "添加成功"
    elif cmd == 'Stop':
        delete_modbus_info()
        if data == 'English':
            print "Successfully deleted"
        else:
            print "删除成功"
    elif cmd == 'Save':
        add_dataitem()
        if data == 'English':
            print "Successfully added"
        else:
            print "添加成功"
    else:
        if data == 'English':
            print "Command error"
        else:
            print "命令错误"