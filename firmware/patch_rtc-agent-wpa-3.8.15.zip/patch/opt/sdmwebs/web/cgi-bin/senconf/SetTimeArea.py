#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'jhjiang'

import os
import cgi
import xml.etree.ElementTree as ET
from config import global_var
from rexml import updateVersion
print "Content-Type: text/html charset=utf-8 \n\n"

basepath = "/usr/share/zoneinfo"


def get_cgi_data():
    global basepath
    '''get cgi time data'''
    form = cgi.FieldStorage()
    TimeArea = form.getvalue('TimeArea', '/Asia/Shanghai')

    realPath = basepath + TimeArea
    try:
        os.system("wr rm -rf /etc/localtime")
        os.system("wr ln -sf " + realPath + " /etc/localtime")
        write_timezone_anylink(TimeArea)
        print "OK"
    except Exception as e:
        print "ERROR"


def write_timezone_anylink(TimeArea):
    ''''''
    anylink_tree = ET.parse(global_var.AnyLinkconfig_path)
    anylink = anylink_tree.getroot()

    timezone_node = anylink_tree.find('TimeZoneInfo/TimeZone')
    timezone_node.text = TimeArea
    updateVersion.write(anylink_tree, global_var.AnyLinkconfig_path)
    # anylink_tree.write(global_var.AnyLinkconfig_path,
    #                    encoding='utf-8',
    #                    xml_declaration='true')


if __name__ == '__main__':
    get_cgi_data()