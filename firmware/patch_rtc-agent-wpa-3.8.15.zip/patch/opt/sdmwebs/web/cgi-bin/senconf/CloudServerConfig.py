#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xhzhang'

import xml.etree.ElementTree as ET
import cgi, os
from config import global_var
from rexml import updateVersion
import Cookie

print "Content-Type: text/html charset=utf-8 \n"

cloudserver = ''


def get_cgi_data():
    '''get cloud server data'''
    global cloudserver
    form = cgi.FieldStorage()
    cloudserver = form.getvalue('CloudAddress', '0.0.0.0')
    #print cloudserver


def save_cloudserver_config():
    '''save cloudserver into Anylink file'''

    anylink_tree = ET.parse(global_var.AnyLinkconfig_path)
    anylink = anylink_tree.getroot()

    cloud_node = anylink_tree.find('CloudInfo/Address')
    cloud_node.text = cloudserver

    # ET.dump(anylink_tree)
    updateVersion.write(anylink_tree, global_var.AnyLinkconfig_path)
    # anylink_tree.write(global_var.AnyLinkconfig_path,
    #                    encoding='utf-8',
    #                    xml_declaration='true')


def save_agent_cloud():
    '''获取cookie'''
    if 'HTTP_COOKIE' in os.environ:
        cookie_string = os.environ.get('HTTP_COOKIE')
        c = Cookie.SimpleCookie()
        c.load(cookie_string)
        data = c['AnyLinkLan'].value
    ''''''
    if os.path.exists(global_var.agent_cloud_path):
        try:
            agent_cloud_tree = ET.parse(global_var.agent_cloud_path)
            agent_cloud = agent_cloud_tree.getroot()
            if global_var.zigbee_type == '0':
                drm_server = agent_cloud_tree.find('DRMServer')
                drm_server.text = 'http://' + cloudserver + '/regagent'
                drmdata_server = agent_cloud_tree.find('DRMDataServer')
                drmdata_server.text = 'http://' + cloudserver + '/at'
                drmping_server = agent_cloud_tree.find('DRMPingServer')
                drmping_server.text = 'http://' + cloudserver + '/regagainagent'
                updateVersion.write(agent_cloud_tree,
                                    global_var.agent_cloud_path)
                # agent_cloud_tree.write(global_var.agent_cloud_path,
                #                        xml_declaration='true')
                if data == "English":
                    print 'Modify success'
                else:
                    print '修改成功'
            else:
                drm_server = agent_cloud_tree.find('DRMServer')
                agent_cloud.remove(drm_server)
                drmdata_server = agent_cloud_tree.find('DRMDataServer')
                agent_cloud.remove(drmdata_server)
                drmping_server = agent_cloud_tree.find('DRMPingServer')
                agent_cloud.remove(drmping_server)
                updateVersion.write(agent_cloud_tree,
                                    global_var.agent_cloud_path)
                # agent_cloud_tree.write(global_var.agent_cloud_path,
                #                        xml_declaration='true')
                # agent_cloud_tree.write(global_var.agent_cloud_path)
                if data == "English":
                    print 'Modify success'
                else:
                    print '修改成功'
        except:
            if data == "English":
                print "Invalid format"
            else:
                print "格式错误"
    else:
        from init import init_AgentConfig
        init_AgentConfig.init_agent_cloudserver(cloudserver)
        if data == "English":
            if os.path.exists(global_var.agent_cloud_path):
                print "Create success!"
            else:
                print "Create fail!"
        else:
            if os.path.exists(global_var.agent_cloud_path):
                print "创建成功！"
            else:
                print "创建失败！"


if __name__ == '__main__':
    get_cgi_data()
    save_cloudserver_config()
    save_agent_cloud()