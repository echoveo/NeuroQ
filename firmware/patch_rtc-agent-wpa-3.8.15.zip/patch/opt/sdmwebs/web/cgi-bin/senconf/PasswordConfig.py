#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xhzhang'

import xml.etree.ElementTree as ET
from config import global_var
from rexml import updateVersion
import cgi
from Log import Loginfo
import os, Cookie
import userlogin
import hashlib
#print "Content-Type: text/html charset=utf-8 \n"

newpassword = ''
username = ''


def get_cgi_data():
    '''get password data '''
    global newpassword, username
    form = cgi.FieldStorage()
    newpassword = form.getvalue('NewPassword', 'admin')
    username = form.getvalue('username', 'admin')


#def save_password_config():
#    '''save password into config file'''
#    anylink_tree = ET.parse(global_var.AnyLinkconfig_path)
#    anylink = anylink_tree.getroot()

#    password_node = anylink_tree.find('LoginInfo/Password')
#    password_node.text = newpassword

#    # ET.dump(anylink_tree)
#    anylink_tree.write(global_var.AnyLinkconfig_path, encoding='utf-8', xml_declaration='true')
#    print '修改成功'


def save_password_config_nouse():
    '''获取cookie'''
    if 'HTTP_COOKIE' in os.environ:
        cookie_string = os.environ.get('HTTP_COOKIE')
        c = Cookie.SimpleCookie()
        c.load(cookie_string)
        data = c['AnyLinkLan'].value
    '''save password into config file'''
    login_tree = ET.parse(global_var.Login_path)
    login = login_tree.getroot()

    # password_node = login_tree.find('LoginInfo/Password')
    # password_node.text = newpassword
    loginInfoNodes = login_tree.findall('LoginInfo')

    for loginNode in loginInfoNodes:
        usernameNode = loginNode.find('UserName')
        if username == usernameNode.text:
            passwdNode = loginNode.find('Password')
            passwdNode.text = newpassword
            break
    updateVersion.write(login_tree, global_var.Login_path)
    # login_tree.write(global_var.Login_path,
    #                  encoding='utf-8',
    #                  xml_declaration='true')
    if data == "English":
        print 'Modify success'
    else:
        print '修改成功'

def save_password_config():
    '''获取cookie'''
    if 'HTTP_COOKIE' in os.environ:
        cookie_string = os.environ.get('HTTP_COOKIE')
        c = Cookie.SimpleCookie()
        c.load(cookie_string)
        data = c['AnyLinkLan'].value
    '''save password into config file'''
    md = hashlib.md5(newpassword.encode())
    
    userlogin.userinfo_update(username,md.hexdigest())
    # login_tree.write(global_var.Login_path,
    #                  encoding='utf-8',
    #                  xml_declaration='true')
    if data == "English":
        print 'Modify success'
    else:
        print '修改成功'

if __name__ == '__main__':
    log = Loginfo.Loginfo()
    get_cgi_data()
    save_password_config()