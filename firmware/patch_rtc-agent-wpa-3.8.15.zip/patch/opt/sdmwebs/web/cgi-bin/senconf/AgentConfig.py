#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xhzhang'

import xml.etree.ElementTree as ET
from config import global_var
from Log import Loginfo
from rexml import updateVersion
import cgi, os
import Cookie

print "Content-Type: text/html charset=utf-8 \n"

agentMode = uploadType = regRetryCount = queueSize = protocol = logpath = alarmmode = database = datasize = cloudserver = ''
forceUploadTime = ''
discardInvalidData = ''
externalid = ''

def get_cgi_data():
    '''get  data '''
    global agentMode, uploadType, regRetryCount, queueSize, protocol, logpath, alarmmode, database, datasize, pubServer, pubPort, subServer, subPort, keepAlive, qos, retain, badDataMode, tls, username, password, isEncrypt, mqttUsernameBase64, mqttPasswordBase64, cloudserver, apiPort, forceUploadTime, discardInvalidData,externalid
    form = cgi.FieldStorage()
    agentMode = form.getvalue('agentMode', '0')
    uploadType = form.getvalue('uploadType', '1')
    regRetryCount = form.getvalue('regRetryCount', '100')
    queueSize = form.getvalue('queueSize', '1')
    protocol = form.getvalue('protocol', 'http')
    database = form.getvalue('dataBase', '1')
    datasize = form.getvalue('size', '10000')
    alarmmode = form.getvalue('AlarmMode', '0')
    pubServer = form.getvalue('mqttPubServer')
    pubPort = form.getvalue('mqttPubPort', '1883').strip()
    subServer = form.getvalue('mqttSubServer')
    subPort = form.getvalue('mqttSubPort', '1883').strip()
    keepAlive = form.getvalue('mqttKeepAlive', '60')
    qos = form.getvalue('mqttQos', '2')
    retain = form.getvalue('mqttRetain', '0')
    badDataMode = form.getvalue('badDataMode', 0)
    tls = form.getvalue('tls')
    username = form.getvalue('mqttUsername', '')
    password = form.getvalue('mqttPassword', '')
    isEncrypt = form.getvalue('isEncrypt', '0')  #默认为空就是不加密
    mqttUsernameBase64 = form.getvalue('mqttUsernameBase64', '')
    mqttPasswordBase64 = form.getvalue('mqttPasswordBase64', '')
    cloudserver = form.getvalue('CloudAddress', '0.0.0.0')
    apiPort = form.getvalue('apiPort', '111')
    forceUploadTime = form.getvalue('ForceUploadTime', '240')
    discardInvalidData = form.getvalue('DiscardInvalidData', '1')
    externalid =  form.getvalue('externalid', '')

def save_agent_config():
    '''save data into config file'''
    anylink_tree = ET.parse(global_var.AnyLinkconfig_path)
    anylink = anylink_tree.getroot()

    agentMode_node = anylink_tree.find('AgentConfig/AgentMode')
    agentMode_node.text = agentMode
    uploadType_node = anylink_tree.find('AgentConfig/UploadType')
    uploadType_node.text = uploadType
    regRetryCount_node = anylink_tree.find('AgentConfig/RegRetryCount')
    regRetryCount_node.text = regRetryCount
    queueSize_node = anylink_tree.find('AgentConfig/QueueSize')
    queueSize_node.text = queueSize
    protocol_node = anylink_tree.find('AgentConfig/Protocol')
    protocol_node.text = protocol
    alarmmode_node = anylink_tree.find('AgentConfig/AlarmMode')
    alarmmode_node.text = alarmmode
    database_node = anylink_tree.find('AgentConfig/DBEnable')
    database_node.text = database
    datasize_node = anylink_tree.find('AgentConfig/DBSize')
    datasize_node.text = datasize
    badDataMode_node = anylink_tree.find('AgentConfig/BadDataMode')
    badDataMode_node.text = badDataMode
    ForceUploadTime_node = anylink_tree.find('AgentConfig/ForceUploadTime')
    ForceUploadTime_node.text = forceUploadTime
    DiscardInvalidData_node = anylink_tree.find('AgentConfig/DiscardInvalidData')
    DiscardInvalidData_node.text = discardInvalidData
    apiPort_node = anylink_tree.find('CloudInfo/API_port')
    apiPort_node.text = apiPort

    # ET.dump(anylink_tree)
    updateVersion.write(anylink_tree, global_var.AnyLinkconfig_path)
    # anylink_tree.write(global_var.AnyLinkconfig_path,
    #                    encoding='utf-8',
    #                    xml_declaration='true')
    #print 'success'


def config_mqtt_driver():
    '''当传输协议从http变成mqtt时，需添加config.xml中mqtt的任务驱动'''
    if isEncrypt == '0':
        mqtt_config = pubServer + ';' + pubPort + ';' + subServer + ';' + subPort + ';' + keepAlive + ';' + qos + ';' + retain + ';' + isEncrypt + ';' + username + ';' + password + ';' + ';' + tls + ';'
    elif isEncrypt == '1':
        mqtt_config = pubServer + ';' + pubPort + ';' + subServer + ';' + subPort + ';' + keepAlive + ';' + qos + ';' + retain + ';' + isEncrypt + ';' + mqttUsernameBase64 + ';' + mqttPasswordBase64 + ';' + ';' + tls + ';'
    task_mqtt = ET.Element('TaskDriver')
    task_mqtt_driver = ET.Element('driver')
    task_mqtt_driver.set('n', 'T.IDrv.Task:libkmqtt')
    task_mqtt_driver.set('config', mqtt_config)
    task_mqtt.append(task_mqtt_driver)

    agent_tree = ET.parse(global_var.itemconfig_path)
    task_node = agent_tree.find('task')
    task_node.append(task_mqtt)
    updateVersion.write(agent_tree, global_var.itemconfig_path)
    # agent_tree.write(global_var.itemconfig_path, encoding='utf-8')


def delete_mqtt_driver():
    '''获取cookie'''
    if 'HTTP_COOKIE' in os.environ:
        cookie_string = os.environ.get('HTTP_COOKIE')
        c = Cookie.SimpleCookie()
        c.load(cookie_string)
        data = c['AnyLinkLan'].value
    '''当传输协议从mqtt变成http,需删除config.xml中mqtt的任务驱动'''
    if data == "English":
        print 'Delete the MQTT task driver'
    else:
        print '删除mqtt任务驱动'
    agent_tree = ET.parse(global_var.itemconfig_path)
    task_node = agent_tree.find('task')
    print task_node
    task_driver_list = task_node.findall('TaskDriver')
    print task_driver_list
    for task_driver in task_driver_list:
        if task_driver.find('driver').get(
                'n', default=None) == 'T.IDrv.Task:libkmqtt':
            task_node.remove(task_driver)
            break
    ET.dump(agent_tree)
    updateVersion.write(agent_tree, global_var.itemconfig_path)
    # agent_tree.write(global_var.itemconfig_path, encoding='utf-8')


def add_agent_server(root):
    anylink_tree = ET.parse(global_var.AnyLinkconfig_path)
    cloudserver = anylink_tree.find('CloudInfo/Address').text
    http_port = anylink_tree.find('CloudInfo/Http_port').text

    agent_drmserver = ET.Element('DRMServer')
    agent_drmserver.text = cloudserver + ':' + http_port + '/regagent'

    agent_drmdataserver = ET.Element('DRMDataServer')
    agent_drmdataserver.text = cloudserver + ':' + http_port + '/at'

    agent_drmpingserver = ET.Element('DRMPingServer')
    agent_drmpingserver.text = cloudserver + ':' + http_port + '/regagainagent'

    root.append(agent_drmserver)
    root.append(agent_drmdataserver)
    root.append(agent_drmpingserver)


def delete_agent_server(tree, root):
    drmserver_node = tree.find('DRMServer')
    drmdataserver_node = tree.find('DRMDataServer')
    drmpingserver_node = tree.find('DRMPingServer')
    if drmserver_node is not None:
        root.remove(drmserver_node)
    if drmdataserver_node is not None:
        root.remove(drmdataserver_node)
    if drmpingserver_node is not None:
        root.remove(drmpingserver_node)


def save_agent_config_agent():
    '''获取cookie'''
    if 'HTTP_COOKIE' in os.environ:
        cookie_string = os.environ.get('HTTP_COOKIE')
        c = Cookie.SimpleCookie()
        c.load(cookie_string)
        data = c['AnyLinkLan'].value
    '''save data into config file(opt/agent/AgentConfig.xml)'''
    anylink_cloud_tree = ET.parse(global_var.agent_cloud_path)
    anylink_cloud_root = anylink_cloud_tree.getroot()

    agentMode_cloud_node = anylink_cloud_tree.find('AgentMode')
    if agentMode_cloud_node.text == '0' and agentMode == '1':
        log.write_debug('[Agent配置] agent模式从客户端模式变成服务器模式。')
        delete_agent_server(anylink_cloud_tree, anylink_cloud_root)
    elif agentMode_cloud_node.text == '1' and agentMode == '0':
        log.write_debug('[Agent配置] agent模式从服务器模式变成客户端模式。')
        add_agent_server(anylink_cloud_root)
    else:
        pass
    agentMode_cloud_node.text = agentMode

    uploadType_cloud_node = anylink_cloud_tree.find('UploadType')
    uploadType_cloud_node.text = uploadType
    regRetryCount_cloud_node = anylink_cloud_tree.find('RegRetryCount')
    regRetryCount_cloud_node.text = regRetryCount
    queueSize_cloud_node = anylink_cloud_tree.find('QueueSize')
    queueSize_cloud_node.text = queueSize
    alarmMode_cloud_node = anylink_cloud_tree.find('AlarmMode')
    alarmMode_cloud_node.text = alarmmode
    badDataMode_node = anylink_cloud_tree.find('BadDataMode')
    badDataMode_node.text = badDataMode
    ForceUploadTime_node = anylink_cloud_tree.find('ForceUploadTime')
    ForceUploadTime_node.text = forceUploadTime
    DiscardInvalidData_node = anylink_cloud_tree.find('DiscardInvalidData')
    DiscardInvalidData_node.text = discardInvalidData
    
    protocol_node = anylink_cloud_tree.find('Protocol')
    if protocol_node.text == 'http' and protocol == 'mqtt':
        log.write_debug('[Agent配置] agent传输协议从http变为mqtt')
        config_mqtt_driver()
    elif protocol_node.text == 'mqtt' and protocol == 'http':
        log.write_debug('[Agent配置] agent传输协议从mqtt变为http')
        delete_mqtt_driver()
    elif protocol_node.text == 'mqtt' and protocol == 'mqtt':
        log.write_debug('[Agent配置] agent传输协议mqtt参数重新设定')
        delete_mqtt_driver()  #先删除上次的mqtt配置
        config_mqtt_driver()
    else:
        pass
    protocol_node.text = protocol
    updateVersion.write(anylink_cloud_tree, global_var.agent_cloud_path)
    # anylink_cloud_tree.write(global_var.agent_cloud_path,
    #                          xml_declaration='true')


def save_config():
    '''修改config.xml'''
    config_tree = ET.parse(global_var.itemconfig_path)
    
    '''save externalid'''
    root = config_tree.getroot()
    root.set("externalid",externalid)

    task_zigbee_node = config_tree.findall(
        'task/TaskDriver/driver[@n="T.IDrv.Task:libzigbee"]')[0]
    task_zigbee_config = task_zigbee_node.get('config')
    print task_zigbee_config
    tmp_list = task_zigbee_config.split(';')
    tmp_list_length = len(tmp_list)
    print tmp_list_length
    print tmp_list_length - 1
    if tmp_list_length > 13:
        tmp_list[13] = database
        tmp_list[14] = datasize
    newconfig = ''
    for i in range(len(tmp_list)):
        if i == 0:
            newconfig = tmp_list[i] + ';'
        elif i == tmp_list_length - 1:
            newconfig = newconfig + tmp_list[i]
        else:
            newconfig = newconfig + tmp_list[i] + ';'
    print newconfig
    task_zigbee_node.set('config', newconfig)
    updateVersion.write(config_tree, global_var.itemconfig_path)
    # config_tree.write(global_var.itemconfig_path, xml_declaration='true')


# add by whc
def save_cloudserver_config():
    '''save cloudserver into Anylink file'''

    if protocol == 'http':
        anylink_tree = ET.parse(global_var.AnyLinkconfig_path)
        anylink = anylink_tree.getroot()

        cloudserverList = cloudserver.split(":")
        cloud_node = anylink_tree.find('CloudInfo/Address')
        cloud_node.text = cloudserverList[0]
        port_node = anylink_tree.find('CloudInfo/Http_port')
        port_node.text = cloudserverList[1]

        # ET.dump(anylink_tree)
        updateVersion.write(anylink_tree, global_var.AnyLinkconfig_path)
        # anylink_tree.write(global_var.AnyLinkconfig_path,
        #                    encoding='utf-8',
        #                    xml_declaration='true')


def save_agent_cloud():
    '''获取cookie'''
    if 'HTTP_COOKIE' in os.environ:
        cookie_string = os.environ.get('HTTP_COOKIE')
        c = Cookie.SimpleCookie()
        c.load(cookie_string)
        data = c['AnyLinkLan'].value
    ''''''
    if os.path.exists(global_var.agent_cloud_path):
        try:
            agent_cloud_tree = ET.parse(global_var.agent_cloud_path)
            agent_cloud = agent_cloud_tree.getroot()
            if global_var.zigbee_type == '0':
                drm_server = agent_cloud_tree.find('DRMServer')
                drm_server.text = 'http://' + cloudserver + '/regagent'
                drmdata_server = agent_cloud_tree.find('DRMDataServer')
                drmdata_server.text = 'http://' + cloudserver + '/at'
                drmping_server = agent_cloud_tree.find('DRMPingServer')
                drmping_server.text = 'http://' + cloudserver + '/regagainagent'
                updateVersion.write(agent_cloud_tree,
                                    global_var.agent_cloud_path)
                # agent_cloud_tree.write(global_var.agent_cloud_path,
                #                        xml_declaration='true')
                if data == "English":
                    print 'Modify success'
                else:
                    print '修改成功'
            else:
                drm_server = agent_cloud_tree.find('DRMServer')
                agent_cloud.remove(drm_server)
                drmdata_server = agent_cloud_tree.find('DRMDataServer')
                agent_cloud.remove(drmdata_server)
                drmping_server = agent_cloud_tree.find('DRMPingServer')
                agent_cloud.remove(drmping_server)
                updateVersion.write(agent_cloud_tree,
                                    global_var.agent_cloud_path)
                # agent_cloud_tree.write(global_var.agent_cloud_path,
                #                        xml_declaration='true')
                # agent_cloud_tree.write(global_var.agent_cloud_path)
                if data == "English":
                    print 'Modify success'
                else:
                    print '修改成功'
        except:
            if data == "English":
                print "Invalid format"
            else:
                print "格式错误"
    else:
        from init import init_AgentConfig
        init_AgentConfig.init_agent_cloudserver(cloudserver)
        if data == "English":
            if os.path.exists(global_var.agent_cloud_path):
                print "Create success!"
            else:
                print "Create fail!"
        else:
            if os.path.exists(global_var.agent_cloud_path):
                print "创建成功！"
            else:
                print "创建失败！"


# add end

if __name__ == '__main__':
    log = Loginfo.Loginfo()
    get_cgi_data()
    save_agent_config()
    save_config()
    save_agent_config_agent()
    save_cloudserver_config()
    save_agent_cloud()
