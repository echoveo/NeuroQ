#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xhzhang'

from CGI import GetCgi
from config import global_var
from Log import Loginfo
from rexml import updateVersion
import xml.etree.ElementTree as ET
from xml.etree.ElementTree import SubElement as SE
import sys, cgi
import os, Cookie
reload(sys)
sys.setdefaultencoding('utf-8')

print "Content-Type: text/html charset=utf-8 \n"

cmd = driver_name = device_id = params = driver_id = ''


def get_cgi_data():
    global cmd, driver_name, device_id, params, driver_id
    form = cgi.FieldStorage()
    cmd = form.getvalue('cmd', '')  # add,delete
    device_id = form.getvalue('deviceId', '')
    driver_id = form.getvalue('driverId', '')
    if cmd == 'add':
        driver_name = form.getvalue('driver', '')
        params = form.getvalue('params', '')


def add_bacnet_info():
    '''添加bacnet驱动信息'''
    config_tree = ET.parse(global_var.itemconfig_path)
    '''添加修改设备的bacnet驱动'''
    device_list = config_tree.iter('device')
    for device in device_list:
        if device.get('id') != '1023':
            bacnet_node = device.find('driver[@n="' + driver_name + '"]')
            if bacnet_node is None:  #add
                device_driver = ET.SubElement(device,
                                              'driver',
                                              attrib={
                                                  'n': driver_name,
                                                  'id': driver_id,
                                                  'config': params
                                              })
                ET.SubElement(device_driver, 'commDataItems')
            else:  #alter
                bacnet_node.set('n', driver_name)
                bacnet_node.set('config', params)
    '''添加修改task的bacnet驱动'''
    task_node = config_tree.find('task')

    bacnet_driver_node = task_node.find('TaskDriver/driver[@n="' +
                                        driver_name + '"]')
    if bacnet_driver_node is None:  #add
        taskdriver = ET.SubElement(task_node, 'TaskDriver')
        ET.SubElement(taskdriver,
                      'driver',
                      attrib={
                          'n': driver_name,
                          'id': driver_id,
                          'config': params
                      })
    else:  #alter
        bacnet_driver_node.set('n', driver_name)
        bacnet_driver_node.set('config', params)
    updateVersion.write(config_tree, global_var.itemconfig_path)
    # config_tree.write(global_var.itemconfig_path,
    #                   encoding='utf-8',
    #                   xml_declaration='true')


def delete_bacnet_info():
    '''删除bacnet驱动信息'''
    config_tree = ET.parse(global_var.itemconfig_path)
    '''删除设备的bacnet驱动'''
    device_list = config_tree.iter('device')
    for device in device_list:
        if device.get('id') != '1023':
            bacnet_node = device.find('driver[@id="' + driver_id + '"]')
            print bacnet_node
            if bacnet_node is not None:  #delete
                device.remove(bacnet_node)
    '''添加修改task的bacnet驱动'''
    task_node = config_tree.find('task')
    taskdriver_list = config_tree.iter('TaskDriver')
    for taskdriver in taskdriver_list:
        bacnet_driver_node = taskdriver.find('driver[@id="' + driver_id + '"]')
        if bacnet_driver_node is not None:  # delete
            task_node.remove(taskdriver)
            break
    updateVersion.write(config_tree, global_var.itemconfig_path)
    # config_tree.write(global_var.itemconfig_path,
    #                   encoding='utf-8',
    #                   xml_declaration='true')


def set_driver_id():
    '''增加driver_id值'''
    idconfig_tree = ET.parse(global_var.idconfig_path)
    driver_node = idconfig_tree.find('DriverID')
    if driver_id != '0':
        driver_node.text = str(int(driver_id) + 1)
        updateVersion.write(idconfig_tree, global_var.idconfig_path)
        # idconfig_tree.write(global_var.idconfig_path,
        #                     encoding='utf-8',
        #                     xml_declaration='true')
    else:
        return


if __name__ == "__main__":
    ''''''

    get_cgi_data()
    '''获取cookie'''
    if 'HTTP_COOKIE' in os.environ:
        cookie_string = os.environ.get('HTTP_COOKIE')
        c = Cookie.SimpleCookie()
        c.load(cookie_string)
        data = c['AnyLinkLan'].value
    if data == "English":
        if cmd == 'add':
            add_bacnet_info()
            set_driver_id()
            print "Add success"
        elif cmd == 'delete':
            delete_bacnet_info()
            print "Delete success"
        else:
            print "Command error"
    else:
        if cmd == 'add':
            add_bacnet_info()
            set_driver_id()
            print "添加成功"
        elif cmd == 'delete':
            delete_bacnet_info()
            print "删除成功"
        else:
            print "命令错误"