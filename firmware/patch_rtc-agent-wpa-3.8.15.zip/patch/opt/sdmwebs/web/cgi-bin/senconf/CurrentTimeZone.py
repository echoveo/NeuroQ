#!/usr/bin/python
# -*- coding: UTF-8 -*-
import os, cgi
import Cookie

print "Content-Type: text/html charset=utf-8 \n"

if __name__ == '__main__':
    r = os.popen('date +"%Z %z"')
    text = r.read()
    r.close()
    print text.strip()