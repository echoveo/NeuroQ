#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xhzhang'

import xml.etree.ElementTree as ET
from config import global_var
from rexml import updateVersion
import os
import Cookie

print "Content-Type: text/html charset=utf-8 \n"


def get_net_status():
    '''获取cookie'''
    if 'HTTP_COOKIE' in os.environ:
        cookie_string = os.environ.get('HTTP_COOKIE')
        c = Cookie.SimpleCookie()
        c.load(cookie_string)
        data = c['AnyLinkLan'].value
    '''from agent's status file to Anylink.xml'''
    zigbee_status = tg_status = device_status = ''
    # 从agent的状态文件中取出zigbee和3Gd的状态信息
    file_exist_status1 = os.path.isfile(global_var.netstatus_path)
    if data == "English":
        if file_exist_status1 == True:
            fd1 = open(global_var.netstatus_path, 'rb')
            net_status_info = fd1.read()
            net_status = net_status_info.split('=')[1]
            if net_status == '1':
                zigbee_status = u'Good'
                tg_status = u'Good'
            elif net_status == '2':
                zigbee_status = u'Disconnected'
                tg_status = u'Good'
            elif net_status == '3':
                zigbee_status = u'Good'
                tg_status = u'Disconnected'
            else:
                zigbee_status = u'Unknown'
                tg_status = u'Unknown'
            fd1.close()
        else:
            zigbee_status = u'Unknown'
            tg_status = u'Unknown'
    else:
        if file_exist_status1 == True:
            fd1 = open(global_var.netstatus_path, 'rb')
            net_status_info = fd1.read()
            net_status = net_status_info.split('=')[1]
            if net_status == '1':
                zigbee_status = u'良好'
                tg_status = u'良好'
            elif net_status == '2':
                zigbee_status = u'中断'
                tg_status = u'良好'
            elif net_status == '3':
                zigbee_status = u'良好'
                tg_status = u'中断'
            else:
                zigbee_status = u'未知'
                tg_status = u'未知'
            fd1.close()
        else:
            zigbee_status = u'未知'
            tg_status = u'未知'
    #从PLC驱动的状态文件中取出PLC的状态信息
    file_exist_status2 = os.path.isfile(global_var.devicestatus_path)
    if data == "English":
        if file_exist_status2 == True:
            fd2 = open(global_var.devicestatus_path, 'rb')
            dstatus_info = fd2.read()
            if dstatus_info == '':
                device_status = u'Unknown'
            else:
                dststus = dstatus_info.split(':')[1]
                if dststus == 0:
                    device_status = u'Disconnected'
                else:
                    device_status = u'Good'
        else:
            device_status = u'Unknown'
    else:
        if file_exist_status2 == True:
            fd2 = open(global_var.devicestatus_path, 'rb')
            dstatus_info = fd2.read()
            if dstatus_info == '':
                device_status = u'未知'
            else:
                dststus = dstatus_info.split(':')[1]
                if dststus == 0:
                    device_status = u'中断'
                else:
                    device_status = u'良好'
        else:
            device_status = u'未知'
    #将zigbee，3G和设备信息写入AnyLink.xml
    anylink_tree = ET.parse(global_var.AnyLinkconfig_path)
    anylink = anylink_tree.getroot()
    hardwarestatus_node = anylink_tree.find('HardwareStatus')
    hardwarestatus_node_list = hardwarestatus_node.getchildren()
    for node in hardwarestatus_node_list:
        if node.tag == 'Zigbee':
            node.text = zigbee_status
        elif node.tag == 'TG':
            node.text = tg_status
        elif node.tag == 'Device':
            node.text = device_status
        else:
            print 'config file error'
    #设置登陆状态到Login.xml
    login_tree = ET.parse(global_var.Login_path)
    logininfo_node = login_tree.find('LoginInfo')
    logininfo_node_list = logininfo_node.getchildren()
    for node in logininfo_node_list:
        if node.tag == 'Status':
            node.text = '1'
            break
    #ET.dump(anylink_tree)
    updateVersion.write(anylink_tree, global_var.AnyLinkconfig_path)
    # anylink_tree.write(global_var.AnyLinkconfig_path,
    #                    encoding='utf-8',
    #                    xml_declaration='true')
    updateVersion.write(login_tree, global_var.Login_path)
    # login_tree.write(global_var.Login_path,
    #                  encoding='utf-8',
    #                  xml_declaration='true')


def set_log_null():
    cmd = 'echo > /opt/sdmwebs/log/access_log'
    excute_set_status = os.system(cmd)


if __name__ == '__main__':
    get_net_status()
    set_log_null()