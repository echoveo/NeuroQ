#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'hongyu.wang'

import time
import datetime

print "Content-Type: text/html charset=utf-8 \n\n"

def datetime_to_local():
    """Converts a datetime object to UTC timestamp"""
 
    utcdate = datetime.datetime.now()
    localdate = utcdate + datetime.timedelta(hours=0)
    print localdate.strftime('%Y,%m,%d,%H,%M,%S')
if __name__ == '__main__':
    datetime_to_local()