# /usr/bin/env python
# -* coding:UTF-8 *-
__author__ = 'xhzhang'

import serial, time


class zigbee():
    def __init__(self):
        self.fd = None
        self.recvsum = 0
        self.times = 0

    def openZigbee(self):
        self.fd = serial.Serial('/dev/ttyO3', baudrate=115200, bytesize=serial.EIGHTBITS, parity=serial.PARITY_NONE,
                                stopbits=serial.STOPBITS_ONE, timeout=0.3)

    def close(self):
        self.fd.close()

    def save(self):
        self.fd.write('AT+SAV' + chr(0x0d) + chr(0x0a))
        time.sleep(0.5)
        self.fd.write('AT+SRS' + chr(0x0d) + chr(0x0a))

    def restart(self):
        self.save()
        self.fd.close()
        self.openZigbee()

    def set_At_mode(self):
        ret = -1
        addstr = '+++'
        for i in range(3):
            self.fd.flush()
            self.fd.write(addstr)
            data = self.fd.read(10)
            if 'OK' in data:
                ret = 0
        return ret

    def check_At_Mode(self):
        ret = -1
        self.fd.flush()
        for i in range(3):
            self.fd.flush()
            self.fd.write('At' + chr(0x0d) + chr(0x0a))
            data = self.fd.read(10)
            if 'OK' in data:
                print('recv is', data)
                ret = 0
        return ret

    def send_comand_to_zigbee(self, cmd):
        ret = -1
        while 1:
            self.fd.write(cmd + chr(0x0d) + chr(0x0a))
            data = self.fd.readall()
            if "OK" in data:
                print (data)
                ret = 0
                break
        return ret

    def set_type(self, type):
        ret = -1
        ret = self.send_comand_to_zigbee('AT+TYP=' + type)
        return ret

    def set_pid(self, pid):
        ret = -1
        ret = self.send_comand_to_zigbee('AT+PID=' + pid)
        return ret

    def set_nid(self, nid):
        ret = -1
        ret = self.send_comand_to_zigbee('AT+NID=' + nid)
        return ret

    def set_cha(self, cha):
        ret = -1
        ret = self.send_comand_to_zigbee('AT+CHA=' + cha)
        return ret

