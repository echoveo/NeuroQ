#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xhzhang'

import xml.etree.ElementTree as ET
from config import global_var
from rexml import updateVersion
import cgi, serial
import os, Cookie

print "Content-Type: text/html charset=utf-8 \n\n"

tyep = netnumber = netaddress = physchannel = ''


def command_to_zigbee(command):
    ''''''
    back_data = '0'
    fd = serial.Serial(global_var.zigbee_port,
                       baudrate=115200,
                       bytesize=8,
                       parity='N',
                       stopbits=1,
                       timeout=1)
    if fd:
        while 1:
            print command
            fd.write(command + chr(0x0d) + chr(0x0a))
            data = fd.readall()
            if "OK" in data:
                print(data)
                back_data = '1'
                break
    fd.close()
    return back_data


def get_cgi_data():
    '''从界面得到zigbee参数 '''
    global tyep, netnumber, netaddress, physchannel
    form = cgi.FieldStorage()
    tyep = form.getvalue('zigbee_DeviceType', '0')
    netnumber = form.getvalue('zigbee_NetNum', '0')
    netaddress = form.getvalue('zigbee_NetAddress', '0')
    physchannel = form.getvalue('zigbee_Physicalchannel', '19')
    print "界面："
    print tyep, netnumber, netaddress, physchannel


def jugde_status(status):
    status = '1'
    if status == '1' or status == '2':
        flag = '1'
    else:
        flag = '0'
    return flag


def alter_config():
    '''当终端的网络地址变化后，需要修改config.xml配置文件的网络地址'''
    conf = ''
    agent_tree = ET.parse(global_var.itemconfig_path)
    task_node_list = agent_tree.findall('task/TaskDriver/driver')
    for task_node in task_node_list:
        if task_node.attrib['n'] == 'T.IDrv.Task:libzigbee':
            conf = task_node.attrib['config'].split(';')
            task_node.set(
                'config', conf[0] + ';' + conf[1] + ';' + conf[2] + ';' +
                conf[3] + ';' + conf[4] + ';' + conf[5] + ';' + conf[6] + ';' +
                netaddress + ';' + conf[8] + ';' + conf[9] + ';' + conf[10] +
                ';' + conf[11] + ';' + conf[12])
            break
    #ET.dump(agent_tree)
    updateVersion.write(agent_tree, global_var.itemconfig_path)
    # agent_tree.write(global_var.itemconfig_path,
    #                  encoding='utf-8',
    #                  xml_declaration='true')


def save_network_config():
    '''将zigbee信息保存到AnyLink.xml中'''
    anylink_tree = ET.parse(global_var.AnyLinkconfig_path)
    zigbee_netnumber_node = anylink_tree.find('ZigbeeInfo/NetNumber')
    zigbee_netnumber_node.text = netnumber
    zigbee_netaddress_node = anylink_tree.find('ZigbeeInfo/NetAddress')
    zigbee_netaddress_node.text = netaddress
    zigbee_phychannel_node = anylink_tree.find('ZigbeeInfo/Physchannel')
    zigbee_phychannel_node.text = physchannel
    #ET.dump(anylink_tree)
    updateVersion.write(anylink_tree, global_var.AnyLinkconfig_path)
    # anylink_tree.write(global_var.AnyLinkconfig_path,
    #                    encoding='utf-8',
    #                    xml_declaration='true')


def set_network_config():
    '''获取cookie'''
    if 'HTTP_COOKIE' in os.environ:
        cookie_string = os.environ.get('HTTP_COOKIE')
        c = Cookie.SimpleCookie()
        c.load(cookie_string)
        data = c['AnyLinkLan'].value
    '''set zigbee info to arm'zigbee'''
    flag_netnumber = flag_phychannel = flag_netaddress = '0'
    anylink_tree = ET.parse(global_var.AnyLinkconfig_path)
    zigbee_netnumber_node = anylink_tree.find('ZigbeeInfo/NetNumber')
    zigbee_netnumber = zigbee_netnumber_node.text
    zigbee_netaddress_node = anylink_tree.find('ZigbeeInfo/NetAddress')
    zigbee_netaddress = zigbee_netaddress_node.text
    zigbee_phychannel_node = anylink_tree.find('ZigbeeInfo/Physchannel')
    zigbee_phychannel = zigbee_phychannel_node.text
    if tyep == 0:
        if zigbee_netnumber != netnumber:
            set_netnumber_status = command_to_zigbee(str('AT+PID=' +
                                                         netnumber))
        else:
            set_netnumber_status = '2'
        flag_netnumber = jugde_status(set_netnumber_status)

        if zigbee_phychannel != physchannel:
            set_phychannel_status = command_to_zigbee(
                str('AT+CHA=' + physchannel))
        else:
            set_phychannel_status = '2'
        flag_phychannel = jugde_status(set_phychannel_status)

        if flag_netnumber == '1' and flag_phychannel == '1':
            save_network_config()
            alter_config()
            if data == "English":
                print 'Zigbee setup was successful'
            else:
                print 'zigbee设置成功'
        else:
            if data == "English":
                print 'Zigbee setup failed'
            else:
                print 'zigbee设置失败'
    else:
        if zigbee_netnumber != netnumber:
            set_netnumber_status = command_to_zigbee(str('AT+PID=' +
                                                         netnumber))
        else:
            set_netnumber_status = '2'
        flag_netnumber = jugde_status(set_netnumber_status)
        if zigbee_netaddress != netaddress:
            set_netaddress_status = command_to_zigbee(
                str('AT+NID=' + netaddress))
        else:
            set_netaddress_status = '2'
        flag_netaddress = jugde_status(set_netaddress_status)
        if zigbee_phychannel != physchannel:
            set_phychannel_status = command_to_zigbee(
                str('AT+CHA=' + physchannel))
        else:
            set_phychannel_status = '2'
        flag_phychannel = jugde_status(set_phychannel_status)
        if flag_netnumber == '1' and flag_phychannel == '1' and flag_netaddress == '1':
            save_network_config()
            alter_config()
            if data == "English":
                print 'Zigbee setup was successful'
            else:
                print 'zigbee设置成功'
        else:
            if data == "English":
                print 'Zigbee setup failed'
            else:
                print 'zigbee设置失败'


def check_gpio():
    '''获取cookie'''
    if 'HTTP_COOKIE' in os.environ:
        cookie_string = os.environ.get('HTTP_COOKIE')
        c = Cookie.SimpleCookie()
        c.load(cookie_string)
        data = c['AnyLinkLan'].value
    '''检查zigbee的gpio值是否设置'''
    zigbee_gpio_path = '/sys/class/gpio/gpio52/value'
    cmd_get_zigbee_gpio = 'cat ' + zigbee_gpio_path
    cmd_set_zigbee_gpio = 'echo 1 > ' + zigbee_gpio_path
    zigbee_gpio_value = os.popen(cmd_get_zigbee_gpio).read()

    if zigbee_gpio_value == 0:
        set_status = os.system(cmd_set_zigbee_gpio)
        zigbee_gpio_value_new = os.popen(cmd_get_zigbee_gpio).read()
        if set_status == 0 and zigbee_gpio_value_new == 1:
            set_network_config()
        else:
            if data == "English":
                print 'The zigbee_gpio setup failed!'
            else:
                print 'zigbee_gpio设置失败！'
            return 0
    else:
        set_network_config()


if __name__ == '__main__':
    get_cgi_data()
    check_gpio()