#!/usr/bin/python
# -*- coding: UTF-8  -*-

import xml.etree.ElementTree as ET
from config import global_var
from Log import Loginfo
from rexml import updateVersion
import Check
import cgi
import os
import csv
import sys
import re
import json
reload(sys)
sys.setdefaultencoding('utf8')

print "Content-Type: text/html charset=utf-8 \n"

fileitem = ''
device_id = ''
address_map_json = ''
with open("../../conf/MITSUBISHI-TX-5HP.json", "r") as f:
    address_map_json = f.read()
address_map = json.loads(address_map_json)


def get_cgi_file():
    ''''''
    global fileitem, device_id
    form = cgi.FieldStorage()
    # 获取文件名
    fileitem = form['filename1']
    device_id = form.getvalue('deviceID')

    # 检测文件是否上传
    if fileitem.filename:
        # 去掉文件路径，获取文件名称
        fn = os.path.basename(fileitem.filename)
        open(global_var.uploadfile_path, 'wb').write(fileitem.file.read())
        #message = '文件"' + fn + '" 上传成功！'
        # print message
    else:
        message = '没有文件上传！'
        print message


def convert_gbk2utf8():
    data_list = []
    fd = open(global_var.uploadfile_path, 'rb')
    csvfd = csv.reader(fd)
    for row in csvfd:
        data_list.append(
            [unit.decode('gb2312').encode('utf-8') for unit in row])
    fd.close()
    return data_list


def analy_csv_file(data_list):
    global device_id
    attrib = []
    dataitemlist = []
    commDataItems_node = None
    type = register = rwmode = address = ''

    global device_id, maxDeviceID, maxDriverID, channelid, ChannelDeviceType
    agent_tree = ET.parse(global_var.itemconfig_path)
    agent = agent_tree.getroot()

    model_list = agent_tree.iter('model')
    for model in model_list:
        device_list = model.iter('device')

        for device in device_list:
            dataitem_list = device.iter('dataItem')
            for dataitem in dataitem_list:
                # 记录所有的数据项ID到list中 用以判重
                dataitemlist.append(dataitem.get('id', default=None))

            if device.get('id', default=None) == device_id:
                modelType = model.get('devicedriver')
                commDataItems_node = device.find('driver/commDataItems')

    if commDataItems_node is None:
        log.write_error("导入时未找到commDataItems节点")
        return 0

    for rownum in range(len(data_list)):
        dataitem = ET.Element('dataItem')
        if rownum == 0:
            attrib = data_list[rownum]
        else:
            for i in range(len(attrib)):
                if attrib[i] == '设备驱动' and data_list[rownum][i] != modelType:
                    print 'csv中第%d行设备驱动[%s]与当前通道[%s]不符合，请检查！' % (
                        rownum + 1, data_list[rownum][i], modelType)
                    return 0

                if attrib[i] == '数据项ID':
                    if data_list[rownum][i] in dataitemlist:
                        print 'csv中第%d行数据项ID与网关已配置数据项ID重复' % (rownum + 1)
                        return 0
                    else:
                        itemId = data_list[rownum][i]
                        dataitem.set('id', itemId)
                elif attrib[i] == '名称':
                    itemName = data_list[rownum][i]
                    dataitem.set('n', itemName)
                elif attrib[i] == '别名':
                    dataitem.set('alias', data_list[rownum][i])
                elif attrib[i] == '数据项配置':
                    try:
                        address = data_list[rownum][i]
                        dataitem.set('config', address_map[address.decode('utf-8')])
                    except KeyError:
                        print "请在%d行填写正确的数据项配置" % (rownum + 1)
                        return 0
                elif attrib[i] == '数据项类型':
                    type = data_list[rownum][i]
                    if type == '字符串':
                        type_a = 's'
                    elif type == '开关量':
                        type_a = 'b'
                    else:
                        type_a = 'a'
                    dataitem.set('type', type_a)
                elif attrib[i] == '读写':
                    if data_list[rownum][i] == '只读':
                        rwmode = '0'
                    elif data_list[rownum][i] == '可写':
                        rwmode = '1'
                    else:
                        print '第%d行读写类型只能为只读或可写!' % (rownum + 1)
                        return 0
                    dataitem.set('rw', rwmode)
                elif attrib[i] == '上报':
                    if data_list[rownum][i] == '全部上传' or data_list[rownum][i] == '上报':
                        report = '1'
                    elif data_list[rownum][i] == '变化上传':
                        report = '2'
                    else:
                        report = '0'
                    dataitem.set('report', report)
                elif attrib[i] == '频率':
                    if not Check.check_frequency(data_list[rownum][i]):
                        return 0
                    dataitem.set('freq', data_list[rownum][i])

                # add by fyj, 新增datahandler驱动
                elif attrib[i] == '值运算参数':
                    zh_to_symbol = {
                        '加': '+',
                        '减': '-',
                        '乘': '*',
                        '除': '/',
                        'b': 'b',
                        '线性': '#'
                    }
                    conf = data_list[rownum][i]
                    if conf != 'null':
                        confArr = conf.split(';')
                        if len(confArr) < 2:
                            print '第%d行值运算参数不符合规范!' % (rownum + 1)
                            return 0
                        else:
                            dhNode = agent_tree.find(
                                'task/TaskDriver/driver/dataHandler/config')
                            if not dhNode:
                                # 如果没有就自动创建
                                task = agent.find('task')
                                task_dh = ET.Element('TaskDriver')
                                task.append(task_dh)
                                task_dh_driver = ET.Element('driver')
                                task_dh.append(task_dh_driver)
                                task_dh_driver.set(
                                    'n', 'T.IDrv.Task:libkdatahandler')
                                task_dh_driver.set('id', '1')
                                task_dh_driver.set('config', '')
                                task_dh_datahandler = ET.Element('dataHandler')
                                task_dh_driver.append(task_dh_datahandler)
                                task_dh_datahandler.set('n', 'DH:libhcommon')
                                task_dh_datahandler.set('id', '1')
                                task_dh_datahandler.set('pri', '2')
                                dhNode = ET.Element('config')
                                task_dh_datahandler.append(dhNode)

                            dhitemNode = ET.Element('item')
                            dhNode.append(dhitemNode)
                            dhitemNode.set('n', itemName)
                            dhitemNode.set('id', itemId)

                            dhitemNode.set('op', zh_to_symbol[confArr[0]])
                            if confArr[0] == "线性":
                                coe_list = confArr[1].split("|")
                                coe = "(%s)*iv+(%s)" % (
                                    coe_list[0], coe_list[1])
                                rcoe = "(iv-(%s))/(%s)" % (
                                    coe_list[1], coe_list[0])
                                dhitemNode.set('coe', coe)
                                dhitemNode.set('rcoe', rcoe)
                            else:
                                dhitemNode.set('coe', confArr[1])
                # end
                else:
                    pass
            commDataItems_node.append(dataitem)
    # ET.dump(agent_tree)
    updateVersion.write(agent_tree, global_var.itemconfig_path)
    # agent_tree.write(global_var.itemconfig_path, encoding='utf-8')
    return True


def deleteDevice():
    global channelid
    agent_tree = ET.parse(global_var.itemconfig_path)
    parient_node_list = agent_tree.findall('model')
    for modelnode in parient_node_list:
        channel_node_id = modelnode.get('id', default=None)
        if channel_node_id != None and channel_node_id == channelid:
            children_node_list = modelnode.getchildren()
            for child_node in children_node_list:
                if child_node.attrib['n'] == 'PresetDeviceName':
                    modelnode.remove(child_node)
                    updateVersion.write(agent_tree, global_var.itemconfig_path)
                    # agent_tree.write(global_var.itemconfig_path,
                    #                  encoding='utf-8')


if __name__ == '__main__':
    log = Loginfo.Loginfo()
    get_cgi_file()
    try:
        data_list = convert_gbk2utf8()
    except Exception as e:
        print "文件转码失败！请检查csv是否为GB2312格式"

    if Check.check_csv_unique(data_list, '数据项ID') and \
       Check.check_csv_unique(data_list, '名称'):
        max_id = Check.get_max_itemid(data_list)
        #    Check.check_xml_unique(data_list,3,device_id) == 1 and \
        #    Check.check_xml_unique(data_list,4,device_id) == 1 :

        if analy_csv_file(data_list):
            Check.set_max_itemid(max_id + 1)
            print "导入成功！"
