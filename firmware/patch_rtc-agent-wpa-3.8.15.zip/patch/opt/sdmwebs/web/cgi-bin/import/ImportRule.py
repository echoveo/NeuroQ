#!/usr/bin/python
# -*- coding: UTF-8  -*-
__author__ = 'xhzhang'

import xml.etree.ElementTree as ET
from config import global_var
from Log import Loginfo
from rexml import updateVersion
import Check
import cgi
import os
import csv
import sys
reload(sys)
sys.setdefaultencoding('utf8')

print "Content-Type: text/html charset=utf-8 \n"

fileitem = ''
device_id = '1'
device_list1 = ''


def get_cgi_file():
    ''''''
    global fileitem, device_id
    form = cgi.FieldStorage()
    # 获取文件名
    fileitem = form['filename1']
    device_id = form.getvalue('deviceID')
    # 检测文件是否上传
    if fileitem.filename:
        # 去掉文件路径，获取文件名称
        fn = os.path.basename(fileitem.filename)
        open(global_var.uploadfile_path, 'wb').write(fileitem.file.read())
        #message = '文件"' + fn + '" 上传成功！'
        #print message
    else:
        message = '没有文件上传！'
        print message


def get_csv_rownumber():
    data_list = []
    fd = open(global_var.uploadfile_path, 'rb')
    csvfd = csv.reader(fd)
    counter = 1
    for row in csvfd:
        counter += 1
    fd.close()
    return len(row)


def convert_gbk2utf8():
    data_list = []
    fd = open(global_var.uploadfile_path, 'rb')
    csvfd = csv.reader(fd)
    for row in csvfd:
        data_list.append(
            [unit.decode('gb2312').encode('utf-8') for unit in row])
    fd.close()
    return data_list


def get_item_type(itemname):
    type = ''
    global device_list1
    for device in device_list1:
        if device.get('id') == device_id:
            dataitem_list = device.findall('driver/commDataItems/dataItem')
            for dataitem in dataitem_list:
                if dataitem.get('n') == itemname:
                    type = dataitem.get('type')
                    break
    return type


def analy_csv_file(data_list):
    attrib = []
    rules_node = None
    item_name_list = []
    rule_id = rule_name = ''
    rule_item_name = rule_item_condition = rule_item_threshold = ''
    rule_alarm_level = rule_alarm_level_a = rule_decription = rule_relation = ''
    item_type = ''

    agent_tree = ET.parse(global_var.itemconfig_path)

    device_list = agent_tree.iter('device')
    for device in device_list:
        if device.get('id', default=None) == device_id:
            item_node = device.findall('driver/commDataItems/dataItem')
            for item in item_node:
                item_name_list.append(item.get('n'))
            rules_node = device.find('Rules')
            if rules_node is None:
                rules_node = ET.Element('Rules')
                device.append(rules_node)

    # log.write_debug(rules_node)

    for rownum in range(len(data_list)):
        if rownum == 0:
            attrib = data_list[rownum]
            # log.write_debug(attrib)
        else:
            for i in range(len(attrib)):
                if attrib[i] == 'ID':
                    rule_id = data_list[rownum][i]
                elif attrib[i] == '名称':
                    rule_name = data_list[rownum][i]
                elif attrib[i] == '数据项':
                    rule_item_nameArray = []
                    rule_item_name = data_list[rownum][i].split(';')
                    for itemName in rule_item_name:
                        if itemName not in item_name_list:
                            print '第%d行第%d列未知数据项' % ((rownum + 1), (i + 1))
                            return False
                        rule_item_nameArray.append(itemName)
                        item_type = get_item_type(itemName)

                elif attrib[i] == '条件':
                    rule_item_condition_a = []
                    tmp = ''
                    rule_item_condition = data_list[rownum][i].split(';')
                    for condition in rule_item_condition:
                        if condition == '包含':
                            tmp = '1'
                        elif condition == '等于':
                            tmp = '4'
                        elif condition == '不等于':
                            tmp = '5'
                        elif condition == '大于等于':
                            tmp = '6'
                        elif condition == '大于':
                            tmp = '10'
                        elif condition == '小于等于':
                            tmp = '8'
                        elif condition == '小于':
                            tmp = '11'
                        else:
                            print '第%d行第%d列未知判断条件' % ((rownum + 1), (i + 1))
                            return False
                        rule_item_condition_a.append(tmp)

                elif attrib[i] == '阈值':
                    rule_item_threshold_a = []
                    rule_item_threshold = data_list[rownum][i].split(';')
                    for threshold in rule_item_threshold:
                        rule_item_threshold_a.append(threshold)

                elif attrib[i] == '告警级别':
                    rule_alarm_level = data_list[rownum][i]
                    if rule_alarm_level == '一级':
                        rule_alarm_level_a = '8'
                    elif rule_alarm_level == '二级':
                        rule_alarm_level_a = '9'
                    elif rule_alarm_level == '三级':
                        rule_alarm_level_a = '10'
                    elif rule_alarm_level == '四级':
                        rule_alarm_level_a = '11'
                    elif rule_alarm_level == '五级':
                        rule_alarm_level_a = '12'
                    else:
                        print '告警级别填写错误！'
                        return False
                elif attrib[i] == '描述':
                    rule_decription = data_list[rownum][i] + ' ,$0'
                elif attrib[i] == '相关联系':
                    rule_relation = data_list[rownum][i]
                else:
                    pass

            rule_node = ET.Element('rule',
                                   attrib={
                                       'id': rule_id,
                                       'name': rule_name
                                   })
            rules_node.append(rule_node)
            # triggers
            triggers_node = ET.Element('Triggers')
            rule_node.append(triggers_node)
            trigger_node = ET.Element('trigger',
                                      attrib={
                                          'name': rule_name,
                                          'type': '1',
                                          'relation': rule_relation
                                      })
            triggers_node.append(trigger_node)
            if len(rule_item_condition_a) != len(rule_item_nameArray) or len(
                    rule_item_nameArray) != len(rule_item_threshold_a):
                print '请检查数据项、条件和阈值三列上同一行";"个数是否一致！'
                return 0
            if len(rule_item_condition_a) > 6:
                print '一条告警中请勿配置超过6个条件！'
                return 0
            for k in range(len(rule_item_condition_a)):
                # log.write_debug(str(k))
                if k == 1:
                    trigger_node.set('relation', rule_relation)
                di_node = ET.Element('di',
                                     attrib={
                                         'name': rule_item_nameArray[k],
                                         'id': str(k),
                                         'dep': '',
                                         'opr': rule_item_condition_a[k],
                                         'opd': rule_item_threshold_a[k]
                                     })
                trigger_node.append(di_node)

            # actions
            actions_node = ET.Element('Actions')
            rule_node.append(actions_node)
            action_node = ET.Element('action',
                                     attrib={
                                         'name': rule_name,
                                         'type': '1',
                                         'alarm': rule_name,
                                         'severity': rule_alarm_level_a,
                                         'descr': rule_decription
                                     })
            actions_node.append(action_node)
    updateVersion.write(agent_tree, global_var.itemconfig_path)
    # agent_tree.write(global_var.itemconfig_path, encoding='utf-8')
    return 1


if __name__ == '__main__':
    agent_tree = ET.parse(global_var.itemconfig_path)
    device_list1 = agent_tree.iter('device')
    log = Loginfo.Loginfo()
    get_cgi_file()

    data_list = convert_gbk2utf8()
    if Check.check_csv_unique_rule(data_list,
                                   0) == 1 and Check.check_rule_xml_unique(
                                       data_list, 0) == 1:
        max_id = Check.get_max_ruleid(data_list)
        if max_id == 0:
            print "规则id有错误。"
        else:
            if analy_csv_file(data_list) == 1:
                Check.set_max_ruleid(max_id + 1)
                print "导入成功！"
            else:
                print '导入失败！'
