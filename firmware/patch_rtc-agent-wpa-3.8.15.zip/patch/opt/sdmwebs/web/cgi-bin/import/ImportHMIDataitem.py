#!/usr/bin/python
# -*- coding: UTF-8  -*-

import xml.etree.ElementTree as ET
from config import global_var
from Log import Loginfo
import cgi,os,re
import Check
import csv
import sys
reload(sys)
sys.setdefaultencoding('utf8')

print "Content-Type: text/html charset=utf-8 \n"

fileitem = ''
device_id = ''
maxDeviceID = ''
maxDriverID = ''
channelid = ''
ChannelDeviceType = ''

def get_cgi_file():
    '''获取界面数据'''
    global fileitem, device_id,maxDeviceID,maxDriverID,channelid,ChannelDeviceType
    form = cgi.FieldStorage()
    # 获取文件名
    fileitem = form['filename1']
    device_id = form.getvalue('deviceID')
    # 检测文件是否上传
    if fileitem.filename:
        fn = os.path.basename(fileitem.filename)
        open(global_var.uploadfile_path, 'wb').write(fileitem.file.read())
    else:
        message = '没有文件上传！'
        print message


def convert_gbk2utf8():
    '''更改编码'''
    data_list = []
    fd = open(global_var.uploadfile_path, 'rb')
    csvfd = csv.reader(fd)
    for c in csvfd:
        data_row_list = []
        for i in range(0,get_csv_rownumber()):
            c_u = c[i].decode('gb2312').encode('utf-8')
            data_row_list.append(c_u)
        data_list.append(data_row_list)
    fd.close()
    return data_list
    

def get_csv_rownumber():
    '''获取上传的csv列数'''
    data_list = []
    fd = open(global_var.uploadfile_path, 'rb')
    csvfd = csv.reader(fd)
    counter = 1 
    for row in csvfd: 
        counter += 1 
    fd.close()
    return len(row)

def analy_csv_file(data_list):
    deviceNode = None
    commDataItems_node = None
    attrib = []
    type = type_a = rwmode = report =  align = ''

    agent_tree = ET.parse(global_var.itemconfig_path)
    agent = agent_tree.getroot()
    model_list = agent_tree.iter('model')
    for model in model_list:
        device_list = model.iter('device')
        global device_id,maxDeviceID,maxDriverID,channelid,ChannelDeviceType

    for device in device_list:
        if device.get('id', default=None) == device_id:
            modelType = model.get('devicedriver')
            deviceNode = device
            commDataItems_node = device.find('driver/commDataItems')
    for i in range(1,len(data_list)):
        if modelType != data_list[i][0]:
            print "第%d行正在导入的设备[" % (i+1) +data_list[i][0]+"]与当前通道["+modelType+"]不符合，请检查！" 
            return 0      

    if commDataItems_node is None:
        print "导入时未找到commDataItems节点"
        return 0
    for rownum in range(len(data_list)):
        dataitem = ET.Element('dataItem')
        if rownum == 0:
            attrib = data_list[rownum]
        else:
            for i in range(len(attrib)):
                if attrib[i] == '数据项ID':
                    dataitem.set('id',data_list[rownum][i])
                elif attrib[i] == '名称':
                    dataitem.set('n', data_list[rownum][i])
                elif attrib[i] == '别名':
                    dataitem.set('alias',data_list[rownum][i])
                elif attrib[i] == '配置信息':
                    dataitem.set('config',data_list[rownum][i])
                elif attrib[i] == '类型':
                    type = data_list[rownum][i]
                    if type == '字符串':
                        type_a = 's'
                    elif type == '开关量':
                        type_a = 'b'
                    else:
                        type_a = 'a'
                    dataitem.set('type', type_a)
                elif attrib[i] == '采集频率':
                    if not Check.check_frequency(data_list[rownum][i]):
                        return 0
                    dataitem.set('freq',data_list[rownum][i])
                elif attrib[i] == '读写':
                    if data_list[rownum][i] == '只读':
                        rwmode = '0'
                    else:
                        rwmode = '1'
                    dataitem.set('rw',rwmode)
                elif attrib[i] == '上报':
                    if data_list[rownum][i] == '全部上传' or data_list[rownum][i] == '上报':
                        report = '1'
                    elif data_list[rownum][i] == '变化上传':
                        report = '2'
                    else:
                        report = '0'
                    dataitem.set('report', report)
                elif attrib[i] == '驱动ID':
                    if maxDeviceID != '':
                        driverNode = deviceNode.find('driver')
                        driverNode.set('id',data_list[rownum][i])
                #add by fyj, 新增datahandler驱动
                elif attrib[i] == '值运算参数':
                    conf = data_list[rownum][i]
                    if conf != 'null':
                        confArr = conf.split(';')
                        if len(confArr) < 2:
                            confArr = conf.split('；')
                        if len(confArr) > 1:
                            dhNode =  agent_tree.find('task/TaskDriver/driver/dataHandler/config')
                            if dhNode == None:
                                #如果没有就自动创建
                                task = agent.find('task')
                                task_dh = ET.Element('TaskDriver')
                                task.append(task_dh)
                                task_dh_driver = ET.Element('driver')
                                task_dh.append(task_dh_driver)
                                task_dh_driver.set('n','T.IDrv.Task:libkdatahandler')
                                task_dh_driver.set('id','1')
                                task_dh_driver.set('config','')
                                task_dh_datahandler = ET.Element('dataHandler')
                                task_dh_driver.append(task_dh_datahandler)
                                task_dh_datahandler.set('n','DH:libhcommon')
                                task_dh_datahandler.set('id','1')
                                task_dh_datahandler.set('pri','2')
                                dhNode = ET.Element('config')
                                task_dh_datahandler.append(dhNode)
                                    
                            dhitemNode = ET.Element('item')
                            dhNode.append(dhitemNode)
                            dhitemNode.set('n', data_list[rownum][4])
                            dhitemNode.set('id', data_list[rownum][3])
                            
                            if confArr[0] == '加':
                                confArr[0] = '+'
                            elif confArr[0] == '减':
                                confArr[0] = '-'
                            elif confArr[0] == '乘':
                                confArr[0] = '*'
                            elif confArr[0] == '除':
                                confArr[0] = '/'
                            elif confArr[0] == 'b':
                                confArr[0] = 'b'
                            dhitemNode.set('op', confArr[0])
                            dhitemNode.set('coe', confArr[1])
                    else:
                        pass
                #end
                else:
                    pass
                #log.write_debug(dataitem.attrib)
            commDataItems_node.append(dataitem)

    agent_tree.write(global_var.itemconfig_path,encoding='utf-8')
    return 1

def deleteDevice():
    '''删除xml中信息'''
    global channelid
    agent_tree = ET.parse(global_var.itemconfig_path)
    parient_node_list = agent_tree.findall('model')
    for modelnode in parient_node_list:
        channel_node_id = modelnode.get('id',default=None)
        if channel_node_id != None and channel_node_id == channelid:
            children_node_list = modelnode.getchildren()
            for child_node in children_node_list:
                if child_node.attrib['n'] == 'PresetDeviceName':
                    modelnode.remove(child_node)
                    agent_tree.write(global_var.itemconfig_path, encoding='utf-8')

if __name__ == '__main__':
    log = Loginfo.Loginfo()
    get_cgi_file()
    try:
        data_list = convert_gbk2utf8()
    except Exception as e:
        print("正在导入的表格中设备驱动与当前通道不符合，请检查！")
        deleteDevice()
    #print Check.check_xml_unique(data_list,4)
    if Check.check_csv_unique(data_list,3) == 1 and \
       Check.check_csv_unique(data_list,4) == 1 and \
       Check.check_xml_unique(data_list,3,device_id) == 1 and \
       Check.check_xml_unique(data_list,4,device_id) == 1 :
        max_id = Check.get_max_itemid(data_list)
        #log.write_debug(max_id)
        if max_id == 0:
            print "数据项id有错误。"
        else:
            if analy_csv_file(data_list) == 1:
                Check.set_max_itemid(max_id + 1)
                print "导入成功！"
    elif maxDeviceID!='':
        deleteDevice()
