#!/usr/bin/python
# -*- coding: UTF-8  -*-

import xml.etree.ElementTree as ET
from config import global_var
from Log import Loginfo
from rexml import updateVersion
import Check
import cgi
import os
import csv
import sys
import re

reload(sys)
sys.setdefaultencoding('utf8')

print "Content-Type: text/html charset=utf-8 \n"

fileitem = device_id = ''
maxDeviceID = ''
maxDriverID = ''
channelid = ''
ChannelDeviceType = ''


def get_cgi_file():
    ''''''
    global fileitem, device_id, maxDeviceID, maxDriverID, channelid, ChannelDeviceType
    form = cgi.FieldStorage()
    # 获取文件名
    fileitem = form['filename1']
    '''
    device_id = form.getvalue('deviceID')
    if device_id == "-1":
        maxDriverID = form.getvalue('maxDriverID')
        maxDeviceID = form.getvalue('maxDeviceID')
        channelid = form.getvalue('channelid')
        ChannelDeviceType = form.getvalue('ChannelDeviceType')
    '''
    # 检测文件是否上传
    if fileitem.filename:
        # 去掉文件路径，获取文件名称
        fn = os.path.basename(fileitem.filename)
        open(global_var.uploadfile_path, 'wb').write(fileitem.file.read())
        # print '文件"' + fn + '" 上传成功！'
    else:
        print '没有文件上传！'


def convert_gbk2utf8():
    data_list = []
    fd = open(global_var.uploadfile_path, 'rb')
    csvfd = csv.reader(fd)
    for row in csvfd:
        data_list.append(
            [unit.decode('gb2312').encode('utf-8') for unit in row])
    fd.close()
    return data_list


def analy_csv_file(data_list):
    attrib = []
    commDataItems_node = None
    deviceNode = None
    devicedriver = ''
    type = register = rwmode = address = ''
    global device_id, maxDeviceID, maxDriverID, channelid, ChannelDeviceType
    agent_tree = ET.parse(global_var.itemconfig_path)
    agent = agent_tree.getroot()

    agent_tree = ET.parse(global_var.itemconfig_path)

    addrArray = []
    for addr in data_list:
        if addr != data_list[0]:
            addrArray.append(addr[5])
            if addr[5]:
                a = int(addr[5])
                if a < 0 or a > 8000 or a == '':
                    print '地址不符合规范，应为0~8000'
                    return 0
            else:
                print '导入csv中请输入地址'
                return 0

    if len(addrArray) != len(set(addrArray)):
        print '请勿出现重复地址'
        return 0

    device_list = agent_tree.iter('device')
    for device in device_list:
        # print device.get('id', default=None)
        device_exist = True
        dataitem_node_list = device.findall('driver/commDataItems/dataItem')
        for dataitem_node in dataitem_node_list:
            rownumber = 0
            for conf in data_list:
                if (dataitem_node.get('id') == conf[0]) and (dataitem_node.get('n') == conf[1]) and (dataitem_node.get('alias') == conf[2]):
                    dataitem_node.set('vtype', conf[4])
                    dataitem_node.set('addr', conf[5])
                    data_list.remove(conf)
    # ET.dump(agent_tree)
    updateVersion.write(agent_tree, global_var.itemconfig_path)
    # agent_tree.write(global_var.itemconfig_path, encoding='utf-8')
    return 1


def deleteDevice():
    global channelid
    agent_tree = ET.parse(global_var.itemconfig_path)
    parient_node_list = agent_tree.findall('model')
    for modelnode in parient_node_list:
        channel_node_id = modelnode.get('id', default=None)
        if channel_node_id != None and channel_node_id == channelid:
            children_node_list = modelnode.getchildren()
            for child_node in children_node_list:
                if child_node.attrib['n'] == 'PresetDeviceName':
                    modelnode.remove(child_node)
                    updateVersion.write(agent_tree, global_var.itemconfig_path)
                    # agent_tree.write(
                    #     global_var.itemconfig_path, encoding='utf-8')


if __name__ == '__main__':
    log = Loginfo.Loginfo()
    get_cgi_file()
    try:
        data_list = convert_gbk2utf8()
    except Exception as e:
        print "正在导入的表格中设备驱动与当前通道不符合，请检查！"

    if analy_csv_file(data_list) == 1:
        print "导入成功！"
