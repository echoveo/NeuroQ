#!/usr/bin/python
# -*- coding: UTF-8  -*-
__author__ = 'xhzhang'

import csv
import xml.etree.ElementTree as ET
from rexml import updateVersion
from config import global_var


def get_csv_col(data_list, col):
    '''获取csv某一列的值的list'''
    col_csv_list = []
    for row in range(1, len(data_list)):
        col_csv_list.append(data_list[row][col])
    return col_csv_list


def get_xml_lable(lable, flable=None, deviceId=None):
    '''获取xml中lable的值list,flable存在的时候代表的是验证告警信息'''

    col_config_list = []
    agent_tree = ET.parse(global_var.itemconfig_path)
    # add by x
    # 现在导入数据项的时候会拿所有的数据项去验证唯一性，实际上只需要验证当前通道下的数据项
    dataItems = filter(lambda d: d.get("id") == deviceId,
                       agent_tree.iter('device'))
    # end add

    if flable is None:
        dataitem_list = dataItems[0].iter(
            'dataItem') if len(dataItems) > 0 else []
    else:
        dataitem_list = agent_tree.iter(flable)

    for dataitem in dataitem_list:
        col_config_list.append(dataitem.get(lable))
    return col_config_list


def check_unique(xml_list, csv_list, flag):
    '''检查csv和xml中的数据项名称是否重复'''
    ret = 1
    repeat_itemname = repeat_id = []

    if flag == 4:
        for xml in xml_list:
            if xml in csv_list:
                repeat_itemname.append(xml)
        if len(repeat_itemname) != 0:
            ret = 0
            print 'csv文件中数据项名称与界面现有数据项重复，数据名称：\n'
            print repeat_itemname
    else:
        for xml in xml_list:
            if xml in csv_list:
                repeat_id.append(xml)
        if len(repeat_id) != 0:
            ret = 0
            print 'csv文件中数据ID与界面现有ID重复，数据名称：\n'
            print repeat_itemname
    return ret


def check_csv_unique(data_list, name):
    '''校验csv文件数据项ID、名称唯一'''
    col = data_list[0].index(name)
    name_list = []
    for row in range(1, len(data_list)):
        if data_list[row][col] != '':
            name_list.append(data_list[row][col])
        else:
            print "csv文件第%d行第%d列的数据为空!" % ((row + 1), col)
            return False

    for dataitem_name in name_list:
        count = name_list.count(dataitem_name)
        if count > 1:
            print "%s[%s]重复%d次！" % (name, dataitem_name, count)
            return False
    return True


def check_csv_unique_rule(data_list, col):
    '''校验告警csv文件ID唯一'''
    ret = 1
    dataitem_name_list = []
    for row in range(1, len(data_list)):
        if data_list[row][col] != '':
            dataitem_name_list.append(data_list[row][col])
        else:
            print "csv文件第%d行第%d列的数据为空!" % ((row + 1), col)
            ret = 0

    for dataitem_name in dataitem_name_list:
        count = dataitem_name_list.count(dataitem_name)
        if count > 1:
            ret = 0
            if col == 0:
                print "数据项ID[%s]重复%d次！" % (dataitem_name, count)
                break
    return ret


def check_xml_unique(data_list, col, device_id):
    '''检验上传的数据信息是否与xml中重复'''
    ret = 1

    # 获取*.csv中的数据项名称list和id的list
    csv_list = get_csv_col(data_list, col)
    # 获取config.xml中现有的数据项名称list和id的list

    if col == 3:
        xml_list = get_xml_lable('id', deviceId=device_id)
    else:
        xml_list = get_xml_lable('n', deviceId=device_id)

    # 检查数据项信息重复
    ret = check_unique(xml_list, csv_list, col)

    return ret


def check_rule_xml_unique(data_list, col):
    '''检验上传的数据信息是否与xml中重复'''
    ret = 1

    # 获取*.csv中的数据项名称list和id的list
    csv_list = get_csv_col(data_list, col)

    # 获取config.xml中现有的数据项名称list和id的list
    if col == 0:
        xml_list = get_xml_lable('id', flable='rule')
    else:
        xml_list = get_xml_lable('n')

    # 检查数据项信息重复
    ret = check_unique(xml_list, csv_list, col)

    return ret


def get_max_itemid(data_list):
    '''获取数据项最大ID'''
    col = data_list[0].index("数据项ID")
    idall_tree = ET.parse(global_var.idconfig_path)
    max_itemid = int(idall_tree.find('ItemID').text)

    for row in range(1, len(data_list)):
        if data_list[row][col] != '':
            max_itemid = max(max_itemid, int(data_list[row][col]))

    agent_tree = ET.parse(global_var.itemconfig_path)
    device_list = agent_tree.iter('device')
    for device in device_list:
        if device.get('id', default=None) != '1023':
            dataitem_list = device.findall('driver/commDataItems/dataItem')
            for dataitem in dataitem_list:
                max_itemid = max(max_itemid,
                                 int(dataitem.get('id', default=None)))
    return max_itemid


def get_max_ruleid(data_list):
    '''获取规则做大ID'''
    idall_tree = ET.parse(global_var.idconfig_path)
    max_ruleid = int(idall_tree.find('RuleID').text)

    for row in range(1, len(data_list)):
        if data_list[row][0] != '':
            max_ruleid = max(max_ruleid, int(data_list[row][0]))

    agent_tree = ET.parse(global_var.itemconfig_path)
    device_list = agent_tree.iter('device')
    for device in device_list:
        if device.get('id', default=None) != '1023':
            rule_list = device.iter('Rules/rule')
            for rule in rule_list:
                max_ruleid = max(max_ruleid, int(rule.get('id', default=None)))
    return max_ruleid


def set_max_itemid(new_max_itemid):
    '''重新写入最大id+1'''
    idall_tree = ET.parse(global_var.idconfig_path)
    itemid_node = idall_tree.find('ItemID')
    # 将新的item_id写入IDinfo.xml文件
    itemid_node.text = str(new_max_itemid)
    updateVersion.write(idall_tree, global_var.idconfig_path)
    # idall_tree.write(global_var.idconfig_path,
    #                  encoding='utf-8',
    #                  xml_declaration='true')


def set_max_ruleid(new_max_ruleid):
    '''重新写入最大id+1'''
    idall_tree = ET.parse(global_var.idconfig_path)
    itemid_node = idall_tree.find('RuleID')
    # 将新的rule_id写入IDinfo.xml文件
    itemid_node.text = str(new_max_ruleid)
    updateVersion.write(idall_tree, global_var.idconfig_path)
    # idall_tree.write(global_var.idconfig_path,
    #                  encoding='utf-8',
    #                  xml_declaration='true')


def get_csv_rownumber():
    """获取upload.csv的列数"""
    with open(global_var.uploadfile_path, "rb") as csvfile:
        reader = csv.reader(csvfile)
        return [len(row) for row in reader][0]


def check_frequency(current_freq):
    try:
        common_tree = ET.parse(global_var.common_path)
        min_freq = int(common_tree.find("MinFrequency").text)
        if int(current_freq) < min_freq:
            print "当前支持的最低频率为" + str(min_freq / 1000) + "秒"
            return False

        return True
    except Exception as e:
        print "上传频率列仅支持数字"
        return False
