#!/usr/bin/python
# -*- coding: UTF-8  -*-
# __author__ = 'xhzhang'


import xml.etree.ElementTree as ET
from config import global_var
from Log import Loginfo
import cgi, os, re
import Check
import csv
import sys

reload(sys)
sys.setdefaultencoding('utf8')

print "Content-Type: text/html charset=utf-8 \n"

fileitem = device_id = ''
maxDeviceID = ''
maxDriverID = ''
channelid = ''
ChannelDeviceType = ''

def get_cgi_file():
    '''获取界面数据'''
    global fileitem, device_id,maxDeviceID,maxDriverID,channelid,ChannelDeviceType
    form = cgi.FieldStorage()
    # 获取文件名
    fileitem = form['filename1']
    device_id = form.getvalue('deviceID')
    if device_id == "-1":
        maxDriverID = form.getvalue('maxDriverID')
        maxDeviceID = form.getvalue('maxDeviceID')
        channelid = form.getvalue('channelid')
        ChannelDeviceType = form.getvalue('ChannelDeviceType')
    # 检测文件是否上传
    if fileitem.filename:
        # 去掉文件路径，获取文件名称
        fn = os.path.basename(fileitem.filename)
        open(global_var.uploadfile_path, 'wb').write(fileitem.file.read())
        # message = '文件"' + fn + '" 上传成功！'
        # print message
    else:
        message = '没有文件上传！'
        print message


def convert_gbk2utf8():
    data_list = []
    fd = open(global_var.uploadfile_path, 'rb')
    csvfd = csv.reader(fd)
    for c1, c2, c3, c4, c5, c6, c7, c8, c9, c10, c11, c12, c13, c14,c15,c16,c17,c18 in csvfd:
        c1_u = c1.decode('gb2312').encode('utf-8')
        c2_u = c2.decode('gb2312').encode('utf-8')
        c3_u = c3.decode('gb2312').encode('utf-8')
        c4_u = c4.decode('gb2312').encode('utf-8')
        c5_u = c5.decode('gb2312').encode('utf-8')
        c6_u = c6.decode('gb2312').encode('utf-8')
        c7_u = c7.decode('gb2312').encode('utf-8')
        c8_u = c8.decode('gb2312').encode('utf-8')
        c9_u = c9.decode('gb2312').encode('utf-8')
        c10_u = c10.decode('gb2312').encode('utf-8')
        c11_u = c11.decode('gb2312').encode('utf-8')
        c12_u = c12.decode('gb2312').encode('utf-8')
        c13_u = c13.decode('gb2312').encode('utf-8')
        c14_u = c14.decode('gb2312').encode('utf-8')
        c15_u = c15.decode('gb2312').encode('utf-8')
        c16_u = c16.decode('gb2312').encode('utf-8')
        c17_u = c17.decode('gb2312').encode('utf-8')
        c18_u = c18.decode('gb2312').encode('utf-8')
        data_row_list = [c1_u, c2_u, c3_u, c4_u, c5_u, c6_u, c7_u, c8_u, c9_u, c10_u, c11_u, c12_u, c13_u, c14_u, c15_u, c16_u, c17_u, c18_u]
        data_list.append(data_row_list)
    fd.close()
    return data_list


def analy_csv_file(data_list):
    attrib = []
    dataitemlist = []
    commDataItems_node = None
    deviceNode = None
    type = type_a = rwmode = report = align = net_num = ''
    slaveID = address = function = calculate = change_upload = ''
    agent_tree = ET.parse(global_var.itemconfig_path)
    global device_id,maxDeviceID,maxDriverID,channelid,ChannelDeviceType
    device_list = agent_tree.iter('device')

    if device_id == "-1":
        device_id = maxDeviceID

    model_list = agent_tree.iter('model')
    for model in model_list:
        device_list = model.iter('device')
        for device in device_list:
            dataitem_list = device.iter('dataItem')
            # print device.get('id', default=None)
            if maxDeviceID != '' and device.get('id',default=None) == data_list[1][1]:
                deleteDevice()
                print "正在导入的表格中设备ID已存在，请检查！"
                return 0

            for dataitem in dataitem_list:
                # 记录所有的数据项ID到list中 用以判重
                dataitemlist.append(dataitem.get('id', default=None))

            if device.get('id', default=None) == device_id:
                modelType = model.get('devicedriver')
                if modelType != data_list[1][0] :
                    print "正在导入的设备["+data_list[1][0]+"]与当前通道["+modelType+"]不符合，请检查！"
                    return 0
                device.set('id',device_id)
                deviceNode = device
                commDataItems_node = device.find('driver/commDataItems')

    if commDataItems_node is None:
        print "导入时未找到commDataItems节点"
        return 0
    for rownum in range(len(data_list)):
        dataitem = ET.Element('dataItem')
        if rownum == 0:
            attrib = data_list[rownum]
        else:
            for i in range(len(attrib)):
                if attrib[i] == '数据项ID':
                    if data_list[rownum][i] in dataitemlist:
                        print 'csv中第%d行数据项ID与网关已配置数据项ID重复' % (rownum + 1)
                        return 0
                    else:
                        dataitem.set('id',data_list[rownum][i])
                elif attrib[i] == '名称':
                    dataitem.set('n', data_list[rownum][i])
                elif attrib[i] == '别名':
                    dataitem.set('alias', data_list[rownum][i])
                elif attrib[i] == '从站ID':
                    slaveID = data_list[rownum][i]
                elif attrib[i] == '地址':
                    address = data_list[rownum][i]
                elif attrib[i] == '类型':
                    type = data_list[rownum][i]
                    if re.match(r'STRING', type) is not None:
                        type_a = 's'
                    elif type == 'BIT' or type == 'BOOLEAN':
                        type_a = 'b'
                    else:
                        type_a = 'a'
                    dataitem.set('type', type_a)
                elif attrib[i] == '功能码':
                    function = data_list[rownum][i]
                    if not function in ['1','2','3','4']:
                        print '第%d行功能码超出范围!' % (rownum + 1)
                        return 0
                elif attrib[i] == '数据项附加':
                    calculate = data_list[rownum][i]
                # elif attrib[i] == '网络号':
                #      netid = data_list[rownum][i]
                elif attrib[i] == '采集频率':
                    if not Check.check_frequency(data_list[rownum][i]):
                        return 0
                    dataitem.set('freq', data_list[rownum][i])
                elif attrib[i] == '读写':
                    if data_list[rownum][i] == '只读':
                        rwmode = '0'
                    else:
                        rwmode = '1'
                    dataitem.set('rw', rwmode)
                elif attrib[i] == '是否变化上传':
                    change_upload = data_list[rownum][i]
                elif attrib[i] == '上报':
                    if data_list[rownum][i] == '全部上传' or data_list[rownum][i] == '上报':
                        report = '1'
                    elif data_list[rownum][i] == '变化上传':
                        report = '2'
                    else:
                        report = '0'
                    dataitem.set('report', report)
                elif attrib[i] == '对齐方式':
                    if data_list[rownum][i] == '大端':
                        align = '0'
                    else:
                        align = '1'
                elif attrib[i] == '网络号':
                    net_num = data_list[rownum][i]
                elif attrib[i] == '设备名称':
                    if maxDeviceID != '':
                        deviceNode.set('n',data_list[rownum][i])
                elif attrib[i] == '驱动ID':
                    if maxDeviceID != '':
                        driverNode = deviceNode.find('driver')
                        driverNode.set('id',data_list[rownum][i])
                else:
                    pass
                dataitem.set('config',
                             slaveID + ';' + function + ';' + address + ';' + calculate + ';' + type + ';' + change_upload + ';' + align + ';' + net_num + ';' + rwmode)
                # log.write_debug(dataitem.attrib)
            commDataItems_node.append(dataitem)
    agent_tree.write(global_var.itemconfig_path, encoding='utf-8')
    return 1

def deleteDevice():
    global channelid
    agent_tree = ET.parse(global_var.itemconfig_path)
    parient_node_list = agent_tree.findall('model')
    for modelnode in parient_node_list:
        channel_node_id = modelnode.get('id',default=None)
        if channel_node_id != None and channel_node_id == channelid:
            children_node_list = modelnode.getchildren()
            for child_node in children_node_list:
                if child_node.attrib['n'] == 'PresetDeviceName':
                    modelnode.remove(child_node)
                    agent_tree.write(global_var.itemconfig_path, encoding='utf-8')

if __name__ == '__main__':
    log = Loginfo.Loginfo()
    get_cgi_file()
    try:
        data_list = convert_gbk2utf8()
    except Exception as e:
        print "正在导入的表格中设备驱动与当前通道不符合，请检查！"
        deleteDevice()
    # log.write_debug(data_list)
    if Check.check_csv_unique(data_list, 3) == 1 and \
        Check.check_csv_unique(data_list, 4) == 1 and \
        Check.check_xml_unique(data_list, 3,device_id) == 1 and \
        Check.check_xml_unique(data_list, 4,device_id) == 1:
        max_id = Check.get_max_itemid(data_list)
        #log.write_debug(max_id)
        if max_id == 0:
            print "数据项id有错误。"
        else:
            if analy_csv_file(data_list) == 1:
                Check.set_max_itemid(max_id + 1)
                print "导入成功！"
    elif maxDeviceID!='':
        deleteDevice()
