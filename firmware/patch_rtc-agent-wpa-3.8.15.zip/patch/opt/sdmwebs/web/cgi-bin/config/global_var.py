# -*- coding: UTF-8 -*-
__author__ = 'xhzhang'
#############################
#config file path infomation#
#############################
Conf_Directory = '../../conf/'
itemconfig_path = Conf_Directory + 'config.xml'
idconfig_path = Conf_Directory + 'IDinfo.xml'
AnyLinkconfig_path = Conf_Directory + 'AnyLink.xml'
Login_path = Conf_Directory + 'Login.xml'
InitStatus_path = Conf_Directory + 'InitStatus.xml'
RealTimeData_path = Conf_Directory + 'RealTimeData.xml'
uploadfile_path = Conf_Directory + 'upload.csv'
download_path = Conf_Directory + 'download.csv'
default_gateway_path = Conf_Directory + 'gateway.dat'
wifi_list_path = Conf_Directory + 'wifiinfo.json'
reserve_wifi_list_path = Conf_Directory + 'reserveWifi.json'
wifi_status_path = Conf_Directory + 'wifistatus'
agent_path = '/opt/agent/'
netstatus_path = agent_path + 'Net.state'
devicestatus_path = agent_path + 'PLCSTA.dat'
plcremoteaddree = agent_path + 'SIEMENS_remoteAddress.dat'
moduleconfig_path = agent_path + 'ModuleConfig.xml'
agent_cloud_path = agent_path + 'AgentConfig.xml'
testdata_path = agent_path + 'PLC.dat'
bacnet_testdata_path = agent_path + 'Bacnet.dat'
modbus_testdata_path = agent_path + 'Modbus.dat'
SMB_CONF_PATH = '/opt/install/samba/smb.conf'

back_directory = Conf_Directory + 'config_bak/'
Login_bak_path = back_directory + 'Login.xml'

agentd_path = "/opt/agentd/"
agentd_moduleconfig_path = agentd_path + "ModuleConfig.xml"

# add by fyj
common_path = Conf_Directory + 'Common.xml'

###########################
##Anylink init infomation##
###########################
# Anylink basic information
HardwareModel = 'AnyLink 100'
HardwareName = 'AnyLink 100'
AnyLinkType = 'DA'
SoftVersion = '3.4.7'
SerialNumber = '1402271'
AgentVersion = 'V3.6.7'
# 判断是否在config.xml中出现ra的额外数据项 默认0为不出现
RaExtraDataitem = '0'
# agent config
agent_loglevel = '100'
# 默认为空，为/PageFile/
# 如果不是默认路径则需写具体路径，linux平台日志路径最后一个字符必须是'/',  比如：/opt/agent/
agent_logpath = ''
agent_pingrate = '30'
agent_regretrycount = '100'
agent_mode = '0'  # 0:client mode ;1:server mode
agent_uploadtype = '1' 
agent_queuesize = '1'
agent_proto = 'mqtt'  # http or mqtt
agent_alarmmode = '0' 
agent_control_port = '10001'
agent_dbenable = '1'
agent_dbthread = '10000'
agent_dbscantime = '3'  # 单位：s
# bad数据配置 0-禁止bad数据上传发布； 1-禁止bad数据上传，允许bad数据发布；2-允许bad数据上传，禁止bad数据发布；3-允许bad数据上传发布，默认为0
badDataMode = '0'
agent_force_upload_time = '240'
agent_discard_invalid_data = '1'

agent_cache = agent_dbenable + ';' + agent_dbthread + ';' + agent_dbscantime
# mqtt config
# 必须配置
mqtt_publish_server = 's1.anylinkcloud.com'
mqtt_publish_port = '1883'
mqtt_sub_server = 's1.anylinkcloud.com'
mqtt_sub_port = '1883'
mqtt_keepalive = '60'
mqtt_qos = '2'
mqtt_retain = '0'
mqtt_tls = '0'
mqtt_isEncrypt = '1'  # 用户名密码加密,默认为1加密
mqtt_username = ''
mqtt_password = ''

# 无需动
mqtt_config = mqtt_publish_server + ';' + mqtt_publish_port + ';' + mqtt_sub_server + ';' + \
    mqtt_sub_port + ';' + mqtt_keepalive + ';' + mqtt_qos + ';' + mqtt_retain + ';' + \
    mqtt_isEncrypt + ';' + mqtt_username + ';' + \
    mqtt_password + ';;' + mqtt_tls + ';'

# 1：主机(有3G模块(或者有线)+zigbee网关) 0：备机(无3G模块并且无外网+zigbee终端),
# 初始化使用，其他地方无用
Product_type = '1'
# AnyLink zigbee information
zigbee_type = '0'  # 1：终端 0：网关
zigbee_netnumber = '50'
zigbee_netaddress = '0'
zigbee_physchannel = '19'
zigbee_port = 'NULL'
# AnyLink lora information
lora_baudrate = '9600'
lora_parity = 'NONE'
lora_RF_freq = '443'
lora_RF_factor = '10'
lora_RF_mode = 'normal'
lora_RF_BW = '125K'
lora_ID_H = '0'
lora_ID_L = '0'
lora_net_ID = '0'
lora_power = '20db'
##############################
#AnyLink network information##
##############################
# hostname = 'id1474'
net_muti = 'NO'  # YES:双网口;NO:单网口
# wan
network_wan_dhcp = 'YES'  # YES:启用dhcp;NO:不启用dhcp
network_wan_ip = '192.168.100.126'
network_wan_mac = ''
network_wan_mask = '255.255.255.0'
network_wan_gateway = '192.168.100.1'
network_wan_dns = '8.8.8.8'
# lan
network_lan_dhcp = 'NO'  # YES:启用dhcp;NO:不启用dhcp
network_lan_ip = '192.168.101.204'
network_lan_mac = ''
network_lan_mask = '255.255.255.0'
network_lan_gateway = '192.168.101.1'
network_lan_dns = '8.8.8.8'
# mode(gateway or 4G)
network_mode = 'gateway'
# model(simcom)
network_model = 'simcom'

# vpn
vpn_display = 'YES'  # YES:显示VPN功能页面;NO:不显示VPN功能页面

##################
#wifi information#
##################
wifi_modestatus = 'stop'
wifi_dhcp = 'YES'
wifi_gateway = '0.0.0.0'
wifi_mask = '255.255.255.0'
wifi_strong = '0'
wifi_ssid = ''
wifi_password = ''
wifi_status = ''
wifi_ip = '0.0.0.0'
wifi_mac = ''

# Anylink cloud server
cloud_address = 's1.anylinkcloud.com'
http_port = '8686'
api_port = '8600'
# AnyLink login infomation
# modified begin by fyj, 增加用户角色分为管理员和普通用户
#username = 'admin'
#password = '21232f297a57a5a743894a0e4a801fc3'
#loginstatus = '0'
adminUsername = 'admin'
adminPassword = 'admin'
adminLoginstatus = '0'
username = 'anylink'
password = 'anylink'
loginstatus = '0'
# modified end
# AnyLinkk timezone information
timezone = '/UTC'
ntp_server1 = '1.pool.ntp.org'
ntp_server2 = '2.pool.ntp.org'
# Router config
router_enable = 'NO'
router_ip = '192.168.101.204'
router_mask = '255.255.255.0'
router_dhcp = '1'
router_dhcp_start = "192.168.101.20"
router_dhcp_end = "192.168.101.60"
