#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xhzhang'

import cgi,sys
from Log import Loginfo
import Cookie
import os

class GetCgi():
    form = ''
    log = ''
    def __init__(self):
        self.form = cgi.FieldStorage()
        self.log = Loginfo.Loginfo()

    def get_data(self,keys):
        '''获取cookie'''
        if 'HTTP_COOKIE' in os.environ:
            cookie_string=os.environ.get('HTTP_COOKIE')
            c=Cookie.SimpleCookie()
            c.load(cookie_string)
            data=c['AnyLinkLan'].value

        if self.form.has_key(keys):
              return self.form.getvalue(keys,'1')
        else:
            if data == "Engish":
                self.log.write_error("key=[%s]Not exist" % (keys))
            else:
                self.log.write_error("key=[%s]不存在" % (keys))
            try:
                sys.exit(1)
            except SystemExit:
                pass
