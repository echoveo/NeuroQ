#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xhzhang'

import sys
import os
import Cookie

def quit_error(mod):
    '''获取cookie'''
    if 'HTTP_COOKIE' in os.environ:
        cookie_string=os.environ.get('HTTP_COOKIE')
        c=Cookie.SimpleCookie()
        c.load(cookie_string)
        data=c['AnyLinkLan'].value

    try:
        sys.exit(1)
    except SystemExit:
        if data == "English":
            print "Module=[%s]abnormal exit." % (mod)
        else:
            print "模块=[%s]异常退出。" % (mod)
            

