#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xhzhang'

import socket
import sys, cgi
import json,os
import xml.etree.ElementTree as ET
from config import global_var
from Log import Loginfo
import os
import Cookie

print "Content-Type: text/html charset=utf-8 \n"


def get_cgi_data():
    '''获取cookie'''
    if 'HTTP_COOKIE' in os.environ:
        cookie_string=os.environ.get('HTTP_COOKIE')
        c=Cookie.SimpleCookie()
        c.load(cookie_string)
        data=c['AnyLinkLan'].value

    global control_cmd
    form = cgi.FieldStorage()
    if form.has_key("Test_Value_YuToXHZhang"):
        control_cmd = form.getvalue('Test_Value_YuToXHZhang')
    else:
        if data == "English":
            log.write_error("没有key=[Test_Value_YuToXHZhang]!")
        else:
            log.write_error("No key=[Test_Value_YuToXHZhang]!")


def send_cmd(control_cmd):
    '''获取cookie'''
    if 'HTTP_COOKIE' in os.environ:
        cookie_string=os.environ.get('HTTP_COOKIE')
        c=Cookie.SimpleCookie()
        c.load(cookie_string)
        data=c['AnyLinkLan'].value

    '''与agent通信，得到实时数据'''

    addr = ('127.0.0.1', 10001)
    timeout = 10
    BUFFER = 1024
    back_data = ''
    socket.setdefaulttimeout(10)
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        client.connect(addr)
    except socket.error, arg:
        (errno, err_msg) = arg
        if data == "English":
            print "Module loading: %s, Coding=%d" % (err_msg, errno)
        else:
            print "模块加载中: %s, 编码=%d" % (err_msg, errno)
        sys.exit()
    try:
        client.send(control_cmd + chr(0x0d) + chr(0x0a))
    except:
        if data == "English":
            print "发送数据失败！"
        else:
            print "Failed to send data!"
    try:
        client.settimeout(timeout)
        while(1):
            temp = client.recv(BUFFER)
            back_data += temp
            if len(temp) < BUFFER:
                break
    except socket.timeout:
        if data == "English":
            print "数据响应超时：%d 秒" % timeout
        else:
            print "Data response timeout:%d second" % timeout
        client.close()
        sys.exit()
    client.close()
    return back_data


def analy_jsondata(jsondata):
    '''得到agent返回的数据list'''
    return json.loads(jsondata)['resps']


def change_list2dic():
    '''将config.xml中的数据项解析为字典'''
    config_dataitem_dic = {}
    config_tree = ET.parse(global_var.itemconfig_path)
    config_dataitem_list = config_tree.findall('model/device/driver/commDataItems/dataItem')
    for config_dataitem in config_dataitem_list:
        id = config_dataitem.attrib['id']
        config_dataitem_dic[id] = config_dataitem
    return config_dataitem_dic

def analy_data(test_list,data_dic):
    '''分析agent返回的实时最新数据，并返回xml'''
    testdata = ET.Element('All')
    testdata_tree = ET.ElementTree(testdata)
    for data in test_list:
        dataitem = ET.Element('dataitem')
        dataitem_id = str(data[0])
        dataitem_quality = data[1]
        dataitem_value = data[2]
        if data_dic.has_key(dataitem_id):
            dataitem = data_dic[dataitem_id]
            dataitem.set('value', str(dataitem_value))
            dataitem.set('quality', str(dataitem_quality))
            testdata.append(dataitem)
    ET.dump(testdata_tree)

def delete_datafile():
    if os.path.exists(global_var.RealTimeData_path):
        os.remove(global_var.RealTimeData_path)

if __name__ == '__main__':
    '''获取cookie'''
    if 'HTTP_COOKIE' in os.environ:
        cookie_string=os.environ.get('HTTP_COOKIE')
        c=Cookie.SimpleCookie()
        c.load(cookie_string)
        data=c['AnyLinkLan'].value

    control_cmd = ''
    log = Loginfo.Loginfo()
    get_cgi_data()
    agent_data = send_cmd(control_cmd)
    #log.write_debug("agent: " + agent_data)
    if data == "English":
        if agent_data != '':
            datainfo_list = analy_jsondata(agent_data)
            try:
                error_code = datainfo_list[0].get('rs')
                if error_code == 5:
                    print "Error sending command format"
                elif error_code == 6:
                    print "Incorrect configuration file"
                elif error_code == 7:
                    print "Driver loading..."
            except:
                print "1"
                #configdata_dic = change_list2dic()
                #analy_data(datainfo_list,configdata_dic)
        else:
            print "The drive return data is empty"
    else:
        if agent_data != '':
            datainfo_list = analy_jsondata(agent_data)
            try:
                error_code = datainfo_list[0].get('rs')
                if error_code == 5:
                    print "发送命令格式错误"
                elif error_code == 6:
                    print "配置文件有误"
                elif error_code == 7:
                    print "驱动加载中..."
            except:
                print "1"
                #configdata_dic = change_list2dic()
                #analy_data(datainfo_list,configdata_dic)
        else:
            print "驱动返回数据为空"