#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xhzhang'

import datetime
import pytz
from config import global_var

print "Content-Type: text/html charset=utf-8 \n\n"


def display_test_data(list):
    print "<!DOCTYPE html>"
    print "<html>"
    print "<head>"
    print "<meta charset= \"UTF-8\">"
    print "<title></title>"
    print "<link rel=\"stylesheet\" href=\"assets/css/style2.css\">"
    print "<style type=\"text/css\">"
    print "</style>"
    print "</head>"
    print "<table width=\"600px\" border= \"0\" cellpadding= \"0\" cellspacing= \"0\" style= \"border:1px #D7D7D7 solid;border-bottom:none;margin-top:20px;\" align=\"center\">"
    print "<tr style=\"line-height:30px;\">"
    print "<td width=\"130px;\" bgcolor=\"#08284E\"><div align=\"center\" style=\"color:#FFFFFF\">名称</div></td>"
    print "<td width=\"130px;\" bgcolor=\"#08284E\"><div align=\"center\" style=\"color:#FFFFFF\">地址</div></td>"
    print "<td width=\"80px;\" bgcolor=\"#08284E\"><div align=\"center\" style=\"color:#FFFFFF\">类型</div></td>"
    print "<td width=\"80px;\" bgcolor=\"#08284E\"><div align=\"center\" style=\"color:#FFFFFF\">值</div></td>"
    print "<td width=\"180px;\" onclick=\"sortTable('tblSort', 2, 'date')\" style=\"cursor:pointer\" bgcolor=\"#08284E\"><div align=\"center\" style=\"color:#FFFFFF\">时间</div></td>"
    print "</tr>"

    for row_data in list:
        # print row_data
        print "<tr>"
        print  "<td style=\"border-bottom-style:solid;border-bottom-width: 1px;border-bottom-color:#D7D7D7; height:25px;line-height:25px;\"><div style=\"margin-left:45px;\">" + \
               row_data[0] + "</div></td>"
        print  "<td style=\"border-bottom-style:solid;border-bottom-width: 1px;border-bottom-color:#D7D7D7; height:25px;line-height:25px;\"><div style=\"margin-left:50px;\">" + \
               row_data[1] + "</div></td>"
        print  "<td style=\"border-bottom-style:solid;border-bottom-width: 1px;border-bottom-color:#D7D7D7; height:25px;line-height:25px;\"><div style=\"margin-left:20px;\">" + \
               row_data[4] + "</div></td>"
        print  "<td style=\"border-bottom-style:solid;border-bottom-width: 1px;border-bottom-color:#D7D7D7; height:25px;line-height:25px;\"><div style=\"margin-left:35px;\">" + \
               row_data[2] + "</div></td>"
        print  "<td width=\"250px;\" style=\"border-bottom-style:solid;border-bottom-width: 1px;border-bottom-color:#D7D7D7; height:25px;line-height:25px;\"><div align=\"center\">" + \
               row_data[3] + "</div></td>"
        print "</tr>"
    print "</table>"
    print "</body>"
    print  "</html>"


# print "<script>"
#print "</script>\n\n"


def change_utc_local(time_st):
    utc_st = datetime.datetime.strptime(time_st, "%Y-%m-%d %H:%M:%S")
    cst_st = utc_st.replace(tzinfo=pytz.utc).astimezone(pytz.timezone('Asia/Shanghai')).strftime('%Y-%m-%d %H:%M:%S')
    #print str(cst_st)
    return str(cst_st)


def get_test_data():
    ''''''
    data_list = []
    testdata_file = open(global_var.testdata_path, 'rb')
    #print global_var.testdata_path
    for line in testdata_file:
        linedata_list = line.split('/')
        #print linedata_list
        data_config = linedata_list[1].split(';')
        #组合生成address
        linedata_list[1] = data_config[0] + data_config[2]
        linedata_list.append(data_config[1])
        #改变time时区
        string = time_config = linedata_list[3].split('\n')[0]
        linedata_list[3] = change_utc_local(string)
        #将解析后的数据添加到数据list
        data_list.append(linedata_list)
    testdata_file.close()
    display_test_data(data_list)


if __name__ == '__main__':
    get_test_data()