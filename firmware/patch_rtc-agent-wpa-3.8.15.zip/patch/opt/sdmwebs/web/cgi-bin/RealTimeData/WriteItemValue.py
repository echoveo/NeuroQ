#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'bzyang'

import socket
import sys, cgi
import json,os
import Cookie
import xml.etree.ElementTree as ET
import urllib2
from config import global_var
from Log import Loginfo

print "Content-Type: text/html charset=utf-8 \n"

cookie_value = ''
WRITE_KEY = "Write_Value_command"

def get_cookie():
    global cookie_value
    ff = open("/opt/sdmwebs/web/conf/cookie.txt","r")
    cookie_value = ff.read()
    ff.close()
    
def get_cgi_data():
    global control_cmd,cookie_value
    global WRITE_KEY
    form = cgi.FieldStorage()
    if form.has_key(WRITE_KEY):
        control_cmd = form.getvalue(WRITE_KEY)
    else:
        log.write_error("没有key=[%s]!"%(WRITE_KEY))

def send_cmd(control_cmd):
    '''与agent通信，得到实时数据'''
    global cookie_value
    addr = ('127.0.0.1', 10001)
    timeout = 10
    BUFFER = 1024
    back_data = ''
    socket.setdefaulttimeout(10)
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        client.connect(addr)
    except socket.error, arg:
        (errno, err_msg) = arg
        log.write_error("模块加载中: %s, 编码=%d" % (err_msg, errno))
        sys.exit()
    try:
        client.send(control_cmd + chr(0x0d) + chr(0x0a))
    except:
        log.write_error("发送数据失败！")
    try:
        client.settimeout(timeout)
        while(1):
            temp = client.recv(BUFFER)
            back_data += temp
            if len(temp) < BUFFER:
                break;
    except socket.timeout:
        log.write_error("数据响应超时：%d 秒" % timeout)
        client.close()
        sys.exit()
    client.close()
    return back_data


def analy_jsondata(jsondata):
    '''得到agent返回的数据list'''
    return json.loads(jsondata)['resps']


def change_list2dic():
    '''将config.xml中的数据项解析为字典'''
    config_dataitem_dic = {}
    config_tree = ET.parse(global_var.itemconfig_path)
    config_dataitem_list = config_tree.findall('model/device/driver/commDataItems/dataItem')
    for config_dataitem in config_dataitem_list:
        id = config_dataitem.attrib['id']
        config_dataitem_dic[id] = config_dataitem
    return config_dataitem_dic

def analy_data(test_list,data_dic):
    '''分析agent返回的实时最新数据，并返回xml'''
    testdata = ET.Element('All')
    testdata_tree = ET.ElementTree(testdata)
    for data in test_list:
        dataitem = ET.Element('dataitem')
        dataitem_id = str(data[0])
        dataitem_quality = data[1]
        dataitem_value = data[2]
        if data_dic.has_key(dataitem_id):
            dataitem = data_dic[dataitem_id]
            dataitem.set('value', str(dataitem_value))
            dataitem.set('quality', str(dataitem_quality))
            testdata.append(dataitem)
    ET.dump(testdata_tree)

def delete_datafile():
    if os.path.exists(global_var.RealTimeData_path):
        os.remove(global_var.RealTimeData_path)

if __name__ == '__main__':
    if 'HTTP_COOKIE' in os.environ:
        cookie_string=os.environ.get('HTTP_COOKIE')
        c=Cookie.SimpleCookie()
        c.load(cookie_string)
        data=c['AnyLinkLan'].value

    control_cmd = ''
    log = Loginfo.Loginfo()    
    get_cgi_data()
    agent_data = send_cmd(control_cmd)
    if agent_data != '':
        datainfo_list = analy_jsondata(agent_data)
        try:
            error_code = datainfo_list[0].get('rs')
            if data == 'English':
                if error_code == 0:               
                    msg_error = "Write operation succeeded"
                elif error_code == -1:               
                    msg_error = "Write operation failed"            
                elif error_code == 5:
                    msg_error = "Send command format error"
                elif error_code == 6:
                    msg_error = "Incorrect configuration file"
                elif error_code == 7:
                    msg_error = "Drive loading, try again later"
                else:
                    msg_error = "Return value is abnormal:%s"%error_code
            else:    
                if error_code == 0:               
                    msg_error = "写入操作成功"
                elif error_code == -1:               
                    msg_error = "写入操作失败"            
                elif error_code == 5:
                    msg_error = "发送命令格式错误"
                elif error_code == 6:
                    msg_error = "配置文件有误"
                elif error_code == 7:
                    msg_error = "驱动加载中,稍后重试"
                else:
                    msg_error = "返回值异常:%s"%error_code
            #log.write_error(msg_error)
            print msg_error
        except:
            configdata_dic = change_list2dic()
            analy_data(datainfo_list,configdata_dic)
    else:
        log.write_warn("驱动返回数据为空")