#/usr/bin/env python
# -*- coding:UTF-8 -*-
__author__ = 'xhzhang'

import socket,time
if __name__ == '__main__':

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(('localhost', 8888))
    sock.listen(5)
    while True:
        connection,address = sock.accept()
        try:
            connection.settimeout(5)
            buf = connection.recv(1024)
            print buf
            if buf == '1':
                #time.sleep(20)
                connection.send('{"id":1,"dn":"","vn":"libOMRON_FINS","resps":  [[1,0,1],[2,1,0],[3,1,5],[4,1,1],[5,1,1],[24,1,5]]}'+chr(0x0d)+chr(0x0a))
            else:
                #time.sleep(20)
                connection.send('{"id":1,"dn":"","vn":"libOMRON_FINS","resps":  [[1,0,1],[2,1,0],[3,1,5],[4,1,1]]}'+chr(0x0d)+chr(0x0a))
        except socket.timeout:
            print 'time out'
        connection.close()