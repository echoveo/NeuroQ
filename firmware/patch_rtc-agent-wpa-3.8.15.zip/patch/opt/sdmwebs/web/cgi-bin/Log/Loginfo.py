# /usr/bin/env python
# -* coding:UTF-8 *-
__author__ = 'xhzhang'

import logging
import logging.config

class Loginfo:
    def __init__(self):
        logging.config.fileConfig('../config/logging.conf')
        self.main_logger = logging.getLogger('main')

    def write_debug(self, info):
        self.main_logger.debug(info)

    def write_info(self, info):
        self.main_logger.info(info)

    def write_warn(self, info):
        self.main_logger.warning(info)

    def write_error(self, info):
        self.main_logger.error(info)

    def write_critical(self, info):
        self.main_logger.critical(info)