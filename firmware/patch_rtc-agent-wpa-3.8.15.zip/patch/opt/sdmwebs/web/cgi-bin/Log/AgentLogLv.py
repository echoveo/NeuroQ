#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xhzhang'

import xml.etree.ElementTree as ET
from config import global_var
from rexml import updateVersion
import cgi
import os
import Cookie

print "Content-Type: text/html charset=utf-8 \n"

debug = cmd = ''


def get_cgi_data():
    '''get  data '''
    global cmd, debug
    cmd = 'search'
    form = cgi.FieldStorage()
    #cmd = form.getvalue('cmd')
    if cmd == 'alter':
        debug = form.getvalue('debug', '100')


def get_current_debug():
    anylink_cloud_tree = ET.parse(global_var.agent_cloud_path)
    anylink_cloud = anylink_cloud_tree.getroot()
    debug_node = anylink_cloud_tree.find('Debug')
    return debug_node.text


def save_agent_config_agent():
    '''save data into config file(opt/agent/AgentConfig.xml)'''
    anylink_cloud_tree = ET.parse(global_var.agent_cloud_path)
    anylink_cloud = anylink_cloud_tree.getroot()
    debug_node = anylink_cloud_tree.find('Debug')
    debug_node.text = debug
    # ET.dump(anylink_cloud_tree)
    updateVersion.write(anylink_cloud_tree, global_var.agent_cloud_path)
    # anylink_cloud_tree.write(global_var.agent_cloud_path,
    #                          xml_declaration='true')
    print 'success'


if __name__ == '__main__':
    get_cgi_data()
    '''获取cookie'''
    if 'HTTP_COOKIE' in os.environ:
        cookie_string = os.environ.get('HTTP_COOKIE')
        c = Cookie.SimpleCookie()
        c.load(cookie_string)
        data = c['AnyLinkLan'].value

    if data == "English":
        if cmd == "alter":
            save_agent_config_agent()
            print "Modify success"
        elif cmd == 'search':
            print get_current_debug()
        else:
            print "Command error"
    else:
        if cmd == "alter":
            save_agent_config_agent()
            print "修改成功"
        elif cmd == 'search':
            print get_current_debug()
        else:
            print "命令错误"
