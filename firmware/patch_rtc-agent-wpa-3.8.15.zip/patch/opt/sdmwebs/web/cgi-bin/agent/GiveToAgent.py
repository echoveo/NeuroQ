#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xhzhang'

import Cookie
import os
import shutil
import sys
import xml.etree.ElementTree as ET
from rexml import updateVersion
from config import global_var

reload(sys)
sys.setdefaultencoding('utf-8')

print "Content-Type: text/html charset=utf-8 \n\n"

language = ""


def get_web_version():
    common_tree = ET.parse(global_var.common_path)
    root_node = common_tree.getroot()
    common_dict = dict()

    for child_node in root_node.iter():
        node_tag = child_node.tag
        node_text = child_node.text.strip()
        common_dict[node_tag] = node_text
    global_var.SoftVersion = common_dict['SoftVersion']


def get_script_version():
    script_version = ''
    if os.path.exists("/opt/script/script_version.txt"):
        with open('/opt/script/script_version.txt', 'rb') as f:
            script_version = f.read().strip()
    return script_version


def get_cookie():
    global language
    if 'HTTP_COOKIE' in os.environ:
        cookie_string = os.environ.get('HTTP_COOKIE')
        c = Cookie.SimpleCookie()
        c.load(cookie_string)
        language = c['AnyLinkLan'].value

def give_agentd_config():
    if os.path.exists(global_var.agentd_moduleconfig_path):
        shutil.copy(global_var.agentd_moduleconfig_path, global_var.agentd_moduleconfig_path + '.bak')

    agent_mqtt_config = ''
    try:
        agent_config_tree = ET.parse(global_var.moduleconfig_path)
    except Exception as e:
        print 'agent_moduleconfig.xml is error'
        print e
    else:
        agent_mqtt_node = agent_config_tree.find('./task/TaskDriver/driver[@n="T.IDrv.Task:libkmqtt"]')
        agent_mqtt_config = agent_mqtt_node.get('config')

    if agent_mqtt_config:
        try:
            agentd_config_tree = ET.parse(global_var.agentd_moduleconfig_path)
        except Exception as e:
            print 'agentd_moduleconfig.xml is error'
            print e
        else:
            agentd_mqtt_node = agentd_config_tree.find('./task/TaskDriver/driver[@n="T.IDrv.Task:libkmqtt"]')
            agentd_mqtt_node.set('config', agent_mqtt_config)
            agentd_config_tree.write(global_var.agentd_moduleconfig_path, encoding='utf-8')


def give_agent_config():
    global language
    convert_status = 0
    if os.path.exists(global_var.moduleconfig_path):
        shutil.copy(global_var.moduleconfig_path,
                    global_var.moduleconfig_path + '.bak')

    try:
        config_tree = ET.parse(global_var.itemconfig_path)
    except Exception as e:
        print '文件损坏 '
        convert_status = 1
    else:
        agent_node = config_tree.getroot()
        if not agent_node.get('sdmwebs'):
            get_web_version()
            agent_node.set('sdmwebs', global_var.SoftVersion)

        if not agent_node.get('script'):
            script_version = get_script_version()
            agent_node.set('script', script_version)

        add_modbustcp_config(config_tree)
        updateVersion.write(config_tree, global_var.itemconfig_path)
        # config_tree.write(global_var.itemconfig_path, encoding='utf-8')
        shutil.copy(global_var.itemconfig_path, global_var.moduleconfig_path)
    if language == "English":
        if convert_status == 0:
            print "Push success!"
        else:
            print "Push failed!"
    else:
        if convert_status == 0:
            print "下发成功！"
        else:
            print "下发失败！"


def add_modbustcp_config(config_tree):
    """判断有没有modbus发布驱动，来添加发布key"""
    task_list = config_tree.findall('task/TaskDriver')
    item_node_list = config_tree.findall(
        'model/device/driver/commDataItems/dataItem')
    for task in task_list:
        if task.find('driver').get('n') == 'T.IDrv.Task:libtmodbus':
            for dataitem_node in item_node_list:
                if not dataitem_node.get('addr'):
                    '''作添加操作'''
                    dataitem_node.set('vtype', "")
                    dataitem_node.set('addr', "-1")
                    # item_node_list.append(dataitem_node)


if __name__ == '__main__':
    get_cookie()
    give_agent_config()
    give_agentd_config()
