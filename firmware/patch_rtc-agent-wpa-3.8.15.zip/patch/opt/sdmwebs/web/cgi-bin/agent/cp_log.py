#!/usr/bin/python
# -*- coding: UTF-8 -*-

import os
from config import global_var
import xml.etree.ElementTree as ET
import sys
import Cookie
reload(sys)
sys.setdefaultencoding('utf-8')

print "Content-Type: text/html charset=utf-8 \n\n"
Aelog_path = '/opt/agent/AeLog*'
Nlog_path = '/opt/sdmwebs/web/log/'

def give_agent_log():
    '''获取cookie'''
    if 'HTTP_COOKIE' in os.environ:
        cookie_string=os.environ.get('HTTP_COOKIE')
        c=Cookie.SimpleCookie()
        c.load(cookie_string)
        data=c['AnyLinkLan'].value

    convert_status = 0
    convert_cmd = 'cp -r ' + Aelog_path + ' ' + Nlog_path
    convert_status = os.system(convert_cmd)
    if data == "English":
        if convert_status == 0:
            print "Copy success!"
        else:
            print "Copy failed!"
    else:
        if convert_status == 0:
            print "复制成功！"
        else:
            print "复制失败！"
        
if __name__ == '__main__':
    give_agent_log()