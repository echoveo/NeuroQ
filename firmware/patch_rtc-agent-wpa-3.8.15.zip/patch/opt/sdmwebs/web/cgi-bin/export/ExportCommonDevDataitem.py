#!/usr/bin/python
# -*- coding=utf-8 -*

import xml.etree.ElementTree as ET
from config import global_var
from CGI import GetCgi
from Log import Loginfo
import csv
import sys, os
import re
reload(sys)
sys.setdefaultencoding('utf8')

print "Content-Disposition: attachment; filename=CommDevDataitem.csv \n"

device_id = ''
def get_cgi_data():
    '''获取界面数据'''
    global device_id
    ct = GetCgi.GetCgi()
    device_id = ct.get_data('deviceID')
    #print device_id

def gerenate_csv_file():
    dataitem_node_list = []
    thisDevice = ''
    modelType = ''
    driverId = ''
    list = [['设备驱动','设备ID','设备名称','数据项ID','名称','别名','配置信息','类型','采集频率','读写','上报','驱动ID','值运算参数']]
    device_exist = False
    agent_tree = ET.parse(global_var.itemconfig_path)

    device_list = agent_tree.iter('device')
    for device in device_list:
        # print device.get('id', default=None)
        if device.get('id', default=None) == device_id:
            device_exist = True
            dataitem_node_list = device.findall('driver/commDataItems/dataItem')
            thisDevice = device

    model_list = agent_tree.iter('model')
    for model in model_list:
        # print model.get('id', default=None)
        device_list = model.iter('device')
        for device in device_list:
            if device.get('id', default=None) == device_id:
                modelType = model.get('devicedriver')
                driverNode = device.find('driver')
                driverId = driverNode.get('id')
                driverName = driverNode.get('n')
                driverConfig = driverNode.get('config')

    if device_exist is False:
        log.write_error('设备%s不存在' %(device_id))
        os._exit(1)

    #add by fyj, 新增datahandler驱动
    dhDict = {}
    dhNode =  agent_tree.find('task/TaskDriver/driver/dataHandler/config')
    if dhNode != None:
        dhnode_list = dhNode.findall('item')
        if dhnode_list != []:
            for dhitem_node in dhnode_list:
                itemId = dhitem_node.get('id')
                itemOp = dhitem_node.get('op')
                itemCoe = dhitem_node.get('coe')
                if itemOp == "+":
                    itemOp = '加'
                elif itemOp == "-":
                    itemOp = '减'
                elif itemOp == "*":
                    itemOp = '乘'
                elif itemOp == "/":
                    itemOp = '除'
                elif itemOp == "b":
                    itemOp = 'b'
                elif itemOp == "#":
                    itemOp = '线性'
                if itemOp == '线性':
                    coe_list = re.findall(r'[(](.*?)[)]', itemCoe)
                    dhDict[itemId] = itemOp + ';' + coe_list[0] + "|" + coe_list[1]
                else:
                    dhDict[itemId] = itemOp + ';' + itemCoe    #end add
       
    for dataitem_node in dataitem_node_list:
        array = []
        list.append(array)
        config_info = dataitem_node.get('config')
        dataItemRW = dataitem_node.get('rw')
        

        type_iec = dataitem_node.get('type')
        if type_iec == 'a':
            type_a = '数值'
        elif type_iec == 'b':
            type_a = '开关量'
        else :
            type_a = '字符串'
        if dataItemRW == '1':
            dataItemRW1 = '可写'
        else:
            dataItemRW1 = '只读'
        
        report = dataitem_node.get('report')
        if report == '0':
            report_a = '不上传'
        elif report == '2':
            report_a = '变化上传'    
        else:
            report_a = '全部上传'
        
        array.append(modelType)
        array.append(thisDevice.get('id'))
        array.append(thisDevice.get('n'))
        array.append(dataitem_node.get('id'))
        array.append(dataitem_node.get('n'))
        array.append(dataitem_node.get('alias'))
        array.append(config_info)
        array.append(type_a)
        array.append(dataitem_node.get('freq'))
        array.append(dataItemRW1)
        array.append(report_a)
        array.append(driverId)
        #add by fyj, 新增datahandler驱动
        if dhDict != {}:
            itemId = dataitem_node.get('id')
            opt = ''
            try:
                opt = dhDict[itemId]
            except Exception, e:
                pass
            array.append(opt)
        else:
            array.append('null')
        #add end
    #print list
    
    csvfile = file(global_var.download_path, 'wb')
    writer = csv.writer(csvfile,dialect='excel')

    for i in range(len(list)):
        writer.writerow(list[i])
        
    csvfile.close()
    
def download():

    download_file = open(global_var.download_path,'rb')
    reader = csv.reader(download_file)
   
    for c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c13 in reader:
        c1_s = c1.decode('utf-8').encode('gb2312')
        c2_s = c2.decode('utf-8').encode('gb2312')
        c3_s = c3.decode('utf-8').encode('gb2312')
        c4_s = c4.decode('utf-8').encode('gb2312')
        c5_s = c5.decode('utf-8').encode('gb2312')
        c6_s = c6.decode('utf-8').encode('gb2312')
        c7_s = c7.decode('utf-8').encode('gb2312')
        c8_s = c8.decode('utf-8').encode('gb2312')
        c9_s = c9.decode('utf-8').encode('gb2312')
        c10_s = c10.decode('utf-8').encode('gb2312')
        c11_s = c11.decode('utf-8').encode('gb2312')
        c12_s = c12.decode('utf-8').encode('gb2312')
        c13_s = c13.decode('utf-8').encode('gb2312')
        print c1_s + ',' + c2_s + ',' + c3_s + ',' + c4_s + ',' + c5_s + ',' + c6_s + ',' + c7_s + ',' + c8_s + ',' + c9_s + ',' + c10_s + ',' + c11_s + ',' + c12_s +',' +c13_s
    download_file.close()

if __name__ == '__main__':
    log = Loginfo.Loginfo()
    get_cgi_data()
    
    gerenate_csv_file()
 
    download()
