#!/usr/bin/python
# -*- coding=utf-8 -*
# author : Randy.Jang
# edit xhzhang at 2016-07-18

import xml.etree.ElementTree as ET
import csv
import os
from config import global_var
from CGI import GetCgi
from Log import Loginfo
import sys
reload(sys)
sys.setdefaultencoding('utf8')

print "Content-Disposition: attachment; filename=download.csv \n"

device_id = ''


def get_cgi_data():
    global device_id
    ct = GetCgi.GetCgi()
    device_id = ct.get_data('deviceID')
    #log.write_info('导出设备的ID是[%s]' %(device_id))


def gerenate_csv_file():

    list = [['ID', '名称', '数据项', '条件', '阈值', '告警级别', '描述', '相关联系']]
    agent_tree = ET.parse(global_var.itemconfig_path)

    device_list = agent_tree.iter('device')
    for device in device_list:

        if device.get('id', default=None) == device_id:
            rule_list = device.findall('Rules/rule')
            for rule in rule_list:
                rule_array = []
                rule_item_opr_a = rule_item_threshold_a = rule_item_name_a = ''
                list.append(rule_array)
                rule_array.append(rule.get('id', default=None))
                rule_array.append(rule.get('name', default=None))
                trigger_root = rule.findall('Triggers/trigger')
                for getrelation in trigger_root:
                    trigger_relation = getrelation.get(
                        'relation', default=None)
                trigger_list = rule.findall('Triggers/trigger/di')
                for trigger in trigger_list:
                    rule_item_opr = trigger.get('opr', default=None)
                    rule_item_threshold = trigger.get('opd', default=None)
                    rule_item_name = trigger.get('name', default=None)
                    if rule_item_opr_a == '':
                        if rule_item_opr == '1':
                            rule_item_opr_a = '包含'
                        elif rule_item_opr == '2' or rule_item_opr == '4':
                            rule_item_opr_a = '等于'
                        elif rule_item_opr == '3' or rule_item_opr == '5':
                            rule_item_opr_a = '不等于'
                        elif rule_item_opr == '6':
                            rule_item_opr_a = '大于等于'
                        elif rule_item_opr == '7' or rule_item_opr == '10':
                            rule_item_opr_a = '大于'
                        elif rule_item_opr == '8':
                            rule_item_opr_a = '小于等于'
                        elif rule_item_opr == '9' or rule_item_opr == '11':
                            rule_item_opr_a = '小于'
                        else:
                            rule_item_opr_a = rule_item_opr
                    else:
                        if rule_item_opr == '1':
                            rule_item_opr_a = rule_item_opr_a + ';' + '包含'
                        elif rule_item_opr == '2' or rule_item_opr == '4':
                            rule_item_opr_a = rule_item_opr_a + ';' + '等于'
                        elif rule_item_opr == '3' or rule_item_opr == '5':
                            rule_item_opr_a = rule_item_opr_a + ';' + '不等于'
                        elif rule_item_opr == '6':
                            rule_item_opr_a = rule_item_opr_a + ';' + '大于等于'
                        elif rule_item_opr == '7' or rule_item_opr == '10':
                            rule_item_opr_a = rule_item_opr_a + ';' + '大于'
                        elif rule_item_opr == '8':
                            rule_item_opr_a = rule_item_opr_a + ';' + '小于等于'
                        elif rule_item_opr == '9' or rule_item_opr == '11':
                            rule_item_opr_a = rule_item_opr_a + ';' + '小于'
                        else:
                            rule_item_opr_a = rule_item_opr_a + ';' + rule_item_opr

                    if rule_item_threshold_a == '':
                        rule_item_threshold_a = rule_item_threshold
                    else:
                        rule_item_threshold_a = rule_item_threshold_a + ';' + rule_item_threshold

                    if rule_item_name_a == '':
                        rule_item_name_a = rule_item_name
                    else:
                        rule_item_name_a = rule_item_name_a + ';' + rule_item_name

                rule_array.append(rule_item_name_a)
                rule_array.append(rule_item_opr_a)
                rule_array.append(rule_item_threshold_a)
                action = rule.find('Actions/action')
                rule_severity = action.get('severity', default=None)
                if rule_severity == '8':
                    rule_severity_a = '一级'
                elif rule_severity == '9':
                    rule_severity_a = '二级'
                elif rule_severity == '10':
                    rule_severity_a = '三级'
                elif rule_severity == '11':
                    rule_severity_a = '四级'
                elif rule_severity == '12':
                    rule_severity_a = '五级'
                else:
                    rule_severity_a = rule_severity

                rule_desc = action.get('descr', default=None)

                rule_array.append(rule_severity_a)
                rule_array.append(rule_desc.split(',')[0])
                rule_array.append(trigger_relation)

    csvfile = file(global_var.download_path, 'wb')
    writer = csv.writer(csvfile, dialect='excel')
    for i in range(len(list)):
        writer.writerow(list[i])
        # log.write_info(list)
    csvfile.close()


def download():
    download_file = open(global_var.download_path, 'rb')
    reader = csv.reader(download_file)
    for row in reader:
        line = ",".join(
            [unit.decode('utf-8').encode('gb2312') for unit in row])
        print line
    download_file.close()


if __name__ == '__main__':
    log = Loginfo.Loginfo()
    get_cgi_data()
    gerenate_csv_file()
    download()
