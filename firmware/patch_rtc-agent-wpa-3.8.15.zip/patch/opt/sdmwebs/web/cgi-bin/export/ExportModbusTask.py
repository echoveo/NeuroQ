#!/usr/bin/python
# -*- coding=utf-8 -*

import xml.etree.ElementTree as ET
from config import global_var
from CGI import GetCgi
from Log import Loginfo
import csv, os
import sys
import re
reload(sys)
sys.setdefaultencoding('utf8')

print "Content-Disposition: attachment; filename=ModbusDataitem.csv \n"

device_id = ''


def get_cgi_data():
    '''获取界面数据'''
    global device_id
    ct = GetCgi.GetCgi()
    device_id = ct.get_data('deviceID')
    #print device_id


def gerenate_csv_file():
    dataitem_node_list = []
    thisDevice = ''
    modelType = ''
    driverId = ''
    list = [[
        '设备驱动', '数据项ID', '名称', '别名', '地址', '类型', '功能码', '采集频率', '读写', '上报',
        '对齐方式', '值运算参数'
    ]]
    agent_tree = ET.parse(global_var.itemconfig_path)

    model_list = agent_tree.iter('model')
    for model in model_list:
        device_list = model.iter('device')
        for device in device_list:
            if device.get('id', default=None) == device_id:
                modelType = model.get('devicedriver')
                dataitem_node_list = device.findall('driver/commDataItems/dataItem')

    dhDict = {}
    dhNode = agent_tree.find('task/TaskDriver/driver/dataHandler/config')
    if dhNode != None:
        dhnode_list = dhNode.findall('item')
        if dhnode_list != []:
            for dhitem_node in dhnode_list:
                itemId = dhitem_node.get('id')
                itemOp = dhitem_node.get('op')
                itemCoe = dhitem_node.get('coe')
                if itemOp == "+":
                    itemOp = '加'
                elif itemOp == "-":
                    itemOp = '减'
                elif itemOp == "*":
                    itemOp = '乘'
                elif itemOp == "/":
                    itemOp = '除'
                elif itemOp == "b":
                    itemOp = 'b'
                elif itemOp == "#":
                    itemOp = '线性'
                if itemOp == '线性':
                    coe_list = re.findall(r'[(](.*?)[)]', itemCoe)
                    dhDict[itemId] = itemOp + ';' + coe_list[0] + "|" + coe_list[1]
                else:
                    dhDict[itemId] = itemOp + ';' + itemCoe
    for dataitem_node in dataitem_node_list:
        array = []
        list.append(array)
        itemId = dataitem_node.get('id')
        config_info = dataitem_node.get('config').split(';')
        function = config_info[0]
        address = 'addr-' + config_info[1]
        type_a = config_info[2]
        align = config_info[3]

        rwmode = dataitem_node.get('rw')
        if rwmode == '1':
            rwmode_a = '可写'
        else:
            rwmode_a = '只读'

        report = dataitem_node.get('report')
        if report == '0':
            report_a = '不上传'
        elif report == '2':
            report_a = '变化上传'    
        else:
            report_a = '全部上传'

        array.append(modelType)
        array.append(itemId)
        array.append(dataitem_node.get('n'))
        array.append(dataitem_node.get('alias'))
        array.append(address)
        array.append(type_a)
        array.append(function)
        array.append(dataitem_node.get('freq'))
        array.append(rwmode_a)
        array.append(report_a)
        array.append(align)
        if not dhDict or itemId not in dhDict:
            array.append('null')
        else:
            opt = dhDict[itemId]
            array.append(opt)
    #print list
    csvfile = file(global_var.download_path, 'wb')
    writer = csv.writer(csvfile, dialect='excel')
    for i in range(len(list)):
        writer.writerow(list[i])
    csvfile.close()


def download():
    download_file = open(global_var.download_path, 'rb')
    reader = csv.reader(download_file)
    for row in reader:
        line = ",".join(
            [unit.decode('utf-8').encode('gb2312') for unit in row])
        print line
    download_file.close()


if __name__ == '__main__':
    log = Loginfo.Loginfo()
    get_cgi_data()
    gerenate_csv_file()
    download()
