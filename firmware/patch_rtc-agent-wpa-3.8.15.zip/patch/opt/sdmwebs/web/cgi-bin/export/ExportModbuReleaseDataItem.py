#!/usr/bin/python
# -*- coding=utf-8 -*

import xml.etree.ElementTree as ET
from config import global_var
from CGI import GetCgi
from Log import Loginfo
import csv
import sys,os
reload(sys)
sys.setdefaultencoding('utf8')

print "Content-Disposition: attachment; filename=ModbusReleaseDataItem.csv \n"

device_id = ''

def get_cgi_data():
    '''获取界面数据'''
    global device_id
    ct = GetCgi.GetCgi()
    #device_id = ct.get_data('deviceID')
    #device_id = '1'

def gerenate_csv_file():
    dataitem_node_list = []
    thisDevice = ''
    modelType = ''
    driverId = ''
    driverName = ''
    driverConfig = ''
    list = [['数据项ID','名称','别名','地址','Modbus数据类型','Modbus数据地址']]
    device_exist = False
    agent_tree = ET.parse(global_var.itemconfig_path)

    device_list = agent_tree.iter('device')
    for device in device_list:
        if device.get('id') == '1023':
            continue
        #print device.get('id', default=None)
        device_exist = True
        dataitem_node_list = device.findall('driver/commDataItems/dataItem')
        
        for dataitem_node in dataitem_node_list:
            array = []
            array.append(dataitem_node.get('id'))
            array.append(dataitem_node.get('n'))
            array.append(dataitem_node.get('alias'))
            array.append(dataitem_node.get('config'))
            if(dataitem_node.get('vtype') != None):
                array.append(dataitem_node.get('vtype'))
            else:
                array.append("")
            if(dataitem_node.get('addr') != None):
                array.append(dataitem_node.get('addr'))
            else:
                array.append("")
            list.append(array)
            
    csvfile = file(global_var.download_path, 'wb')
    writer = csv.writer(csvfile,dialect='excel')
    for i in range(len(list)):
        writer.writerow(list[i])
    csvfile.close()

def download():
    download_file = open(global_var.download_path, 'rb')
    reader = csv.reader(download_file)
    for row in reader:
        line = ",".join(
            [unit.decode('utf-8').encode('gb2312') for unit in row])
        print line
    download_file.close()

if __name__ == '__main__':
    log = Loginfo.Loginfo()
    #get_cgi_data()
    gerenate_csv_file()
    download()