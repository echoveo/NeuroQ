#!/usr/bin/python
# -*- coding=utf-8 -*
__author__ = 'xhzhang'

import xml.etree.ElementTree as ET
from config import global_var
from CGI import GetCgi
from Log import Loginfo
import csv
import sys,os
reload(sys)
sys.setdefaultencoding('utf8')

print "Content-Disposition: attachment; filename=HKGDataitem.csv \n"

device_id = ''

def get_cgi_data():
    '''获取界面数据'''
    global device_id
    ct = GetCgi.GetCgi()
    device_id = ct.get_data('deviceID')

def gerenate_csv_file():
    dataitem_node_list = []
    list = [['数据项ID','名称','别名','ID','类型','读写','频率','上报','值运算参数']]
    device_exist = False
    agent_tree = ET.parse(global_var.itemconfig_path)

    device_list = agent_tree.iter('device')
    for device in device_list:
        #print device.get('id', default=None)
        if device.get('id',default=None) == device_id:
            device_exist = True
            dataitem_node_list = device.findall('driver/commDataItems/dataItem')

    if device_exist is False:
        log.write_error('设备%s不存在' % (device_id))
        os._exit(1)

    #add by fyj, 新增datahandler驱动
    dhDict = {}
    dhNode =  agent_tree.find('task/TaskDriver/driver/dataHandler/config')
    if dhNode != None:
        dhnode_list = dhNode.findall('item')
        if dhnode_list != []:
            for dhitem_node in dhnode_list:
                itemId = dhitem_node.get('id')
                itemOp = dhitem_node.get('op')
                itemCoe = dhitem_node.get('coe')
                if itemOp == "+":
                    itemOp = '加'
                elif itemOp == "-":
                    itemOp = '减'
                elif itemOp == "*":
                    itemOp = '乘'
                elif itemOp == "/":
                    itemOp = '除'
                elif itemOp == "b":
                    itemOp = 'b'
                dhDict[itemId] = itemOp + ';' + itemCoe
    #end add

    for dataitem_node in dataitem_node_list:
        array = []
        list.append(array)
        config_info = dataitem_node.get('config').split(';')
        register = config_info[0]
        register_rwmode = dataitem_node.get('rw')
        if register_rwmode == '1':
            register_rwmode_mode = '可写'
        else:
            register_rwmode_mode = '只读'
        register_type = dataitem_node.get('type')
        if register_type == 'b':
            register_type_mode = '开关量'
        elif register_type == 's':
            register_type_mode = '字符串'
        else:
            register_type_mode = '数值'

        array.append(dataitem_node.get('id'))
        array.append(dataitem_node.get('n'))
        array.append(dataitem_node.get('alias'))
        array.append(register)
        array.append(register_type_mode)
        array.append(register_rwmode_mode)
        array.append(dataitem_node.get('freq'))
        report = dataitem_node.get('report')
        if report == '0':
            report_mode = '不上传'
        elif report == '2':
            report_mode = '变化上传'    
        else:
            report_mode = '全部上传'
        array.append(report_mode)
        #add by fyj, 新增datahandler驱动
        if dhDict != {}:
            itemId = dataitem_node.get('id')
            opt = ''
            try:
                opt = dhDict[itemId]
            except Exception, e:
                pass
            array.append(opt)
        else:
            array.append('null')
        #add end
    #print list
    csvfile = file(global_var.download_path, 'wb')
    writer = csv.writer(csvfile,dialect='excel')
    for i in range(len(list)):
        writer.writerow(list[i])
    csvfile.close()

def download():

    download_file = open(global_var.download_path,'rb')
    reader = csv.reader(download_file)
    for c1,c2,c3,c4,c5,c6,c7,c8,c9 in reader:
        c1_s = c1.decode('utf-8').encode('gb2312')
        c2_s = c2.decode('utf-8').encode('gb2312')
        c3_s = c3.decode('utf-8').encode('gb2312')
        c4_s = c4.decode('utf-8').encode('gb2312')
        c5_s = c5.decode('utf-8').encode('gb2312')
        c6_s = c6.decode('utf-8').encode('gb2312')
        c7_s = c7.decode('utf-8').encode('gb2312')
        c8_s = c8.decode('utf-8').encode('gb2312')
        c9_s = c9.decode('utf-8').encode('gb2312')
        print c1_s + ','+ c2_s + ','+ c3_s + ','+ c4_s+ ','+ c5_s + ',' +c6_s + ','+ c7_s +','+c8_s + ',' + c9_s
    download_file.close()

if __name__ == '__main__':
    log = Loginfo.Loginfo()
    get_cgi_data()
    gerenate_csv_file()
    download()