#!/usr/bin/python
# -*- coding=utf-8 -*
# __author__ = 'xhzhang'
# Edit By Randy.Jang
# 2015/06/01

import xml.etree.ElementTree as ET
from config import global_var
from CGI import GetCgi
from Log import Loginfo
import csv
import sys
import os
import re
reload(sys)
sys.setdefaultencoding('utf8')

print "Content-Disposition: attachment; filename=BACNetDataitem.csv \n"

device_id = ''


def get_cgi_data():
    '''获取界面数据'''
    global device_id
    ct = GetCgi.GetCgi()
    device_id = ct.get_data('deviceID')

    #print device_id
    #log.write_info('device id is ' + device_id)


def gerenate_csv_file():
    dataitem_node_list = []
    thisDevice = ''
    modelType = ''
    driverId = ''
    list = [
        ['设备驱动',  '数据ID', '名称', '别名', '类型', '频率',
            '读写', 'Bac类型', '数据项ID', '上报', '值运算参数']
    ]

    agent_tree = ET.parse(global_var.itemconfig_path)

    model_list = agent_tree.iter('model')
    for model in model_list:
        # print model.get('id', default=None)
        device_list = model.iter('device')
        for device in device_list:
            if device.get('id', default=None) == device_id:
                modelType = model.get('devicedriver')
                dataitem_node_list = device.findall('driver/commDataItems/dataItem')

    # add by fyj, 新增datahandler驱动
    dhDict = {}
    dhNode = agent_tree.find('task/TaskDriver/driver/dataHandler/config')
    if dhNode != None:
        dhnode_list = dhNode.findall('item')
        if dhnode_list != []:
            for dhitem_node in dhnode_list:
                itemId = dhitem_node.get('id')
                itemOp = dhitem_node.get('op')
                itemCoe = dhitem_node.get('coe')
                if itemOp == "+":
                    itemOp = '加'
                elif itemOp == "-":
                    itemOp = '减'
                elif itemOp == "*":
                    itemOp = '乘'
                elif itemOp == "/":
                    itemOp = '除'
                elif itemOp == "b":
                    itemOp = 'b'
                elif itemOp == "#":
                    itemOp = '线性'
                if itemOp == '线性':
                    coe_list = re.findall(r'[(](.*?)[)]', itemCoe)
                    dhDict[itemId] = itemOp + ';' + coe_list[0] + "|" + coe_list[1]
                else:
                    dhDict[itemId] = itemOp + ';' + itemCoe    # end add

    for dataitem_node in dataitem_node_list:
        array = []
        list.append(array)
        config_info = dataitem_node.get('config').split(';')
        # DeviceID = config_info[0]
        vtype = config_info[0]
        DataID = config_info[1]

        array.append(modelType)
        array.append(dataitem_node.get('id'))
        array.append(dataitem_node.get('n'))
        array.append(dataitem_node.get('alias'))
        array.append(dataitem_node.get('type'))
        array.append(dataitem_node.get('freq'))
        rwmode = dataitem_node.get('rw')
        if rwmode == '1':
            rwmode_mode = '可写'
        else:
            rwmode_mode = '只读'
        array.append(rwmode_mode)
        # array.append(DeviceID)
        array.append(vtype)
        array.append(DataID)
        report = dataitem_node.get('report')
        if report == '0':
            report_a = '不上传'
        elif report == '2':
            report_a = '变化上传'    
        else:
            report_a = '全部上传'
        array.append(report_a)
        # add by fyj, 新增datahandler驱动
        if not dhDict or itemId not in dhDict:
            array.append('null')
        else:
            opt = dhDict[itemId]
            array.append(opt)
        # add end
    #print list
    csvfile = file(global_var.download_path, 'wb')
    writer = csv.writer(csvfile, dialect='excel')
    for i in range(len(list)):
        writer.writerow(list[i])
    csvfile.close()


def download():
    download_file = open(global_var.download_path, 'rb')
    reader = csv.reader(download_file)
    for row in reader:
        line = ",".join(
            [unit.decode('utf-8').encode('gb2312') for unit in row])
        print line
    download_file.close()


if __name__ == '__main__':
    log = Loginfo.Loginfo()
    get_cgi_data()
    gerenate_csv_file()
    download()
