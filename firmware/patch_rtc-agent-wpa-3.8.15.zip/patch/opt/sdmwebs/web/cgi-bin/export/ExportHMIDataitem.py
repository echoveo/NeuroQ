#!/usr/bin/python
# -*- coding=utf-8 -*

import xml.etree.ElementTree as ET
from config import global_var
from Log import Loginfo
import csv, os, codecs, cgi
import sys
reload(sys)
sys.setdefaultencoding('utf8')

print "Content-Disposition: attachment; filename=DeviceDataitem.csv \n"
device_id = ''

def get_cgi_data():
    '''获取界面数据'''
    global device_id
    form = cgi.FieldStorage()
    device_id = form.getvalue('deviceID', '0')
    

def getDHinformation(agent_tree):
    '''获取值运算datahandler驱动内信息，存放在dictionary内，需要的参数是ET.parse(global_var.itemconfig_path)对象'''
    dhDict = {}
    dhNode =  agent_tree.find('task/TaskDriver/driver/dataHandler/config')
    if dhNode is None:
        return {}
    dhnode_list = dhNode.findall('item')
    if dhnode_list == []:
        return {}
    OptoZH = {'+':'加','-':'减','*':'乘','/':'除','b':'b'}
    for dhitem_node in dhnode_list:
        itemId = dhitem_node.get('id')
        itemOp = dhitem_node.get('op')
        itemCoe = dhitem_node.get('coe')
        dhDict[itemId] = OptoZH[itemOp] + ';' + itemCoe
    return dhDict    


def gerenate_csv_file():
    dataitem_node_list = []
    thisDevice = ''
    modelType = ''
    driverId = ''
    header = [['设备驱动','设备ID','设备名称','数据项ID','名称','别名','配置信息','类型','采集频率','读写','上报','驱动ID','值运算参数']]
    device_exist = False
    agent_tree = ET.parse(global_var.itemconfig_path)

    device_list = agent_tree.iter('device')
    for device in device_list:
        if device.get('id', default=None) == device_id:
            device_exist = True
            dataitem_node_list = device.findall('driver/commDataItems/dataItem')
            thisDevice = device

    model_list = agent_tree.iter('model')
    for model in model_list:
        device_list = model.iter('device')
        for device in device_list:
            if device.get('id', default=None) == device_id:
                modelType = model.get('devicedriver')
                driverNode = device.find('driver')
                driverId = driverNode.get('id')
                driverName = driverNode.get('n')
                driverConfig = driverNode.get('config')

    if device_exist is False:
        log.write_error('设备%s不存在' %(device_id))
        os._exit(1)


    dhDict = getDHinformation(agent_tree)
 
    for dataitem_node in dataitem_node_list:
        array = []
        header.append(array)
        config_info = dataitem_node.get('config')
        dataItemRW = dataitem_node.get('rw')
        

        type_iec = dataitem_node.get('type')
        if type_iec == 'a':
            type_a = '数值'
        elif type_iec == 'b':
            type_a = '开关量'
        else :
            type_a = '字符串'
        if dataItemRW == '1':
            dataItemRW1 = '可写'
        else:
            dataItemRW1 = '只读'
        
        report = dataitem_node.get('report')
        if report == '0':
            report_a = '不上传'
        elif report == '2':
            report_a = '变化上传'    
        else:
            report_a = '全部上传'
        
        array.append(modelType)
        array.append(thisDevice.get('id'))
        array.append(thisDevice.get('n'))
        array.append(dataitem_node.get('id'))
        array.append(dataitem_node.get('n'))
        array.append(dataitem_node.get('alias'))
        array.append(config_info)
        array.append(type_a)
        array.append(dataitem_node.get('freq'))
        array.append(dataItemRW1)
        array.append(report_a)
        array.append(driverId)
        #add by fyj, 新增datahandler驱动
        if dhDict != {}:
            itemId = dataitem_node.get('id')
            opt = ''
            opt = dhDict.get(itemId,'')
            array.append(opt)
        else:
            array.append('null')
        #add end
    #print header
    csvfile = codecs.open(global_var.download_path, 'wb',"gb2312")
    writer = csv.writer(csvfile)
    for i in range(len(header)):
        writer.writerow(header[i])
    csvfile.close()

def get_csv_rownumber():
    '''获取conf/download.csv的列数,在gerenate_csv_file函数后运行才能保证正确'''
    data_list = []
    fd = open(global_var.download_path, 'rb')
    csvfd = csv.reader(fd)
    counter = 1 
    for row in csvfd: 
        counter += 1 
    fd.close()
    return len(row)


def download(number):
    '''传入的参数为csv文件的列数'''
    download_file = open(global_var.download_path,'rb')
    reader = csv.reader(download_file)
    
    for line in reader:
        lineStr = ''
        for i in range(number):
            if i == number - 1:
                lineStr += line[i] 
            else:
                lineStr += line[i] + ','  
        print lineStr 
    download_file.close()


if __name__ == '__main__':
    log = Loginfo.Loginfo()
    get_cgi_data()
    gerenate_csv_file()
    colNumber = get_csv_rownumber()
    download(colNumber)
