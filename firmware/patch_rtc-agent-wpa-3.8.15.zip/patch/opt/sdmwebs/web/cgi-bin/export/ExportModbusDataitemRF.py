#!/usr/bin/python
# -*- coding=utf-8 -*

import xml.etree.ElementTree as ET
from config import global_var
from CGI import GetCgi
from Log import Loginfo
import csv, os
import sys
reload(sys)
sys.setdefaultencoding('utf8')

print "Content-Disposition: attachment; filename=ModbusDataitem.csv \n"

device_id = ''
def get_cgi_data():
    '''获取界面数据'''
    global device_id
    ct = GetCgi.GetCgi()
    device_id = ct.get_data('deviceID')
    #print device_id

def gerenate_csv_file():
    dataitem_node_list = []
    thisDevice = ''
    modelType = ''
    driverId = ''
    list = [['设备驱动','设备ID','设备名称','数据项ID', '名称', '别名', '从站ID', '地址', '类型', '功能码', '数据项附加', '采集频率', '读写', '是否变化上传', '上报', '对齐方式', '网络号','驱动ID']]
    device_exist = False
    agent_tree = ET.parse(global_var.itemconfig_path)

    device_list = agent_tree.iter('device')
    for device in device_list:
        # print device.get('id', default=None)
        if device.get('id', default=None) == device_id:
            device_exist = True
            dataitem_node_list = device.findall('driver/commDataItems/dataItem')
            thisDevice = device

    model_list = agent_tree.iter('model')
    for model in model_list:
        # print model.get('id', default=None)
        device_list = model.iter('device')
        for device in device_list:
            if device.get('id', default=None) == device_id:
                modelType = model.get('devicedriver')
                driverNode = device.find('driver')
                driverId = driverNode.get('id')

    if device_exist is False:
        log.write_error('设备%s不存在' %(device_id))
        os._exit(1)

    for dataitem_node in dataitem_node_list:
        array = []
        list.append(array)
        config_info = dataitem_node.get('config').split(';')
        slaveID = config_info[0]
        function = config_info[1]
        address = config_info[2]
        calculate = config_info[3]
        type_a = config_info[4]
        change_upload = config_info[5]
        align = config_info[6]
        if align == '0':
            align_a = '大端'
        else:
            align_a = '小端'
        net_port = config_info[7]
        rwmode = config_info[8]
        if rwmode == '1':
            rwmode_a = '可写'
        else:
            rwmode_a = '只读'

        report = dataitem_node.get('report')
        if report == '0':
            report_a = '不上传'
        elif report == '2':
            report_a = '变化上传'    
        else:
            report_a = '全部上传'
        array.append(modelType)
        array.append(thisDevice.get('id'))
        array.append(thisDevice.get('n'))
        array.append(dataitem_node.get('id'))
        array.append(dataitem_node.get('n'))
        array.append(dataitem_node.get('alias'))
        array.append(slaveID)
        array.append(address)
        array.append(type_a)
        array.append(function)
        array.append(calculate)
        array.append(dataitem_node.get('freq'))
        array.append(rwmode_a)
        array.append(change_upload)
        array.append(report_a)
        array.append(align_a)
        array.append(net_port)
        array.append(driverId)
    # print list
    csvfile = file(global_var.download_path, 'wb')
    writer = csv.writer(csvfile, dialect='excel')
    for i in range(len(list)):
        writer.writerow(list[i])
    csvfile.close()


def download():
    download_file = open(global_var.download_path, 'rb')
    reader = csv.reader(download_file)
    for c1, c2, c3, c4, c5, c6, c7, c8, c9, c10, c11, c12, c13, c14, c15, c16, c17,c18 in reader:
        c1_s = c1.decode('utf-8').encode('gb2312')
        c2_s = c2.decode('utf-8').encode('gb2312')
        c3_s = c3.decode('utf-8').encode('gb2312')
        c4_s = c4.decode('utf-8').encode('gb2312')
        c5_s = c5.decode('utf-8').encode('gb2312')
        c6_s = c6.decode('utf-8').encode('gb2312')
        c7_s = c7.decode('utf-8').encode('gb2312')
        c8_s = c8.decode('utf-8').encode('gb2312')
        c9_s = c9.decode('utf-8').encode('gb2312')
        c10_s = c10.decode('utf-8').encode('gb2312')
        c11_s = c11.decode('utf-8').encode('gb2312')
        c12_s = c12.decode('utf-8').encode('gb2312')
        c13_s = c13.decode('utf-8').encode('gb2312')
        c14_s = c14.decode('utf-8').encode('gb2312')
        c15_s = c15.decode('utf-8').encode('gb2312')
        c16_s = c16.decode('utf-8').encode('gb2312')
        c17_s = c17.decode('utf-8').encode('gb2312')
        c18_s = c18.decode('utf-8').encode('gb2312')
        print c1_s + ',' + c2_s + ',' + c3_s + ',' + c4_s + ',' + c5_s + ',' + c6_s + ',' + c7_s + ',' + c8_s + ',' + c9_s + ',' + c10_s + ',' + c11_s + ',' + c12_s + ',' + c13_s + ',' + c14_s + ',' + c15_s + ',' + c16_s + ',' + c17_s + ',' + c18_s
    download_file.close()


if __name__ == '__main__':
    log = Loginfo.Loginfo()
    get_cgi_data()
    gerenate_csv_file()
    download()
