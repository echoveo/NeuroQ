#!/usr/bin/python
# -*- coding=utf-8 -*

import xml.etree.ElementTree as ET
from config import global_var
from CGI import GetCgi
from Log import Loginfo
import csv
import sys,os
reload(sys)
sys.setdefaultencoding('utf8')

print "Content-Disposition: attachment; filename=PLCDataitem.csv \n"

device_id = ''

def get_cgi_data():
    '''获取界面数据'''
    global device_id
    ct = GetCgi.GetCgi()
    device_id = ct.get_data('deviceID')
    #device_id = '1'

def gerenate_csv_file():
    dataitem_node_list = []
    thisDevice = ''
    modelType = ''
    driverId = ''
    driverName = ''
    driverConfig = ''
    list = [['设备驱动','设备ID','设备名称','数据项ID','名称','别名','通道','类型','读写','频率','上报','驱动ID','序列号']]
    device_exist = False
    agent_tree = ET.parse(global_var.itemconfig_path)

    device_list = agent_tree.iter('device')
    for device in device_list:
        #print device.get('id', default=None)
        if device.get('id',default=None) == device_id:
            device_exist = True
            dataitem_node_list = device.findall('driver/commDataItems/dataItem')
            #print dataitem_node_list
            thisDevice = device

    model_list = agent_tree.iter('model')
    for model in model_list:
        # print model.get('id', default=None)
        device_list = model.iter('device')
        for device in device_list:
            if device.get('id', default=None) == device_id:
                modelType = model.get('devicedriver')
                driverNode = device.find('driver')
                driverId = driverNode.get('id')
                driverConfig = driverNode.get('config')
                driverName = driverNode.get('n')


    if device_exist is False:
        log.write_error('设备%s不存在' % (device_id))
        os._exit(1)

    for dataitem_node in dataitem_node_list:
        array = []
        list.append(array)
        config_info = dataitem_node.get('config')
        register_type = 'a'
        register_channel = config_info
        register_rwmode = dataitem_node.get('rw')
        if register_rwmode == '1':
            register_rwmode_mode = '可写'
        else:
            register_rwmode_mode = '只读'

        array.append(modelType)
        array.append(thisDevice.get('id'))
        array.append(thisDevice.get('n'))
        array.append(dataitem_node.get('id'))
        array.append(dataitem_node.get('n'))
        array.append(dataitem_node.get('alias'))
        array.append(register_channel)
        array.append(register_type)
        array.append(register_rwmode_mode)
        array.append(dataitem_node.get('freq'))
        report = dataitem_node.get('report')
        if report == '0':
            report_mode = '不上传'
        elif report == '2':
            report_mode = '变化上传'    
        else:
            report_mode = '全部上传'
        array.append(report_mode)
        array.append(driverId)
        array.append(driverConfig)
        
    #print list
    csvfile = file(global_var.download_path, 'wb')
    writer = csv.writer(csvfile,dialect='excel')
    for i in range(len(list)):
        writer.writerow(list[i])
    csvfile.close()

def download():

    download_file = open(global_var.download_path,'rb')
    reader = csv.reader(download_file)
    for c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c13 in reader:
        c1_s = c1.decode('utf-8').encode('gb2312')
        c2_s = c2.decode('utf-8').encode('gb2312')
        c3_s = c3.decode('utf-8').encode('gb2312')
        c4_s = c4.decode('utf-8').encode('gb2312')
        c5_s = c5.decode('utf-8').encode('gb2312')
        c6_s = c6.decode('utf-8').encode('gb2312')
        c7_s = c7.decode('utf-8').encode('gb2312')
        c8_s = c8.decode('utf-8').encode('gb2312')
        c9_s = c9.decode('utf-8').encode('gb2312')
        c10_s = c10.decode('utf-8').encode('gb2312')
        c11_s = c11.decode('utf-8').encode('gb2312')
        c12_s = c12.decode('utf-8').encode('gb2312')
        c13_s = c13.decode('utf-8').encode('gb2312')
        print c1_s + ','+ c2_s + ','+ c3_s + ','+ c4_s+ ','+ c5_s + ',' +c6_s + ','+ c7_s +','+c8_s +','+c9_s + ','+ c10_s +','+c11_s +','+c12_s +','+c13_s
    download_file.close()

if __name__ == '__main__':
    log = Loginfo.Loginfo()
    get_cgi_data()
    gerenate_csv_file()
    download()