#!/usr/bin/python
# -*- coding: UTF-8  -*-
import json
import os

print "Content-Type: text/html charset=utf-8 \n"

strength_file_path = "/tmp/netintensity"
mode_file_path = "/tmp/netmode"


# 从/tmp/netintensity 中 获取信号强度
def read_4Gstrength():
    if not os.path.exists(strength_file_path):
        return 0
    else:
        with open(strength_file_path, "r") as f:
            strength = f.read().strip()
            if not strength:
                strength = "0"
    return int(strength)


# 从/tmp/netmode 中 获取上网模式和运营商名称
def read_netmode():
    if not os.path.exists(mode_file_path):
        return '0', 'Unknown'
    else:
        with open(mode_file_path, "r") as f:
            lines = f.readlines()
            mode = lines[0].strip()
            if len(lines) > 1:
                operator = lines[1].strip()
            else:
                operator = 'Unknown'
        return mode, operator


if __name__ == "__main__":
    data = {'mode': '', 'strength': '', 'operator': ''}

    data['strength'] = read_4Gstrength()
    data['mode'], data['operator'] = read_netmode()
    net_info = json.dumps(data)
    print net_info
