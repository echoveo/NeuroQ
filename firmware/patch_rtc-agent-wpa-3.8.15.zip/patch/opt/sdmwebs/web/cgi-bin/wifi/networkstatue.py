#!/usr/bin/python
#coding=utf-8

import  os
from config import global_var
import sys
reload(sys)
sys.setdefaultencoding('utf-8')

print "Content-Type: text/html charset=utf-8 \n"

import socket
def start_tcp_client(ip, port):
    #server port and ip
    server_ip = ip
    server_port = port
    tcp_client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        tcp_client.connect((server_ip, server_port))
        tcp_client.sendall(b'1')
    except socket.error:
        pass
    finally:
        tcp_client.close()

# 从/tmp/netstat 中 获取脚本写入的连通性状态 1为连通
def read_netstat():
    netstat = '0'
    if os.path.exists("/tmp/netstat"):
        with open("/tmp/netstat","r") as f:
            netstat = f.read().strip() 
    return netstat        

if __name__ == '__main__':
    start_tcp_client('127.0.0.1', 9999)
    print read_netstat()