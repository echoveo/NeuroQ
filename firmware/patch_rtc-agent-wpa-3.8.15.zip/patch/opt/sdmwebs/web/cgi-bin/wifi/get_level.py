#!/usr/bin/python
# -*- coding: utf-8 -*-
import serial
import json
import os
import xml.etree.ElementTree as ET
from config import global_var
from Log import Loginfo
import commands
print "Content-Type: text/html charset=utf-8 \n"

def run_cmd(cmd):   
    (status, output) = commands.getstatusoutput(cmd)
    if output != "":
        return output.strip()
    else:
        return ""

def get_net_level():
    res_data = {"mode": 'ethernet', "level": 0,"wifi_status":"stop"}
    anylink_tree = ET.parse(global_var.AnyLinkconfig_path)
    model = anylink_tree.find("BasicInfo/HardwareModel").text
    sim_status = anylink_tree.find("NetworkInfo/Mode").text
    wifi_status = anylink_tree.find("Wifi/W_Modestatus").text

    

    if '400' in model and '4G' in sim_status:
        level_4g = get_4g_level()
        res_data["mode"] = '4G'
        res_data["level"] = level_4g
    elif '200' in model and 'start' in wifi_status:
        level_wifi = get_wifi_level()
        res_data["mode"] = 'wifi'
        res_data["level"] = level_wifi

    #modify by kali query wifi mode in ifconfig
    wifi_status = run_cmd("ifconfig wlan0 | grep 'RX bytes'")
    if 'Device not found' in wifi_status:
        res_data["wifi_status"] = 'stop'
    else:
        res_data["wifi_status"] = 'start'
    return json.dumps(res_data)


# document.getElementById('Cellular-Connection-path-1').setAttribute("fill","rgba(255,255,255,0.3)")

def get_4g_level():
    strength_file_path = "/tmp/netintensity"
    if not os.path.exists(strength_file_path):
        return 0
    else:
        with open(strength_file_path, "r") as f:
            strength = f.read().strip()
            if not strength:
                strength = "0"
    return int(strength)


def get_wifi_level():
    level = ''
    script_tree = ET.parse("/opt/script/ScriptConfig.xml")
    nic_name = script_tree.find('WiFi/WifiIf').text + ":"
    with open('/proc/net/wireless', 'r') as fd:
        for line in fd.readlines():
            if nic_name in line:
                try:
                    level = line.split()[3].strip(".")
                except Exception as e:
                    log.write_error(repr(e))
                    level = '0'
    return int(level)


if __name__ == "__main__":
    print get_net_level()
