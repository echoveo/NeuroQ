#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xhzhang'
from Log import Loginfo
import time
import rexml.reusexml as rx
from config import global_var
import json,commands,sys
import os, Cookie
import cgi
import psutil
import xml.etree.ElementTree as ET
import sys
reload(sys)
sys.setdefaultencoding("utf-8")
print "Content-Type: text/html charset=utf-8 \n"

#wifi模块路径
scriptConfig_path = "/opt/script/ScriptConfig.xml"
#Wifi连接脚本名称
WifiScript = 'wpa_module.py'
#wifi模块名称
WifiModule = 'FC20'
#模块对应文件目录
WifiModuleDir = '/opt/script/WiFi/FC20'
#Wifi连接配置文件
WifiConf = '/opt/script/WiFi/wpa_supplicant.conf'   #配置文件位置固定在这个目录下
#无线网卡名
WifiIf = 'wlan0'

wifi_cmd = ''
wifi_ssid = ''
wifi_password = ''

AnyLinkconfig_path_tmp = global_var.AnyLinkconfig_path+".tmp"   #anylink 配置文件，用于wifi refresh使用

def get_cgi_data():
    global wifi_cmd, wifi_ssid, wifi_password
    fs = cgi.FieldStorage()
    wifi_cmd = fs.getvalue('wifi_cmd','')
    wifi_ssid = fs.getvalue('wifi_ssid','')
    wifi_password = fs.getvalue('wifi_pwd','')


def killProcessIfExist(processName):
    process_list = psutil.pids()
    try:
        for pid in process_list:
            process = psutil.Process(pid)
            if processName in process.name():
                cmd = 'kill -9 %d' % pid
                os.system(cmd)
                #break
    except Exception, e:
        pass

# 这是旧的模块上使用的启动wifi脚本
def startWpaIfNotExist():
    process_list = psutil.pids()
    isExist = False
    try:
        for pid in process_list:
            process = psutil.Process(pid)
            if WifiScript in process.name():
                isExist = True
                break
        if isExist == False:
            wait_seconds=0
            (status, output) = commands.getstatusoutput('/sbin/ifconfig -a | grep "wlan0"')
            if output == '':
                #如果wifi 驱动未加载，需要sleep一段时间，以等待加载成功
                wait_seconds = 5
            WifiScriptFullPath = WifiModuleDir + WifiScript
            cmdStr = WifiScriptFullPath + ' &'
            os.popen(cmdStr)
            if wait_seconds>0:
                time.sleep(wait_seconds)
    except Exception, e:
        pass

# 添加对FC20的支持 临时使用
def startWpaIfNotExist_test():    
    try:        
        os.system('/etc/init.d/wlan start')
        WifiScriptFullPath = '/usr/sbin/wpa_supplicant -c ' + WifiConf
        cmdStr = WifiScriptFullPath + ' -i ' + WifiIf + ' &'
        os.system(cmdStr)
    except Exception, e:
        pass


def get_ifaddr(ifname):
    import socket, fcntl, struct

    isExistWpa = isExistWpaProcess()
    if not isExistWpa:
        return -1

    sourcePath = '/sys/class/net/' + WifiIf + '/operstate'
    fileContent = ''
    with open(sourcePath, 'r') as f:
        fileContent = f.read().strip()
    
    if fileContent.lower() != 'up':
        return -1

    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        ifaddr = fcntl.ioctl(sock.fileno(), 0x8915, struct.pack('256s', ifname[:15]))
        return socket.inet_ntoa(ifaddr[20:24])
    except Exception, e:
        return -1

def waitToGetIp(timeoutSec):
    timeCount = 0
    timeStep = 2
    ra0Res = -1
    while True:
        ra0Res = get_ifaddr(WifiIf)
        if ra0Res == -1:
            time.sleep(timeStep)
            timeCount += timeStep
        if (timeCount > timeoutSec) or (ra0Res != -1):
            break
    return ra0Res

def writemodestatus(tag,modestatus):
    '''将wifi启用状态写入文件'''
    rexml = rx.reusexml(global_var.AnyLinkconfig_path)
    rexml.setTagVal('Wifi/'+tag, modestatus)
    rexml.savexml()
    os.system('cp -f %s /tmp/AnyLink.xml' % (global_var.AnyLinkconfig_path))

#因为refresh功能会经常写，而且写的是wifi的动态状态，所以修改为写在tmp目录下
def writemodestatus_refresh(tag,modestatus):
    '''将wifi启用状态写入文件'''
    if not os.path.exists('/tmp/AnyLink.xml'):
        os.system('cp -f %s /tmp/AnyLink.xml' % (global_var.AnyLinkconfig_path))
    
    if not os.path.exists(AnyLinkconfig_path_tmp):
        os.system('ln -s /tmp/AnyLink.xml  %s' % (AnyLinkconfig_path_tmp))
    rexml = rx.reusexml(AnyLinkconfig_path_tmp)
    rexml.setTagVal('Wifi/'+tag, modestatus)
    rexml.savexml()

def getwifistatus(wifiKey):
    ipAddr = get_ifaddr(WifiIf)
    if ipAddr == -1:
        return -1

    cmd = '/usr/sbin/wpa_cli -i ' + WifiIf + ' status'
    status, output = commands.getstatusoutput(cmd)
    if status == 0:
        lines = output.split('\n')
        for line in lines:
            info = line.split('=')
            if info != ['']:
                key = info[0]
                val = info[1]
                if key == wifiKey:
                    return val
                else:
                    continue
    else:
        return -1

def getwifilist():
    ''' write wifi info to a json file'''

    cmd = 'iwlist ' + WifiIf + ' scanning > .log'
    os.system(cmd)
    wifi_config_path = global_var.wifi_list_path
    l = []
    with open('.log', 'r') as f:
        l = f.readlines()
    l = parse_wifi_info(l)

    with open(wifi_config_path, 'w') as f:
        f.write(json.dumps(l))
    
    return l

def parse_wifi_info(_list):
    
    li = list()
    d = dict()
    ssids = dict()
    try:
        for l in _list:
            data = l.strip()
            if data.startswith('Cell'):
                d = dict()
            elif data.startswith('ESSID'):
                ssid = data[data.index(':') + 2:-1]
                if ssids.has_key(ssid):
                    continue
                ssids[ssid] = True
                d['SSID'] = ssid
                li.append(d)
            elif data.startswith('Encryption key'):
                buf = data[data.index(':') + 1:]
                d['Encryption key'] = buf
    except Exception as e:
        pass
    return li

def updateWifiInfo():
    ipAddr = get_ifaddr(WifiIf)
    if ipAddr == -1:
        writemodestatus_refresh('W_IP','')
        writemodestatus_refresh('W_STRONG','')
        return

    writemodestatus_refresh('W_IP',ipAddr)
    W_STRONG = get_level()
    if W_STRONG == -1:
        writemodestatus_refresh('W_STRONG','')
    else:
        writemodestatus_refresh('W_STRONG',W_STRONG)

    cmd = '/usr/sbin/wpa_cli -i ' + WifiIf + ' status'
    status, output = commands.getstatusoutput(cmd)
    if status == 0:
        lines = output.split('\n')
        for line in lines:
            info = line.split('=')
            if info != ['']:
                key = info[0]
                val = info[1]
                if key == 'ssid':
                    writemodestatus_refresh('W_SSID',val)

def get_level():
    with open('/proc/net/wireless', 'r') as fd:
        for line in fd.readlines():
            eth0Name = WifiIf + ':'
            if eth0Name in line:
                try:
                    level = line.split()[3].strip()
                    l = len(level)
                    if (l > 0) and (level.rfind('.') == (l-1)):
                        level = level[0:l-1]
                    return level
                except Exception, e:
                    return -1
    return -1

def getWpaConfWifiInfoList():
    wifi_config_path = WifiConf
    wifiList = []
    wifi = None
    with open(wifi_config_path, 'r') as f:
        for line in f.readlines():
            lineStrip = line.strip()
            if 'network={' in lineStrip:
                wifi = dict()
                wifiList.append(wifi)
            if 'ssid="' in lineStrip:
                ssid = lineStrip[len('ssid="'):len(lineStrip)-1]
                wifi['ssid'] = ssid
            if  'psk="' in lineStrip:
                psk = lineStrip[len('psk="'):len(lineStrip)-1]
                wifi['psk'] = psk
    
    return wifiList

def syncWpaconfAndReverseList(wpa_wifi_list, reverse_wifi_list):
    # 将wpa_wifi_list中的信息合并到reverse_wifi_list中
    extr_wifi_list = []
    for wpa_wifi in wpa_wifi_list:
        isExist = False
        wpa_ssid = wpa_wifi['ssid']
        for reverse_wifi in reverse_wifi_list:
            if reverse_wifi['ssid'] == wpa_ssid:
                isExist = True
        if isExist == False:
            extr_wifi_list.append(wpa_wifi)
    
    for extr_wifi in extr_wifi_list:
        reverse_wifi_list.append(extr_wifi)
    
    return reverse_wifi_list
    
def isExistWpaProcess():
    process_list = psutil.pids()
    isExist = False
    try:
        for pid in process_list:
            process = psutil.Process(pid)
            if 'wpa_supplicant' in process.name():
                isExist = True
                break
    except Exception, e:
        pass
    
    return isExist

def addOrUpdateWifiInfoInList(wifi_list,wifi_ssid,wifi_pwd):
    isExist = False
    for wifi_info in wifi_list:
        if wifi_ssid == wifi_info['ssid']:
            isExist = True
            if (wifi_pwd == '') and (wifi_info.has_key('psk')):
                del wifi_info['psk']
            else:
                wifi_info['psk'] = wifi_pwd
    
    if not isExist:
        wifi_info = dict()
        wifi_info['ssid'] = wifi_ssid
        if wifi_pwd != '':
            wifi_info['psk'] = wifi_pwd
        wifi_list.append(wifi_info)

    return wifi_list

def saveWifiInfoInAnylinkXml(wifi_list):
    #将wifi信息保存至AnyLink.xml

    anylink_tree = ET.parse(global_var.AnyLinkconfig_path)
    wifi_node = anylink_tree.find('Wifi')
    remote_node = anylink_tree.findall('Wifi/W_Remote')
    if len(remote_node) > 0:
        remote_node = remote_node[0]
        wifi_node.remove(remote_node)
    

    remote_node = ET.Element('W_Remote')
    list_node = ET.Element('W_List')
    
    for wifi_info in wifi_list:
        wifiinfo_node = ET.Element('W_Info')
        wifissid_node = ET.Element('W_SSID')
        wifissid_node.text = wifi_info['ssid']
        wifipsk_node = ET.Element('W_Password')
        if wifi_info.has_key('psk'):
            wifipsk_node.text = wifi_info['psk']
        else:
            wifipsk_node.text = ''
        wifiinfo_node.append(wifissid_node)
        wifiinfo_node.append(wifipsk_node)
        list_node.append(wifiinfo_node)
    
    remote_node.append(list_node)
    wifi_node.append(remote_node)

    anylink_tree.write(global_var.AnyLinkconfig_path, encoding='utf-8')

def getWifiInfoFromAnylinkXml():
    #从AnyLink.xml中读取wifi信息

    anylink_tree = ET.parse(global_var.AnyLinkconfig_path)
    wifiinfo_nodes = anylink_tree.findall('Wifi/W_Remote/W_List/W_Info')
    wifi_list = []
    if len(wifiinfo_nodes) < 1:
        return wifi_list
    
    for wifiinfo_node in wifiinfo_nodes:
        wifi_info = dict()
        wifi_ssid = wifiinfo_node.find('W_SSID').text
        wifi_psk = wifiinfo_node.find('W_Password').text
        wifi_info['ssid'] = wifi_ssid
        if (wifi_psk is not None) and (len(wifi_psk) > 0):
            wifi_info['psk'] = wifi_psk
        wifi_list.append(wifi_info)
    
    return wifi_list

def saveWifiInfoInWpaSupplicant(wifiinfo_list):
    #将wifi信息保存至wpa_supplicant.conf 
    fileContent = 'ctrl_interface=/var/run/wpa_supplicant\n'
    fileContent += 'update_config=1\n\n'
    for wifiInfo in wifiinfo_list:
        fileContent += 'network={\n'
        fileContent += '        ssid="' + wifiInfo['ssid'] + '"\n'
        if WifiModule != 'rt3070':
            fileContent += '        scan_ssid=1\n'
        else:
            pass
        if wifiInfo.has_key('psk'):
            fileContent += '        psk="' + wifiInfo['psk'] + '"\n'
        else:
            fileContent += '        key_mgmt=NONE\n'
        fileContent += '}\n'

    # wifi_config_path = '/opt/script/rtl8812/wpa_supplicant.conf'
    wifi_config_path = WifiConf
    with open(wifi_config_path, 'w') as f:
        f.write(fileContent)

def get_script_data():
    global scriptConfig_path, WifiScript, WifiModuleDir, WifiConf, WifiIf, WifiModule
    scriptTree = ET.parse(scriptConfig_path)

    scriptWifiNode = scriptTree.find('WiFi')

    WifiModuleDirNode = scriptWifiNode.find('WifiModuleDir')
    WifiModuleDir = WifiModuleDirNode.text

    WifiScriptNode = scriptWifiNode.find('WifiScript')
    WifiScript = WifiScriptNode.text

    WifiDirNode = scriptWifiNode.find('WifiDir')
    WifiDir = WifiDirNode.text

#wpa_supplicant.conf文件固定放在/opt/script/WiFi/wpa_supplicant.conf 不再从配置文件中取
    #WifiConfNode = scriptWifiNode.find('WifiConf')
    #WifiConf = WifiConfNode.text
    #WifiConf = WifiModuleDir + WifiConf
    

    WifiIfNode = scriptWifiNode.find('WifiIf')
    WifiIf = WifiIfNode.text

    WifiModuleNode = scriptWifiNode.find('WifiModule')
    WifiModule = WifiModuleNode.text

    
if __name__ == '__main__':
    log = Loginfo.Loginfo()
    get_cgi_data()

    get_script_data()

    # 开启wifi
    if wifi_cmd == 'start':
        # 1. 写入开启wifi的标志位
        writemodestatus('W_Modestatus','start')

        # 2. 通过无线网卡是否有ip来判断wifi有没有连上
        ra0Res = get_ifaddr(WifiIf)
        
        if ra0Res == -1:
            # 3. 启用无线网卡
            #cmd = '/sbin/ifconfig | grep "' + WifiIf + '"'
            #(status, output) = commands.getstatusoutput(cmd)
            #if output == "":
            #    cmd = "ifconfig " + WifiIf + " up"
            #    os.system(cmd)

            # 4 停止wpa_rtl8812.py和killall wpa_supplicant
            killProcessIfExist(WifiScript)
            # os.system('killall wpa_supplicant')
            killProcessIfExist('wpa_supplicant')
            
            time.sleep(3)

            # 5 同步AnyLink.xml, wpa_supplicant.conf和reserveWifi.json
            wifiinfo_list = getWifiInfoFromAnylinkXml()
            with open(global_var.reserve_wifi_list_path, 'w') as f:
                f.write(json.dumps(wifiinfo_list))
            
            saveWifiInfoInWpaSupplicant(wifiinfo_list)

            if len(wifiinfo_list) > 0:
                # 6. 开启wpa_rtl8812.py
                startWpaIfNotExist()

                # 7. 查看无线网卡是否获取到ip
                # 超时时间
                timeoutSec = 30
                if waitToGetIp(timeoutSec) == -1:
                    print 'fail'
                else:
                    print 'success'
            else:
                #启动无线网卡 这样才有机会做iwlist wlan0 scanning
                startWpaIfNotExist()                
                print 'fail'

        else:
            print 'success'
    
    # 连接wifi
    elif wifi_cmd == 'connwifi':
        # 1. 停止 wpa_rtl8812.py和killall wpa_supplicant
        killProcessIfExist(WifiScript)
        killProcessIfExist('wpa_supplicant')
        time.sleep(3)

        # 2. 将ssid, psk写入文件

        # 2.1 判断要添加的wifi信息是否存在于wpa_supplicant.conf中
        # wpa_wifi_list = getWpaConfWifiInfoList()
        wpa_wifi_list = getWifiInfoFromAnylinkXml()
        wpa_wifi_list = addOrUpdateWifiInfoInList(wpa_wifi_list,wifi_ssid,wifi_password)
        
        # 2.2拼接wpa_supplicant.conf文件字符串
        saveWifiInfoInWpaSupplicant(wpa_wifi_list)
        
        # 3. 开启 wpa_rtl8812.py
        startWpaIfNotExist()

        # 4. 查看无线网卡是否获取到ip
        # 超时时间
        timeoutSec = 30
        if waitToGetIp(timeoutSec) == -1:
            print 'fail'
        else:
            print 'success'
            # # 5. 查看当前连接了哪个wifi
            # cur_ssid = getwifistatus('ssid')
            # if (cur_ssid != -1) and (cur_ssid == wifi_ssid):
            #     # 6. 当前WiFi更新至global_var.reserve_wifi_list_path
            #         wifiInfoList = []
            #         content = ''
            #         with open(global_var.reserve_wifi_list_path, 'r') as f:
            #             content = f.read()
            #         try:
            #             wifiInfoList = json.loads(content)
            #         except Exception, e:
            #             pass
                    
            #         wifiInfoList = addOrUpdateWifiInfoInList(wifiInfoList,wifi_ssid,wifi_password)
            #         with open(global_var.reserve_wifi_list_path, 'w') as f:
            #             f.write(json.dumps(wifiInfoList))
    
    # 停用wifi
    elif wifi_cmd == 'stop':
        # 1. 写入停用wifi的标志位
        writemodestatus('W_Modestatus','stop')

        # 2. 停止 wpa_rtl8812.py和wpa_supplicant
        killProcessIfExist(WifiScript)
        killProcessIfExist('wpa_supplicant')
        time.sleep(3)
        cmd = '/sbin/ifconfig | grep "' + WifiIf + '"'
        (status, output) = commands.getstatusoutput(cmd)
        if output != "":
            cmd = "ifconfig " + WifiIf + " 0.0.0.0 down"
            os.system(cmd)
            
        print 'success'

    # 获取wifi列表
    elif wifi_cmd == 'getwifi':
        getwifilist()
    
    # 刷新wifi
    elif wifi_cmd == 'refresh':
        time.sleep(1)
        updateWifiInfo()
    
    # 保存或者修改wifi信息
    elif wifi_cmd == 'update':
        #WiFi信息更新至global_var.reserve_wifi_list_path
        wifiInfoList = []
        content = ''
        with open(global_var.reserve_wifi_list_path, 'r') as f:
            content = f.read()

        try:
            wifiInfoList = json.loads(content)
        except Exception, e:
            pass
        
        wifiInfoList = addOrUpdateWifiInfoInList(wifiInfoList,wifi_ssid,wifi_password)

        # 将同步后的信息保存至AnyLink.xml
        saveWifiInfoInAnylinkXml(wifiInfoList)
        
        with open(global_var.reserve_wifi_list_path, 'w') as f:
            f.write(json.dumps(wifiInfoList))

        # 将同步后的信息保存至wpa_supplicant.conf
        saveWifiInfoInWpaSupplicant(wifiInfoList)

    elif wifi_cmd == 'delete':
        #WiFi信息更新至global_var.reserve_wifi_list_path
        wifiInfoList = []
        content = ''
        with open(global_var.reserve_wifi_list_path, 'r') as f:
            content = f.read()
        try:
            wifiInfoList = json.loads(content)
        except Exception, e:
            pass
        
        cur_wifi_list = []
        for wifi_info in wifiInfoList:
            if wifi_ssid != wifi_info['ssid']:
                cur_wifi_list.append(wifi_info)

        # 将同步后的信息保存至AnyLink.xml
        saveWifiInfoInAnylinkXml(cur_wifi_list)
        
        with open(global_var.reserve_wifi_list_path, 'w') as f:
            f.write(json.dumps(cur_wifi_list))

        # 将同步后的信息保存至wpa_supplicant.conf
        saveWifiInfoInWpaSupplicant(cur_wifi_list)

    elif wifi_cmd == 'restart':
        # 1. 写入开启wifi的标志位
        writemodestatus('W_Modestatus','start')

        # 2. 启用无线网卡
        cmd = '/sbin/ifconfig | grep "' + WifiIf + '"'
        (status, output) = commands.getstatusoutput(cmd)
        if output == "":
            cmd = "ifconfig " + WifiIf + " up"
            os.system(cmd)

        # 3. 停止wpa_rtl8812.py和killall wpa_supplicant
        killProcessIfExist(WifiScript)
        # os.system('killall wpa_supplicant')
        killProcessIfExist('wpa_supplicant')
        time.sleep(3)

        
        # 4. 将预设的wifi信息保存至wpa_supplicant.conf
        wifiInfoList = []
        content = ''
        with open(global_var.reserve_wifi_list_path, 'r') as f:
            content = f.read()

        try:
            wifiInfoList = json.loads(content)
        except Exception, e:
            pass

        fileContent = 'ctrl_interface=/var/run/wpa_supplicant\n'
        fileContent += 'update_config=1\n\n'
        for wifiInfo in wifiInfoList:
            fileContent += 'network={\n'
            fileContent += '        ssid="' + wifiInfo['ssid'] + '"\n'
            if WifiModule != 'rt3070':
                fileContent += '        scan_ssid=1\n'
            else:
                pass
            if wifiInfo.has_key('psk'):
                fileContent += '        psk="' + wifiInfo['psk'] + '"\n'
            else:
                fileContent += '        key_mgmt=NONE\n'
            fileContent += '}\n'

        wifi_config_path = WifiConf
        with open(wifi_config_path, 'w') as f:
            f.write(fileContent)

        if len(wifiInfoList) > 0:
            # 5. 开启 wpa_rtl8812.py
            startWpaIfNotExist()

            # 6. 查看无线网卡是否获取到ip
            # 超时时间
            timeoutSec = 30
            if waitToGetIp(timeoutSec) == -1:
                print 'fail'
            else:
                print 'success'
        else:
            print 'fail'
    
    elif wifi_cmd == 'sync':
        #同步AnyLink.xml, wpa_supplicant.conf和reserveWifi.json
        wifiinfo_list = getWifiInfoFromAnylinkXml()
        with open(global_var.reserve_wifi_list_path, 'w') as f:
            f.write(json.dumps(wifiinfo_list))
        
        saveWifiInfoInWpaSupplicant(wifiinfo_list)
    elif wifi_cmd == 'connwifi2':
        # 1. 停止 wpa_rtl8812.py和killall wpa_supplicant
        killProcessIfExist(WifiScript)
        killProcessIfExist('wpa_supplicant')
        time.sleep(0.5)

        wpa_wifi_list = [{}]
        wpa_wifi_list[0]['ssid'] = wifi_ssid
        if wifi_password != '':
            wpa_wifi_list[0]['psk'] = wifi_password

        # 2拼接wpa_supplicant.conf文件字符串
        saveWifiInfoInWpaSupplicant(wpa_wifi_list)
        
        # 3. 开启 wpa_rtl8812.py
        startWpaIfNotExist()

        # 4. 查看无线网卡是否获取到ip
        # 超时时间
        timeoutSec = 45
        if waitToGetIp(timeoutSec) == -1:
            wpa_wifi_list = getWifiInfoFromAnylinkXml()
            # 保存至wpa_supplicant.conf
            saveWifiInfoInWpaSupplicant(wpa_wifi_list)
            print 'fail'
        else:
            # 连接成功，将连接的wifi信息保存至AnyLink.xml
            wpa_wifi_list = getWifiInfoFromAnylinkXml()
            wpa_wifi_list = addOrUpdateWifiInfoInList(wpa_wifi_list,wifi_ssid,wifi_password)
            saveWifiInfoInAnylinkXml(wpa_wifi_list)
            
            # 保存至wpa_supplicant.conf
            saveWifiInfoInWpaSupplicant(wpa_wifi_list)
            print 'success'
    
    elif wifi_cmd == 'reserve':
        # 1. 停止 wpa_rtl8812.py和killall wpa_supplicant
        killProcessIfExist(WifiScript)
        killProcessIfExist('wpa_supplicant')
        time.sleep(3)

        # 2.从AnyLink.xml中获取wifi列表
        wpa_wifi_list = getWifiInfoFromAnylinkXml()

        # 3 拼接wpa_supplicant.conf文件字符串
        saveWifiInfoInWpaSupplicant(wpa_wifi_list)

        # 4. 开启 wpa_rtl8812.py
        startWpaIfNotExist()

        # 5. 查看无线网卡是否获取到ip
        # 超时时间
        timeoutSec = 30
        if waitToGetIp(timeoutSec) == -1:
            print 'fail'
        else:
            print 'success'