#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'yue.zhang'
import os
import sys
import getopt
import xml.etree.ElementTree as ET
from config import global_var
import cgi
import time

#参数存放路径:AnyLinkconfig_path = /opt/sdmwebs/web/conf/AnyLink.xml

dhcp = ''
ip = ''
mask = ''
gateway  = ''
dns_list = {}
frequency_select = ''
reload(sys)
sys.setdefaultencoding("utf-8")
print "Content-Type: text/html charset=utf-8 \n"
def init_logger():
    import logging
    from logging.handlers import RotatingFileHandler
    global logger
    logger = logging.getLogger()
    Rthandler = RotatingFileHandler('/PageFile/wificonfig.log', mode='a', maxBytes=32 * 1024, backupCount=1)
    formatter = logging.Formatter('%(asctime)s %(levelname)s----%(message)s')
    Rthandler.setFormatter(formatter)
    logger.addHandler(Rthandler)
    logger.setLevel(logging.INFO)
    return 0

def get_cgi_data():
    global dhcp,ip,mask,gateway,dns_list,frequency_select
    fs = cgi.FieldStorage()

    dhcp = fs.getvalue('wifi_dhcp', '')#YES/NO
    logger.info("dhcp:%s" % dhcp)
    print("dhcp:%s" % dhcp)

    ip = fs.getvalue('wifi_ip', '')
    logger.info("ip:%s" % ip)
    print("ip:%s" % ip)

    mask = fs.getvalue('wifi_mask', '')
    logger.info("mask:%s" % mask)
    print("mask:%s" % mask)

    gateway = fs.getvalue('wifi_gateway', '')
    logger.info("gateway:%s" % gateway)
    print("gateway:%s" % gateway)

    dns = fs.getvalue('wifi_dns', '')#多个DNS之间用,分割
    print("dns:%s" % dns)
    logger.info("dns:%s" % dns)
    dns_list = dns.split(",")

    frequency_select = fs.getvalue('wifi_frequency_select', '')#0:无/1: 2.4G优先/2: 5G优先/3: 只连2.4G/4: 只连5G
    print("frequency:%s" % frequency_select)
    logger.info("frequency:%s" % frequency_select)


def saveWifiGetIPModeInfoInAnylinkXml():
    global dhcp,ip,mask,gateway,dns_list,frequency_select
    anylink_tree = ET.parse(global_var.AnyLinkconfig_path)
    wifi_node = anylink_tree.find('Wifi')
    
    #frequency
    if(frequency_select != ''):
        FREQUENCY = anylink_tree.findall('Wifi/W_FREQUENCY_SELECT')
        if len(FREQUENCY) > 0:
            FREQUENCY = FREQUENCY[0]
            wifi_node.remove(FREQUENCY)
        W_FREQUENCY_SELECT = ET.Element('W_FREQUENCY_SELECT')
        W_FREQUENCY_SELECT.text = frequency_select
        wifi_node.append(W_FREQUENCY_SELECT)

    if(dhcp == ''):
        anylink_tree.write(global_var.AnyLinkconfig_path, encoding='utf-8')
        print 'success'
        logger.info('leave saveWifiGetIPModeInfoInAnylinkXml')
        return 0

    #dhcp
    DHCP = anylink_tree.findall('Wifi/W_DHCP')
    if len(DHCP) > 0:
        DHCP = DHCP[0]
        wifi_node.remove(DHCP)
    W_DHCP = ET.Element('W_DHCP')
    W_DHCP.text = dhcp
    wifi_node.append(W_DHCP)
    if dhcp == "YES":
        anylink_tree.write(global_var.AnyLinkconfig_path, encoding='utf-8')
        logger.info('leave saveWifiGetIPModeInfoInAnylinkXml')
        print 'success'
        return 0

    if(ip == '' or mask == '' or gateway == '' or dns_list == ''):
        anylink_tree.write(global_var.AnyLinkconfig_path, encoding='utf-8')
        logger.info('leave saveWifiGetIPModeInfoInAnylinkXml')
        print 'success'
        return 0

    #clear static_ip param
    StaticIP_IP = anylink_tree.findall('Wifi/W_StaticIP_IP')
    if len(StaticIP_IP) > 0:
        StaticIP_IP = StaticIP_IP[0]
        wifi_node.remove(StaticIP_IP)

    StaticIP_NETMASK = anylink_tree.findall('Wifi/W_StaticIP_NETMASK')
    if len(StaticIP_NETMASK) > 0:
        StaticIP_NETMASK = StaticIP_NETMASK[0]
        wifi_node.remove(StaticIP_NETMASK)

    StaticIP_GATEWAY = anylink_tree.findall('Wifi/W_StaticIP_GATEWAY')
    if len(StaticIP_GATEWAY) > 0:
        StaticIP_GATEWAY = StaticIP_GATEWAY[0]
        wifi_node.remove(StaticIP_GATEWAY)

    StaticIP_DNS = anylink_tree.findall('Wifi/W_StaticIP_DNS')
    if len(StaticIP_DNS) > 0:
        StaticIP_DNS = StaticIP_DNS[0]
        wifi_node.remove(StaticIP_DNS)

    #set ip,mask,gateway,dns
    W_StaticIP_IP = ET.Element('W_StaticIP_IP')
    W_StaticIP_IP.text = ip
    W_StaticIP_NETMASK = ET.Element('W_StaticIP_NETMASK')
    W_StaticIP_NETMASK.text = mask
    W_StaticIP_GATEWAY = ET.Element('W_StaticIP_GATEWAY')
    W_StaticIP_GATEWAY.text = gateway
    W_StaticIP_DNS = ET.Element('W_StaticIP_DNS')
    for i in range(len(dns_list)):
        W_StaticIP_DNS_Address = ET.Element('W_StaticIP_DNS_Address')
        W_StaticIP_DNS_Address.text = dns_list[i]
        W_StaticIP_DNS.append(W_StaticIP_DNS_Address)
    wifi_node.append(W_StaticIP_IP)
    wifi_node.append(W_StaticIP_NETMASK)
    wifi_node.append(W_StaticIP_GATEWAY)
    wifi_node.append(W_StaticIP_DNS)

    anylink_tree.write(global_var.AnyLinkconfig_path, encoding='utf-8')
    print 'success'
    return 0

    
def for_opt(argv):
    #argv


    #关于频率倾向性->0:无/1: 2.4G优先/2: 5G优先/3: 只连2.4G/4: 只连5G
    #关于DNS->多个DNS之间用,连接
    #DHCP,无频率倾向性      : --dhcp=YES --frenquency_select=0
    #static ip，2.4G优先 : --dhcp=NO --ip=192.168.0.43 --mask=255.255.255.0 --gateway=192.168.0.1 --dns=8.8.8.8,208.67.222.123 --frequency_select=1
    try:
        options, args = getopt.getopt(argv, "hMD:i:m:g:d:f:", ["help","MAC","dhcp=", "ip=", "mask=","gateway=","dns=","frequency_select="])
        print("============ opts ==================");         
        print(options)  
      
        print("============ args ==================");  
        print(args)
    except getopt.GetoptError:
        print("get opt error")
        sys.exit()

    for option, value in options:
        if option in ("-h", "--help"):
           usage()
        if option in ("-M", "--MAC"):
           return get_MAC_ADDRESS()
        if option in ("-D", "--dhcp"):
            dhcp = value
        if option in ("-i", "--ip"):
            ip = value
        if option in ("-m", "--mask"):
            mask = value
        if option in ("-g", "--gateway"):
            gateway = value
        if option in ("-d", "--dns"):
            print("dns is: {0}".format(value))
            dns_list = value.split(",")
        if option in ("-f", "--frequency_select"):
            frequency_select = value

    print("error args: {0}".format(args))
    saveWifiGetIPModeInfoInAnylinkXml()

def usage():  
    print("Usage:%s [--help|--MAC|--dhcp|--ip|--mask|--gateway|--dns|--frequenry_select] args...." % sys.argv[0])  
    
    
if __name__ == '__main__':
    #for_opt(sys.argv[1:])

    init_logger()
    get_cgi_data()
    saveWifiGetIPModeInfoInAnylinkXml()