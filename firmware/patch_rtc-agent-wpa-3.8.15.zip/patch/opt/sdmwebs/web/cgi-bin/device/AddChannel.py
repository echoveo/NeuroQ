#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xhzhang'

import xml.etree.ElementTree as ET
from config import global_var
from Log import Loginfo
from CGI import GetCgi
from QUIT import Quit
from rexml import updateVersion
import sys, cgi
import os
import Cookie
reload(sys)
sys.setdefaultencoding('utf-8')

print "Content-Type: text/html charset=utf-8 \n"

channel_name = ''
channel_id = new_channel_id = ''
channel_driver = ''
channel_config = ''
device_driver = device_driver_type = ''


def get_cgi_data():
    global channel_name, channel_id, channel_driver, channel_config, device_driver, device_driver_type
    form = cgi.FieldStorage()
    channel_name = form.getvalue('Add_ChannelName_YuToXHZhang', '')
    channel_id = form.getvalue('Add_ChannelMaxID_YuToXHZhang', '')
    channel_driver = form.getvalue('Add_ChannelModelType_YuToXHZhang', '')
    channel_config = form.getvalue('Add_ChannelConfig_YuToXHZhang', '')
    device_driver = form.getvalue('Add_ChannelDriver_YuToXHZhang', '')
    device_driver_type = form.getvalue('Add_IsTask_YuToXHZhang', '')
    #print channel_name,channel_id,channel_driver,channel_config,device_driver


#任务驱动处理
def add_task(node):
    '''if driver is taskdriver,need to use'''
    ele = ET.Element('TaskDriver')
    subele = ET.Element('driver',
                        attrib={
                            'n': channel_driver,
                            'config': channel_config,
                            'id': channel_id
                        })
    ele.append(subele)
    node.append(ele)


#添加model节点(通道名称，唯一)
def add_channel_moduleconfig():
    '''获取cookie'''
    if 'HTTP_COOKIE' in os.environ:
        cookie_string = os.environ.get('HTTP_COOKIE')
        c = Cookie.SimpleCookie()
        c.load(cookie_string)
        data = c['AnyLinkLan'].value

    if channel_id == '0' or channel_id == '':
        log.write_error('通道id为0或者空。')
        Quit.quit_error('AddChannel')
    agent_tree = ET.parse(global_var.itemconfig_path)
    agent = agent_tree.getroot()
    if device_driver_type == 'YES':
        '''YES:表示任务驱动 ；NO:表示自定义驱动'''
        log.write_info('[%s]是任务驱动' % (device_driver))
        task_node = agent_tree.find('task')
        add_task(task_node)
    else:
        log.write_info('[%s]是自定义驱动' % (device_driver))
    model = ET.Element('model')
    model.set('n', channel_name)
    model.set('id', channel_id)
    model.set('d', channel_driver)
    model.set('config', channel_config)
    model.set('devicedriver', device_driver)
    agent.append(model)
    log.write_debug('通道[%s]添加成功。' % (channel_name))
    # agent_tree.write(global_var.itemconfig_path, encoding='utf-8')
    updateVersion.write(agent_tree, global_var.itemconfig_path)


def set_channel_id():
    '''获取cookie'''
    if 'HTTP_COOKIE' in os.environ:
        cookie_string = os.environ.get('HTTP_COOKIE')
        c = Cookie.SimpleCookie()
        c.load(cookie_string)
        data = c['AnyLinkLan'].value
    '''设置通道id'''
    idconfig_tree = ET.parse(global_var.idconfig_path)
    channel_node = idconfig_tree.find('ChannelID')
    if channel_id != '0':
        new_channel_id = str(int(channel_id) + 1)
        channel_node.text = new_channel_id
        log.write_debug('通道id由 %s 增加到 %s ' % (channel_id, new_channel_id))
        # idconfig_tree.write(global_var.idconfig_path,
        #                     encoding='utf-8',
        #                     xml_declaration='true')
        updateVersion.write(idconfig_tree, global_var.idconfig_path)
    else:
        log.write_error('通道id为0')


if __name__ == '__main__':
    log = Loginfo.Loginfo()
    get_cgi_data()
    add_channel_moduleconfig()
    set_channel_id()