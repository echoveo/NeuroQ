#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xhzhang'

import xml.etree.ElementTree as ET
from config import global_var
import Write_Additional
from CGI import GetCgi
from Log import Loginfo
from QUIT import Quit
from rexml import updateVersion
import sys
import cgi
import os
import Cookie
import AddTXDataitem
reload(sys)
sys.setdefaultencoding('utf8')
print "Content-Type: text/html charset=utf-8 \n"

device_name = device_ip = device_id = device_driver_name = device_driver_config = device_driver_id = ''
channel_id = parient_channel_node = remoteaddress = device_model = device_type = ''


def get_cgi_data():
    global device_name, device_type, device_ip, device_id, device_driver_name, device_driver_config, device_driver_id, channel_id,\
        remoteaddress, device_model
    form = cgi.FieldStorage()
    device_name = form.getvalue('Add_DeviceName_YuToXHZhang', '')
    device_ip = form.getvalue('Add_DeviceIP_YuToXHZhang', '')
    device_id = form.getvalue('Add_DeviceID_YuToXHZhang', '')
    device_driver_name = form.getvalue('Add_ChannelModelType_YuToXHZhang', '')
    device_driver_config = form.getvalue('Add_ChannelConfig_YuToXHZhang', '')
    device_driver_id = form.getvalue('Add_DriverID_YuToXHZhang', '')
    channel_id = form.getvalue('Add_ChannelID_YuToXHZhang', '')
    device_model = form.getvalue('Add_DeviceModel_YuToXHZhang', '')
    device_type = form.getvalue('Add_DeviceType_YuToXHZhang', '')
    remoteaddress = form.getvalue('Add_DeviceRemoteAddress_YuToXHZhang', '')


def add_device_moduleconfig():
    '''获取cookie'''
    if 'HTTP_COOKIE' in os.environ:
        cookie_string = os.environ.get('HTTP_COOKIE')
        c = Cookie.SimpleCookie()
        c.load(cookie_string)
        data = c['AnyLinkLan'].value

    if device_id == '0' or device_id == '':
        log.write_error('设备id为0或者空。')
        Quit.quit_error('AddDevice')

    agent_tree = ET.parse(global_var.itemconfig_path)
    agent = agent_tree.getroot()

    device = ET.Element('device')
    device.set('n', device_name)
    device.set('id', device_id)
    device.set('ip', device_ip)
    device.set('type', device_type)

    driver = ET.Element('driver')
    driver.set('n', device_driver_name)
    driver.set('config', device_driver_config)
    driver.set('id', device_driver_id)

    commDataItems = ET.Element('commDataItems')
    driver.append(commDataItems)
    device.append(driver)

    parient_node_list = agent_tree.findall('model')
    for node in parient_node_list:
        channel_node_id = node.get('id', default=None)
        if channel_node_id != None and channel_node_id == channel_id:
            node.append(device)
            log.write_debug('添加设备[%s]成功。' % (device_name))
            break
    if device_model == "MITSUBISHI-TX-5HP":
        AddTXDataitem.add_TX_dataitem(
            "MITSUBISHI-TX-5HP.xml", agent_tree, commDataItems)
    if device_model == "MITSUBISHI-TX-Multi-link":
        AddTXDataitem.add_TX_dataitem(
            "MITSUBISHI-TX-Multi-link.xml", agent_tree, commDataItems)
    if device_model == "MITSUBISHI-TX-15P":
        AddTXDataitem.add_TX_dataitem(
            "MITSUBISHI-TX-15P.xml", agent_tree, commDataItems)
    if device_model == "MITSUBISHI-TXZ-MomMach":
        AddTXDataitem.add_TX_dataitem(
            "templates/MITSUBISHI-TXZ-MomMach.xml", agent_tree, commDataItems)
    if device_model == "MITSUBISHI-TXZ-SubMach1":
        AddTXDataitem.add_TX_dataitem(
            "templates/MITSUBISHI-TXZ-SubMach1.xml", agent_tree, commDataItems)
    if device_model == "MITSUBISHI-TXZ-SubMach2":
        AddTXDataitem.add_TX_dataitem(
            "templates/MITSUBISHI-TXZ-SubMach2.xml", agent_tree, commDataItems)
    if device_model == "R1R2":
        device_map = {"0": "templates/samsung-indoor.xml", "1": "templates/samsung-hydro.xml", "2": "templates/samsung-ERV.xml",
                      "3": "templates/samsung-AHU.xml", "4": "templates/samsung-EHS.xml", "5": "templates/samsung-ERV+.xml"}
        slave_device_type = device_driver_config.split(";")[0]
        AddTXDataitem.add_TX_dataitem(
            device_map[slave_device_type], agent_tree, commDataItems)
    updateVersion.write(agent_tree, global_var.itemconfig_path)
    # agent_tree.write(global_var.itemconfig_path,
    #                  encoding='utf-8',
    #                  xml_declaration='true')


def set_device_id():
    '''获取cookie'''
    if 'HTTP_COOKIE' in os.environ:
        cookie_string = os.environ.get('HTTP_COOKIE')
        c = Cookie.SimpleCookie()
        c.load(cookie_string)
        data = c['AnyLinkLan'].value

    idconfig_tree = ET.parse(global_var.idconfig_path)
    device_node = idconfig_tree.find('DeviceID')
    if channel_id != '0' and int(
            device_id) < 1021:  # 现支持1023个设备，id为1023的是plc远程更新的设备id。
        new_device_id = str(int(device_id) + 1)
        device_node.text = new_device_id
        log.write_debug('设备id由 %s 增加到 %s ' % (device_id, new_device_id))
        updateVersion.write(idconfig_tree, global_var.idconfig_path)
        # idconfig_tree.write(global_var.idconfig_path, encoding='utf-8')
    else:
        log.write_error('通道id=0')


def set_driver_id():
    '''增加driver_id值'''
    idconfig_tree = ET.parse(global_var.idconfig_path)
    driver_node = idconfig_tree.find('DriverID')
    if device_driver_id != '0':
        driver_node.text = str(int(device_driver_id) + 1)
        updateVersion.write(idconfig_tree, global_var.idconfig_path)
        # idconfig_tree.write(global_var.idconfig_path,
        #                     encoding='utf-8',
        #                     xml_declaration='true')
    else:
        return


if __name__ == '__main__':
    log = Loginfo.Loginfo()
    get_cgi_data()
    add_device_moduleconfig()
    set_device_id()
    set_driver_id()
