#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xhzhang'

import xml.etree.ElementTree as ET
from config import global_var
from CGI import GetCgi
from Log import Loginfo
from rexml import updateVersion
import Write_Additional as WA
import sys, cgi
import os
import Cookie
reload(sys)
sys.setdefaultencoding('utf8')

print "Content-Type: text/html charset=utf-8 \n"

channel_driver = channel_id = channel_name = channel_config = device_driver = device_driverid = ''


def get_cgi_data():
    global channel_driver, channel_id, channel_name, channel_config, device_driver, device_driverid
    form = cgi.FieldStorage()
    channel_name = form.getvalue('Alter_ChannelName_YuToXHZhang', '')
    channel_id = form.getvalue('Alter_ChannelID_YuToXHZhang', '')
    channel_driver = form.getvalue('Alter_ChannelModelType_YuToXHZhang', '')
    channel_config = form.getvalue('Alter_ChannelConfig_YuToXHZhang', '')
    device_driver = form.getvalue('Alter_ChannelDriver_YuToXHZhang', '')
    device_driverid = form.getvalue('Alter_ChannelDriverID_YuToXHZhang', '')
    print channel_name
    print channel_id
    print channel_driver
    print channel_config
    print device_driver
    print device_driverid


def alter_task(node, config):
    '''获取cookie'''
    if 'HTTP_COOKIE' in os.environ:
        cookie_string = os.environ.get('HTTP_COOKIE')
        c = Cookie.SimpleCookie()
        c.load(cookie_string)
        data = c['AnyLinkLan'].value
    '''if driver is taskdriver,need to use'''
    if node is not None:
        node.set('config', config)
    else:
        if data == "English":
            log.write_info('[%s]Drive is custom driven' % (device_driver))
        else:
            log.write_info('[%s]驱动为自定义驱动' % (device_driver))


def alter_driver_moduleconfig():
    '''获取cookie'''
    if 'HTTP_COOKIE' in os.environ:
        cookie_string = os.environ.get('HTTP_COOKIE')
        c = Cookie.SimpleCookie()
        c.load(cookie_string)
        data = c['AnyLinkLan'].value

    agent_tree = ET.parse(global_var.itemconfig_path)
    channel_node_list = agent_tree.findall('model')
    for channel_node in channel_node_list:
        channel_node_id = channel_node.get('id', default=None)
        if channel_node_id is not None and channel_node_id == channel_id:
            if data == "English":
                log.write_debug('Modify channel[%s]information.' %
                                (channel_node.get('n')))
            else:
                log.write_debug('修改通道[%s]信息。' % (channel_node.get('n')))
            channel_node.set('n', channel_name)
            channel_node.set('d', channel_driver)
            channel_node.set('config', channel_config)
            channel_node.set('devicedriver', device_driver)
            task_node = agent_tree.find('./task/TaskDriver/driver[@id="%s"]' %
                                        (channel_id))
            if device_driverid == 'NULL':
                if data == "English":
                    log.write_info(
                        'Currently there is no added device, no need to modify device driver information.'
                    )
                else:
                    log.write_info('当前没有添加设备，不需要修改设备驱动信息。')
                alter_task(task_node, channel_config)
            else:
                device_node_list = channel_node.findall('device')
                for device_node in device_node_list:
                    driver_node_list = device_node.findall('driver')
                    for driver_node in driver_node_list:
                        if device_driver == "device":
                            driver_node.set('n', channel_driver)
                        old_config = driver_node.get('config')
                        re_config = WA.get_re_driver_config(
                            device_driver, channel_config, old_config)
                        if re_config is not None:
                            if device_driver != "Modbus-RTU-task" and device_driver != "Modbus-ASCII-task" and device_driver != "Modbus-TCP-task" and device_driver != "SIEMENS-S7-PPI-Task" \
                                and device_driver != "BacNet-IP-task" and device_driver != "BacNet-MS/TP-task" and device_driver != "KUKA" and \
                                device_driver != "CloudWeb" and device_driver != "DLT645-2007" and device_driver != "DLT645-1997" and device_driver != "OMRON-HostLink-Task"and device_driver != "OMRON-FINS-Task" and device_driver != "TwinCAT" and device_driver != "R1R2":
                                driver_node.set('config', re_config)
                            alter_task(task_node, re_config)
                            log.write_debug('修改驱动设备[%s]驱动id[%s]的信息为[%s]。' %
                                            (device_node.get('n'),
                                             driver_node.get('id'), re_config))
            if data == "English":
                log.write_debug('Modify channel[%s]success.' % (channel_name))
            else:
                log.write_debug('修改通道[%s]成功。' % (channel_name))
            break
    #ET.dump(agent_tree)
    updateVersion.write(agent_tree, global_var.itemconfig_path)
    # agent_tree.write(global_var.itemconfig_path, encoding='utf-8')


if __name__ == '__main__':
    log = Loginfo.Loginfo()
    get_cgi_data()
    alter_driver_moduleconfig()
