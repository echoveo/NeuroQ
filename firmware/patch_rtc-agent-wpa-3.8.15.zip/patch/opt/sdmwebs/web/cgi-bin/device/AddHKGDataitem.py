#!/usr/bin/python
# -*- coding: UTF-8 -*-
# __author__ = 'xhzhang'
# Edit By Randy.Jang
# 2015/06/01

import xml.etree.ElementTree as ET
import time
from config import global_var
from CGI import GetCgi
from Log import Loginfo
from QUIT import Quit
from rexml import updateVersion
import sys, cgi
import os
import Cookie
reload(sys)
sys.setdefaultencoding('utf8')
print "Content-Type: text/html charset=utf-8 \n"

device_id = ''
dataitem_name = dataitem_id = dataitem_alias = dataitem_type = dataitem_rwmode = dataTag = ''
dataitem_fre = dataitem_report = dataitem_config = ''


def get_cgi_data():
    global device_id, dataitem_name, dataitem_alias, dataitem_id, dataitem_type, dataitem_fre, dataitem_report, dataitem_config, dataitem_rwmode, dataTag
    form = cgi.FieldStorage()
    nct = form.getvalue('addDataItem', '')
    device_id = form.getvalue('HKGDeviceID', '')
    dataHKGItem = nct.split('$')
    agent_tree = ET.parse(global_var.itemconfig_path)
    agent = agent_tree.getroot()
    parient_node_list = agent_tree.findall('model/device')
    for node in parient_node_list:
        if node.attrib['id'] == device_id:
            for cg in dataHKGItem:
                ndataHKGItem = eval(cg)
                device_id = ndataHKGItem['Add_DeviceID']
                dataitem_name = ndataHKGItem['Add_DataItemName']
                dataitem_alias = ndataHKGItem['Add_DataItemAlias']
                dataitem_fre = ndataHKGItem['Add_DataItemFreq']
                dataitem_type = ndataHKGItem['Add_DataItemType']
                dataitem_rwmode = ndataHKGItem['Add_DataItemRWmode']
                dataitem_report = ndataHKGItem['Add_DataItemReport']
                dataitem_config = ndataHKGItem['Add_DataItemConfig']
                dataitem_id = ndataHKGItem['Add_DataItemID']
                dataitem = ET.Element(
                    "dataItem", {
                        "id": dataitem_id,
                        "n": dataitem_name,
                        "alias": dataitem_alias,
                        "config": dataitem_config,
                        "type": dataitem_type,
                        "rw": dataitem_rwmode,
                        "freq": dataitem_fre,
                        "report": dataitem_report
                    })
                node.find('driver/commDataItems').append(dataitem)
            break
    updateVersion.write(agent_tree, global_var.itemconfig_path)
    # agent_tree.write(global_var.itemconfig_path, encoding='utf-8')


def set_dataitem_id():
    global dataitem_id
    '''增加dataitem_id值'''
    idconfig_tree = ET.parse(global_var.idconfig_path)
    idconfig = idconfig_tree.getroot()
    dataitem_node = idconfig_tree.find('ItemID')
    if dataitem_id != '0':
        dataitem_node.text = str(int(dataitem_id) + 1)
        ET.dump(idconfig_tree)
        updateVersion.write(idconfig_tree, global_var.idconfig_path)
        # idconfig_tree.write(global_var.idconfig_path,
        #                     encoding='utf-8',
        #                     xml_declaration='true')


if __name__ == '__main__':
    log = Loginfo.Loginfo()
    get_cgi_data()
    set_dataitem_id()