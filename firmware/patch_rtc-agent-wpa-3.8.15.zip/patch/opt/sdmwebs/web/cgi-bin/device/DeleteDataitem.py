#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xhzhang'

import xml.etree.ElementTree as ET
from config import global_var
from CGI import GetCgi
from Log import Loginfo
from rexml import updateVersion
import os, cgi
import Cookie

print "Content-Type: text/html charset=utf-8 \n"

device_id = ''
delete_id_list = ''


def get_cgi_data():
    global device_id, delete_id_list
    form = cgi.FieldStorage()
    device_id = form.getvalue('Delete_DeviceID_YuToXHZhang', '')
    delete_id_list = form.getvalue('Delete_DataItemAllID_YuToXHZhang',
                                   '').split(',')


def delete_dataitem_moduleconfig():
    '''获取cookie'''
    if 'HTTP_COOKIE' in os.environ:
        cookie_string = os.environ.get('HTTP_COOKIE')
        c = Cookie.SimpleCookie()
        c.load(cookie_string)
        data = c['AnyLinkLan'].value

    agent_tree = ET.parse(global_var.itemconfig_path)
    agent = agent_tree.getroot()

    device_node_list = agent_tree.findall('model/device')
    for device_node in device_node_list:
        if device_node.attrib['id'] == device_id:
            parient_node = device_node.find('driver/commDataItems')
            dataitem_node_list = parient_node.findall('dataItem')
            for dataitem_node in dataitem_node_list:
                for i in range(len(delete_id_list)):
                    if dataitem_node.get('id') == delete_id_list[i]:
                        parient_node.remove(dataitem_node)
                        if data == "English":
                            log.write_debug(
                                'Delete data item id=[%s]success.' %
                                (delete_id_list[i]))
                        else:
                            log.write_debug('删除数据项id=[%s]成功。' %
                                            (delete_id_list[i]))
                        continue
    # add by fyj, datahandler
    dhNode = agent_tree.find('task/TaskDriver/driver/dataHandler/config')
    if dhNode == None:
        #没有采用datahandler驱动, 不做处理
        updateVersion.write(agent_tree, global_var.itemconfig_path)
        # agent_tree.write(global_var.itemconfig_path, encoding='utf-8')
        return

    dhitem_node_list = dhNode.findall('item')
    for dhitem_node in dhitem_node_list:
        for i in range(len(delete_id_list)):
            if dhitem_node.get('id') == delete_id_list[i]:
                dhNode.remove(dhitem_node)
    dhitem_node_list = dhNode.findall('item')
    if len(dhitem_node_list) == 0:
        taskNode = agent_tree.find("task")
        tasks = taskNode.getchildren()
        dhtask = None
        for task in tasks:
            task_drivers = task.getchildren()
            task_driver = task_drivers[0]
            if task_driver.get('n') == 'T.IDrv.Task:libkdatahandler':
                dhtask = task
                break
        if dhtask:
            taskNode.remove(dhtask)
    # add end
    #ET.dump(agent_tree)
    updateVersion.write(agent_tree, global_var.itemconfig_path)
    # agent_tree.write(global_var.itemconfig_path, encoding='utf-8')


if __name__ == '__main__':
    log = Loginfo.Loginfo()
    get_cgi_data()
    delete_dataitem_moduleconfig()
