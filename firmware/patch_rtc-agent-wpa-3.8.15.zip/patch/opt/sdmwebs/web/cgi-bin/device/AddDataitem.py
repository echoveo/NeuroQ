#!/usr/bin/python
# -*- coding: UTF-8 -*-
# __author__ = 'xhzhang'
# Edit By Randy.Jang
# 2015/06/01

import xml.etree.ElementTree as ET
from config import global_var
from CGI import GetCgi
from Log import Loginfo
from QUIT import Quit
from rexml import updateVersion
import sys
import cgi
import os
import Cookie
reload(sys)
sys.setdefaultencoding('utf8')
print "Content-Type: text/html charset=utf-8 \n"

device_id = ''
dataitem_name = dataitem_id = dataitem_alias = dataitem_type = dataitem_rwmode = ''
dataitem_fre = dataitem_report = ''
parient_device_node = ''
dataitem_dhVal = ''
dataitem_optType = ''
dataitem_optParam = ''


def get_cgi_data():
    global device_id, dataitem_name, dataitem_alias, dataitem_id, dataitem_type, dataitem_fre, dataitem_report, dataitem_config, dataitem_rwmode, dataitem_dhVal, dataitem_optType, dataitem_optParam
    form = cgi.FieldStorage()
    device_id = form.getvalue('Add_DeviceID_YuToXHZhang', '')
    dataitem_name = form.getvalue('Add_DataItemName_YuToXHZhang', '')
    dataitem_alias = form.getvalue('Add_DataItemAlias_YuToXHZhang', '')
    dataitem_fre = form.getvalue('Add_DataItemFreq_YuToXHZhang', '')
    dataitem_type = form.getvalue('Add_DataItemType_YuToXHZhang', '')
    dataitem_rwmode = form.getvalue('Add_DataItemRWmode_YuToXHZhang', '')
    dataitem_report = form.getvalue('Add_DataItemReport_YuToXHZhang', '')
    dataitem_config = form.getvalue('Add_DataItemConfig_YuToXHZhang', '')
    dataitem_id = form.getvalue('Add_DataItemID_YuToXHZhang', '')
    dataitem_dhVal = form.getvalue('Add_DataItemDHEnable_YuToXHZhang', '')
    if dataitem_dhVal == '1':
        dataitem_optType = form.getvalue('Add_DataItemDHOptType_YuToXHZhang',
                                         '')
        dataitem_optParam = form.getvalue('Add_DataItemDHOptParam_YuToXHZhang',
                                          '')


def add_dataitem_moduleconfig():
    '''获取cookie'''
    if 'HTTP_COOKIE' in os.environ:
        cookie_string = os.environ.get('HTTP_COOKIE')
        c = Cookie.SimpleCookie()
        c.load(cookie_string)
        data = c['AnyLinkLan'].value

    global device_id, dataitem_name, dataitem_alias, dataitem_id, dataitem_type, dataitem_fre, dataitem_report, dataitem_config, dataitem_rwmode, dataitem_dhVal, dataitem_optType, dataitem_optParam
    if device_id == '0' or device_id == '':
        if data == "English":
            log.write_error(
                'When adding a data item, the device id is 0 or null.')
            Quit.quit_error('AddDataitem')
        else:
            log.write_error('添加数据项时，设备id为0或者空。')
            Quit.quit_error('AddDataitem')

    agent_tree = ET.parse(global_var.itemconfig_path)
    agent = agent_tree.getroot()
    dataitem = ET.Element('dataItem')
    dataitem.set('id', dataitem_id)
    dataitem.set('n', dataitem_name)
    # dataitem.set('alias',dataitem_alias)
    dataitem.set('config', dataitem_config)
    dataitem.set('type', dataitem_type)
    dataitem.set('rw', dataitem_rwmode)
    dataitem.set('freq', dataitem_fre)
    dataitem.set('report', dataitem_report)
    parient_node_list = agent_tree.findall('model')
    devicedriver = ''
    for model_node in parient_node_list:
        device_node_list = model_node.findall('device')
        for node in device_node_list:
            if node.attrib['id'] == device_id:
                devicedriver = model_node.get('devicedriver')
                # add by whc
                # if devicedriver != 'OPC':
                dataitem.set('alias', dataitem_alias)
                node.find('driver/commDataItems').append(dataitem)
                log.write_debug('添加数据项[%s]成功。' % (dataitem_name))
                break
        if devicedriver != '':
            break
    # add by fyj, datahandler
    if dataitem_dhVal == '1':
        dataitem_dh_item = ET.Element('item')
        dataitem_dh_item.set('n', dataitem_name)
        dataitem_dh_item.set('id', dataitem_id)
        if dataitem_optType == '1':
            dataitem_optType = '+'
        elif dataitem_optType == '2':
            dataitem_optType = '-'
        elif dataitem_optType == '3':
            dataitem_optType = '*'
        elif dataitem_optType == '4':
            dataitem_optType = '/'
        elif dataitem_optType == '5':
            dataitem_optType = 'b'
        dataitem_dh_item.set('op', dataitem_optType)
        if dataitem_optType == '#':
            linear_param_list = dataitem_optParam.split("|")
            coe = "(%s)*iv+(%s)" % (linear_param_list[0], linear_param_list[1])
            rcoe = "(iv-(%s))/(%s)" % (
                linear_param_list[1], linear_param_list[0])
            dataitem_dh_item.set('coe', coe)
            dataitem_dh_item.set('rcoe', rcoe)
        else:
            dataitem_dh_item.set('coe', dataitem_optParam)
        dhNode = agent.find('task/TaskDriver/driver/dataHandler/config')
        if dhNode == None:
            # 如果没有就自动创建
            task = agent.find('task')
            task_dh = ET.Element('TaskDriver')
            task.append(task_dh)
            task_dh_driver = ET.Element('driver')
            task_dh.append(task_dh_driver)
            task_dh_driver.set('n', 'T.IDrv.Task:libkdatahandler')
            task_dh_driver.set('id', '1')
            task_dh_driver.set('config', '')
            task_dh_datahandler = ET.Element('dataHandler')
            task_dh_driver.append(task_dh_datahandler)
            task_dh_datahandler.set('n', 'DH:libhcommon')
            task_dh_datahandler.set('id', '1')
            task_dh_datahandler.set('pri', '2')
            dhNode = ET.Element('config')
            task_dh_datahandler.append(dhNode)
        dhNode.append(dataitem_dh_item)
    # add end
    # agent_tree.write(global_var.itemconfig_path, encoding='utf-8')
    updateVersion.write(agent_tree, global_var.itemconfig_path)


def set_dataitem_id():
    '''获取cookie'''
    if 'HTTP_COOKIE' in os.environ:
        cookie_string = os.environ.get('HTTP_COOKIE')
        c = Cookie.SimpleCookie()
        c.load(cookie_string)
        data = c['AnyLinkLan'].value

    global device_id, dataitem_name, dataitem_alias, dataitem_id, dataitem_type, dataitem_fre, dataitem_report, dataitem_config, dataitem_rwmode
    '''增加dataitem_id值'''
    idconfig_tree = ET.parse(global_var.idconfig_path)
    idconfig = idconfig_tree.getroot()
    dataitem_node = idconfig_tree.find('ItemID')
    if data == "English":
        if dataitem_id != '0':
            dataitem_node.text = str(int(dataitem_id) + 1)
            log.write_debug('Data item id is increased to [%s]' %
                            (dataitem_id))
            ET.dump(idconfig_tree)
            updateVersion.write(idconfig_tree, global_var.idconfig_path)
            # idconfig_tree.write(global_var.idconfig_path,
            #                     encoding='utf-8',
            #                     xml_declaration='true')
        else:
            log.write_error('Data item id = 0')
            return
    else:
        if dataitem_id != '0':
            dataitem_node.text = str(int(dataitem_id) + 1)
            log.write_debug('数据项id增加到 [%s]' % (dataitem_id))
            ET.dump(idconfig_tree)
            updateVersion.write(idconfig_tree, global_var.idconfig_path)
            # idconfig_tree.write(global_var.idconfig_path,
            #                     encoding='utf-8',
            #                     xml_declaration='true')
        else:
            log.write_error('数据项id=0')
            return


if __name__ == '__main__':
    log = Loginfo.Loginfo()
    get_cgi_data()
    add_dataitem_moduleconfig()
    set_dataitem_id()
