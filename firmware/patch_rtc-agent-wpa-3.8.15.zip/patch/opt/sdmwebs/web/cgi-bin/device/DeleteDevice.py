#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xhzhang'

import xml.etree.ElementTree as ET
from config import global_var
from CGI import GetCgi
from Log import Loginfo
from rexml import updateVersion
import os, cgi
import Cookie

print "Content-Type: text/html charset=utf-8 \n"

channel_id = ''
device_id = ''
delete_task_driverid = ''


def get_cgi_data():
    global channel_id, device_id, delete_task_driverid
    form = cgi.FieldStorage()
    channel_id = form.getvalue('Alter_ChannelID_YuToXHZhang', '')
    device_id = form.getvalue('Alter_DeviceID_YuToXHZhang', '')
    delete_task_driverid = form.getvalue('Alter_TaskID_YuToXHZhang', '')


def delete_device_moduleconfig():
    '''获取cookie'''
    if 'HTTP_COOKIE' in os.environ:
        cookie_string = os.environ.get('HTTP_COOKIE')
        c = Cookie.SimpleCookie()
        c.load(cookie_string)
        data = c['AnyLinkLan'].value

    agent_tree = ET.parse(global_var.itemconfig_path)

    parient_node_list = agent_tree.findall('model')
    for node in parient_node_list:
        channel_node_id = node.get('id', default=None)
        if channel_node_id != None and channel_node_id == channel_id:
            children_node_list = node.getchildren()
            for child_node in children_node_list:
                if child_node.attrib['id'] == device_id:
                    node.remove(child_node)
                    if data == "English":
                        log.write_debug('Delete device[%s]success.' %
                                        (device_id))
                    else:
                        log.write_debug('删除设备[%s]成功。' % (device_id))
                    break
    if delete_task_driverid != 'NULL':
        task_root = agent_tree.find('task')
        task_node_list = task_root.findall('TaskDriver')
        '''for task_node in task_node_list:
            task_driver_node = task_node.find('driver')
            if task_driver_node.get('id') == delete_task_driverid and task_driver_node.get('n') != 'T.IDrv.Task:libkdatahandler':
                task_root.remove(task_node)
                log.write_debug('删除任务驱动[%s]成功。' %(delete_task_driverid))
                break'''
    # ET.dump(agent_tree)
    updateVersion.write(agent_tree, global_var.itemconfig_path)
    # agent_tree.write(global_var.itemconfig_path, encoding='utf-8')


def delete_device_datahandler():
    agent_tree = ET.parse(global_var.itemconfig_path)
    dhNode = agent_tree.find('task/TaskDriver/driver/dataHandler/config')
    if dhNode == None:
        updateVersion.write(agent_tree, global_var.itemconfig_path)
        # agent_tree.write(global_var.itemconfig_path, encoding='utf-8')
        return

    parient_node_list = agent_tree.findall('model')
    delete_id_list = []
    flag = False
    for node in parient_node_list:
        channel_node_id = node.get('id', default=None)
        if channel_node_id != None and channel_node_id == channel_id:
            children_node_list = node.getchildren()
            for child_node in children_node_list:
                if child_node.attrib['id'] == device_id:
                    flag = True
                    dataItemsNode = child_node.find('driver/commDataItems')
                    dataItem_nodes = dataItemsNode.getchildren()
                    for dataItem_node in dataItem_nodes:
                        delete_id_list.append(dataItem_node.attrib['id'])
                    break
            if flag:
                break

    dhitem_node_list = dhNode.findall('item')
    for dhitem_node in dhitem_node_list:
        for i in range(len(delete_id_list)):
            if dhitem_node.get('id') == delete_id_list[i]:
                dhNode.remove(dhitem_node)

    dhitem_node_list = dhNode.findall('item')
    if len(dhitem_node_list) == 0:
        taskNode = agent_tree.find("task")
        tasks = taskNode.getchildren()
        dhtask = None
        for task in tasks:
            task_drivers = task.getchildren()
            task_driver = task_drivers[0]
            if task_driver.get('n') == 'T.IDrv.Task:libkdatahandler':
                dhtask = task
                break
        if dhtask:
            taskNode.remove(dhtask)
    updateVersion.write(agent_tree, global_var.itemconfig_path)
    # agent_tree.write(global_var.itemconfig_path, encoding='utf-8')


if __name__ == '__main__':
    log = Loginfo.Loginfo()
    get_cgi_data()
    #add by fyj, 删除该设备下的在datahandler驱动中存在的数据项
    delete_device_datahandler()
    #add end
    delete_device_moduleconfig()