#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xhzhang'

import xml.etree.ElementTree as ET
from config import global_var
from CGI import GetCgi
from Log import Loginfo
from rexml import updateVersion
import sys, cgi
import os
import Cookie
reload(sys)
sys.setdefaultencoding('utf-8')

print "Content-Type: text/html charset=utf-8 \n"

device_id = ''
dataitem_name = dataitem_alias = dataitem_id = dataitem_type = dataitem_fre = dataitem_report = dataitem_config = dataitem_id_after = ''
dataitem_dhVal = ''
dataitem_optType = ''
dataitem_optParam = ''


def get_cgi_data():
    global device_id, dataitem_name, dataitem_alias, dataitem_id, dataitem_type, dataitem_fre, dataitem_report, dataitem_config, dataitem_rwmode, dataitem_id_after, dataitem_dhVal, dataitem_optType, dataitem_optParam
    form = cgi.FieldStorage()
    device_id = form.getvalue('Alter_DeviceID_YuToXHZhang', '')
    dataitem_name = form.getvalue('Alter_DataItemName_YuToXHZhang', '')
    dataitem_alias = form.getvalue('Alter_DataItemAlias_YuToXHZhang', '')
    dataitem_id = form.getvalue('Alter_DataItemID_YuToXHZhang', '')
    dataitem_type = form.getvalue('Alter_DataItemType_YuToXHZhang', '')
    dataitem_rwmode = form.getvalue('Alter_DataItemRWmode_YuToXHZhang', '')
    dataitem_fre = form.getvalue('Alter_DataItemFreq_YuToXHZhang', '')
    dataitem_report = form.getvalue('Alter_DataItemReport_YuToXHZhang', '')
    dataitem_config = form.getvalue('Alter_DataItemConfig_YuToXHZhang', '')
    dataitem_id_after = form.getvalue('Alter_DataItemID_after', '')
    dataitem_dhVal = form.getvalue('Alter_DataItemDHEnable_YuToXHZhang', '')
    dataitem_optType = form.getvalue('Alter_DataItemDHOptType_YuToXHZhang', '')
    if dataitem_dhVal == '1':
        if dataitem_optType == '1':
            dataitem_optType = '+'
        elif dataitem_optType == '2':
            dataitem_optType = '-'
        elif dataitem_optType == '3':
            dataitem_optType = '*'
        elif dataitem_optType == '4':
            dataitem_optType = '/'
        elif dataitem_optType == '5':
            dataitem_optType = 'b'
    dataitem_optParam = form.getvalue('Alter_DataItemDHOptParam_YuToXHZhang',
                                      '')


def alter_dataitem_moduleconfig():
    '''获取cookie'''
    if 'HTTP_COOKIE' in os.environ:
        cookie_string = os.environ.get('HTTP_COOKIE')
        c = Cookie.SimpleCookie()
        c.load(cookie_string)
        data = c['AnyLinkLan'].value

    agent_tree = ET.parse(global_var.itemconfig_path)
    agent = agent_tree.getroot()
    model_node_list = agent_tree.findall('model')
    # device_node_list = agent_tree.findall('model/device')
    devicedriver = ''
    for model_node in model_node_list:
        device_node_list = model_node.findall('device')
        if device_node_list != []:
            for device_node in device_node_list:
                if device_node.attrib['id'] == device_id:
                    dataitem_node_list = device_node.findall(
                        'driver/commDataItems/dataItem')
                    for dataitem_node in dataitem_node_list:
                        if dataitem_node.attrib['id'] == dataitem_id:
                            dataitem_node.set('n', dataitem_name)
                            #dataitem_node.set('alias',dataitem_alias)
                            dataitem_node.set('type', dataitem_type)
                            dataitem_node.set('rw', dataitem_rwmode)
                            dataitem_node.set('freq', dataitem_fre)
                            dataitem_node.set('report', dataitem_report)
                            dataitem_node.set('config', dataitem_config)
                            dataitem_node.set('id', dataitem_id_after)
                            devicedriver = model_node.get('devicedriver')
                            #add by whc
                            #if devicedriver != 'OPC':
                            dataitem_node.set('alias', dataitem_alias)
                            if data == "English":
                                log.write_debug(
                                    'Modify data item[%s]success.' %
                                    (dataitem_name))
                            else:
                                log.write_debug('修改数据项[%s]成功。' %
                                                (dataitem_name))
                            break
            if devicedriver != '':
                break
        else:
            if data == "English":
                log.write_error('No device cannot modify the data item.')
            else:
                log.write_error('无设备无法修改数据项。')
    #add by fyj, hostlink add datahandler
    dhNode = agent_tree.find('task/TaskDriver/driver/dataHandler/config')
    if dhNode == None:
        #如果没有就自动创建
        task = agent.find('task')
        task_dh = ET.Element('TaskDriver')
        task.append(task_dh)
        task_dh_driver = ET.Element('driver')
        task_dh.append(task_dh_driver)
        task_dh_driver.set('n', 'T.IDrv.Task:libkdatahandler')
        task_dh_driver.set('id', '1')
        task_dh_driver.set('config', '')
        task_dh_datahandler = ET.Element('dataHandler')
        task_dh_driver.append(task_dh_datahandler)
        task_dh_datahandler.set('n', 'DH:libhcommon')
        task_dh_datahandler.set('id', '1')
        task_dh_datahandler.set('pri', '2')
        dhNode = ET.Element('config')
        task_dh_datahandler.append(dhNode)

    dhnode_list = dhNode.findall('item')
    isExist = False
    if dhnode_list != []:
        for dhitem_node in dhnode_list:
            if dhitem_node.attrib['id'] == dataitem_id:
                isExist = True
                #此dataitem原来存在于datahandler中
                if dataitem_dhVal == '0':
                    #删除datahandler中的item
                    dhNode.remove(dhitem_node)
                elif dataitem_dhVal == '1':
                    #更新datahandler中的item
                    dhitem_node.set('n', dataitem_name)
                    dhitem_node.set('id', dataitem_id_after)
                    dhitem_node.set('op', dataitem_optType)
                    if dataitem_optType == '#':
                        linear_param_list = dataitem_optParam.split("|")
                        coe = "(%s)*iv+(%s)" % (linear_param_list[0], linear_param_list[1])
                        rcoe = "(iv-(%s))/(%s)" % (
                            linear_param_list[1], linear_param_list[0])
                        dhitem_node.set('coe', coe)
                        dhitem_node.set('rcoe', rcoe)
                    else:
                        dhitem_node.set('coe', dataitem_optParam)
                        if 'rcoe' in dhitem_node.attrib:
                            del dhitem_node.attrib['rcoe']
                break
    if isExist == False and dataitem_dhVal == '1':
        #此dataitem原来不存在于datahandler中
        dhitemNode = ET.Element('item')
        dhNode.append(dhitemNode)
        dhitemNode.set('n', dataitem_name)
        dhitemNode.set('id', dataitem_id_after)
        dhitemNode.set('op', dataitem_optType)
        if dataitem_optType == '#':
            linear_param_list = dataitem_optParam.split("|")
            coe = "(%s)*iv+(%s)" % (linear_param_list[0], linear_param_list[1])
            rcoe = "(iv-(%s))/(%s)" % (
                linear_param_list[1], linear_param_list[0])
            dhitemNode.set('coe', coe)
            dhitemNode.set('rcoe', rcoe)
        else:
            dhitemNode.set('coe', dataitem_optParam)

    #如果 datahandler驱动中没有items 就删除这个 taskdriver
    dhitems = dhNode.getchildren()
    if len(dhitems) == 0:
        taskNode = agent_tree.find("task")
        tasks = taskNode.getchildren()
        dhtask = None
        for task in tasks:
            task_drivers = task.getchildren()
            task_driver = task_drivers[0]
            if task_driver.get('n') == 'T.IDrv.Task:libkdatahandler':
                dhtask = task
                break
        if dhtask:
            taskNode.remove(dhtask)
    #add end
    updateVersion.write(agent_tree, global_var.itemconfig_path)
    # agent_tree.write(global_var.itemconfig_path, encoding='utf-8')


if __name__ == '__main__':
    log = Loginfo.Loginfo()
    get_cgi_data()
    alter_dataitem_moduleconfig()