#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xhzhang'

import xml.etree.ElementTree as ET
from config import global_var
from Log import Loginfo
import sys
import cgi
import os
import Cookie
reload(sys)
sys.setdefaultencoding('utf-8')

print "Content-Type: text/html charset=utf-8 \n"

device_id = ''
dataitem_name = ''
comparison_operator = ''
operand1 = ''
operand2 = ''
action = ''


def get_cgi_data():
    global device_id, dataitem_name, comparison_operator, operand1, operand2, action
    form = cgi.FieldStorage()
    device_id = form.getvalue('deviceID', '')
    dataitem_name = form.getvalue('dateitemName', '')
    comparison_operator = form.getvalue('comparison-operator', '')
    operand1 = form.getvalue('operand1', '')
    operand2 = form.getvalue('operand2', '')
    action = form.getvalue('action', '')

    #print channel_name,channel_id,channel_driver,channel_config,device_driver


def run():
    if 'HTTP_COOKIE' in os.environ:
        cookie_string = os.environ.get('HTTP_COOKIE')
        c = Cookie.SimpleCookie()
        c.load(cookie_string)
        data = c['AnyLinkLan'].value

    agent_tree = ET.parse(global_var.itemconfig_path)
    device_node = agent_tree.find('./model/device[@id="%s"]' % device_id)

    common_node = device_node.find("driver/commDataItems")

    dateitem_node = common_node.find('dataItem[@n="%s"]' % dataitem_name)

    dateitem_node.set("report", "3")
    dateitem_node.set("rstype", "5")
    if comparison_operator == '1':
        dateitem_node.set("rsvalue", "(%s,~)" % operand1)
    elif comparison_operator == '2':
        dateitem_node.set("rsvalue", "(~,%s)" % operand1)
    elif comparison_operator == '3':
        dateitem_node.set("rsvalue", "(%s,%s)" % (operand1, operand2))
    common_node.remove(dateitem_node)
    common_node.insert(0, dateitem_node)
    agent_tree.write(global_var.itemconfig_path, encoding='utf-8')
    if data == "English":
        print "Success!"
    else:
        print "设置成功！"


if __name__ == '__main__':
    log = Loginfo.Loginfo()
    get_cgi_data()
    run()
