#!/usr/bin/python
# -*- coding=utf-8 -*-
#author : Randy.Jang

from config import global_var
from CGI import GetCgi
from Log import Loginfo
from QUIT import Quit
from rexml import updateVersion
import xml.etree.ElementTree as ET
import sys, cgi
import os
import Cookie
reload(sys)
sys.setdefaultencoding('utf8')
print 'Content-Type: text/html charset=utf-8 \n'

device_id = ''
item_id = ''


def get_cgi_data():
    global device_id, item_id, delete_id_list
    form = cgi.FieldStorage()
    device_id = form.getvalue('Delete_DeviceID_YuToXHZhang', '')
    item_id = form.getvalue('Delete_RuleID_YuToJSzhou', '')

    # device_id = '1000224'
    # item_id ='24332,4'
    delete_id_list = item_id.split(',')


def delete_rule():
    '''获取cookie'''
    if 'HTTP_COOKIE' in os.environ:
        cookie_string = os.environ.get('HTTP_COOKIE')
        c = Cookie.SimpleCookie()
        c.load(cookie_string)
        data = c['AnyLinkLan'].value

    agent_tree = ET.parse(global_var.itemconfig_path)
    # agent_tree = ET.parse('./test_rule.xml')

    device_node_list = agent_tree.findall('model/device')
    for device_node in device_node_list:
        if device_node.attrib['id'] == device_id:
            parient_node = device_node.find('Rules')
            rule_list = parient_node.findall('rule')
            if parient_node != None and rule_list != []:
                for node in rule_list:
                    for i in range(len(delete_id_list)):
                        print "Compare", node.get('id'), delete_id_list[i]
                        if node.get('id') == delete_id_list[i]:
                            parient_node.remove(node)
                            # del delete_id_list[i]
                            # rule_list.remove(node)
                            if data == "English":
                                log.write_debug(
                                    'Delete data item id=[%s]success.' %
                                    (delete_id_list[i]))
                            else:
                                log.write_debug('删除数据项id=[%s]成功。' %
                                                (delete_id_list[i]))
                            print "Delete Success"
                            break
    print "Finished.."
    # agent_tree.write('./test_rule.xml',encoding='utf-8')
    updateVersion.write(agent_tree, global_var.itemconfig_path)
    # agent_tree.write(global_var.itemconfig_path, encoding='utf-8')


if __name__ == '__main__':
    log = Loginfo.Loginfo()
    get_cgi_data()
    delete_rule()
