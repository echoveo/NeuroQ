#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xhzhang'

import xml.etree.ElementTree as ET
from config import global_var
from Log import Loginfo
import os
import re
import Cookie


def get_re_driver_config(driver_type, new_config, old_config):
    '''当通道驱动和设备驱动的config信息个数不一致时，需要将二者统一，得到新的config序列。
    西门子设备----远程地址(PPI)和站地址(MPI)
    松下设备----远程地址
    AB-MicroLogix和AB-Ethernet/IP----设备IP
    driver格式：设备ip;响应延时
    eg. 2016/07/21
    三菱-------站号(MITSUBISHI-FXS)
    '''

    device_type = global_var.AnyLinkType
    re_config = new_config

    type_tup = ('SIEMENS-PPI', 'SIEMENS-MPI', 'Panasonic')
    type_tup_reserve = ('AB-Ethernet/IP', 'AB-MicroLogix')

    if driver_type in type_tup:
        config_list = old_config.split(';')
        re_add = config_list[len(config_list)-1]
        re_config = new_config + ';' + re_add
        return re_config

    if driver_type in type_tup_reserve:
        config_list = old_config.split(';')
        # 获取设备ip
        re_add = config_list[0]
        re_config = re_add + ';' + new_config
        return re_config

    if device_type == "DA":
        if driver_type == "MITSUBISHI-FXS":
            config_list = old_config.split(';')
            re_add = config_list[len(config_list)-1]
            re_config = new_config + ';' + re_add
            return re_config

    if driver_type == "FATEK编程口":
        config_list = old_config.split(';')
        re_add = config_list[len(config_list)-1]
        re_config = new_config + ';' + re_add
        return re_config

    elif device_type == "RF":
        if driver_type == "MITSUBISHI-FXP":
            config_list = old_config.split(';')
            re_add = config_list[len(config_list)-1]
            re_config = new_config + ';' + re_add
            return re_config

        elif driver_type == "MITSUBISHI-FXS":
            config_list = old_config.split(';')
            re_station = config_list[len(config_list) - 3]
            re_net = config_list[len(config_list) - 1]
            new_list = new_config.rsplit(';', 1)
            re_config = new_list[0] + ";" + re_station + \
                ";" + new_list[1] + ";" + re_net
            return re_config

    return re_config
