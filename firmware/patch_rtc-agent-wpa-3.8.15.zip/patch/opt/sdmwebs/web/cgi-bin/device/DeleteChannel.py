#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xhzhang'

import xml.etree.ElementTree as ET
from config import global_var
from CGI import GetCgi
from Log import Loginfo
from rexml import updateVersion
import os, cgi
import Cookie

print "Content-Type: text/html charset=utf-8 \n"

channel_id = delete_task_driverid = ''


def get_cgi_data():
    global channel_id, delete_task_driverid
    form = cgi.FieldStorage()
    channel_id = form.getvalue('Alter_ChannelID_YuToXHZhang', '')
    delete_task_driverid = form.getvalue('Alter_TaskID_YuToXHZhang', '')


def delete_channel():
    '''获取cookie'''
    if 'HTTP_COOKIE' in os.environ:
        cookie_string = os.environ.get('HTTP_COOKIE')
        c = Cookie.SimpleCookie()
        c.load(cookie_string)
        data = c['AnyLinkLan'].value

    agent_tree = ET.parse(global_var.itemconfig_path)
    agent = agent_tree.getroot()

    delete_node_list = agent_tree.findall('model')
    for node in delete_node_list:
        channel_node_id = node.get('id', default=None)
        if channel_node_id != None and channel_node_id == channel_id:
            agent.remove(node)
            if data == "English":
                log.write_debug('Delete channel[%s]success' % (channel_id))
            else:
                log.write_debug('删除通道[%s]成功。' % (channel_id))
            break
    # ET.dump(agent_tree)
    updateVersion.write(agent_tree, global_var.itemconfig_path)
    # agent_tree.write(global_var.itemconfig_path, encoding='utf-8')


def delete_task():
    '''获取cookie'''
    if 'HTTP_COOKIE' in os.environ:
        cookie_string = os.environ.get('HTTP_COOKIE')
        c = Cookie.SimpleCookie()
        c.load(cookie_string)
        data = c['AnyLinkLan'].value
    '''delete task driver node'''
    agent_tree = ET.parse(global_var.itemconfig_path)
    task_root = agent_tree.find('task')
    task_node_list = task_root.findall('TaskDriver')
    for task_node in task_node_list:
        task_driver_node = task_node.find('driver')
        if task_driver_node.get('id') == channel_id and task_driver_node.get(
                'n') != 'T.IDrv.Task:libkdatahandler':
            task_root.remove(task_node)
            if data == 'English':
                log.write_debug('Delete task driver[%s]success.' %
                                (delete_task_driverid))
            else:
                log.write_debug('删除任务驱动[%s]成功。' % (delete_task_driverid))
            break
    updateVersion.write(agent_tree, global_var.itemconfig_path)
    # agent_tree.write(global_var.itemconfig_path, encoding='utf-8')


def delete_channel_datahandler():
    agent_tree = ET.parse(global_var.itemconfig_path)
    dhNode = agent_tree.find('task/TaskDriver/driver/dataHandler/config')
    if dhNode == None:
        updateVersion.write(agent_tree, global_var.itemconfig_path)
        # agent_tree.write(global_var.itemconfig_path, encoding='utf-8')
        return

    parient_node_list = agent_tree.findall('model')
    delete_id_list = []
    for node in parient_node_list:
        channel_node_id = node.get('id', default=None)
        if channel_node_id != None and channel_node_id == channel_id:
            dataItemsNode = node.findall('device/driver/commDataItems')
            for child_node in dataItemsNode:
                dataItem_nodes = child_node.getchildren()
                for dataItem_node in dataItem_nodes:
                    delete_id_list.append(dataItem_node.attrib['id'])
            break

    dhitem_node_list = dhNode.findall('item')
    for dhitem_node in dhitem_node_list:
        for i in range(len(delete_id_list)):
            if dhitem_node.get('id') == delete_id_list[i]:
                dhNode.remove(dhitem_node)

    dhitem_node_list = dhNode.findall('item')
    if len(dhitem_node_list) == 0:
        taskNode = agent_tree.find("task")
        tasks = taskNode.getchildren()
        dhtask = None
        for task in tasks:
            task_drivers = task.getchildren()
            task_driver = task_drivers[0]
            if task_driver.get('n') == 'T.IDrv.Task:libkdatahandler':
                dhtask = task
                break
        if dhtask:
            taskNode.remove(dhtask)
    updateVersion.write(agent_tree, global_var.itemconfig_path)
    # agent_tree.write(global_var.itemconfig_path, encoding='utf-8')


if __name__ == '__main__':
    log = Loginfo.Loginfo()
    get_cgi_data()
    #add by fyj, 删除该通道下的在datahandler驱动中存在的数据项
    delete_channel_datahandler()
    #add end
    delete_channel()
    delete_task()
