#!/usr/bin/python
# -*- coding=utf-8 -*-
#author : Randy.Jang

from config import global_var
from Log import Loginfo
from QUIT import Quit
from rexml import updateVersion
import xml.etree.ElementTree as ET
import sys, cgi
import os
import Cookie
reload(sys)
sys.setdefaultencoding('utf8')
print 'Content-Type: text/html charset=utf-8 \n'

device_id = ''
rule_name = rule_id = item_tag = rule_operator = item_des = rule_operand = item_severity = item_logicaloper = ''


def get_cgi_data():
    global device_id, rule_name, rule_id, item_tag, rule_operator, item_des, rule_operand, item_severity, item_logicaloper
    form = cgi.FieldStorage()
    device_id = form.getvalue('Add_DeviceID_YuToXHZhang', '')
    rule_name = form.getvalue('Add_RuleName_YuToJSzhou', '')
    rule_id = form.getvalue('Add_RuleID_YuToJSzhou', '')
    item_tag = form.getvalue('Add_TagName_YuToJSzhou', '')
    rule_operator = form.getvalue('Add_Condition_YuToJSzhou', '')
    rule_operand = form.getvalue('Add_L_YuToJSzhou', '')
    item_des = form.getvalue('Add_Des_YuToJSzhou', '')
    item_severity = form.getvalue('Add_Severity_YuToJSzhou', '')
    item_logicaloper = form.getvalue('Add_logicaloper_YuToJSzhou', '')


def add_rule():
    '''获取cookie'''
    if 'HTTP_COOKIE' in os.environ:
        cookie_string = os.environ.get('HTTP_COOKIE')
        c = Cookie.SimpleCookie()
        c.load(cookie_string)
        data = c['AnyLinkLan'].value

    global device_id, rule_name, rule_id, item_tag, rule_operator, item_des, rule_operand, item_severity
    if device_id == '0' or device_id == '':
        print "Device", device_id
        if data == "English":
            log.write_error(
                'When the alarm rule is added, the device id is 0 or null.')
        else:
            log.write_error('添加报警规则时，设备id为0或者空。')
        Quit.quit_error('AddRule')
    agent_tree = ET.parse(global_var.itemconfig_path)
    rules = ET.Element('Rules')
    rule = ET.Element('rule')
    print 'set id to rule.'

    rule_id = str(int(rule_id) + 1)
    print 'id add 1.'

    rule.set('id', rule_id)
    rule.set('name', rule_name)
    print 'finish setting.'

    triggers = ET.Element('Triggers')
    operator = rule_operator.split(';')
    diNumber = len(operator) - 1
    operand = rule_operand.split(';')
    item_name = item_tag.split(';')

    trigger = ET.Element('trigger')
    trigger.set('name', rule_name)
    trigger.set('type', '1')
    if diNumber == 1:
        trigger.set('relation', '0')
    elif diNumber > 1:
        relationStr = '0'
        i = 1
        while (i < diNumber):
            if item_logicaloper == 'and':
                relationStr = relationStr + '&' + str(i)
            elif item_logicaloper == 'or':
                relationStr = relationStr + '|' + str(i)
            i = i + 1
        trigger.set('relation', relationStr)
    actions = ET.Element('Actions')
    action = ET.Element('action')
    action.set('name', rule_name)
    action.set('type', '1')
    action.set('alarm', rule_name)
    action.set('severity', item_severity)
    action.set('descr', item_des)

    parient_node_list = agent_tree.findall('model/device')
    for node in parient_node_list:
        print node.attrib['id'], device_id
        if node.attrib['id'] == device_id:
            if node.find('Rules') == None:
                node.append(rules)
            else:
                tmp = node.findall('Rules/rule')
                if tmp != []:
                    for inode in tmp:
                        print "find.."
                        if inode.attrib['id'] == rule_id:
                            return False
            node.find('Rules').append(rule)
            print "append rule ok"
            for inode in node.findall('Rules/rule'):
                print inode.attrib['id'], rule_id
                if inode.attrib['id'] == rule_id:
                    inode.append(triggers)
                    inode.append(actions)
                    inode.find('Triggers').append(trigger)
                    print "append trigger ok"
                    for i in range(diNumber):
                        di = ET.Element('di')
                        di.set('name', item_name[i])
                        di.set('id', str(i))
                        di.set('dep', '')
                        di.set('opr', operator[i])
                        di.set('opd', operand[i])
                        inode.find('Triggers/trigger').append(di)

                    inode.find('Actions').append(action)
                    print "Add Finished"
                    if data == "English":
                        log.write_debug('Add rules[%s]success.' % (rule_name))
                    else:
                        log.write_debug('添加规则[%s]成功。' % (rule_name))
                    break
            break
    # agent_tree.write('./test_rule.xml',encoding='utf-8')
    updateVersion.write(agent_tree, global_var.itemconfig_path)
    # agent_tree.write(global_var.itemconfig_path, encoding='utf-8')
    return True


def set_item_id():
    '''获取cookie'''
    if 'HTTP_COOKIE' in os.environ:
        cookie_string = os.environ.get('HTTP_COOKIE')
        c = Cookie.SimpleCookie()
        c.load(cookie_string)
        data = c['AnyLinkLan'].value
    '''增加item_id值'''
    global device_id, rule_name, rule_id, item_tag, rule_operator, item_des, rule_operand, item_severity
    idconfig_tree = ET.parse(global_var.idconfig_path)
    idconfig = idconfig_tree.getroot()
    item_node = idconfig_tree.find('RuleID')
    if rule_id != '0':
        item_node.text = rule_id
        log.write_debug('规则id增加到 [%s]' % (rule_id))
        ET.dump(idconfig_tree)
        updateVersion.write(idconfig_tree, global_var.idconfig_path)
        # idconfig_tree.write(global_var.idconfig_path,
        #                     encoding='utf-8',
        #                     xml_declaration='true')
    else:
        log.write_error('规则id=0')
        return


if __name__ == '__main__':
    log = Loginfo.Loginfo()
    get_cgi_data()
    print 'get date.'
    add_rule()
    print 'rule add.'
    set_item_id()
    print 'set max id.'