#!/usr/bin/python
# -*- coding: UTF-8 -*-
import xml.etree.ElementTree as ET


def add_TX_dataitem(xml_name, agent_tree, commDataItems_node):
    max_id = get_max_item_id(agent_tree)
    datahandler_config_node = add_datahandler(agent_tree)

    dataitem_tree = ET.parse("/opt/sdmwebs/web/conf/"+xml_name)
    dataitem_node_list = dataitem_tree.findall("commDataItems/dataItem")
    tx_datahandler_node_list = dataitem_tree.find("config")

    for dataitem_node in dataitem_node_list:
        dataitem_id = dataitem_node.attrib['id']
        dataitem_node.set('id', str(max_id))
        commDataItems_node.append(dataitem_node)

        datahandler_node = tx_datahandler_node_list.find(
            'item[@id="' + dataitem_id + '"]')
        if datahandler_node is not None:
            dhitemNode = ET.Element('item')
            dhitemNode.set('n', datahandler_node.attrib['n'])
            dhitemNode.set('id', str(max_id))
            dhitemNode.set('op', datahandler_node.attrib['op'])
            dhitemNode.set('coe', datahandler_node.attrib['coe'])
            if datahandler_node.get("rcoe") is not None:
                dhitemNode.set('rcoe', datahandler_node.attrib['rcoe'])
            datahandler_config_node.append(dhitemNode)
        max_id = max_id + 1


def add_datahandler(agent_tree):
    dhNode = agent_tree.find('task/TaskDriver/driver/dataHandler/config')
    if dhNode is None:
        agent = agent_tree.getroot()
        # 如果没有就自动创建
        task = agent.find('task')
        task_dh = ET.Element('TaskDriver')
        task.append(task_dh)
        task_dh_driver = ET.Element('driver')
        task_dh.append(task_dh_driver)
        task_dh_driver.set('n', 'T.IDrv.Task:libkdatahandler')
        task_dh_driver.set('id', '1')
        task_dh_driver.set('config', '')
        task_dh_datahandler = ET.Element('dataHandler')
        task_dh_driver.append(task_dh_datahandler)
        task_dh_datahandler.set('n', 'DH:libhcommon')
        task_dh_datahandler.set('id', '1')
        task_dh_datahandler.set('pri', '2')
        dhNode = ET.Element('config')
        task_dh_datahandler.append(dhNode)
    return dhNode


def get_max_item_id(agent_tree):
    item_node_list = agent_tree.findall(
        'model/device/driver/commDataItems/dataItem')
    max_id = 0
    for item_node in item_node_list:
        dataitem_id = int(item_node.attrib['id'])
        if dataitem_id > max_id:
            max_id = dataitem_id
    return max_id + 1
