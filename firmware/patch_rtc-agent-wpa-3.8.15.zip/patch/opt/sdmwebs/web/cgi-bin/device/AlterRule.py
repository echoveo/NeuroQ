#!/usr/bin/python
# -*- coding=utf-8 -*-
#author : Randy.Jang

import xml.etree.ElementTree as ET
from config import global_var
from Log import Loginfo
from rexml import updateVersion
import sys
import os
import Cookie
import cgi
reload(sys)
sys.setdefaultencoding('utf8')

print "Content-Type: text/html charset=utf-8 \n"

device_id = rule_name = rule_id = item_tag = rule_operator = item_des = rule_operand = item_severity = item_logicaloper = ''


def get_cgi_data():
    global device_id, rule_name, rule_id, item_tag, rule_operator, item_des, rule_operand, item_severity, item_logicaloper
    form = cgi.FieldStorage()
    device_id = form.getvalue('Alter_DeviceID_YuToXHZhang', '')
    rule_name = form.getvalue('Alter_RuleName_YuToJSzhou', '')
    rule_id = form.getvalue('Alter_RuleID_YuToJSzhou', '')
    item_tag = form.getvalue('Alter_TagName_YuToJSzhou', '')
    rule_operator = form.getvalue('Alter_Condition_YuToJSzhou', '')
    rule_operand = form.getvalue('Alter_L_YuToJSzhou', '')
    item_des = form.getvalue('Alter_Des_YuToJSzhou', '')
    print item_des
    item_severity = form.getvalue('Alter_Severity_YuToJSzhou', '')
    item_logicaloper = form.getvalue('Alter_logicaloper_YuToJSzhou', '')


def alter_rule():
    '''获取cookie'''
    if 'HTTP_COOKIE' in os.environ:
        cookie_string = os.environ.get('HTTP_COOKIE')
        c = Cookie.SimpleCookie()
        c.load(cookie_string)
        data = c['AnyLinkLan'].value

    agent_tree = ET.parse(global_var.itemconfig_path)

    device_node_list = agent_tree.findall('model/device')
    if device_node_list != []:
        for device_node in device_node_list:
            if device_node.attrib['id'] == device_id:
                node_list = device_node.findall('Rules/rule')
                for node in node_list:
                    if node.attrib['id'] == rule_id:
                        print 'found..'
                        node.set('name', rule_name)
                        operator = rule_operator.split(';')
                        operand = rule_operand.split(';')
                        diNumber = len(operator) - 1
                        item_name = item_tag.split(';')

                        trigger = node.find('Triggers/trigger')
                        trigger.set('name', rule_name)
                        trigger.set('type', '1')
                        if diNumber == 1:
                            trigger.set('relation', '0')
                        else:
                            relationStr = '0'
                            i = 1
                            while (i < diNumber):
                                if item_logicaloper == 'and':
                                    relationStr = relationStr + '&' + str(i)
                                elif item_logicaloper == 'or':
                                    relationStr = relationStr + '|' + str(i)
                                i = i + 1
                            trigger.set('relation', relationStr)
                        di_list = trigger.findall('di')
                        for di_node in di_list:
                            trigger.remove(di_node)

                        for i in range(diNumber):
                            di = ET.Element('di')
                            di.set('name', item_name[i])
                            di.set('id', str(i))
                            di.set('dep', '')
                            di.set('opr', operator[i])
                            di.set('opd', operand[i])
                            trigger.append(di)

                        action = node.find('Actions/action')
                        action.set('name', rule_name)
                        action.set('type', '1')
                        action.set('alarm', rule_name)
                        action.set('severity', item_severity)
                        action.set('descr', item_des)
                        if data == "English":
                            log.write_debug('Modify rule[%s]success.' %
                                            (item_name))
                        else:
                            log.write_debug('修改规则[%s]成功。' % (item_name))
                        break
    else:
        if data == "English":
            log.write_error('No device cannot modify the rule.')
        else:
            log.write_error('无设备无法修改规则。')
    # agent_tree.write('./test_rule.xml',encoding='utf-8')
    updateVersion.write(agent_tree, global_var.itemconfig_path)
    # agent_tree.write(global_var.itemconfig_path, encoding='utf-8')


if __name__ == '__main__':
    log = Loginfo.Loginfo()
    get_cgi_data()
    alter_rule()
