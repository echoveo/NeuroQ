#!/usr/bin/python
# -*- coding: UTF-8 -*-
__author__ = 'xhzhang'

import xml.etree.ElementTree as ET
from config import global_var
from CGI import GetCgi
from Log import Loginfo
from rexml import updateVersion
import os
import sys, cgi
import Cookie
reload(sys)
sys.setdefaultencoding('utf-8')

print "Content-Type: text/html charset=utf-8 \n"

device_name = device_ip = device_id = device_model = device_type = ''
device_driver_name = device_driver_config = device_driver_id = ''
remoteaddress = ''


def get_cgi_data():
    global device_name, device_ip, device_id, device_model, device_driver_name, device_driver_config, device_driver_id, device_type, remoteaddress
    form = cgi.FieldStorage()
    device_name = form.getvalue('Alter_DeviceName_YuToXHZhang', '')
    device_ip = form.getvalue('Alter_DeviceIP_YuToXHZhang', '')
    device_id = form.getvalue('Alter_DeviceID_YuToXHZhang', '')
    device_model = form.getvalue('Alter_DeviceModel_YuToXHZhang', '')
    device_driver_name = form.getvalue('Alter_ChannelModelType_YuToXHZhang',
                                       '')
    device_driver_config = form.getvalue('Alter_ChannelConfig_YuToXHZhang', '')
    device_driver_id = form.getvalue('Alter_DriverID_YuToXHZhang', '')
    device_type = form.getvalue('Alter_DeviceType_YuToXHZhang', '')
    remoteaddress = form.getvalue('Alter_DeviceRemoteAddress_YuToXHZhang', '')


def alter_device_moduleconfig():
    '''获取cookie'''
    if 'HTTP_COOKIE' in os.environ:
        cookie_string = os.environ.get('HTTP_COOKIE')
        c = Cookie.SimpleCookie()
        c.load(cookie_string)
        data = c['AnyLinkLan'].value

    agent_tree = ET.parse(global_var.itemconfig_path)
    # agent = agent_tree.getroot()
    device_node_list = agent_tree.findall('model/device')
    for device_node in device_node_list:
        if device_node.attrib['id'] == device_id:
            device_node.set('n', device_name)
            device_node.set('ip', device_ip)
            device_node.set('type', device_type)
            driver_node = device_node.find('driver')
            if driver_node.attrib['id'] == device_driver_id:
                driver_node.set('n', device_driver_name)
                driver_node.set('config', device_driver_config)
            if data == "English":
                log.write_debug('Modify device[%s]success.' % (device_name))
            else:
                log.write_debug('修改设备[%s]成功。' % (device_name))
            break
    #ET.dump(agent_tree)
    updateVersion.write(agent_tree, global_var.itemconfig_path)
    # agent_tree.write(global_var.itemconfig_path, encoding='utf-8')


if __name__ == '__main__':
    log = Loginfo.Loginfo()
    get_cgi_data()
    alter_device_moduleconfig()
