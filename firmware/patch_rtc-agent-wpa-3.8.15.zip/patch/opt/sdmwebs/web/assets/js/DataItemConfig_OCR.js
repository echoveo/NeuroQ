document.writeln("<script src=\"assets/js/effect_Com.js?t="+(new Date()).getTime()+"\" type=\"text/javascript\" charset=\"utf-8\"></script>");
CheckLogin();
$.ajaxSetup({
    cache: false
});
//全局变量
var diffCol = 1000000000000;
var EditChange = 100000000000000;
//通道ID
var ChannelID = "";
//设备ID
var DeviceID = "";
//驱动ID
var DriverID = "";
//校验所需要的
var category = "";
//数据项总数    
var DataItemNum = "";
//设备驱动类型
var ChannelDriver = "";
//设备的驱动类型
var ChannelDeviceType = "";
var ZundarConfig = "";

var modeln = "";

//根据传值获取通道ID和设备ID
function initUI() {
    //传值
    var string = decodeURIComponent(document.location.search).substr(1);
    var logArr = new Array();
    logArr = string.split("=");
    ChannelID = string.split("&")[0].split("=")[1];
    DeviceID = string.split("&")[1].split("=")[1];

}

//点击切告警和数据项
$("#dataTab").click(function () {
    window.location.href = "../DataItemConfig_OCR.html?channelid=" + ChannelID + "&deviceid=" + DeviceID + "&t=" + (new Date()).getTime();
});
$("#rulesTab").click(function () {
    window.location.href = "../Alarm.html?channelid=" + ChannelID + "&deviceid=" + DeviceID + "&t=" + (new Date()).getTime();
});
$(document).ready(function () {
    initUI();
    getID();
    getData();

});
//根据通道ID、设备ID读数据项
function getData() {
    getID();
    $("#allItemName").empty();
    DataItemNum = 0;
    $("#DataItemNum").empty();
    $("#info").empty();
    $("#itemTable tr").empty("");
    $("#itemTable  tr").css("display","none");
    $.get('../conf/config.xml', function (d1) {
        $(d1).find("model[id='" + ChannelID + "']").each(function () {
            var $model = $(this);
            var modelid = $model.attr('id');
            modeln = $model.attr('n');
            var modeld = $model.attr('d');
            ChannelDriver = $model.attr("d");
            ChannelDeviceType = $model.attr("devicedriver");
           
            $("#ChannelName").html(modeln);
            $("#ChannelName").attr("title", modeln);
            $model.find("device[id='" + DeviceID + "']").each(function () {
                var $device = $(this);
                var deviceid = $device.attr('id');
                var deviceip = $device.attr('ip');
                var devicen = $device.attr('n');
                var type = $device.attr('type');
                $device.find('driver').each(function () {
                    var $driver = $(this);
                    var config = $driver.attr('config');
                    var configArr = new Array();
                    configArr = config.split(";");
                    category = configArr[0];

                });
                $("#DeviceName").html(devicen);
                $("#DeviceName").attr("title", devicen);
                $device.find("commDataItems").each(function () {
                    var $commDataItems = $(this);
                    $commDataItems.find("dataItem").each(function () {
                        var $dataItem = $(this);
                        var dataItemN = $dataItem.attr('n');
                        var dataItemA = $dataItem.attr('alias');
                        var dataItemID = $dataItem.attr('id');
                        var dataItemFreq = $dataItem.attr('freq');
                        var dataItemReport1 = $dataItem.attr('report');
                        var dataItemWR1 = $dataItem.attr('rw');
                        var dataItemType_wang = $dataItem.attr('type');
                        var dataItemReport = "";
                        if (dataItemReport1 == "1") {
                            dataItemReport = "上报";
                        }
                        if (dataItemReport1 == "0") {
                            dataItemReport = "不上报";
                        }
                        var dataItemConfig = $dataItem.attr('config');
                        var ConfigArr = new Array();
                        ConfigArr = dataItemConfig.split(";");
                        var screenName = ConfigArr[0];
                        var areaName = ConfigArr[1];
                        

                        if (dataItemWR1 == "0") {
                            dataItemWR = "只读";
                        }

                        if (dataItemWR1 == "1") {
                            dataItemWR = "可写";
                        }
                        diffCol++;
                        EditChange++;
                        DataItemNum++;
                        var list;
                        list = "<tr id=" + diffCol + " class='diffC' onMouseOver='Highlight(id)' onMouseOut='HideHighlight(id)' onDblClick='Open_Alter_DataItem_Layer(" + dataItemID + ")'>" +
                        "<td>" + "<input name='tryadd' type='checkbox' value='" + dataItemID + "'>" + "</td>" +
                        "<td>" + dataItemID + "</td>" +
                        "<td class='nameAliasWidth'>" + dataItemN + "</td>" +
                        "<td class='nameAliasWidth'>" + dataItemA + "</td>" +
                        "<td>" + screenName + "</td>" +
                        "<td>" + areaName + "</td>" +
                        "<td>" + dataItemWR + "</td>" +
                        "<td>" + dataItemFreq / 1000 + "秒</td>" +
                        "<td>" + dataItemReport + "</td>" +
                        "<td>" +
                        "<img src='assets/img/bianji_ico.png'  onClick='Open_Alter_DataItem_Layer(" + dataItemID + ")' class='edit' title='编辑'>" + "</td>" +
                        "</tr>";
            
                        $("#itemTable").append(list);
                        if (coo == "English") {
                            $(".edit").attr("title","Edit");
                        }else{
                            $(".edit").attr("title","编辑");
                        }
                        if (diffCol % 2 == "0")
                            document.getElementById(diffCol).className = "diffC1";
                        document.getElementById("DataItemNum").innerHTML = "数据项总数： " + "<strong>" + DataItemNum + "</strong>" + " &nbsp; ";
                        var allName = dataItemN + ";";
                        $("#allItemName").append(allName);
                    });
                    $(".edit").mouseover(function () {
                        $(this).attr("src", "assets/img/bianji_hover_ico.png");
                        this.myTitle = this.title;
                        this.title = "";
                        var tooltip = "<div id='tooltip'>" + this.myTitle + "</div>";
                        $("body").append(tooltip);
                        var width = parseInt($("#tooltip").css("width")) + 10;
                        $("#tooltip").css("top", y + "px");
                        $("#tooltip").css("left", x + "px");
                        $("#tooltip").css("width", width + "px");
                    });
                    $(".edit").mouseout(function () {
                        $(this).attr("src", "assets/img/bianji_ico.png");
                        this.title = this.myTitle;
                        $("#tooltip").remove();
                    });
                });
            });
        });
    });
}

//点击返回效果
function ReturnToDevice() {
    window.location.href = "../Device_PLC_Change.html?id=" + ChannelID + "&t=" + (new Date()).getTime();
}


//移动高亮显示
function Highlight(txt) {
    document.getElementById(txt).className = "diffC2";

}

function HideHighlight(txt) {
    if (txt % 2 == "0")
        document.getElementById(txt).className = "diffC1";
    else
        document.getElementById(txt).className = "diffC";
}

//全局变量当前编辑的名称
var NowItemName = "";
//根据设备ID和数据项ID查找数据项信息并显示
function Open_Alter_DataItem_Layer(txt) {
    //将ID赋值给表单
    document.getElementById("Alter_DataItemID_YuToXHZhang").value = txt;
    document.getElementById('Alter_idTip').innerHTML = "";
    document.getElementById('Alter_nameTip').innerHTML = "";
    document.getElementById('Alter_AliasTip').innerHTML = "";
    document.getElementById('Alter_ScreenNameTip').innerHTML = "";
    document.getElementById('Alter_AreaNameTip').innerHTML = "";
    document.getElementById('Alter_freqTip').innerHTML = '';

    $(document).ready(function () {
        //end add
        $.get('../conf/config.xml', function (d1) {
            $(d1).find("model").each(function () {
                var $model = $(this);
                $model.find("device[id='" + DeviceID + "']").each(function () {
                    var $device = $(this);
                    $device.find("commDataItems").each(function () {
                        var $commDataItems = $(this);
                        $commDataItems.find("dataItem[id='" + txt + "']").each(function () {
                            var $dataItem = $(this);
                            var dataItemN = $dataItem.attr('n');
                            NowItemName = dataItemN;
                            var dataItemA = $dataItem.attr('alias');
                            var dataItemID = $dataItem.attr('id');
                            ZundarConfig = dataItemID;
                            var dataItemFreq = $dataItem.attr('freq');
                            var dataItemReport = $dataItem.attr('report');
                            var type_wang = $dataItem.attr('type');
                            var dataItemWR = $dataItem.attr('rw');
                            if (dataItemReport == "1")
                                document.getElementById("Alter_DataItemReport1").checked = "checked";
                            if (dataItemReport == "0")
                                document.getElementById("Alter_DataItemReport1").checked = "";
                            var dataItemConfig = $dataItem.attr('config');
                            var ConfigArr = new Array();
                            ConfigArr = dataItemConfig.split(";");
                           
                          
                           
                           
                            if (dataItemWR == "0")
                                document.getElementById("RWmode1Info").checked = "checked";
                            if (dataItemWR == "1")
                                document.getElementById("RWmode2Info").checked = "checked";
                            document.getElementById("Alter_DataItemID").value = dataItemID;
                            document.getElementById("Alter_DataItemName").value = dataItemN;
                            document.getElementById("Alter_DataItemAlias").value = dataItemA;
                            var Freq = "";
                            if (dataItemFreq % 60000 == 0) {
                                Freq = dataItemFreq / 60000;
                                $("#Alter_DataItemUnit").val("minute");
                            } else {
                                Freq = dataItemFreq / 1000;
                                $("#Alter_DataItemUnit").val("second");
                            }
                            document.getElementById("Alter_DataItemFreq").value = Freq;
                            document.getElementById("Alter_DataItemReport").value = dataItemReport;
                            $("#Alter_ScreenName").val(ConfigArr[0]);
                            $("#Alter_AreaName").val(ConfigArr[1]);
                        });
                    });
                });
            });
        });
        document.getElementById("popWindow").style.display = '';
        document.getElementById("Alter_DataItem_Layer").style.display = '';
    });
}


//弹出PLC数据项添加层
function openPLCadd() {
    getID();
    document.getElementById("Add_DataItemName").value = "";
    document.getElementById("idTip").innerHTML = "";
    document.getElementById("nameTip").innerHTML = "";
    document.getElementById("AliasTip").innerHTML = "";

    document.getElementsByName("Add_DataItemRWmode").value = "0";
    document.getElementById("Add_DataItemReport").value = "1";
    document.getElementById("popWindow").style.display = '';
    document.getElementById("Add_DataItem_Layer").style.display = '';

}

//弹出删除层
function openDeleteLayer() {
    CheckedLength();
    document.getElementById("popWindow").style.display = "";
    document.getElementById("DeleteDataItemLayer").style.display = "";
    if (document.getElementById("AllDataitemID").value == "") {
        document.getElementById("NoDataItemChecked").style.display = "";
        document.getElementById("DeleteChecked").style.display = "none";
        document.getElementById("DeleteDataItem_Button_Confim").style.display = "none";
        document.getElementById("DeleteDataItem_Button_Cancel").style.display = "none";
        document.getElementById("DeleteDataItem_Success_Button_Confim").style.display = "";
    } else {
        document.getElementById("NoDataItemChecked").style.display = "none";
        document.getElementById("DeleteChecked").style.display = "";
        document.getElementById("DeleteChecked").innerHTML = "确定要删除选中的<strong> &nbsp;" + checkLength + "&nbsp; </strong>个数据项吗？";
        document.getElementById("DeleteDataItem_Button_Confim").style.display = "";
        document.getElementById("DeleteDataItem_Button_Cancel").style.display = "";
        document.getElementById("DeleteDataItem_Success_Button_Confim").style.display = "none";
    }
}

//弹出帮助层
function Open_DataItemHelpLayer() {
    if (document.getElementById("Help_DataItemLayer").style.display == "none")
        document.getElementById("Help_DataItemLayer").style.display = '';
    else
        document.getElementById("Help_DataItemLayer").style.display = 'none';
}


//缺省 单选按钮


function changeReport() {
    if (document.getElementById("DataItemReport1").checked)
        document.getElementById("Add_DataItemReport").value = "1";
    else
        document.getElementById("Add_DataItemReport").value = "0";

}


function changeReportInfo() {
    if (document.getElementById("Alter_DataItemReport1").checked)
        document.getElementById("Alter_DataItemReport").value = "1";
    else
        document.getElementById("Alter_DataItemReport").value = "0";
}

//检查重名
function CheckReName(txt) {
    var string = document.getElementById("allItemName").innerHTML;
    var NameArr = new Array();
    NameArr = string.split(";");
    for (var i = 0; i < NameArr.length - 1; i++) {
        //alert(NameArr[i])
        if (txt != NameArr[i]) {} else {
            return false;
        }
    }
    return true;
}
//检查数据项名称输入格式

function Check_Chinese_Character(txt) {
    var str = txt;
    var re = /^[A-Za-z]\w*$/;
    if (re.test(str)) {
        return true;
    } else {
        return false;
    }
}

//添加数据项的校验
function Check_Add_DataItem() {

    var CheckID = $("#Add_DataItemID").val();
    var CheckName = $("#Add_DataItemName").val();
    var Alies = $("#Add_DataItemAlias").val();
    var Freq = $("#Add_DataItemFreq").val();
    var screenName = $("#Add_ScreenName").val();
    var areaName = $("#Add_AreaName").val();
    
    
    var StringLength = $("#stringLength").val();
    var reg = new RegExp("^[0-9]+$");
    var regID = new RegExp("^[1-9]+[0-9]*$");
    //校验数据项ID输入格式
    if (CheckID == "" || !regID.test(CheckID)) {
        $("#idTip").html("数据项ID必须为非负整数");
    } else {
        $.ajax({
            type: "get",
            url: "../conf/config.xml",
            async: false,
            success: function (data) {
                var flag = true;
                $(data).find("model").each(function () {
                    var $model = $(this);
                    $model.find("device").each(function () {
                        var $device = $(this);
                        $device.find("commDataItems").each(function () {
                            var $commDataItems = $(this);
                            $commDataItems.find("dataItem").each(function () {
                                var $dataItem = $(this);
                                var dataItemID = $dataItem.attr('id');
                                if (dataItemID == CheckID) {
                                    $("#idTip").html("数据项ID已重复，请更改");
                                    flag = false;
                                }
                            });
                        });
                    });
                });
                if (flag) {
                    $("#idTip").html("");
                }
            }
        });
    }

    //校验数据项名称输入格式
    if (CheckName == "") {
        $("#nameTip").html("*数据项名称不能为空");
    } else {
        //校验数据项名称是否重名
        if (!CheckReName(CheckName)) {
            $("#nameTip").html("数据项名称重复");
        } else {
            $("#nameTip").html("");
        }
    }
    //校验数据项别名不为空
    if (Alies == "") {
        $("#AliasTip").html("*请填写别名");
    } else {
        $("#AliasTip").html("");
    }
    
    //校验频率不为空
    if (Freq == "") {
        $("#freqTip").html("*请填写采集频率");
    } else {
        if (!reg.test(Freq) || Freq == 0) {
            $("#freqTip").html("*频率必须为正整数");
        } else {
            $("#freqTip").html("");
        }
    }
    
    // 校验屏幕名称
    if(screenName == "") {
        $("#ScreenNameTip").html("*请填写屏幕名称");
    } else {
        $("#ScreenNameTip").html("");
    }

    // 校验区域名称
    if (areaName == "") {
        $("#AreaNameTip").html("*请填写区域名称");
    } else {
        $("#AreaNameTip").html("");
    }

    //判断是否通过
    if ($("#idTip").html() == "" && $("#nameTip").html() == "" && $("#AliasTip").html() == "" && $("#ScreenNameTip").html() == "" && $("#AreaNameTip").html() == "") {
        //        全部通过
        Add_DataItemMethod();
    } else {
    }
}

//添加数据点方法
function Add_DataItemMethod() {

    document.getElementById("Add_DataItemType_YuToXHZhang").value = "a";
    var Freq = document.getElementById("Add_DataItemFreq").value;
    var Unit = document.getElementById("Add_DataItemUnit").value;
    if (Unit == "minute") {
        Freq = Freq * 60000;
    } else {
        Freq = Freq * 1000;
    }
    //数据项ID
    document.getElementById("Add_DataItemID_YuToXHZhang").value = document.getElementById("Add_DataItemID").value;
    //数据项名称
    document.getElementById("Add_DataItemName_YuToXHZhang").value = document.getElementById("Add_DataItemName").value;
    //别名
    document.getElementById("Add_DataItemAlias_YuToXHZhang").value = document.getElementById("Add_DataItemAlias").value;
    //频率
    document.getElementById("Add_DataItemFreq_YuToXHZhang").value = Freq;
    //读写模式
    document.getElementById("Add_DataItemRWmode_YuToXHZhang").value = $("input[name='Add_DataItemRWmode']:checked").val();
    //是否上报
    document.getElementById("Add_DataItemReport_YuToXHZhang").value = document.getElementById("Add_DataItemReport").value;
    //数据项信息
    document.getElementById("Add_DataItemConfig_YuToXHZhang").value = $("#Add_ScreenName").val() + ";" + $("#Add_AreaName").val();
    

    //设备ID
    document.getElementById("Add_DeviceID_YuToXHZhang").value = DeviceID;

    $("#return3").attr("disabled", "disabled");
    $("#return4").attr("disabled", "disabled");
    var params = $("#Add_DataItemForm_YuToXHZhang").serialize();
    $.ajax({
        type: "post",
        url: "cgi-bin/device/AddDataitem.py",
        data: params,
        async: true,
        success: function (data) {
            $("#popWindow").hide();
            $("#Add_DataItem_Layer").hide();
            $("#return3").attr("disabled", "");
            $("#return4").attr("disabled", "");
            getData();
        }
    });
}

//修改数据项校验
function Check_Alter_DataItem() {

    var CheckID = $("#Alter_DataItemID").val();
    var CheckName = $("#Alter_DataItemName").val();
    var Alies = $("#Alter_DataItemAlias").val();
    var Freq = $("#Alter_DataItemFreq").val();
    var reg = new RegExp("^[0-9]+$");
    var regID = new RegExp("^[1-9]+[0-9]*$");
    var screenName = $("#Alter_ScreenName").val();
    var areaName = $("#Alter_AreaName").val();

    //校验数据项ID输入格式
    if (CheckID == "" || !regID.test(CheckID)) {
        $("#Alter_idTip").html("数据项ID必须为非负整数");
    } else {
        $.ajax({
            type: "get",
            url: "../conf/config.xml",
            async: false,
            success: function (data) {
                var flag = 0;
                $(data).find("model").each(function () {
                    var $model = $(this);
                    $model.find("device").each(function () {
                        var $device = $(this);
                        $device.find("commDataItems").each(function () {
                            var $commDataItems = $(this);
                            $commDataItems.find("dataItem").each(function () {
                                var $dataItem = $(this);
                                var dataItemID = $dataItem.attr('id');
                                if (dataItemID == CheckID) {
                                    var dataItemName = $dataItem.attr('n');
                                    if (dataItemName == NowItemName) {
                                        //跳过
                                    } else {
                                        flag = flag + 1;
                                    }
                                }
                            });
                        });
                    });
                });
                if (flag < 1) {
                    $("#Alter_idTip").html("");
                } else {
                    $("#Alter_idTip").html("数据项ID已重复，请更改");
                }
            }
        });
    }

    //校验数据项名称输入格式
    if (CheckName == "") {
        $("#Alter_nameTip").html("*数据项名称不能为空");
    } else {
        //名字未修改时，不校验重名
        if (CheckName == NowItemName) {
            $("#Alter_nameTip").html("");
        } else {
            //校验数据项名称是否重名
            if (!CheckReName(CheckName)) {
                $("#Alter_nameTip").html("数据项名称重复");
            } else {
                $("#Alter_nameTip").html("");
            }
        }
    }
    //校验数据项别名不为空
    if (Alies == "") {
        $("#Alter_AliasTip").html("*请填写别名");
    } else {
        $("#Alter_AliasTip").html("");
    }
   
    //校验频率不为空
    if (Freq == "") {
        $("#Alter_freqTip").html("*请填写采集频率");
    } else {
        if (!reg.test(Freq) || Freq == 0) {
            $("#Alter_freqTip").html("*频率必须为正整数");
        } else {
            $("#Alter_freqTip").html("");
        }
    }

    // 校验屏幕名称
    if (screenName == "") {
        $("#Alter_ScreenNameTip").html("*请填写屏幕名称");
    } else {
        $("#Alter_ScreenNameTip").html("");
    }

    // 校验区域名称
    if (areaName == '') {
        $("#Alter_AreaNameTip").html("*请填写区域名称");
    } else {
        $("#Alter_AreaNameTip").html("");
    }

    //判断是否通过
    if ($("#Alter_idTip").html() == "" && $("#Alter_nameTip").html() == "" && $("#Alter_AliasTip").html() == "" && $("#Alter_ScreenNameTip").html() == "" && $("#Alter_freqTip").html() == "" && $("#Alter_AreaNameTip").html() == "") {
        //        全部通过
        Alter_DataItemMethod();
    } else {}
}

//修改数据项方法
function Alter_DataItemMethod() {
    var reg = /[a-zA-Z]/g;

    var Freq = document.getElementById("Alter_DataItemFreq").value;
    var Unit = document.getElementById("Alter_DataItemUnit").value;
    if (Unit == "minute") {
        Freq = Freq * 60000;
    } else {
        Freq = Freq * 1000;
    }

    //数据项类型
    document.getElementById("Alter_DataItemType_YuToXHZhang").value = "a";
    //设备ID
    document.getElementById("Alter_DeviceID_YuToXHZhang").value = DeviceID;
    //数据项ID
    document.getElementById("Alter_DataItemID_after").value = document.getElementById("Alter_DataItemID").value;
    //数据项名称
    document.getElementById("Alter_DataItemName_YuToXHZhang").value = document.getElementById("Alter_DataItemName").value;
    //数据项别名
    document.getElementById("Alter_DataItemAlias_YuToXHZhang").value = document.getElementById("Alter_DataItemAlias").value;
    //读写模式
    document.getElementById("Alter_DataItemRWmode_YuToXHZhang").value = $("input[name='Alter_DataItemRWmode']:checked").val();
    //频率
    document.getElementById("Alter_DataItemFreq_YuToXHZhang").value = Freq;
    //是否上报
    document.getElementById("Alter_DataItemReport_YuToXHZhang").value = document.getElementById("Alter_DataItemReport").value;
    //数据项配置字符串
    document.getElementById("Alter_DataItemConfig_YuToXHZhang").value = $('#Alter_ScreenName').val() + ";" + $("#Alter_AreaName").val();

    $("#return5").attr("disabled", "disabled");
    $("#return6").attr("disabled", "disabled");
    var params = $("#Alter_DataItemForm_YuToXHZhang").serialize();
    $.ajax({
        type: "post",
        url: "cgi-bin/device/AlterDataitem.py",
        data: params,
        async: true,
        success: function (data) {
            $("#popWindow").hide();
            $("#Alter_DataItem_Layer").hide();
            $("#return5").attr("disabled", "");
            $("#return6").attr("disabled", "");
            getData();
        }
    });
}

//全局一个需要删除的长度
var checkLength = "";

function CheckedLength() {
    checkLength = 0;
    document.getElementById("AllDataitemID").value = "";
    document.getElementById("Delete_DataItemAllID_YuToXHZhang").value = "";
    var inputs = document.getElementsByName("tryadd");
    var length = inputs.length;
    for (var i = 0; i < length; i++) {
        if (inputs[i].checked) {
            document.getElementById("AllDataitemID").value += inputs[i].value + ";";
            checkLength++;
        }
    }
    var str = document.getElementById("AllDataitemID").value;
    var strArr = new Array();
    strArr = str.split(";");
    var maxlength = strArr.length;
    for (var j = 0; j < maxlength - 2; j++) {
        document.getElementById("Delete_DataItemAllID_YuToXHZhang").value += strArr[j] + ",";
    }
    document.getElementById("Delete_DataItemAllID_YuToXHZhang").value += strArr[maxlength - 2];
}

//删除数据项
function DeleteConfig() {
    document.getElementById("Delete_DeviceID_YuToXHZhang").value = DeviceID;
    CheckedLength();
    $("#DeleteDataItem_Button_Confim").attr("disabled", "disabled");
    $("#DeleteDataItem_Button_Cancel").attr("disabled", "disabled");
    var params = $("#Delete_DataItemForm_YuToXHZhang").serialize();
    $.ajax({
        type: "post",
        url: "cgi-bin/device/DeleteDataitem.py",
        data: params,
        async: true,
        success: function (data) {
            $("#popWindow").hide();
            $("#DeleteDataItemLayer").hide();
            $("#DeleteDataItem_Button_Confim").attr("disabled", "");
            $("#DeleteDataItem_Button_Cancel").attr("disabled", "");
            getData();
            $("#selectAll").attr("checked", "");
        }
    });
}

//全选和反选
function addTry() {
    if (document.getElementById("selectAll").checked) {
        var inputs = document.getElementsByName("tryadd");
        for (var i = 0; i < inputs.length; i++) {
            inputs[i].checked = true;
        }
    } else {
        var inputs = document.getElementsByName("tryadd");
        for (var i = 0; i < inputs.length; i++) {
            inputs[i].checked = false;
        }
    }
}
//下发数据项
function Open_IssuedLayer() {
    document.getElementById("popWindow").style.display = ''
    document.getElementById("IssuedLayer").style.display = ''
    document.getElementById("ConUp1").style.display = ''
    $("#up_success").hide();
    //      document.getElementById("Hide_IssuedIframe").style.display = 'none'
    document.getElementById("Issued_Button_Confim").style.display = ''
    document.getElementById("Issued_Button_Cancel").style.display = ''
    document.getElementById("Issued_Success_Button_Confim").style.display = 'none'
    //动态图隐藏
    document.getElementById("Loading").style.display = "none";
}

function UpConfigCon() {
    times = 0;
    document.getElementById("IssuedLayer").style.display = 'none';
    window.parent.document.getElementById("IssuedLayer").style.display = '';
    document.getElementById("ConUp1").style.display = 'none';
    //      document.getElementById("Hide_IssuedIframe").style.display = "none"
    $("#Issued_Button_Confim").attr("disabled", "disabled");
    $("#Issued_Button_Cancel").attr("disabled", "disabled");
    $.ajax({
        type: "post",
        url: "cgi-bin/agent/GiveToAgent.py",
        data: "up=1",
        async: false,
        success: function (data) {
            $("#up_success").html(data);
            document.getElementById("popWindow").style.backgroundColor = "#ddd";
            window.parent.document.getElementById("popWindow").style.display = "";
            window.parent.document.getElementById("IssuedLayer").style.display = '';
            getagent = setInterval("getAgentStatue()", 5000);
        }
    });
}
//全局一个发送次数
var times = 0
var getagent = "";

function getAgentStatue() {
    //获取测试字符串
    var value = getFirstID();
    $("#Test_Value_YuToXHZhang").val(value);
    var params = $("#Test_DataItemForm_YuToXHZhang").serialize();
    times++;
    //两分钟超时
    if (times < 18) {
        $.ajax({
            type: "post",
            url: "cgi-bin/RealTimeData/GetAgentStatue.py",
            data: params,
            async: true,
            success: function (data) {
                //如果测试返回结果正确，即返回为1，则可以关闭下发窗口
                if (data == 1) {
                    $("#up_success").show();
                    $("#Loading").hide();
                    $("#Issued_Button_Confim").attr("disabled", "");
                    $("#Issued_Button_Cancel").attr("disabled", "");
                    $("#Issued_Button_Confim").hide();
                    $("#Issued_Button_Cancel").hide();
                    $("#Issued_Success_Button_Confim").show();
                    $("#ConUp1").hide();
                    window.parent.document.getElementById("popWindow").style.display = "none";
                    document.getElementById("popWindow").style.backgroundColor = "#9D9D9D";
                    window.parent.document.getElementById("IssuedLayer").style.display = 'none';
                    document.getElementById("IssuedLayer").style.display = '';
                    clearInterval(getagent);
                } else {

                }
            },
        });
    } else {
        $("#Issued_Button_Confim").attr("disabled", "");
        $("#Issued_Button_Cancel").attr("disabled", "");
        document.getElementById("IssuedLayer").style.display = '';
        window.parent.document.getElementById("popWindow").style.display = "none";
        document.getElementById("popWindow").style.backgroundColor = "#9D9D9D";
        window.parent.document.getElementById("IssuedLayer").style.display = 'none';
        document.getElementById("up_success").innerHTML = "agent启动超时，请稍后再试";
        document.getElementById("up_success").style.display = "";
        document.getElementById("ConUp1").style.display = "none";
        document.getElementById("Issued_Button_Confim").style.display = 'none';
        document.getElementById("Issued_Success_Button_Confim").style.display = '';
        clearInterval(getagent);
    }
}

function getFirstID() {
    var id = "";
    $.ajax({
        type: "get",
        url: "../conf/config.xml",
        async: false,
        success: function (data) {
            $(data).find("model[id='" + ChannelID + "']").each(function () {
                var $model = $(this);
                $model.find("device[id='" + DeviceID + "']").each(function () {
                    var $device = $(this);
                    $device.find("driver").each(function() {
                        var $driver = $(this);
                        DriverID = $driver.attr('id');
                        $driver.find("commDataItems").each(function () {
                            var $commDataItems = $(this);
                            $commDataItems.find("dataItem:first-child").each(function () {
                                var $dataItem = $(this);
                                var dataItemID = $dataItem.attr('id');
                                id = dataItemID;
                            });
                        });
                    })  
                });
            });
        }
    });
    //拼出测试字符串

    var value = "";
    var ChannelDriverArr = new Array();
    ChannelDriverArr = ChannelDriver.split(":");
    var ChannelDriverShort = ChannelDriverArr[1];
    if (id == "") {
        //没有数据时候
        value = '{"id":' + DeviceID + ',"dn":"","vid":' + DriverID + ',"vn":"' + ChannelDriverShort + '", "cmds":{"read":1}}'
    } else {
        value = '{"id":' + DeviceID + ',"dn":"","vid":' + DriverID + ',"vn":"' + ChannelDriverShort + '", "cmds":{"read":0,"ids":[' + id + ']}}'
    }
    return value;
}
//读数据项ID最大值并赋值
function getID() {
    $.get('../conf/IDinfo.xml', function (d1) {
        $(d1).find("IDALL").each(function () {
            var $IDALL = $(this);
            var DataitemID = $IDALL.find('ItemID').text();
            document.getElementById("Add_DataItemID_YuToXHZhang").value = DataitemID;
            document.getElementById("Add_DataItemID").value = DataitemID;
        });
    });
}

function Import_Success_ReloadNewPage() {
    getData();
    $("#popWindow").hide();
    $("#ImportLayer").hide();
}


function Import_DataItem() {
    if (document.getElementById("FileName").value == "") {
        alert("请选择需要上传的文件！")
    } else {
        // $("#importDeviceID").val(DeviceID);
        document.getElementById('Import_Button_Confirm').disabled = true;
        document.getElementById('Import_Button_Cancel').disabled = true;
        
        document.getElementById("ImportForm_YuToXHZhang").action = '../cgi-bin/import/ImportOCRDataitem.py?deviceID=' + DeviceID;

        document.getElementById("ImportForm_YuToXHZhang").submit();
        var iframe01 = document.getElementById("Hide_ImportIframe");
        if (iframe01.attachEvent) {
            iframe01.attachEvent("onload", function () {

                document.getElementById("UpWord").style.display = 'none';
                document.getElementById("Import_Two_Button").style.display = 'none';
                document.getElementById("Success_Import").style.display = '';
                document.getElementById("Import_Success_Button").style.display = '';
                document.getElementById('Import_Button_Confirm').disabled = false;
                document.getElementById('Import_Button_Cancel').disabled = false;
            });
        } else {
            iframe01.onload = function () {

                document.getElementById("UpWord").style.display = 'none';
                document.getElementById("Import_Two_Button").style.display = 'none';
                document.getElementById("Success_Import").style.display = '';
                document.getElementById("Import_Success_Button").style.display = '';
                document.getElementById('Import_Button_Confirm').disabled = false;
                document.getElementById('Import_Button_Cancel').disabled = false;
            };
        }
    }
}

function Close_ExportLayer() {
    document.getElementById("popWindow").style.display = 'none'
    document.getElementById("ExprotLayer").style.display = 'none'
    document.getElementById('Exportout').disabled = false;
    document.getElementById('ExSucc').disabled = false;
}

function ExportInfo() {
    
    document.getElementById("ExportForm_YuToXHZhang").action = '../cgi-bin/export/ExportOCRDataitem.py?deviceID=' + DeviceID;
    
    document.getElementById("ExportForm_YuToXHZhang").submit();
    document.getElementById("ExportForm_YuToXHZhang").target = 'Hide_ExportIframe';
    document.getElementById('Exportout').disabled = true;
    document.getElementById('ExSucc').disabled = true;
    window.setTimeout(Close_ExportLayer, 3000);
}

//切换到测试
function Open_TestLayer() {
    //alert(ChannelDriver)
    var value = "";
    var idArr = "";
    var ChannelDriverArr = new Array();
    ChannelDriverArr = ChannelDriver.split(":");
    var ChannelDriverShort = ChannelDriverArr[1];
    CheckedLength();
    if (document.getElementById("AllDataitemID").value == "") {
        value = '{"id":' + DeviceID + ',"dn":"", "vn":"' + ChannelDriverShort + '", "cmds":{"read":1}}'
    } else {
        var str = document.getElementById("AllDataitemID").value;
        var strArr = new Array();
        strArr = str.split(";");
        var maxlength = strArr.length;
        for (var j = 0; j < maxlength - 2; j++) {
            idArr += strArr[j] + ",";
        }
        idArr += strArr[maxlength - 2];
        value = '{"id":' + DeviceID + ',"dn":"", "vn":"' + ChannelDriverShort + '", "cmds":{"read":0,"ids":[' + idArr + ']}}'
        //alert(strArr[1])
    }
    TestDateItem(value);
}

function TestDateItem(txt) {
    $("#testInfomation").empty();
    document.getElementById("Test_Value_YuToXHZhang").value = txt;
    document.getElementById("popWindow").style.display = "";
    var params = $("#Test_DataItemForm_YuToXHZhang").serialize();
    $.ajax({
        type: "post",
        url: "cgi-bin/RealTimeData/GetRealTimeData.py",
        data: params,
        async: true,
        datatype: "xml",
        beforeSend: function () {
            $("#wait").show();
        },
        complete: function () {
            $("#wait").hide();
            //方法执行完毕，效果自己可以关闭，或者隐藏效果
        },
        success: function (data) {
            if (data.substr(1, 3) != "All") {
                $("#wait").hide();
                $("#popWindow").hide();
                alert(data);
            } else {
                $("#TestLayer").show();
                $(data).find("dataItem").each(function () {
                    var $dataitem = $(this);
                    var name = $dataitem.attr("n");
                    var config = $dataitem.attr("config");
                    var id = $dataitem.attr("id");
                    var typeshort = $dataitem.attr("type");
                    var freq = $dataitem.attr("freq");
                    var report = $dataitem.attr("report");
                    var value = $dataitem.attr("value");
                    var alias = $dataitem.attr("alias");
                    var quality1 = $dataitem.attr("quality");
                    var configArr = new Array();
                    configArr = config.split(";");
                    var screenName = configArr[0];
                    var areaName = configArr[1];
                    var quality = "";
                    if (quality1 == 1) {
                        quality = "good";
                    }
                    if (quality1 != 1) {
                        quality = "bad";
                    }
                  
                    var list = "<div style='width:678px;height:25px;border: 1px solid #D7D7D7;border-top:none'>" +
                        "<div align='center' style='width:150px;float:left;height:25px;line-height:25px;overflow:hidden' title='" + name + "'>" + name + "</div>" +
                        "<div align='center' style='width:150px;float:left;height:25px;line-height:25px;overflow:hidden' title='" + alias + "'>" + alias + "</div>" +
                        "<div align='center' style='width:80px;float:left;height:25px;line-height:25px'>" + screenName + "</div>" +
                        "<div align='center' style='width:80px;float:left;height:25px;line-height:25px'>" + areaName + "</div>" +
                        "<div align='center' style='width:130px;float:left;height:25px;line-height:25px'>" + value + "</div>" +
                        "<div align='center' style='width:68px;float:left;height:25px;line-height:25px'>" + quality + "</div>" +
                        "</div>"
                    $("#testInfomation").append(list);
                });
            }
        },
        error: function () {
            $("#popWindow").hide();
            alert("测试失败，请联系管理员");
        }
    });
}

//切换到导入
function Open_ImportLayer() {
    $("#popWindow").show();
    $("#ImportLayer").show();
    $("#FileName").val("");
    // $("#importDeviceID").val("");
    $("#UpWord").show();
    $("#Import_Two_Button").show();
    $("#Success_Import").hide();
    $("#Import_Success_Button").hide();
    $("#Import_Button_Confirm").show();
    $("#Import_Button_Cancel").show();
}

//切换到导出
function Open_ExportLayer() {

    document.getElementById("popWindow").style.display = '';
    document.getElementById("ExprotLayer").style.display = '';
}


$("#Add_DataItemType").change(function () {
    if ($(this).val() == "STRING" && ChannelDeviceType != "OMRON_NJNX" && ChannelDeviceType != "HKG-SERIAL" && ChannelDeviceType != "Custom-TCP") {
        $("#tr_string").show();
        $("#tr_string_msg").show();
    } else {
        $("#tr_string").hide();
        $("#tr_string_msg").hide();
    }
});

$("#Alter_DataItemType").change(function () {
    if ($(this).val() == "STRING" && ChannelDeviceType != "OMRON_NJNX" && ChannelDeviceType != "HKG-SERIAL" && ChannelDeviceType != "Custom-TCP") {
        $("#Alter_tr_string").show();
        $("#Alter_tr_string_msg").show();
    } else {
        $("#Alter_tr_string").hide();
        $("#Alter_tr_string_msg").hide();
    }
});