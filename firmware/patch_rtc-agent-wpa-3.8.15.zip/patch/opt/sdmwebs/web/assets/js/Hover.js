// 添加删除的浮动
// title效果
var x = "";
var y = "";

//function getXY() {
//        event = event || window.event;
//        x = event.clientX + 10;
//        y = event.clientY + 15;
//    }

// 兼容多浏览器，获取鼠标位置的方法
document.onmousemove = mouseMove; //没明白为什么一定要加这一句
function mouseMove(ev) {
    ev = ev || window.event;
    var mousePos = mouseCoords(ev);
    //alert(ev.pageX); 
    x = mousePos.x + 10;
    y = mousePos.y + 15;
}

function mouseCoords(ev) {
    if (ev.pageX || ev.pageY) {
        return {
            x: ev.pageX,
            y: ev.pageY
        };
    }
    return {
        x: ev.clientX + document.body.scrollLeft - document.body.clientLeft,
        y: ev.clientY + document.body.scrollTop - document.body.clientTop
    };
}





//添加
$(".butAddPIC").mouseover(function () {
    $("#PLCaddPIC").attr("src", "assets/img/add_hover_ico.png");
    this.myTitle = this.title;
    this.title = "";
    var tooltip = "<div id='tooltip'>" + this.myTitle + "</div>";
    $("body").append(tooltip);
    var width = parseInt($("#tooltip").css("width")) + 10;
    $("#tooltip").css("top", y + "px")
    $("#tooltip").css("left", x + "px")
    $("#tooltip").css("width", width + "px")
});
$(".butAddPIC").mouseout(function () {
    $("#PLCaddPIC").attr("src", "assets/img/add_ico.png");
    this.title = this.myTitle;
    $("#tooltip").remove();
});
//删除
$(".butDelPIC").mouseover(function () {
    $("#DeletePIC").attr("src", "assets/img/delet_hover_ico.png");
    this.myTitle = this.title;
    this.title = "";
    var tooltip = "<div id='tooltip'>" + this.myTitle + "</div>";
    $("body").append(tooltip);
    var width = parseInt($("#tooltip").css("width")) + 10;
    $("#tooltip").css("top", y + "px")
    $("#tooltip").css("left", x + "px")
    $("#tooltip").css("width", width + "px")
});
$(".butDelPIC").mouseout(function () {
    $("#DeletePIC").attr("src", "assets/img/delet_ico.png");
    this.title = this.myTitle;
    $("#tooltip").remove();
});
//下发、导入、导出、测试
$(".DataItemImg").mouseover(function () {
    this.myTitle = this.title;
    this.title = "";
    var tooltip = "<div id='tooltip'>" + this.myTitle + "</div>";
    $("body").append(tooltip);
    var width = parseInt($("#tooltip").css("width")) + 10;
    $("#tooltip").css("top", y + "px")
    $("#tooltip").css("left", x + "px")
    $("#tooltip").css("width", width + "px")
});
$(".DataItemImg").mouseout(function () {
    this.title = this.myTitle;
    $("#tooltip").remove();
});