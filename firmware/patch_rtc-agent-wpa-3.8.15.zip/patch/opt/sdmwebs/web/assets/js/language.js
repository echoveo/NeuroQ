/**
 * cookie操作
 */
// var getCookie = function(name, value, options) {
//     if (typeof value != 'undefined') { // name and value given, set cookie
//         options = options || {};
//         if (value === null) {
//             value = '';
//             options.expires = -1;
//         }
//         var expires = '';
//         if (options.expires && (typeof options.expires == 'number' || options.expires.toUTCString)) {
//             var date;
//             if (typeof options.expires == 'number') {
//                 date = new Date();
//                 date.setTime(date.getTime() + (options.expires * 24 * 60 * 60 * 1000));
//             } else {
//                 date = options.expires;
//             }
//             expires = '; expires=' + date.toUTCString(); // use expires attribute, max-age is not supported by IE
//         }
//         var path = options.path ? '; path=' + options.path : '';
//         var domain = options.domain ? '; domain=' + options.domain : '';
//         var s = [cookie, expires, path, domain, secure].join('');
//         var secure = options.secure ? '; secure' : '';
//         var c = [name, '=', encodeURIComponent(value)].join('');
//         var cookie = [c, expires, path, domain, secure].join('')
//         document.cookie = cookie;
//     } else { // only name given, get cookie
//         var cookieValue = null;
//         if (document.cookie && document.cookie != '') {
//             var cookies = document.cookie.split(';');
//             for (var i = 0; i < cookies.length; i++) {
//                 var cookie = jQuery.trim(cookies[i]);
//                 // Does this cookie string begin with the name we want?
//                 if (cookie.substring(0, name.length + 1) == (name + '=')) {
//                     cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
//                     break;
//                 }
//             }
//         }
//         return cookieValue;
//     }
// };


///获取cookie值
function getCookie(AnyLinkLan) {
    // 首先检查下cookie是否存在.
    // 如果不存在则document.cookie的长度为0
    if (document.cookie.length > 0) {
        // 接着我们检查下cookie的名字是否存在于document.cookie
        // 因为不止一个cookie值存储,所以即使document.cookie的长度不为0也不能保证我们想要的名字的cookie存在
        //所以我们需要这一步看看是否有我们想要的cookie
        //如果begin的变量值得到的是-1那么说明不存在
        var begin = document.cookie.indexOf(AnyLinkLan + "=");
        if (begin != -1) {
            // 说明存在我们的cookie.
            begin += AnyLinkLan.length + 1; //cookie值的初始位置
            var end = document.cookie.indexOf(";", begin); //结束位置
            if (end == -1)
                end = document.cookie.length; //没有;则end为字符串结束位置
            return unescape(document.cookie.substring(begin, end));
        }
    } else
        return null;
    // cookie不存在返回null
}

/**
 * 获取浏览器语言类型
 * @return {string} 浏览器国家语言
 */
var getNavLanguage = function(){
    if(navigator.appName == "Netscape"){
        var navLanguage = navigator.language || navigator.userLanguage;
        if(navLanguage.indexOf('zh') == 0){
            return 'Chinese';
        }else {
            return 'English';
        }
    }
    return false;
}

/**
 * 设置语言类型： 默认为英文
 */
var i18nLanguage = "English";

/*
设置一下网站支持的语言种类
 */
var webLanguage = ['Chinese',  'English'];

/**
 * 执行页面i18n方法
 * @return
 */ 
var execI18n = function(){
    /*
    获取一下资源文件名
     */
    var optionEle = $("#i18n_pagename");
    if (optionEle.length < 1) {
        console.log("未找到页面名称元素，请在页面写入\n <meta id=\"i18n_pagename\" content=\"页面名(对应语言包的语言文件名)\">");
        return false;
    };
    var sourceName = optionEle.attr('content');
    sourceName = sourceName.split('-');
    /*
    首先获取用户浏览器设备之前选择过的语言类型
     */
    if (getCookie("AnyLinkLan")) {
        i18nLanguage = getCookie("AnyLinkLan");
    } else {
        // 获取浏览器语言
        var navLanguage = getNavLanguage();
        if (navLanguage) {
            // 判断是否在网站支持语言数组里
            var charSize = $.inArray(navLanguage, webLanguage);
            if (charSize > -1) {
                i18nLanguage = navLanguage;
                // 存到缓存中
                var expiredays = 5;
                var ExpireDate = new Date();
                ExpireDate.setTime(ExpireDate.getTime() + (expiredays * 24 * 3600 * 1000));
                document.cookie = "AnyLinkLan=" + escape(navLanguage) + ((expiredays == null) ? "" : "; expires=" + ExpireDate.toGMTString());
            };
        } else{
            console.log("not navigator");
            return false;
        }
    }

    /* 需要引入 i18n 文件*/
    if ($.i18n == undefined) {
        console.log("请引入i18n js 文件")
        return false;
    };

    /*
    这里需要进行i18n的翻译
     */
    jQuery.i18n.properties({
        name : sourceName, //资源文件名称
        path : 'i18n/' + i18nLanguage +'/', //资源文件路径
        mode : 'map', //用Map的方式使用资源文件中的值
        language : i18nLanguage,
        callback : function() {//加载成功后设置显示内容
            var insertEle = $(".i18n");
            insertEle.each(function() {
                // 根据i18n元素的 name 获取内容写入
                $(this).html($.i18n.prop($(this).attr('i18nname')));
                // console.log($(this).attr('i18nname'));
            });
            // console.log("写入完毕");
            $('body').show();
            var insertInputEle = $(".i18n-input");
            insertInputEle.each(function() {
                var selectAttr = $(this).attr('selectattr');
                if (!selectAttr) {
                    selectAttr = "value";
                };
                $(this).attr(selectAttr, $.i18n.prop($(this).attr('selectname')));
            });
            // console.log("写入完毕");
        }
    });
}

/*页面执行加载执行*/
$(function(){
    /*执行I18n翻译*/
    execI18n();
    
    // /*将语言选择默认选中缓存中的值*/
    $("#language option[value="+i18nLanguage+"]").attr("selected",true);

    /* 选择语言 */
    $("#language").change(function (){
        var language = $(this).children('option:selected').val()
        console.log(language);
        var expiredays = 5;
        var ExpireDate = new Date();
        ExpireDate.setTime(ExpireDate.getTime() + (expiredays * 24 * 3600 * 1000));
        document.cookie = "AnyLinkLan=" + escape(language) + ((expiredays == null) ? "" : "; expires=" + ExpireDate.toGMTString());
        location.reload();
    });
});
