document.writeln("<script src=\"assets/js/effect_Com.js?t=" + (new Date()).getTime() + "\" type=\"text/javascript\" charset=\"utf-8\"></script>");
document.writeln("<" + "script language='javascript' src='assets/js/language.js?t=" + (new Date()).getTime() + "'></" + "script>");

CheckLogin();
$.ajaxSetup({
    cache: false
});
//全局变量
var diffCol = 1000000000000;
var EditChange = 100000000000000;
//通道ID
var ChannelID = "";
//设备ID
var DeviceID = "";
//驱动ID
var DriverID = "";
//校验所需要的
var category = "";
//数据项总数    
var DataItemNum = "";

//设备驱动类型
var ChannelDriver = "";

//驱动类型字符串
var ChannelDeviceType = "";
//功能码
var DataItemFunctionNo = "";
//AnyLink 版本  DA还是 RF,true为RF，false为DA；
var AnyLinkType = 'DA';
var coo = '';
//根据传值获取通道ID和设备ID

function initUI() {
    //传值
    var string = decodeURIComponent(document.location.search).substr(1);
    var logArr = new Array();
    logArr = string.split("=");
    ChannelID = string.split("&")[0].split("=")[1];
    DeviceID = string.split("&")[1].split("=")[1];

    // 加入AnyLink版本获取
    $.ajax({
        type: "get",
        url: "../conf/AnyLink.xml",
        async: false,
        success: function (data) {
            $(data).find('BasicInfo').each(function () {
                var $BasicInfo = $(this);
                AnyLinkType = $BasicInfo.find('AnyLinkType').text();
                $("#Add_NetNumber_tr").hide();
                $("#Alter_NetNumber_tr").hide();
            });
        }
    });
}
//点击切告警和数据项
$("#dataTab").click(function () {
    window.location.href = "../DataItemConfig_ModBus.html?channelid=" + ChannelID + "&deviceid=" + DeviceID + "&t=" + (new Date()).getTime();
});
$("#rulesTab").click(function () {
    window.location.href = "../Alarm.html?channelid=" + ChannelID + "&deviceid=" + DeviceID + "&t=" + (new Date()).getTime();
});
$("#computeTab").click(function () {
    window.location.href = "../ConditionalUpload.html?channelid=" + ChannelID + "&deviceid=" + DeviceID + "&t=" + (new Date()).getTime();
});

//根据通道ID、设备ID读数据项
$(document).ready(function () {
    initUI();
    getID();
    getData();
    coo = getCookie("AnyLinkLan");
    if (coo == "English") {
        $(".AutoRefresh").css("left", "289px");
        $("#computeTab").css("width", "100px");
    } else {
        $(".AutoRefresh").css("left", "77px");
        $("#computeTab").css("width", "60px");
    }
});

function getData() {
    getID();
    $("#allItemName").empty();
    DataItemNum = 0;
    $("#DataItemNum").empty();
    $("#info").empty();
    $("#itemTable tr").empty("");
    $("#itemTable  tr").css("display", "none");
    $.get('../conf/config.xml', function (d1) {
        $(d1).find("model[id='" + ChannelID + "']").each(function () {
            var $model = $(this);
            var modelid = $model.attr('id');
            var modeln = $model.attr('n');
            var modeld = $model.attr('d');
            ChannelDriver = $model.attr("d");
            ChannelDeviceType = $model.attr("devicedriver");
            //add 2017-11-10 begin by x
            //如果是modbus任务驱动，将从站id和网络id隐藏掉，这两个参数被移动到添加设备界面
            if (ChannelDeviceType == "Modbus-RTU-task" || ChannelDeviceType == "Modbus-ASCII-task" || ChannelDeviceType == "Modbus-TCP-task") {
                $("#Add_NetNumber_tr").hide();
                $("#Alter_NetNumber_tr").hide();
                $("#Add_DataItemSlave").parents('tr').hide();
                $("#Alter_DataItemSlave").parents('tr').hide();
                $('#Add_DataItemUpload').hide();
                //表格里的从站要隐藏
                $("#czTablehide").hide();
            }
            //end add
            $("#ChannelName").html(modeln);
            $("#ChannelName").attr("title", modeln);
            $model.find("device[id='" + DeviceID + "']").each(function () {
                var $device = $(this);
                var deviceid = $device.attr('id');
                var deviceip = $device.attr('ip');
                var devicen = $device.attr('n');
                var driverId = '';
                $device.find('driver').each(function () {
                    var $driver = $(this);
                    var config = $driver.attr('config');
                    driverId = $driver.attr('id');
                    var configArr = new Array();
                    configArr = config.split(";");
                    category = configArr[0];
                    ItemConfigHelp(category);
                });
                $("#DeviceName").html(devicen);
                $("#DeviceName").attr("title", devicen);
                $device.find("commDataItems").each(function () {
                    var $commDataItems = $(this);
                    $commDataItems.find("dataItem").each(function () {
                        var $dataItem = $(this);
                        var dataItemN = $dataItem.attr('n');
                        var dataItemA = $dataItem.attr('alias');
                        var dataItemID = $dataItem.attr('id');
                        var dataItemFreq = $dataItem.attr('freq');
                        var dataItemReport1 = $dataItem.attr('report');
                        var dataItemType1 = $dataItem.attr("type");
                        var dataItemType_wang = $dataItem.attr('type');
                        var dataItemReport = "";
                        if (coo == "English") {
                            if (dataItemReport1 == "0") {
                                dataItemReport = "Not report"
                            } else if ( dataItemReport1 == "2") {
                                dataItemReport = "change report"
                            } else {
                                dataItemReport = "Report"
                            }
                        } else {
                            if (dataItemReport1 == "0") {
                                dataItemReport = "不上传"
                            }  else if ( dataItemReport1 == "2") {
                                dataItemReport = "变化上传"
                            } else {
                                dataItemReport = "全部上传"
                            }
                        }
                        var dataItemConfig = $dataItem.attr('config');
                        var ConfigArr = new Array();
                        ConfigArr = dataItemConfig.split(";");
                        if (ChannelDeviceType != "Modbus-RTU-task" && ChannelDeviceType != "Modbus-ASCII-task" && ChannelDeviceType != "Modbus-TCP-task") {
                            var dataItemSalveID = ConfigArr[0];
                            var dataItemFunction = ConfigArr[1];
                            var dataItemAdd = ConfigArr[2];
                            var dataItemCalculate = ConfigArr[3];
                            var dataItemType1 = ConfigArr[4];
                            var dataItemAlianType = ConfigArr[6];
                        } else {

                            var dataItemFunction = ConfigArr[0];
                            var dataItemAdd = ConfigArr[1];
                            var dataItemType1 = ConfigArr[2];
                            var dataItemAlianType = ConfigArr[3];
                        }
                        var dataItemWR1 = $dataItem.attr('rw');
                        var dataItemWR = "";
                        var dataItemType = "";
                        if (dataItemType1 == "BOOLEAN")
                            dataItemType = "Boolean";
                        if (dataItemType1 == "BYTE")
                            dataItemType = "Byte";
                        if (dataItemType1 == "DWORD")
                            dataItemType = "Dword";
                        if (dataItemType1 == "WORD")
                            dataItemType = "Word";
                        if (dataItemType1 == "FLOAT")
                            dataItemType = "Float";
                        if (dataItemType1.indexOf("STRING") != -1)
                            dataItemType = "String"
                        if (dataItemType1 == "int16_t")
                            dataItemType = "int16";
                        if (dataItemType1 == "int32_t")
                            dataItemType = "int32";
                        if (dataItemType1 == "BCD")
                            dataItemType = "BCD";
                        if (dataItemType1 == "int64")
                            dataItemType = "Int64";
                        if (dataItemType1 == "uint64")
                            dataItemType = "Uint64";
                        if (dataItemType1.indexOf("CUSTOM") != -1)
                            dataItemType = "Custom"
                        if (coo == "English") {
                            if (dataItemWR1 == "0") {
                                dataItemWR = "Read";
                            }
                            if (dataItemWR1 == "1") {
                                dataItemWR = "Read&Write";
                            }
                        } else {
                            if (dataItemWR1 == "0") {
                                dataItemWR = "只读";
                            }
                            if (dataItemWR1 == "1") {
                                dataItemWR = "可写";
                            }
                        }
                        diffCol++;
                        EditChange++;
                        DataItemNum++;
                        if (ChannelDeviceType == "Modbus-RTU-task" || ChannelDeviceType == "Modbus-ASCII-task" || ChannelDeviceType == "Modbus-TCP-task") {
                            var list = "<tr id=" + diffCol + " class='diffC' onMouseOver='Highlight(id)' onMouseOut='HideHighlight(id)' onDblClick='Open_Alter_DataItem_Layer(" + dataItemID + ")'>" +
                                "<td>" + "<input name='tryadd' type='checkbox' value='" + dataItemID + "'>" + "</td>" +
                                "<td>" + dataItemID + "</td>" +
                                "<td class='nameAliasWidth'>" + dataItemN + "</td>" +
                                "<td class='nameAliasWidth'>" + dataItemA + "</td>" +
                                "<td class='nameAliasWidth'>" + dataItemAdd + "</td>" +
                                "<td class='nameAliasWidth'>" + dataItemType + "</td>" +
                                "<td class='nameAliasWidth'>" + dataItemFunction + "</td>" +
                                "<td>" + dataItemWR + "</td>"
                            if (coo == "English") {
                                list += "<td>" + dataItemFreq / 1000 + "s</td>"
                            } else {
                                list += "<td>" + dataItemFreq / 1000 + "秒</td>"
                            }
                            list = list + "<td>" + dataItemReport + "</td>" +
                                "<td>" +
                                "<img src='assets/img/bianji_ico.png' onClick='Open_Alter_DataItem_Layer(" + dataItemID + ")' class='edit' title='编辑'>" +
                                "&nbsp;<img src='assets/img/xieru_ico.png'  onClick='open_write_layer(" + JSON.stringify({
                                    'id': +deviceid,
                                    'dn': '',
                                    'vn': modeld.split(":")[1],
                                    'vid': +driverId,
                                    'cmds': [{
                                        'dt': dataItemType_wang,
                                        'cfg': dataItemConfig,
                                        'itemid': dataItemID,
                                        'rw': dataItemWR1
                                    }]
                                }).replace(/"/g, '&quot;') + ")' class='write i18n-input' selectname='WriteOperation' selectattr='title' >" + "</td>" +
                                "</tr>"
                        } else {
                            var list = "<tr id=" + diffCol + " class='diffC' onMouseOver='Highlight(id)' onMouseOut='HideHighlight(id)' onDblClick='Open_Alter_DataItem_Layer(" + dataItemID + ")'>" +
                                "<td>" + "<input name='tryadd' type='checkbox' value='" + dataItemID + "'>" + "</td>" +
                                "<td>" + dataItemID + "</td>" +
                                "<td class='nameAliasWidth'>" + dataItemN + "</td>" +
                                "<td class='nameAliasWidth'>" + dataItemA + "</td>" +
                                "<td class='nameAliasWidth'>" + dataItemSalveID + "</td>" +
                                "<td class='nameAliasWidth'>" + dataItemAdd + "</td>" +
                                "<td class='nameAliasWidth'>" + dataItemType + "</td>" +
                                "<td class='nameAliasWidth'>" + dataItemFunction + "</td>" +
                                "<td>" + dataItemWR + "</td>"
                            if (coo == "English") {
                                list += "<td>" + dataItemFreq / 1000 + "s</td>"
                            } else {
                                list += "<td>" + dataItemFreq / 1000 + "秒</td>"
                            }
                            list = list + "<td>" + dataItemReport + "</td>" +
                                "<td>" +
                                "<img src='assets/img/bianji_ico.png' onClick='Open_Alter_DataItem_Layer(" + dataItemID + ")' class='edit' title='编辑'>" +
                                "&nbsp;<img src='assets/img/xieru_ico.png'  onClick='open_write_layer(" + JSON.stringify({
                                    'id': +deviceid,
                                    'dn': '',
                                    'vn': modeld.split(":")[1],
                                    'vid': +driverId,
                                    'cmds': [{
                                        'dt': dataItemType_wang,
                                        'cfg': dataItemConfig,
                                        'itemid': dataItemID,
                                        'rw': dataItemWR1
                                    }]
                                }).replace(/"/g, '&quot;') + ")' class='write i18n-input' selectname='WriteOperation' selectattr='title' >" + "</td>" +
                                "</tr>"
                        }
                        $("#itemTable").append(list);
                        if (coo == "English") {
                            $(".edit").attr("title", "Edit");
                            $(".write").attr("title", "Write");
                        } else {
                            $(".edit").attr("title", "编辑");
                            $(".write").attr("title", "写入");
                        }
                        if (diffCol % 2 == "0")
                            document.getElementById(diffCol).className = "diffC1";
                        if (coo == "English") {
                            document.getElementById("DataItemNum").innerHTML = "Total number of dataItems: " + "<strong>" + DataItemNum + "</strong>" + " &nbsp; ";
                        } else {
                            document.getElementById("DataItemNum").innerHTML = "数据项总数： " + "<strong>" + DataItemNum + "</strong>" + " &nbsp; ";
                        }
                        var allName = dataItemN + ";"
                        $("#allItemName").append(allName);
                    });
                    $(".edit").mouseover(function () {
                        $(this).attr("src", "assets/img/bianji_hover_ico.png");
                        this.myTitle = this.title;
                        this.title = "";
                        var tooltip = "<div id='tooltip'>" + this.myTitle + "</div>";
                        $("body").append(tooltip);
                        var width = parseInt($("#tooltip").css("width")) + 10;
                        $("#tooltip").css("top", y + "px")
                        $("#tooltip").css("left", x + "px")
                        $("#tooltip").css("width", width + "px")
                    });
                    $(".edit").mouseout(function () {
                        $(this).attr("src", "assets/img/bianji_ico.png");
                        this.title = this.myTitle;
                        $("#tooltip").remove();
                    });

                    if (ChannelDeviceType == "Modbus-RTU-task" || ChannelDeviceType == "Modbus-ASCII-task" || ChannelDeviceType == "Modbus-TCP-task") {
                        $("#Add_AlignmentTask_tr").show();
                        $("#Alter_AlignmentTask_tr").show();
                        $("#Add_Alignment_tr").hide();
                        $("#Alter_Alignment_tr").hide();
                    } else {
                        $("#Add_Alignment_tr").show();
                        $("#Alter_Alignment_tr").show();
                        $("#Add_AlignmentTask_tr").hide();
                        $("#Alter_AlignmentTask_tr").hide();
                    }

                });
            });
        });
    });
}
//点击返回效果
function ReturnToDevice() {
    window.location.href = "../Device_PLC_Change.html?id=" + ChannelID + "&t=" + (new Date()).getTime();
}
//移动高亮显示
function Highlight(txt) {
    document.getElementById(txt).className = "diffC2";
}

function HideHighlight(txt) {
    if (txt % 2 == "0")
        document.getElementById(txt).className = "diffC1";
    else
        document.getElementById(txt).className = "diffC";
}

function DHEnableClicked(radioVal) {
    if (radioVal == '0') {
        $('#line_Add_DataItemDHOpt').hide();
    } else {
        $('#line_Add_DataItemDHOpt').show();
    }
}

function DHEnableClicked_alter(radioVal) {
    if (radioVal == '0') {
        $('#line_Alter_DataItemDHOpt').hide();
    } else {
        $('#line_Alter_DataItemDHOpt').show();
    }
}

function ChangeDHSelect(dhSelect) {
    var optType = $(dhSelect).val();
    if (optType == "#") {
      $("#Add_DataItemDHParam").hide();
      $("#Add_DHFunctionParam1").show();
      $("#Add_DHFunctionParam2").show();
    } else {
      $("#Add_DataItemDHParam").show();
      $("#Add_DHFunctionParam1").hide();
      $("#Add_DHFunctionParam2").hide();
    }
}

function ChangeDHSelect_alter(dhSelect) {
    var optType = $(dhSelect).val();
    if (optType == "#") {
      $("#Alter_DataItemDHParam").hide();
      $("#Alter_DHFunctionParam1").show();
      $("#Alter_DHFunctionParam2").show();
    } else {
      $("#Alter_DataItemDHParam").show();
      $("#Alter_DHFunctionParam1").hide();
      $("#Alter_DHFunctionParam2").hide();
    }
}

//全局变量当前编辑的名称
var NowItemName = "";
//根据设备ID和数据项ID查找数据项信息并显示
function Open_Alter_DataItem_Layer(txt) {
    //将ID赋值给表单

    document.getElementById("Alter_DataItemID_YuToXHZhang").value = txt;
    document.getElementById('idTipInfo').innerHTML = "";
    document.getElementById('nameTipInfo').innerHTML = "";
    document.getElementById('AliasTipInfo').innerHTML = "";
    document.getElementById('addressTipInfo').innerHTML = "";
    document.getElementById('checkTwoInfo').innerHTML = "";
    document.getElementById('FreqTipInfo').innerHTML = "";
    document.getElementById('AdditionalTipInfo').innerHTML = "";
    document.getElementById('SlaveTipInfo').innerHTML = "";
    document.getElementById('Alter_stringMsg').innerHTML = "";
    document.getElementById("popWindow").style.display = '';
    document.getElementById("Alter_DataItem_Layer").style.display = '';
    $('#Alter_DataItemUpload').hide();
    $("#Alter_NetNumber").val("");
    $("#NetNumberTipInfo").html("");
    $("#DHMode1_alter").attr('checked', 'checked');
    $("#line_Alter_DataItemDHOpt").hide();
    $.get('../conf/config.xml', function (d1) {
        $(d1).find("model").each(function () {
            var $model = $(this);
            $model.find("device[id='" + DeviceID + "']").each(function () {
                var $device = $(this);
                $device.find("commDataItems").each(function () {
                    var $commDataItems = $(this);
                    $commDataItems.find("dataItem[id='" + txt + "']").each(function () {
                        var $dataItem = $(this);
                        var dataItemN = $dataItem.attr('n');
                        NowItemName = dataItemN;
                        var dataItemA = $dataItem.attr('alias');
                        var dataItemID = $dataItem.attr('id');
                        var dataItemFreq = $dataItem.attr('freq');
                        var dataItemReport = $dataItem.attr('report');
                        var dataItemType1 = $dataItem.attr("type");

                        if (dataItemReport == "3") {
                            $("input[name='Alter_ReportType']").each(function(){
                                if($(this).val()=='1'){
                                    $(this).attr("checked",true);
                                }
                            })
                        } else {
                            $("input[name='Alter_ReportType']").each(function(){
                                if($(this).val()==dataItemReport){
                                    $(this).attr("checked",true);
                                }
                            })
                        }

                        var dataItemConfig = $dataItem.attr('config');
                        var ConfigArr = new Array();
                        ConfigArr = dataItemConfig.split(";");
                        if (ChannelDeviceType != "Modbus-RTU-task" && ChannelDeviceType != "Modbus-ASCII-task" && ChannelDeviceType != "Modbus-TCP-task") {
                            var dataItemSalveID = ConfigArr[0];
                            var dataItemFunction = ConfigArr[1];
                            var dataItemAdd = ConfigArr[2];
                            var dataItemReport2 = ConfigArr[5];
                            var dataItemCalculate = ConfigArr[3];
                            var dataItemType = ConfigArr[4];
                            var dataItemAlianType = ConfigArr[6];
                            //加入对其方式默认显示
                            if (dataItemAlianType == "1") {
                                document.getElementById("AlignTypeSmall").checked = "checked";
                            }
                            if (dataItemAlianType == "0") {
                                document.getElementById("AlignTypeBig").checked = "checked";
                            }

                        } else {

                            var dataItemFunction = ConfigArr[0];
                            var dataItemAdd = ConfigArr[1];
                            var dataItemReport2 = $dataItem.attr('report');
                            var dataItemType = ConfigArr[2]
                            var dataItemAlianType = ConfigArr[3];

                            $("input[name='Alter_AlignTypeTask']").each(function () {
                                if ($(this).val() == dataItemAlianType) {
                                    $(this).attr("checked", true);
                                }
                            })
                        }
                        //根据获取的数据项地址来给功能码赋值
                        $("#Alter_DataItemFunction").empty();
                        var firstword = dataItemAdd.substr(0, 1);
                        var reg = /^[A-Za-z]*$/;
                        if (reg.test(firstword)) {
                            option = getDataItemFunction(firstword);
                        } else {
                            option = "<option value='1'>01</option><option value='2'>02</option><option value='3'>03</option><option value='4'>04</option>"
                        }
                        $("#Alter_DataItemFunction").append(option);
                        $("#Alter_DataItemFunction").val(dataItemFunction);
                        DataItemFunctionNo = dataItemFunction;
                        var dataItemWR = $dataItem.attr("rw");
                        // if (dataItemReport2 == "1")
                        //     document.getElementById("A_DataItemReport2").checked = "checked";
                        // if (dataItemReport2 == "0")
                        //     document.getElementById("A_DataItemReport2").checked = "";
                        if (dataItemWR == "0")
                            document.getElementById("RWmode1Info").checked = "checked";
                        if (dataItemWR == "1")
                            document.getElementById("RWmode2Info").checked = "checked";


                        //判断数据项类型是否为String，如果是则初始化并显示长度
                        if (dataItemType.indexOf("STRING") != -1) {
                            document.getElementById("Alter_DataItemType").value = "STRING";
                            document.getElementById("Alter_stringLength").value = dataItemType.substr(6);
                            $("#Alter_tr_string").show();
                            $("#Alter_tr_string_msg").show();
                        } else if (dataItemType.indexOf("CUSTOM") != -1) {
                            document.getElementById("Alter_DataItemType").value = "CUSTOM";
                            document.getElementById("Alter_stringLength").value = dataItemType.substr(6);
                            $("#Alter_tr_string").show();
                            $("#Alter_tr_string_msg").show();
                        } else {
                            document.getElementById("Alter_DataItemType").value = dataItemType;
                            $("#Alter_tr_string").hide();
                            $("#Alter_tr_string_msg").hide();
                        }
                        if (AnyLinkType == 'RF') { //RF加入网络号的显示
                            var netNum = ConfigArr[7];
                            $("#Alter_NetNumber").val(netNum);
                        }
                        $("#Alter_DataItemID").val(txt)
                        document.getElementById("Alter_DataItemName").value = dataItemN;
                        document.getElementById("Alter_DataItemAlias").value = dataItemA;
                        document.getElementById("Alter_DataItemSlave").value = dataItemSalveID;
                        document.getElementById("Alter_DataItemAddress").value = dataItemAdd;
                        document.getElementById("Alter_DataItemFunction").value = dataItemFunction;
                        var Freq = "";
                        if (dataItemFreq % 60000 == 0) {
                            Freq = dataItemFreq / 60000;
                            $("#Alter_DataItemUnit").val("minute");
                        } else {
                            Freq = dataItemFreq / 1000;
                            $("#Alter_DataItemUnit").val("second");
                        }
                        document.getElementById("Alter_DataItemFreq").value = Freq;
                        // document.getElementById("Alter_DataItemReport").value = dataItemReport;
                        // document.getElementById("Alter_DataItemReport2").value = dataItemReport2;
                    });
                });
            });
        });
        $(d1).find('task dataHandler item[id="' + txt + '"]').each(function () {
            $('#line_Alter_DataItemDHOpt').show();
            var dhItem = $(this);
            $("#DHMode2_alter").attr("checked", "checked");
            var dhOptType = dhItem.attr('op');
            var dhOptParam = dhItem.attr('coe');
            if (dhOptType == '+') {
                dhOptType = '1';
            } else if (dhOptType == '-') {
                dhOptType = '2';
            } else if (dhOptType == '*') {
                dhOptType = '3';
            } else if (dhOptType == '/') {
                dhOptType = '4';
            } else if (dhOptType == 'b') {
                dhOptType = '5';
                // $('#RWmode2Info').attr('disabled', true);
            }
            $('#Alter_DataItemDHSelect').val(dhOptType);
            if(dhOptType=="#" ){
                $("#Alter_DataItemDHParam").hide();
                $("#Alter_DHFunctionParam1").show();
                $("#Alter_DHFunctionParam2").show();
                var reBrackets = /\([^\)]+\)/g;
                var coeList = dhOptParam.match(reBrackets);
                $("#Alter_DHFunctionParam1").val(coeList[0].substring(1,coeList[0].length-1) );
                $("#Alter_DHFunctionParam2").val(coeList[1].substring(1,coeList[1].length-1) );
              }else{
                $("#Alter_DataItemDHParam").show();
                $("#Alter_DHFunctionParam1").hide();
                $("#Alter_DHFunctionParam2").hide();
                $("#Alter_DataItemDHParam").val(dhOptParam);
              }
        });
    });
}
//弹出PLC数据项添加层
function openPLCadd() {
    getID();
    document.getElementById("Add_DataItemName").value = "";
    document.getElementById("Add_DataItemAddress").value = "";
    document.getElementById("idTip").innerHTML = "";
    document.getElementById("nameTip").innerHTML = "";
    document.getElementById("AliasTip").innerHTML = "";
    document.getElementById("addressTip").innerHTML = "";
    document.getElementById("checkTwo").innerHTML = "";
    document.getElementById("SlaveTip").innerHTML = "";
    document.getElementById("AdditionalTip").innerHTML = "";
    document.getElementById("FreqTip").innerHTML = "";
    document.getElementById("stringMsg").innerHTML = "";
    document.getElementById("NetNumberTip").innerHTML = "";
    document.getElementsByName("Add_DataItemRWmode").value = "0";
    // document.getElementById("Add_DataItemReport").value = "1";
    // document.getElementById("Add_DataItemReport2").value = "0"
    $("input[name='Add_ReportType']").each(function(){
        if($(this).val()=="1"){
            $(this).attr("checked",true);
        }
    })
    $("#Add_NetNumber").val("0");
    $('#line_Add_DataItemDHOpt').hide();

    document.getElementById("popWindow").style.display = ''
    document.getElementById("Add_DataItem_Layer").style.display = ''
    $("#Add_DataItemFunction").val("1");
    $("input[name='Add_AlignTypeTask']").each(function () {
        if ($(this).val() == "1234") {
            $(this).attr("checked", true);
        }
    })
    $('#DHMode1').attr('checked', 'checked');
    $("#Add_DataItemDHParam").show();
    $("#Add_DHFunctionParam1").hide();
    $("#Add_DHFunctionParam2").hide();
    $("#Add_DataItemAlias").val("");
    $('#Add_DataItemDHParam').val('');
    $('#Add_DataItemDHSelect').val('1');
    $("#Add_DHFunctionParam1").val("");
    $("#Add_DHFunctionParam2").val("");
}
//弹出删除层
function openDeleteLayer() {
    CheckedLength();
    document.getElementById("popWindow").style.display = "";
    document.getElementById("DeleteDataItemLayer").style.display = "";
    if (document.getElementById("AllDataitemID").value == "") {
        document.getElementById("NoDataItemChecked").style.display = "";
        document.getElementById("DeleteChecked").style.display = "none";
        document.getElementById("DeleteDataItem_Button_Confim").style.display = "none";
        document.getElementById("DeleteDataItem_Button_Cancel").style.display = "none";
        document.getElementById("DeleteDataItem_Success_Button_Confim").style.display = "";
    } else {
        document.getElementById("NoDataItemChecked").style.display = "none";
        document.getElementById("DeleteChecked").style.display = "";
        if (coo == "English") {
            document.getElementById("DeleteChecked").innerHTML = "Make sure to delete the selected<strong> &nbsp;" + checkLength + "&nbsp; </strong>dataItems?";
        } else {
            document.getElementById("DeleteChecked").innerHTML = "确定要删除选中的<strong> &nbsp;" + checkLength + "&nbsp; </strong>个数据项吗？";
        }
        document.getElementById("DeleteDataItem_Button_Confim").style.display = "";
        document.getElementById("DeleteDataItem_Button_Cancel").style.display = "";
        document.getElementById("DeleteDataItem_Success_Button_Confim").style.display = "none";
    }
}
//弹出帮助层
function Open_DataItemHelpLayer() {
    if (document.getElementById("Help_DataItemLayer").style.display == "none")
        document.getElementById("Help_DataItemLayer").style.display = ''
    else
        document.getElementById("Help_DataItemLayer").style.display = 'none'
}
//缺省 单选按钮
function changeReport() {
    if (document.getElementById("DataItemReport1").checked)
        document.getElementById("Add_DataItemReport").value = "1";
    else
        document.getElementById("Add_DataItemReport").value = "0";
}

function changeReport2() {
    if (document.getElementById("DataItemReport2").checked)
        document.getElementById("Add_DataItemReport2").value = "1";
    else
        document.getElementById("Add_DataItemReport2").value = "0";
}

function changeReportInfo() {
    if (document.getElementById("A_DataItemReport1").checked)
        document.getElementById("Alter_DataItemReport").value = "1";
    else
        document.getElementById("Alter_DataItemReport").value = "0";
}

function changeReportInfo2() {
    if (document.getElementById("A_DataItemReport2").checked)
        document.getElementById("Alter_DataItemReport2").value = "1";
    else
        document.getElementById("Alter_DataItemReport2").value = "0";
}
//检查重名
function CheckReName(txt) {
    var string = document.getElementById("allItemName").innerHTML;
    var NameArr = new Array();
    NameArr = string.split(";");
    for (var i = 0; i < NameArr.length - 1; i++) {
        //alert(NameArr[i])
        if (txt != NameArr[i]) {} else {
            return false;
        }
    }
    return true;
}
//检查数据项名称输入格式
function Check_Chinese_Character(txt) {
    var str = txt;
    var re = /^[A-Za-z]\w*$/;
    if (re.test(str)) {
        return true;
    } else {
        return false;
    }
}
//根据输入的数据项地址来自动填写功能码
$("#Add_DataItemAddress").change(function () {
    //清空下拉框
    $("#Add_DataItemFunction").empty();
    var option = "";

    var val = $(this).val();
    if (val == "") {
        if (coo == "English") {
            option = "<option value='-1'>Please enter the correct dataItem address</option>"
        } else {
            option = "<option value='-1'>请输入正确的数据项地址</option>"
        }
    }
    var firstword = val.substr(0, 1);
    //字母的正则
    var reg = /^[A-Za-z]*$/;
    if (reg.test(firstword)) {
        option = getDataItemFunction(firstword);
    } else {
        option = "<option value='1'>01</option><option value='2'>02</option><option value='3'>03</option><option value='4'>04</option>"
    }

    //下拉框赋值
    $("#Add_DataItemFunction").append(option);
});
//根据输入的数据项地址来自动填写功能码
$("#Alter_DataItemAddress").change(function () {
    //清空下拉框
    $("#Alter_DataItemFunction").empty();
    var option = "";

    var val = $(this).val();
    if (val == "") {
        if (coo == "English") {
            option = "<option value='-1'>Please enter the correct dataItem address</option>"
        } else {
            option = "<option value='-1'>请输入正确的数据项地址</option>"
        }
    }
    var firstword = val.substr(0, 1);
    //字母的正则
    var reg = /^[A-Za-z]*$/;
    if (reg.test(firstword)) {
        option = getDataItemFunction(firstword);
    } else {
        option = "<option value='1'>01</option><option value='2'>02</option><option value='3'>03</option><option value='4'>04</option>"
    }

    //下拉框赋值
    $("#Alter_DataItemFunction").append(option);
    $("#Alter_DataItemFunction").val(DataItemFunctionNo);
});
//根据字母来获取功能码
function getDataItemFunction(txt) {
    var word = txt.toUpperCase();
    switch (word) {
        case "S":
            return "<option value='1'>01</option>";
            break;
        case "X":
            return "<option value='2'>02</option>";
            break;
        case "Y":
            return "<option value='1'>01</option>";
            break;
        case "T":
            return "<option value='1'>01</option><option value='3'>03</option>";
            break;
        case "M":
            return "<option value='1'>01</option>";
            break;
        case "C":
            return "<option value='1'>01</option><option value='3'>03</option>";
            break;
        case "D":
            return "<option value='3'>03</option>";
            break;
        default:
            if (coo == "English") {
                return "<option value='-1'>Please enter the correct dataItem address</option>";
            } else {
                return "<option value='-1'>请输入正确的数据项地址</option>";
            }
            break;
    }

}

//添加数据项的校验
function Check_Add_DataItem() {
    var CheckID = $("#Add_DataItemID").val();
    var CheckName = $("#Add_DataItemName").val();
    var reg = new RegExp("^[0-9]+$");
    var regID = new RegExp("^[1-9]+[0-9]*$");
    //校验数据项ID输入格式
    if (CheckID == "" || !regID.test(CheckID)) {
        if (coo == "English") {
            $("#idTip").html("The dataItem ID must be a non-negative integer");
        } else {
            $("#idTip").html("数据项ID必须为非负整数");
        }
    } else {
        $.ajax({
            type: "get",
            url: "../conf/config.xml",
            async: false,
            success: function (data) {
                var flag = true;
                $(data).find("dataItem").each(function () {
                    var $dataItem = $(this);
                    var dataItemID = $dataItem.attr('id');
                    if (dataItemID == CheckID) {
                        if (coo == "English") {
                            $("#idTip").html("The dataItem ID is repeated, please change");
                        } else {
                            $("#idTip").html("数据项ID已重复，请更改");
                        }
                        flag = false;
                    }
                });
                if (flag) {
                    $("#idTip").html("");
                }
            }
        });
    }

    //校验数据项名称输入格式
    if (!Check_Chinese_Character(CheckName)) {
        if (coo == "English") {
            $("#nameTip").html("*The dataItem name format error, only the alphanumeric underscore and must start with the letter");
        } else {
            $("#nameTip").html("*数据项名称格式错误，仅允许字母数字下划线且必须以字母开头");
        }
    } else {
        //校验数据项名称是否重名
        if (!CheckReName(CheckName)) {
            if (coo == "English") {
                $("#nameTip").html("The dataItem name is repeated");
            } else {
                $("#nameTip").html("数据项名称重复");
            }
        } else {
            $("#nameTip").html("");
        }
    }
    //校验数据项别名不为空
    if (document.getElementById("Add_DataItemAlias").value == "") {
        if (coo == "English") {
            $("#AliasTip").html("*Please enter the alias");
        } else {
            $("#AliasTip").html("*请输入别名");
        }
    } else {
        document.getElementById("AliasTip").innerHTML = "";
    }
    if (ChannelDeviceType != "Modbus-RTU-task" && ChannelDeviceType != "Modbus-ASCII-task" && ChannelDeviceType != "Modbus-TCP-task") {
        //从站ID为空
        if (document.getElementById("Add_DataItemSlave").value == "") {
            if (coo == "English") {
                document.getElementById("SlaveTip").innerHTML = "*Please enter a slave station ID";
            } else {
                document.getElementById("SlaveTip").innerHTML = "*请输入从站ID";
            }
        } else {
            document.getElementById("SlaveTip").innerHTML = "";
        }
    }
    //数据项地址为空
    if (document.getElementById("Add_DataItemAddress").value == "") {
        if (coo == "English") {
            document.getElementById("addressTip").innerHTML = "*Please enter the dataItem address";
        } else {
            document.getElementById("addressTip").innerHTML = "*请输入数据项地址";
        }
    } else {
        document.getElementById("addressTip").innerHTML = "";
    }
    //数据项附加为空或不匹配
    $("#AdditionalTip").html('');
    var isChecked = $("input[name='Add_DataItemDHEnable']:checked").val();
    if (isChecked == '1') {
        var paramVal = $('#Add_DataItemDHParam').val();
        if ($("#Add_DataItemDHSelect").val() == "#") {
            var linearParam1 = $("#Add_DHFunctionParam1").val();
            var linearParam2 = $("#Add_DHFunctionParam2").val();
            if (linearParam1 == "" || linearParam2 == "") {
              if (coo == "English") {
                $("#AdditionalTip").html(
                  "Please fill in the value operation parameters"
                );
              } else {
                $("#AdditionalTip").html("请填写值运算参数");
              }
            } else {
              var dhReg = /^-?[0-9]+.?[0-9]*$/;
              if (!dhReg.test(linearParam1) || !dhReg.test(linearParam2)) {
                if (coo == "English") {
                  $("#AdditionalTip").html(
                    "The value operation parameter must be a number"
                  );
                } else {
                  $("#AdditionalTip").html("值运算参数必须是数字");
                }
              }
            }
          } else if (paramVal == "") {
            if (coo == "English") {
                $("#AdditionalTip").html('Please fill in the value operation parameters');
            } else {
                $("#AdditionalTip").html('请填写值运算参数');
            }
        } else {
            // 校验输入的操作数是否是数字
            var dhReg = /^-?[0-9]+.?[0-9]*$/;
            if (!dhReg.test(paramVal)) {
                if (coo == "English") {
                    $("#AdditionalTip").html('The value operation parameter must be a number');
                } else {
                    $("#AdditionalTip").html('值运算参数必须是数字');
                }
            } else if ($("#Add_DataItemDHSelect").val() == '5') {
                var dhReg = /^[0-9]+$/;
                if (!dhReg.test(paramVal)) {
                    if (coo == "English") {
                        $("#AdditionalTip").html('The parameter of the fetch operation must be an integer');
                    } else {
                        $("#AdditionalTip").html('取位运算的参数必须是整数');
                    }
                } else {
                    var paramVal = Number(paramVal);
                    if (paramVal < 0 || paramVal > 31) {
                        if (coo == "English") {
                            $("#AdditionalTip").html('The range of parameters for the fetch operation must be 0 to 31');
                        } else {
                            $("#AdditionalTip").html('取位运算的参数的范围必须是0到31');
                        }
                    }
                }
            }
        }
    }

    //采集频率为空或不为正整数
    if (document.getElementById("Add_DataItemFreq").value == "") {
        if (coo == "English") {
            document.getElementById("FreqTip").innerHTML = "*Please enter the sample frequency";
        } else {
            document.getElementById("FreqTip").innerHTML = "*请输入采集频率";
        }
    } else {
        num = document.getElementById("Add_DataItemFreq").value;
        var reg = new RegExp("^[0-9]*[1-9][0-9]*$");
        if (reg.test(num)) {
            $.ajax({
              type: "get",
              url: "../conf/Common.xml",
              async: false,
              success: function (data) {
                var minFrequency = $(data).find("MinFrequency").text();
                var currentFreq = 0;
                if ($("#Add_DataItemUnit").val() == "second") {
                  currentFreq = parseInt(num) * 1000;
                } else {
                  currentFreq = parseInt(num) * 1000 * 60;
                }

                if (currentFreq < parseInt(minFrequency)) {
                  if (coo == "English") {
                    $("#FreqTip").html(
                      "*The lowest frequency currently supported is" +
                        minFrequency / 1000 +
                        "seconds"
                    );
                  } else {
                    $("#FreqTip").html(
                      "*当前支持的最低频率为" + minFrequency / 1000 + "秒"
                    );
                  }
                } else {
                  $("#FreqTip").html("");
                }
              },
            });
        } else {
            if (coo == "English") {
                document.getElementById("FreqTip").innerHTML = "*The sample frequency should be positive integer";
            } else {
                document.getElementById("FreqTip").innerHTML = "*采集频率应为正整数";
            }
        }
    }
    if ($("#Add_DataItemFunction").val() == "-1") {
        if (coo == "English") {
            $("#checkTwo").html("*Please enter the correct dataItem address");
        } else {
            $("#checkTwo").html("*请输入正确的数据项地址");
        }
    } else {
        $("#checkTwo").html("");
    }
    if (AnyLinkType == 'RF') { //RF有网络号
        if ($("#Add_NetNumber").val() == "") {
            if (coo == "English") {
                $("#NetNumberTip").html("Please enter network number");
            } else {
                $("#NetNumberTip").html("请输入网络号");
            }
        } else {
            var num = $("#Add_NetNumber").val();
            var reg = new RegExp("^[0-9]+$");
            if (reg.test(num)) {
                $("#NetNumberTip").html("");
            } else {
                if (coo == "English") {
                    $("#NetNumberTip").html("Network Numbers should be Numbers");
                } else {
                    $("#NetNumberTip").html("网络号应为数字");
                }
            }
        }
    }

    var DataItemType = $("#Add_DataItemType").val();
    var StringLength = $("#stringLength").val();
    var reg2 = new RegExp("^[0-9]*$");
    //如果数据项类型为String，则校验长度是否为整数且为偶数
    if (DataItemType == "STRING") {
        if (StringLength == "") {
            if (coo == "English") {
                $("#stringMsg").html("*Please enter the length");
            } else {
                $("#stringMsg").html("*请输入长度");
            }
        } else {
            if (reg2.test(StringLength) && parseInt(StringLength) % 2 == 0) {
                $("#stringMsg").html("");
            } else {
                if (coo == "English") {
                    $("#stringMsg").html("*Must be numeric and even");
                } else {
                    $("#stringMsg").html("*必须为数字且为偶数");
                }
            }
        }
    } else if (DataItemType == "CUSTOM") {
        if (StringLength == "") {
            if (coo == "English") {
                $("#stringMsg").html("*Please enter the length");
            } else {
                $("#stringMsg").html("*请输入长度");
            }
        }
    } else {
        $("#stringMsg").html("");
    }
    //全部校验都过
    if ($("#idTip").html() == "" && document.getElementById('nameTip').innerHTML == "" && document.getElementById('addressTip').innerHTML == "" && document.getElementById('AliasTip').innerHTML == "" && document.getElementById("SlaveTip").innerHTML == "" && document.getElementById('FreqTip').innerHTML == "" && document.getElementById("AdditionalTip").innerHTML == "" && document.getElementById("checkTwo").innerHTML == "" && document.getElementById("stringMsg").innerHTML == "" && document.getElementById("NetNumberTip").innerHTML == "") {
        //校验是否有中文字符
        if (Check_Chinese_Character(CheckName)) {
            //校验重名
            if (CheckReName(CheckName)) {
                //校验全部通过，添加数据项方法
                Add_DataItemMethod();
            } else {
                if (coo == "English") {
                    document.getElementById('nameTip').innerHTML = "*The dataItem name is repeated"
                } else {
                    document.getElementById('nameTip').innerHTML = "*数据项名称重复"
                }
            }
        } else {
            if (coo == "English") {
                document.getElementById('nameTip').innerHTML = "*Only allow alphanumeric underscores and must begin with a letter"
            } else {
                document.getElementById('nameTip').innerHTML = "*仅允许字母数字下划线且必须以字母开头"
            }
        }
    }
}
//添加数据点方法
function Add_DataItemMethod() {
    var DataItemType = $("#Add_DataItemType").val();
    var StringLength = $("#stringLength").val();

    //赋值
    if ($("#Add_DataItemType").val() == "BOOLEAN") {
        $("#Add_DataItemType_YuToXHZhang").val("b");
    } else if ($("#Add_DataItemType").val() == "STRING" || $("#Add_DataItemType").val() == "CUSTOM") {
        $("#Add_DataItemType_YuToXHZhang").val("s");
    } else {
        $("#Add_DataItemType_YuToXHZhang").val("a");
    }

    var Freq = $("#Add_DataItemFreq").val();
    var Unit = $("#Add_DataItemUnit").val();
    if (Unit == "minute") {
        Freq = Freq * 60000;
    } else {
        Freq = Freq * 1000;
    }
    //数据项ID
    $("#Add_DataItemID_YuToXHZhang").val($("#Add_DataItemID").val());
    //数据项名称
    $("#Add_DataItemName_YuToXHZhang").val($("#Add_DataItemName").val());
    //别名
    $("#Add_DataItemAlias_YuToXHZhang").val($("#Add_DataItemAlias").val());
    //频率
    $("#Add_DataItemFreq_YuToXHZhang").val(Freq);
    //读写模式
    $("#Add_DataItemRWmode_YuToXHZhang").val($("input[name='Add_DataItemRWmode']:checked").val());
    //是否上报
    $("#Add_DataItemReport_YuToXHZhang").val( $("input[name='Add_ReportType']:checked").val()  );

    var isChecked = $("input[name='Add_DataItemDHEnable']:checked").val();
    $('#Add_DataItemDHEnable_YuToXHZhang').val(isChecked);
    if (isChecked == '1') {
        $('#Add_DataItemDHOptType_YuToXHZhang').val($('#Add_DataItemDHSelect').val());
        if ($("#Add_DataItemDHSelect").val() === "#") {
            $("#Add_DataItemDHOptParam_YuToXHZhang").val(
              $("#Add_DHFunctionParam1").val() +
                "|" +
                $("#Add_DHFunctionParam2").val()
            );
          } else {
            $("#Add_DataItemDHOptParam_YuToXHZhang").val(
              $("#Add_DataItemDHParam").val()
            );
          }
    }

    //数据项信息数据项类型为String则添加长度，在config增加对齐方式
    //如果是RF在大小端后添加网络号 config=从站ID；功能码；地址；倍率；类型；变化上传；大小端；网络号；读写
    if (ChannelDeviceType != "Modbus-RTU-task" && ChannelDeviceType != "Modbus-ASCII-task" && ChannelDeviceType != "Modbus-TCP-task") {
        if (AnyLinkType == 'RF') {
            $("#Add_DataItemConfig_YuToXHZhang").val($("#Add_DataItemSlave").val() + ";" + $("#Add_DataItemFunction").val() + ";" + $("#Add_DataItemAddress").val() + ";" + (DataItemType == "STRING" || DataItemType == "CUSTOM" ? DataItemType + StringLength : DataItemType) + ";" + $("#Add_DataItemReport2").val() + ";" + $("input[name='Add_AlignType']:checked").val() + ";" + $("#Add_NetNumber").val() + ";" + $("input[name='Add_DataItemRWmode']:checked").val());
        } else {
            $("#Add_DataItemConfig_YuToXHZhang").val($("#Add_DataItemSlave").val() + ";" + $("#Add_DataItemFunction").val() + ";" + $("#Add_DataItemAddress").val() + ";" + (DataItemType == "STRING" || DataItemType == "CUSTOM" ? DataItemType + StringLength : DataItemType) + ";" + $("#Add_DataItemReport2").val() + ";" + $("input[name='Add_AlignType']:checked").val() + ";" + $("input[name='Add_DataItemRWmode']:checked").val());
        }
    } else {
        $("#Add_DataItemConfig_YuToXHZhang").val($("#Add_DataItemFunction").val() + ";" + $("#Add_DataItemAddress").val() + ";" + (DataItemType == "STRING" || DataItemType == "CUSTOM" ? DataItemType + StringLength : DataItemType) + ";" + $("input[name='Add_AlignTypeTask']:checked").val());
    }
    //设备ID
    $("#Add_DeviceID_YuToXHZhang").val(DeviceID);

    $("#return3").attr("disabled", "disabled");
    $("#return4").attr("disabled", "disabled");
    var params = $("#Add_DataItemForm_YuToXHZhang").serialize();
    $.ajax({
        type: "post",
        url: "cgi-bin/device/AddDataitem.py",
        data: params,
        async: true,
        success: function (data) {
            $("#popWindow").hide();
            $("#Add_DataItem_Layer").hide();
            $("#return3").attr("disabled", "");
            $("#return4").attr("disabled", "");
            getData();
        }
    });

}

//修改数据项校验
function Check_Alter_DataItem() {
    var CheckID = $("#Alter_DataItemID").val();
    var CheckName = $("#Alter_DataItemName").val();
    var address = document.getElementById("Alter_DataItemAddress").value;
    var type = document.getElementById("Alter_DataItemType").value;
    var reg = new RegExp("^[0-9]+$");
    var regID = new RegExp("^[1-9]+[0-9]*$");
    //校验数据项ID输入格式
    if (CheckID == "" || !regID.test(CheckID)) {
        if (coo == "English") {
            $("#idTipInfo").html("The dataItem ID must be a non-negative integer");
        } else {
            $("#idTipInfo").html("数据项ID必须为非负整数");
        }
    } else {
        $.ajax({
            type: "get",
            url: "../conf/config.xml",
            async: false,
            success: function (data) {
                var flag = 0;
                $(data).find("dataItem").each(function () {
                    var $dataItem = $(this);
                    var dataItemID = $dataItem.attr('id');
                    if (dataItemID == CheckID) {
                        var dataItemName = $dataItem.attr('n');
                        if (dataItemName == NowItemName) {
                            //跳过
                        } else {
                            flag = flag + 1;
                        }
                    }
                });

                if (flag < 1) {
                    $("#idTipInfo").html("");
                } else {
                    if (coo == "English") {
                        $("#idTipInfo").html("DataItem ID has been repeated, please change it");
                    } else {
                        $("#idTipInfo").html("数据项ID已重复，请更改");
                    }
                }
            }
        });
    }

    //校验数据项名称输入格式
    if (!Check_Chinese_Character(CheckName)) {
        if (coo == "English") {
            $("#nameTipInfo").html("*The dataItem name format error, only the alphanumeric underscore and must start with the letter");
        } else {
            $("#nameTipInfo").html("*数据项名称格式错误，仅允许字母数字下划线且必须以字母开头");
        }
    } else {
        //名字未修改时，不校验重名
        if (CheckName == NowItemName) {
            $("#nameTipInfo").html("");
        } else {
            //校验数据项名称是否重名
            if (!CheckReName(CheckName)) {
                if (coo == "English") {
                    $("#nameTipInfo").html("The dataItem name is repeated")
                } else {
                    $("#nameTipInfo").html("数据项名称重复")
                }
            } else {
                $("#nameTipInfo").html("");
            }
        }
    }
    //校验数据项别名不为空
    if (document.getElementById("Alter_DataItemAlias").value == "") {
        if (coo == "English") {
            document.getElementById("AliasTipInfo").innerHTML = "*Please enter the alias";
        } else {
            document.getElementById("AliasTipInfo").innerHTML = "*请输入别名";
        }
    } else {
        document.getElementById("AliasTipInfo").innerHTML = "";
    }
    if (ChannelDeviceType != "Modbus-RTU-task" && ChannelDeviceType != "Modbus-ASCII-task" && ChannelDeviceType != "Modbus-TCP-task") {
        //从站ID为空
        if (document.getElementById("Alter_DataItemSlave").value == "") {
            if (coo == "English") {
                document.getElementById("SlaveTipInfo").innerHTML = "*Please enter a slave station ID";
            } else {
                document.getElementById("SlaveTipInfo").innerHTML = "*请输入从站ID";
            }
        } else {
            document.getElementById("SlaveTipInfo").innerHTML = "";
        }
    } else {

    }
    //数据项地址为空
    if (document.getElementById("Alter_DataItemAddress").value == "") {
        if (coo == "English") {
            document.getElementById("addressTipInfo").innerHTML = "*Please enter the dataItem address";
        } else {
            document.getElementById("addressTipInfo").innerHTML = "*请输入数据项地址";
        }
    } else {
        document.getElementById("addressTipInfo").innerHTML = "";
    }

    $("#AdditionalTipInfo").html('');
    var isChecked = $("input[name='Alter_DataItemDHEnable']:checked").val();
    if (isChecked == '1') {
        var paramVal = $('#Alter_DataItemDHParam').val();
        if ($("#Alter_DataItemDHSelect").val() == "#") {
            var linearParam1 = $("#Alter_DHFunctionParam1").val();
            var linearParam2 = $("#Alter_DHFunctionParam2").val();
            if (linearParam1 == "" || linearParam2 == "") {
              if (coo == "English") {
                $("#AdditionalTipInfo").html(
                  "Please fill in the value operation parameters"
                );
              } else {
                $("#AdditionalTipInfo").html("请填写值运算参数");
              }
            } else {
              var dhReg = /^-?[0-9]+.?[0-9]*$/;
              if (!dhReg.test(linearParam1) || !dhReg.test(linearParam2)) {
                if (coo == "English") {
                  $("#AdditionalTipInfo").html(
                    "The value operation parameter must be a number"
                  );
                } else {
                  $("#AdditionalTipInfo").html("值运算参数必须是数字");
                }
              }
            }
          }else if (paramVal == "") {
            if (coo == "English") {
                $("#AdditionalTipInfo").html('Please fill in the value operation parameters');
            } else {
                $("#AdditionalTipInfo").html('请填写值运算参数');
            }
        } else {
            // 校验输入的操作数是否是数字
            var dhReg = /^-?[0-9]+.?[0-9]*$/;
            if (!dhReg.test(paramVal)) {
                if (coo == "English") {
                    $("#AdditionalTipInfo").html('The value operation parameter must be a number');
                } else {
                    $("#AdditionalTipInfo").html('值运算参数必须是数字');
                }
            } else if ($("#Alter_DataItemDHSelect").val() == '5') {
                var dhReg = /^[0-9]+$/;
                if (!dhReg.test(paramVal)) {
                    if (coo == "English") {
                        $("#AdditionalTipInfo").html('The parameter of the fetch operation must be an integer');
                    } else {
                        $("#AdditionalTipInfo").html('取位运算的参数必须是整数');
                    }
                } else {
                    var paramVal = Number(paramVal);
                    if (paramVal < 0 || paramVal > 31) {
                        if (coo == "English") {
                            $("#AdditionalTipInfo").html('The range of parameters for the fetch operation must be 0 to 31');
                        } else {
                            $("#AdditionalTipInfo").html('取位运算的参数的范围必须是0到31');
                        }
                    }
                }
            }
        }
    }

    //采集频率为空或不为正整数
    if (document.getElementById("Alter_DataItemFreq").value == "") {
        if (coo == "English") {
            document.getElementById("FreqTipInfo").innerHTML = "*Please enter the sample frequency";
        } else {
            document.getElementById("FreqTipInfo").innerHTML = "*请输入采集频率";
        }
    } else {
        num = document.getElementById("Alter_DataItemFreq").value;
        var reg = new RegExp("^[0-9]*[1-9][0-9]*$");
        if (reg.test(num)) {
           $.ajax({
             type: "get",
             url: "../conf/Common.xml",
             async: false,
             success: function (data) {
               var minFrequency = $(data).find("MinFrequency").text();
               var currentFreq = 0;
               if ($("#Alter_DataItemUnit").val() == "second") {
                 currentFreq = parseInt(num) * 1000;
               } else {
                 currentFreq = parseInt(num) * 1000 * 60;
               }

               if (currentFreq < parseInt(minFrequency)) {
                 if (coo == "English") {
                   $("#FreqTipInfo").html(
                     "*The lowest frequency currently supported is" +
                       minFrequency / 1000 +
                       "seconds"
                   );
                 } else {
                   $("#FreqTipInfo").html(
                     "*当前支持的最低频率为" + minFrequency / 1000 + "秒"
                   );
                 }
               } else {
                 $("#FreqTipInfo").html("");
               }
             },
           });
        } else {
            if (coo == "English") {
                document.getElementById("FreqTipInfo").innerHTML = "*The sample frequency should be positive integer";
            } else {
                document.getElementById("FreqTipInfo").innerHTML = "*采集频率应为正整数";
            }
        }
    }
    if ($("#Alter_DataItemFunction").val() == "-1") {
        if (coo == "English") {
            $("#checkTwoInfo").html("*Please enter the correct dataItem address");
        } else {
            $("#checkTwoInfo").html("*请输入正确的数据项地址");
        }
    } else {
        $("#checkTwoInfo").html("");
    }

    if (AnyLinkType == 'RF') { //RF有网络号
        if (ChannelDeviceType != "Modbus-RTU-task" && ChannelDeviceType != "Modbus-ASCII-task" && ChannelDeviceType != "Modbus-TCP-task") {
            if ($("#Alter_NetNumber").val() == "") {
                if (coo == "English") {
                    $("#NetNumberTipInfo").html("Please enter network number");
                } else {
                    $("#NetNumberTipInfo").html("请输入网络号");
                }
            } else {
                var num = $("#Alter_NetNumber").val();
                var reg = new RegExp("^[0-9]+$");
                if (reg.test(num)) {
                    $("#NetNumberTipInfo").html("");
                } else {
                    if (coo == "English") {
                        $("#NetNumberTipInfo").html("Network Numbers should be Numbers");
                    } else {
                        $("#NetNumberTipInfo").html("网络号应为数字");
                    }
                }
            }
        } else {
            $("#NetNumberTipInfo").html("");
        }
    }

    var DataItemType = $("#Alter_DataItemType").val();
    var StringLength = $("#Alter_stringLength").val();
    var reg2 = new RegExp("^[0-9]*$");
    //如果数据项类型为String，则校验长度是否为整数且为偶数
    if (DataItemType == "STRING") {
        if (StringLength == "") {
            if (coo == "English") {
                $("#Alter_stringMsg").html("*Please enter the length");
            } else {
                $("#Alter_stringMsg").html("*请输入长度");
            }
        } else {
            if (reg2.test(StringLength) && parseInt(StringLength) % 2 == 0) {
                $("#Alter_stringMsg").html("");
            } else {
                if (coo == "English") {
                    $("#Alter_stringMsg").html("*The length must be numeric and even");
                } else {
                    $("#Alter_stringMsg").html("*长度必须为数字且为偶数");
                }
            }
        }
    } else if (DataItemType == "CUSTOM") {
        if (StringLength == "") {
            if (coo == "English") {
                $("#Alter_stringMsg").html("*Please enter the length");
            } else {
                $("#Alter_stringMsg").html("*请输入长度");
            }
        }

    } else {
        $("#Alter_stringMsg").html("");
    }

    //全部校验都过
    if ($("#idTipInfo").html() == "" && document.getElementById('nameTipInfo').innerHTML == "" && document.getElementById('addressTipInfo').innerHTML == "" && document.getElementById('AliasTipInfo').innerHTML == "" && document.getElementById("SlaveTipInfo").innerHTML == "" && document.getElementById('FreqTipInfo').innerHTML == "" && document.getElementById("AdditionalTipInfo").innerHTML == "" && document.getElementById("checkTwoInfo").innerHTML == "" && document.getElementById("Alter_stringMsg").innerHTML == "" && document.getElementById("NetNumberTipInfo").innerHTML == "") {
        //校验重名
        //如果没有修改，即输入名称框没有变化，则直接保存
        if (CheckName == NowItemName) {
            Alter_DataItemMethod();
        } else {
            if (Check_Chinese_Character(CheckName)) {
                if (CheckReName(CheckName)) {
                    Alter_DataItemMethod();
                } else {
                    if (coo == "English") {
                        document.getElementById('nameTipInfo').innerHTML = "*The dataItem name is repeated";
                    } else {
                        document.getElementById('nameTipInfo').innerHTML = "*数据项名称重复";
                    }
                }
            } else {
                if (coo == "English") {
                    document.getElementById('nameTipInfo').innerHTML = "*Only allow alphanumeric underscores and must begin with a letter";
                } else {
                    document.getElementById('nameTipInfo').innerHTML = "*仅允许字母数字下划线且必须以字母开头";
                }
            }
        }
    }
}
//修改数据项方法
function Alter_DataItemMethod() {
    var DataItemType = $("#Alter_DataItemType").val();
    var StringLength = $("#Alter_stringLength").val();
    var Freq = $("#Alter_DataItemFreq").val();
    var Unit = $("#Alter_DataItemUnit").val();
    if (Unit == "minute") {
        Freq = Freq * 60000;
    } else {
        Freq = Freq * 1000;
    }
    //数据项类型
    if ($("#Alter_DataItemType").val() == "BOOLEAN") {
        $("#Alter_DataItemType_YuToXHZhang").val("b");
    } else if ($("#Alter_DataItemType").val() == "STRING" || $("#Alter_DataItemType").val() == "CUSTOM") {
        $("#Alter_DataItemType_YuToXHZhang").val("s");
    } else {
        $("#Alter_DataItemType_YuToXHZhang").val("a");
    }

    //设备ID
    $("#Alter_DeviceID_YuToXHZhang").val(DeviceID);
    //数据项ID
    $("#Alter_DataItemID_after").val($("#Alter_DataItemID").val());
    //数据项名称
    $("#Alter_DataItemName_YuToXHZhang").val($("#Alter_DataItemName").val());
    //数据项别名
    $("#Alter_DataItemAlias_YuToXHZhang").val($("#Alter_DataItemAlias").val());
    //读写模式
    $("#Alter_DataItemRWmode_YuToXHZhang").val($("input[name='Alter_DataItemRWmode']:checked").val());
    //频率
    $("#Alter_DataItemFreq_YuToXHZhang").val(Freq);
    //是否上报
    $("#Alter_DataItemReport_YuToXHZhang").val( $("input[name='Alter_ReportType']:checked").val() );

    var isChecked = $("input[name='Alter_DataItemDHEnable']:checked").val();
    $('#Alter_DataItemDHEnable_YuToXHZhang').val(isChecked);
    if (isChecked == '1') {
        $('#Alter_DataItemDHOptType_YuToXHZhang').val($('#Alter_DataItemDHSelect').val());
        if ($("#Alter_DataItemDHSelect").val() === "#") {
            $("#Alter_DataItemDHOptParam_YuToXHZhang").val(
              $("#Alter_DHFunctionParam1").val() +
                "|" +
                $("#Alter_DHFunctionParam2").val()
            );
          } else {
            $("#Alter_DataItemDHOptParam_YuToXHZhang").val(
              $("#Alter_DataItemDHParam").val()
            );
          }
    }

    //数据项配置字符串,数据项类型为String，则添加长度。config字符串添加对其方式
    //如果是RF，则大小端后面添加网络号
    if (ChannelDeviceType != "Modbus-RTU-task" && ChannelDeviceType != "Modbus-ASCII-task" && ChannelDeviceType != "Modbus-TCP-task") {
        if (AnyLinkType == 'RF') {
            $("#Alter_DataItemConfig_YuToXHZhang").val($("#Alter_DataItemSlave").val() + ";" + $("#Alter_DataItemFunction").val() + ";" + $("#Alter_DataItemAddress").val() + ";" + (DataItemType == "STRING" || DataItemType == "CUSTOM" ? DataItemType + StringLength : DataItemType) + ";" + $("#Alter_DataItemReport2").val() + ";" + $("input[name='Alter_AlignType']:checked").val() + ";" + $("#Alter_NetNumber").val() + ";" + $("input[name='Alter_DataItemRWmode']:checked").val());
        } else {
            $("#Alter_DataItemConfig_YuToXHZhang").val($("#Alter_DataItemSlave").val() + ";" + $("#Alter_DataItemFunction").val() + ";" + $("#Alter_DataItemAddress").val() + ";" + (DataItemType == "STRING" || DataItemType == "CUSTOM" ? DataItemType + StringLength : DataItemType) + ";" + $("#Alter_DataItemReport2").val() + ";" + $("input[name='Alter_AlignType']:checked").val() + ";" + $("input[name='Alter_DataItemRWmode']:checked").val());
        }
    } else {
        $("#Alter_DataItemConfig_YuToXHZhang").val($("#Alter_DataItemFunction").val() + ";" + $("#Alter_DataItemAddress").val() + ";" + (DataItemType == "STRING" || DataItemType == "CUSTOM" ? DataItemType + StringLength : DataItemType) + ";" + $("input[name='Alter_AlignTypeTask']:checked").val());
    }
    //document.getElementById("Alter_DataItemConfig_YuToXHZhang").value = str.substr(0, length) + ";" + document.getElementById("Alter_DataItemType").value + ";" + str.substr(length) + ";" + $("input[name='Alter_DataItemRWmode']:checked").val();
    $("#return5").attr("disabled", "disabled");
    $("#return6").attr("disabled", "disabled");
    var params = $("#Alter_DataItemForm_YuToXHZhang").serialize();
    $.ajax({
        type: "post",
        url: "cgi-bin/device/AlterDataitem.py",
        data: params,
        async: true,
        success: function (data) {
            $("#popWindow").hide();
            $("#Alter_DataItem_Layer").hide();
            $("#return5").attr("disabled", "");
            $("#return6").attr("disabled", "");
            getData();
        }
    });
}

//全局一个需要删除的长度
var checkLength = "";

function CheckedLength() {
    checkLength = 0;
    document.getElementById("AllDataitemID").value = "";
    document.getElementById("Delete_DataItemAllID_YuToXHZhang").value = "";
    var inputs = document.getElementsByName("tryadd");
    var length = inputs.length;
    for (var i = 0; i < length; i++) {
        if (inputs[i].checked) {
            document.getElementById("AllDataitemID").value += inputs[i].value + ";";
            checkLength++;
        }
    }
    var str = document.getElementById("AllDataitemID").value;
    var strArr = new Array();
    strArr = str.split(";");
    var maxlength = strArr.length;
    for (var j = 0; j < maxlength - 2; j++) {
        document.getElementById("Delete_DataItemAllID_YuToXHZhang").value += strArr[j] + ",";
    }
    document.getElementById("Delete_DataItemAllID_YuToXHZhang").value += strArr[maxlength - 2];
}

//删除数据项
function DeleteConfig() {
    document.getElementById("Delete_DeviceID_YuToXHZhang").value = DeviceID;
    CheckedLength();
    $("#DeleteDataItem_Button_Confim").attr("disabled", "disabled");
    $("#DeleteDataItem_Button_Cancel").attr("disabled", "disabled");
    var params = $("#Delete_DataItemForm_YuToXHZhang").serialize();
    $.ajax({
        type: "post",
        url: "cgi-bin/device/DeleteDataitem.py",
        data: params,
        async: true,
        success: function (data) {
            $("#popWindow").hide();
            $("#DeleteDataItemLayer").hide();
            $("#DeleteDataItem_Button_Confim").attr("disabled", "");
            $("#DeleteDataItem_Button_Cancel").attr("disabled", "");
            getData();
            $("#selectAll").attr("checked", "");
        }
    });
}

//全选和反选
function addTry() {
    if (document.getElementById("selectAll").checked) {
        var inputs = document.getElementsByName("tryadd");
        for (var i = 0; i < inputs.length; i++) {
            inputs[i].checked = true;
        }
    } else {
        var inputs = document.getElementsByName("tryadd");
        for (var i = 0; i < inputs.length; i++) {
            inputs[i].checked = false;
        }
    }
}
//下发数据项
function Open_IssuedLayer() {
    document.getElementById("popWindow").style.display = ''
    document.getElementById("IssuedLayer").style.display = ''
    document.getElementById("ConUp1").style.display = ''
    $("#up_success").hide();
    //      document.getElementById("Hide_IssuedIframe").style.display = 'none'
    document.getElementById("Issued_Button_Confim").style.display = ''
    document.getElementById("Issued_Button_Cancel").style.display = ''
    document.getElementById("Issued_Success_Button_Confim").style.display = 'none'
    //动态图隐藏
    document.getElementById("Loading").style.display = "none";
}

function UpConfigCon() {
    times = 0;
    document.getElementById("IssuedLayer").style.display = 'none';
    window.parent.document.getElementById("IssuedLayer").style.display = '';
    document.getElementById("ConUp1").style.display = 'none';
    //      document.getElementById("Hide_IssuedIframe").style.display = "none"
    $("#Issued_Button_Confim").attr("disabled", "disabled");
    $("#Issued_Button_Cancel").attr("disabled", "disabled");
    $.ajax({
        type: "post",
        url: "cgi-bin/agent/GiveToAgent.py",
        data: "up=1",
        async: false,
        success: function (data) {
            $("#up_success").html(data);
            document.getElementById("popWindow").style.backgroundColor = "#ddd";
            window.parent.document.getElementById("popWindow").style.display = "";
            window.parent.document.getElementById("IssuedLayer").style.display = '';
            getagent = setInterval("getAgentStatue()", 5000);
        }
    });
}
//全局一个发送次数
var times = 0
var getagent = "";

function getAgentStatue() {
    //获取测试字符串
    var value = getFirstID();
    $("#Test_Value_YuToXHZhang").val(value);
    var params = $("#Test_DataItemForm_YuToXHZhang").serialize();
    times++;
    //45秒超时
    if (times < 18) {
        $.ajax({
            type: "post",
            url: "cgi-bin/RealTimeData/GetAgentStatue.py",
            data: params,
            async: true,
            success: function (data) {
                //如果测试返回结果正确，即返回为1，则可以关闭下发窗口
                if (data == 1) {
                    $("#up_success").show();
                    $("#Loading").hide();
                    $("#Issued_Button_Confim").attr("disabled", "");
                    $("#Issued_Button_Cancel").attr("disabled", "");
                    $("#Issued_Button_Confim").hide();
                    $("#Issued_Button_Cancel").hide();
                    $("#Issued_Success_Button_Confim").show();
                    $("#ConUp1").hide();
                    window.parent.document.getElementById("popWindow").style.display = "none";
                    document.getElementById("popWindow").style.backgroundColor = "#9D9D9D";
                    window.parent.document.getElementById("IssuedLayer").style.display = 'none';
                    document.getElementById("IssuedLayer").style.display = '';
                    clearInterval(getagent);
                } else {

                }
            },
        });
    } else {
        $("#Issued_Button_Confim").attr("disabled", "");
        $("#Issued_Button_Cancel").attr("disabled", "");
        document.getElementById("IssuedLayer").style.display = '';
        window.parent.document.getElementById("popWindow").style.display = "none";
        document.getElementById("popWindow").style.backgroundColor = "#9D9D9D";
        window.parent.document.getElementById("IssuedLayer").style.display = 'none';
        if (coo == "English") {
            document.getElementById("up_success").innerHTML = "Agent startup timeout, please try again later";
        } else {
            document.getElementById("up_success").innerHTML = "agent启动超时，请稍后再试";
        }
        document.getElementById("up_success").style.display = "";
        document.getElementById("ConUp1").style.display = "none";
        document.getElementById("Issued_Button_Confim").style.display = 'none';
        document.getElementById("Issued_Success_Button_Confim").style.display = '';
        clearInterval(getagent);
    }
}

function getFirstID() {
    var id = "";
    $.ajax({
        type: "get",
        url: "../conf/config.xml",
        async: false,
        success: function (data) {
            $(data).find("model[id='" + ChannelID + "']").each(function () {
                var $model = $(this);
                $model.find("device[id='" + DeviceID + "']").each(function () {
                    var $device = $(this);
                    $device.find("driver").each(function () {
                        var $driver = $(this);
                        DriverID = $driver.attr('id');
                        $driver.find("commDataItems").each(function () {
                            var $commDataItems = $(this);
                            $commDataItems.find("dataItem:first-child").each(function () {
                                var $dataItem = $(this);
                                var dataItemID = $dataItem.attr('id');
                                id = dataItemID;
                            });
                        });
                    })
                });
            });
        }
    });
    //拼出测试字符串

    var value = "";
    var ChannelDriverArr = new Array();
    ChannelDriverArr = ChannelDriver.split(":");
    var ChannelDriverShort = ChannelDriverArr[1];
    if (id == "") {
        //没有数据时候
        value = '{"id":' + DeviceID + ',"dn":"","vid":' + DriverID + ',"vn":"' + ChannelDriverShort + '", "cmds":{"read":1}}'
    } else {
        value = '{"id":' + DeviceID + ',"dn":"","vid":' + DriverID + ',"vn":"' + ChannelDriverShort + '", "cmds":{"read":0,"ids":[' + id + ']}}'
    }
    return value;
}
//读数据项ID最大值并赋值
function getID() {
    $.get('../conf/IDinfo.xml', function (d1) {
        $(d1).find("IDALL").each(function () {
            var $IDALL = $(this);
            var DataitemID = $IDALL.find('ItemID').text();
            document.getElementById("Add_DataItemID_YuToXHZhang").value = DataitemID;
            document.getElementById("Add_DataItemID").value = DataitemID;
        });
    });
}

function Import_DataItem() {
    if (document.getElementById("FileName").value == "") {
        if (coo == "English") {
            alert("Please select the files to upload!")
        } else {
            alert("请选择需要上传的文件！")
        }
    } else {
        document.getElementById('Import_Button_Confirm').disabled = true;
        document.getElementById('Import_Button_Cancel').disabled = true;
        document.getElementById("ImportForm_YuToXHZhang").action = '../cgi-bin/import/ImportModbusTask.py?deviceID=' + DeviceID;
        document.getElementById("ImportForm_YuToXHZhang").submit();
        var iframe01 = document.getElementById("Hide_ImportIframe");
        if (iframe01.attachEvent) {
            iframe01.attachEvent("onload", function () {
                document.getElementById("UpWord").style.display = 'none';
                document.getElementById("Import_Two_Button").style.display = 'none';
                document.getElementById("Success_Import").style.display = '';
                document.getElementById("Import_Success_Button").style.display = '';
                document.getElementById('Import_Button_Confirm').disabled = false;
                document.getElementById('Import_Button_Cancel').disabled = false;
            });
        } else {
            iframe01.onload = function () {
                document.getElementById("UpWord").style.display = 'none';
                document.getElementById("Import_Two_Button").style.display = 'none';
                document.getElementById("Success_Import").style.display = '';
                document.getElementById("Import_Success_Button").style.display = '';
                document.getElementById('Import_Button_Confirm').disabled = false;
                document.getElementById('Import_Button_Cancel').disabled = false;
            };
        }
    }
}


function Close_ExportLayer() {
    document.getElementById("popWindow").style.display = 'none'
    document.getElementById("ExprotLayer").style.display = 'none'
    document.getElementById('Exportout').disabled = false;
    document.getElementById('ExSucc').disabled = false;
}

function ExportInfo() {
    document.getElementById("ExportForm_YuToXHZhang").action = '../cgi-bin/export/ExportModbusTask.py?deviceID=' + DeviceID;
    document.getElementById("ExportForm_YuToXHZhang").submit();
    document.getElementById("ExportForm_YuToXHZhang").target = 'Hide_ExportIframe';
    document.getElementById('Exportout').disabled = true;
    document.getElementById('ExSucc').disabled = true;
    window.setTimeout(Close_ExportLayer, 3000);
}
//切换到测试
function Open_TestLayer() {
    //alert(ChannelDriver)
    var value = "";
    var idArr = "";
    var ChannelDriverArr = new Array();
    ChannelDriverArr = ChannelDriver.split(":");
    var ChannelDriverShort = ChannelDriverArr[1];
    CheckedLength();
    if (document.getElementById("AllDataitemID").value == "") {
        value = '{"id":' + DeviceID + ',"dn":"", "vn":"' + ChannelDriverShort + '", "cmds":{"read":1}}'
    } else {
        var str = document.getElementById("AllDataitemID").value;
        var strArr = new Array();
        strArr = str.split(";");
        var maxlength = strArr.length;
        for (var j = 0; j < maxlength - 2; j++) {
            idArr += strArr[j] + ",";
        }
        idArr += strArr[maxlength - 2];
        value = '{"id":' + DeviceID + ',"dn":"", "vn":"' + ChannelDriverShort + '", "cmds":{"read":0,"ids":[' + idArr + ']}}'
    }

    TestDateItem(value);

    if (window.testTimer) {
        clearInterval(window.testTimer);
        window.testTimer = null;
    }

    window.testTimer = setInterval(function () {
        var testWindowVisable = $('#TestLayer').is(":hidden");
        var popWindowVisable = $('#popWindow').is(":hidden");
        var autoTest = ($("#onoffswitch").is(':checked'));
        if (testWindowVisable || popWindowVisable) {
            clearInterval(window.testTimer);
            window.testTimer = null;
        } else if (autoTest) {
            console.log('刷新！');
            TestDateItem(value);
        }
    }, 10000);

}

function TestDateItem(txt) {
    $("#testInfomation").empty();
    document.getElementById("Test_Value_YuToXHZhang").value = txt;
    document.getElementById("popWindow").style.display = "";
    var params = $("#Test_DataItemForm_YuToXHZhang").serialize();
    $.ajax({
        type: "post",
        url: "cgi-bin/RealTimeData/GetRealTimeData.py",
        data: params,
        async: true,
        datatype: "xml",
        beforeSend: function () {
            $("#wait").show();
        },
        complete: function () {
            $("#wait").hide();
            //方法执行完毕，效果自己可以关闭，或者隐藏效果
        },
        success: function (data) {
            if (data.substr(1, 3) != "All") {
                $("#wait").hide();
                $("#popWindow").hide();
                alert(data);
            } else {
                $("#TestLayer").show();
                $(data).find("dataItem").each(function () {
                    var $dataitem = $(this);
                    var name = $dataitem.attr("n");
                    var config = $dataitem.attr("config");
                    var id = $dataitem.attr("id");
                    var typeshort = $dataitem.attr("type");
                    var freq = $dataitem.attr("freq");
                    var report = $dataitem.attr("report");
                    var value = $dataitem.attr("value");
                    var alias = $dataitem.attr("alias");
                    var quality1 = $dataitem.attr("quality");
                    var configArr = new Array();
                    configArr = config.split(";");
                    var salve = configArr[0];
                    var add = configArr[2];
                    var type = "";
                    var quality = "";
                    if (quality1 == 1) {
                        quality = "good";
                    }
                    if (quality1 != 1) {
                        quality = "bad";
                    }
                    if (typeshort == "b")
                        type = "Boolean";
                    if (typeshort == "a")
                        type = "Dword";
                    if (typeshort == "s")
                        type = "String";

                    var list = "<div style='width:678px;height:25px;border: 1px solid #D7D7D7;border-top:none'>" +
                        "<div align='center' style='width:137px;float:left;height:25px;line-height:25px;overflow:hidden' title='" + alias + "'>" + name + "</div>" +
                        "<div align='center' style='width:136px;float:left;height:25px;line-height:25px;overflow:hidden' title='" + alias + "'>" + alias + "</div>" +
                        "<div align='center' style='width:136px;float:left;height:25px;line-height:25px'>" + add + "</div>" +
                        "<div align='center' style='width:136px;float:left;height:25px;line-height:25px'>" + value + "</div>" +
                        "<div align='center' style='width:125px;float:left;height:25px;line-height:25px'>" + quality + "</div>" +
                        "</div>"

                    if (ChannelDeviceType == "Modbus-RTU-task" || ChannelDeviceType == "Modbus-ASCII-task" || ChannelDeviceType == "Modbus-TCP-task") {
                        list = "<div style='width:678px;height:25px;border: 1px solid #D7D7D7;border-top:none'>" +
                            "<div align='center' style='width:137px;float:left;height:25px;line-height:25px;overflow:hidden' title='" + alias + "'>" + name + "</div>" +
                            "<div align='center' style='width:136px;float:left;height:25px;line-height:25px;overflow:hidden' title='" + alias + "'>" + alias + "</div>" +
                            "<div align='center' style='width:136px;float:left;height:25px;line-height:25px'>" + configArr[1] + "</div>" +
                            "<div align='center' style='width:136px;float:left;height:25px;line-height:25px'>" + value + "</div>" +
                            "<div align='center' style='width:125px;float:left;height:25px;line-height:25px'>" + quality + "</div>" +
                            "</div>"
                    }
                    $("#testInfomation").append(list);
                });
            }
        },
        error: function () {
            $("#popWindow").hide();
            if (coo == "English") {
                alert("Test fails, please contact your administrator");
            } else {
                alert("测试失败，请联系管理员");
            }
        }
    });
}
//解析传输的值
//根据ID解析数据
// function resolveData(txt) {
//     var dataItemN = "";
//     var dataItemA = "";
//     var dataItemType = "";
//     var dataItemSalveID = "";
//     var dataItemAdd = "";
//     $.ajax({
//         type: "GET",
//         async: false,
//         url: "../conf/config.xml",
//         success: function (result) {
//             $(result).find("model[id='" + ChannelID + "']").each(function () {
//                 var $model = $(this);
//                 $model.find("device[id='" + DeviceID + "']").each(function () {
//                     var $device = $(this);
//                     $device.find("commDataItems").each(function () {
//                         var $commDataItems = $(this);
//                         $commDataItems.find("dataItem[id='" + txt + "']").each(function () {
//                             var $dataItem = $(this);
//                             dataItemN = $dataItem.attr('n');
//                             dataItemA = $dataItem.attr('alias');
//                             var config = $dataItem.attr("config");
//                             var configArr = new Array();
//                             configArr = config.split(";");
//                             dataItemType = configArr[4];
//                             dataItemSalveID = configArr[0];
//                             dataItemAdd = configArr[2];
//                         });
//                     });
//                 });
//             });
//         }
//     });
//     var context = {
//         "name": dataItemN,
//         "alies": dataItemA,
//         "type": dataItemType,
//         "SalveID": dataItemSalveID,
//         "add": dataItemAdd
//     };
//     return context;
// }
//切换到导入
function Open_ImportLayer() {
    $("#popWindow").show();
    $("#ImportLayer").show();
    $("#FileName").val("");
    $("#UpWord").show();
    $("#Import_Two_Button").show();
    $("#Success_Import").hide();
    $("#Import_Success_Button").hide();
    $("#Import_Button_Confirm").show();
    $("#Import_Button_Cancel").show();
}
//切换到导出
function Open_ExportLayer() {
    document.getElementById("popWindow").style.display = '';
    document.getElementById("ExprotLayer").style.display = '';
}


//配置和MASK
function ChangeMASK() {
    if (document.getElementById("Add_DataItemAdditionalSelect").value == 1) {
        // $("#AdditionalTip").html("");
        $("#Add_addition_a").remove();
        $("#Add_addition_b").remove();
        $("#Add_DataItemAdditional").remove();
        $("#Add_DataItemAdditionalSelect").parent().append('<input name="" type="text" id="Add_DataItemAdditional" style="width:90px; height:20px;" value="1">');
    }
    if (document.getElementById("Add_DataItemAdditionalSelect").value == 2) {
        $("#Add_addition_a").remove();
        $("#Add_addition_b").remove();
        $("#Add_DataItemAdditional").remove();
        $("#Add_DataItemAdditionalSelect").parent().append('<input name="" type="text" id="Add_DataItemAdditional" style="width:90px; height:20px;" value="mask-">');
    }
    if (document.getElementById("Add_DataItemAdditionalSelect").value == 3) {
        $("#Add_addition_a").remove();
        $("#Add_addition_b").remove();
        $("#Add_DataItemAdditional").remove();
        $("#Add_DataItemAdditionalSelect").parent().append("<input type='text' placeholder='a' id='Add_addition_a' style='width:40px; height:20px;'><input type='text' placeholder='b' id='Add_addition_b' style='width:40px; height:20px;margin-left:6px;'>");
    }
}

function Alter_ChangeMASK() {
    if (document.getElementById("Alter_DataItemAdditionalSelect").value == 1) {
        $("#Alter_addition_a").remove();
        $("#Alter_addition_b").remove();
        $("#Alter_DataItemAdditional").remove();
        $("#Alter_DataItemAdditionalSelect").parent().append('<input name="" type="text" id="Alter_DataItemAdditional" style="width:90px; height:20px;" value="1">');
    }
    if (document.getElementById("Alter_DataItemAdditionalSelect").value == 2) {
        $("#Alter_addition_a").remove();
        $("#Alter_addition_b").remove();
        $("#Alter_DataItemAdditional").remove();
        $("#Alter_DataItemAdditionalSelect").parent().append('<input name="" type="text" id="Alter_DataItemAdditional" style="width:90px; height:20px;" value="mask-">');
    }
    if (document.getElementById("Alter_DataItemAdditionalSelect").value == 3) {
        $("#Alter_addition_a").remove();
        $("#Alter_addition_b").remove();
        $("#Alter_DataItemAdditional").remove();
        $("#Alter_DataItemAdditionalSelect").parent().append("<input type='text' placeholder='a' id='Alter_addition_a' style='width:40px; height:20px;'><input type='text' placeholder='b' id='Alter_addition_b' style='width:40px; height:20px;margin-left:6px;'>");
    }
}

function Import_Success_ReloadNewPage() {
    getData();
    $("#popWindow").hide();
    $("#ImportLayer").hide();
}

$("#Add_DataItemType").change(function () {
    if ($(this).val() == "STRING" || $(this).val() == "CUSTOM") {
        $("#tr_string").show();
        $("#tr_string_msg").show();
    } else {
        $("#tr_string").hide();
        $("#tr_string_msg").hide();
    }
});

$("#Alter_DataItemType").change(function () {
    if ($(this).val() == "STRING" || $(this).val() == "CUSTOM") {
        $("#Alter_tr_string").show();
        $("#Alter_tr_string_msg").show();
    } else {
        $("#Alter_tr_string").hide();
        $("#Alter_tr_string_msg").hide();
    }
});

function open_write_layer(data) {

    $('#write_layer').css('display', '');
    $("#popWindow").css('display', '');
    //
    $("#Write_Button_Confirm").unbind("click").click(function () {
        //构造参数
        data.cmds[0]["userid"] = "1493282026529"; //userid 可以随便填写
        data.cmds[0]["cmd"] = $("#write_input").val();

        //验证非空
        if (data.cmds[0]["cmd"] == "" || data.cmds[0]["cmd"] == null) {
            if (coo == "English") {
                alert("Write value cannot be empty");
            } else {
                alert("写入值不能为空");
            }
            return;
        }
        if (data.cmds[0]["rw"] == "0") {
            if (coo == "English") {
                alert("Please set the R/W type to be Read&Write first.");
            } else {
                alert("请先设置读写类型为可写");
            }
            return;
        }
        //验证bool 类型(dt == b)只能为0或1
        if (data.cmds[0]['dt'] == 'b' && ['0', '1'].indexOf(data.cmds[0]["cmd"]) == -1) {
            if (coo == "English") {
                alert("Boolean type can only fill 0 or 1");
            } else {
                alert("Boolean类型只能填写0或者1");
            }
            return;
        }
        //直接提交json cgi无法收到，这里把json字符串放到一个伪造的表单里,key是'Write_Value_command'
        var $form = $("<form></form>");
        var $input = $("<input tyle='text' name='Write_Value_command'>");
        $input.val(JSON.stringify(data))
        $form.append($input);
        var param = $form.serialize();
        $.ajax({
            type: 'post',
            url: 'cgi-bin/RealTimeData/WriteItemValue.py',
            data: param,
            // dataType: 'xml',
            beforeSend: function (request) {
                $("#Write_Button_Confirm").attr("disabled", "disabled");
                $("#write_Button_Cancel").attr("disabled", "disabled");
            },
            complete: function () {
                $("#Write_Button_Confirm").removeAttr("disabled");
                $("#write_Button_Cancel").removeAttr("disabled");
                $('#write_layer').css('display', 'none');
                $("#popWindow").css('display', 'none');
                $('#write_input').val("");
            },
            success: function (data) {
                alert(data);
            },
            error: function () {
                alert('error');
            }
        })
    })
    // }
};

function clocs_write_layer() {
    $('#write_layer').css('display', 'none');
    $("#popWindow").css('display', 'none');
    $('#write_input').val("");
};