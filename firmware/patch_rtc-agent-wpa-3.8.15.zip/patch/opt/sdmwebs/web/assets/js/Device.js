﻿//根据cookies来刷页面
CheckLogin();
//取出cookies中的语言值，根据语言来判断哪种中文或英文

//禁缓存
$.ajaxSetup({
    cache: false
});
//验证ip的正则
var reg = /^(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9])\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[0-9])$/;
var regnum = new RegExp("^[0-9]*$");
//设置全局变量
//通道名称
var ChannelName = "";
//通道ID
var ChannelID = "";
//通道设备驱动
var ChannelDevice = "";
//传过来的通道配置
var ChannelConfig = "";
//远程地址
var DeviceRemoteAdd = "";
//add begin by x
//新增的id属性
var AmsNetID = "";
//end add
//设备数量（定ID用，与下面的max作为点击变化效果）
var DeviceNum = 1000000000000;
//总共的设备数量
var maxDeviceNum = "";
//添加时用到的最大设备ID
var maxDeviceID = "";
//移动效果中的选中的ID
var CheckedDeviceID = "";
//修改删除需要的设备ID;
var Alter_Delete_CheckedDeviceID = "";
//设备的驱动类型
//添加带有站地址的设备时，需要在增加方法、修改方法和解析方法中添加
var ChannelDeviceType = "";
//添加时用到的最大驱动ID
var maxDriverID = "";
//修改时用到的驱动ID
var Alter_Delete_CheckedDriverID = "";
//设定变量存图片地址
var DevicePic = "";
//点击效果
var DevicePic1 = "";
//覆盖效果
var DevicePicHover = "";
//AnyLink 版本  DA还是 RF
var AnyLinkType = '';
//全局taskid
var taskID = "";
//海信科龙数据项字符串
var HKGparams = "";
//HKG数据项 id
var DataItemID = "";
//站号
var StationNum = "";

var coo = "";
//进入页面根据通道的ID读取当前ID下的设备信息
$(document).ready(function () {
    getAnylinkType();
    initUI();
    coo = getCookie("AnyLinkLan");
});

function getAnylinkType() {
    //加入AnyLink版本获取
    $.ajax({
        type: "get",
        url: "../conf/AnyLink.xml",
        async: false,
        success: function (data) {
            $(data).find('BasicInfo').each(function () {
                var $BasicInfo = $(this);
                AnyLinkType = $BasicInfo.find('AnyLinkType').text();
                // if (SoftVersion.indexOf("DA") > -1) {
                //     AnyLinkType = 'DA';
                // }
                // if (SoftVersion.indexOf("RF") > -1) {
                //     AnyLinkType = 'RF';
                // }
            });
        }
    });
}

//从XML中读具体设备信息
function ReadCheckedDeviceDriver(txt) {
    $("#Add_DeviceDriver").empty();
    if (coo == "English") {
        $.get('../conf/AllDeviceDriverEn.xml', function (d1) {
            $(d1).find("Fac").each(function () {
                $Fac = $(this);
                $Fac.find("Agr[value='" + txt + "']").each(function () {
                    $Agr = $(this);
                    var val_Driver = txt;
                    var text_Driver = $Agr.text();
                    var option2 = $("<option>").val(val_Driver).text(text_Driver);
                    $("#Add_DeviceDriver").append(option2);
                });
            });
        });
    } else {
        $.get('../conf/AllDeviceDriver.xml', function (d1) {
            $(d1).find("Fac").each(function () {
                $Fac = $(this);
                $Fac.find("Agr[value='" + txt + "']").each(function () {
                    $Agr = $(this);
                    var val_Driver = txt;
                    var text_Driver = $Agr.text();
                    var option2 = $("<option>").val(val_Driver).text(text_Driver);
                    $("#Add_DeviceDriver").append(option2);
                });
            });
        });
    }
}
//按按钮进入数据项界面

function GoToConfigByButton() {
    var type = locationhref(ChannelDeviceType);
    //PLC协议的三个设备
    if (type == "1") {
        // add by whc
        if (ChannelDeviceType == "FATEK编程口") {
            window.location.href = "DataItemConfig.html?channelid=" + ChannelID + "&deviceid=" + Alter_Delete_CheckedDeviceID + "&stationNum=" + StationNum + "&t=" + (new Date()).getTime();
        } else {
            window.location.href = "DataItemConfig.html?channelid=" + ChannelID + "&deviceid=" + Alter_Delete_CheckedDeviceID + "&t=" + (new Date()).getTime();
        }
        // add end
    }
    //ModBus协议的三个设备
    if (type == "2") {
        window.location.href = "DataItemConfig_ModBus.html?channelid=" + ChannelID + "&deviceid=" + Alter_Delete_CheckedDeviceID + "&t=" + (new Date()).getTime();
    }
    if (type == "3") {
        window.location.href = "DataItemConfig_MPI.html?channelid=" + ChannelID + "&deviceid=" + Alter_Delete_CheckedDeviceID + "&t=" + (new Date()).getTime();
    }
    if (type == "4") {
        window.location.href = "DataItemConfig_BacNet.html?channelid=" + ChannelID + "&deviceid=" + Alter_Delete_CheckedDeviceID + "&t=" + (new Date()).getTime();
    }
    if (type == "5") {
        window.location.href = "DataItemConfig_MBus.html?channelid=" + ChannelID + "&deviceid=" + Alter_Delete_CheckedDeviceID + "&t=" + (new Date()).getTime();
    }
    // add by fyj, 增加OCR驱动
    // add begin
    if (type == "6") {
        window.location.href = "DataItemConfig_OCR.html?channelid=" + ChannelID + "&deviceid=" + Alter_Delete_CheckedDeviceID + "&t=" + (new Date()).getTime();
    }
    // add end
    // add by fyj, 增加cloudweb驱动
    if (type == "7") {
        window.location.href = "DataItemConfig_CloudWeb.html?channelid=" + ChannelID + "&deviceid=" + Alter_Delete_CheckedDeviceID + "&t=" + (new Date()).getTime();
    }
    // add end
}
//双击打开数据项页面

function GoToConfigByDbClick(txt) {
    var type = locationhref(ChannelDeviceType);
    //PLC协议的三个设备
    if (type == "1") {
        // add by whc
        if (ChannelDeviceType == "FATEK编程口") {
            window.location.href = "DataItemConfig.html?channelid=" + ChannelID + "&deviceid=" + Alter_Delete_CheckedDeviceID + "&stationNum=" + StationNum + "&t=" + (new Date()).getTime();
        } else {
            window.location.href = "DataItemConfig.html?channelid=" + ChannelID + "&deviceid=" + Alter_Delete_CheckedDeviceID + "&t=" + (new Date()).getTime();
        }
        // add end
    }
    //ModBus协议的三个设备
    if (type == "2") {
        window.location.href = "DataItemConfig_ModBus.html?channelid=" + ChannelID + "&deviceid=" + Alter_Delete_CheckedDeviceID + "&t=" + (new Date()).getTime();
    }
    if (type == "3") {
        window.location.href = "DataItemConfig_MPI.html?channelid=" + ChannelID + "&deviceid=" + Alter_Delete_CheckedDeviceID + "&t=" + (new Date()).getTime();
    }
    if (type == "4") {
        window.location.href = "DataItemConfig_BacNet.html?channelid=" + ChannelID + "&deviceid=" + Alter_Delete_CheckedDeviceID + "&t=" + (new Date()).getTime();
    }
    if (type == "5") {
        window.location.href = "DataItemConfig_MBus.html?channelid=" + ChannelID + "&deviceid=" + Alter_Delete_CheckedDeviceID + "&t=" + (new Date()).getTime();
    }
}
//读设备ID最大值

function getIDinfo() {
    $.get('../conf/IDinfo.xml', function (d1) {
        $(d1).find("IDALL").each(function () {
            var $IDALL = $(this);
            var DeviceID = $IDALL.find('DeviceID').text();
            //            DeviceRemoteAdd = $IDALL.find("SiemRemote").text();
            maxDeviceID = DeviceID;
            maxDriverID = $IDALL.find('DriverID').text();
            DataItemID = $IDALL.find('ItemID').text();
        });
    });
}

function OpenDeviceInfoLayer(txt, ele) {
    // 计算设备信息框显示的位置 -----start-----
    var offsetLeft = ele.offsetLeft;
    var offsetTop = ele.offsetTop;
    var devInfoWidth = $('#DevOperation').width() || 342;
    var devWidth = $(ele).width() || 106;
    var devHeight = $(ele).height() || 103;
    offsetLeft = offsetLeft + devWidth * 0.5 - devInfoWidth * 0.5 + 9;
    if (offsetLeft == null || isNaN(offsetLeft)) {
        offsetLeft = 100;
    }
    offsetTop = offsetTop + devHeight + 15;
    $('#DevOperation').css('left', offsetLeft + 'px').css('top', offsetTop + 'px');
    // -----end-----

    CheckedDeviceID = txt;
    Alter_Delete_CheckedDeviceID = txt;
    document.getElementById("PLCInfo").style.display = "";
    OpenDeviceInfoLayerMethod(txt);
}


//显示信息

function OpenDeviceInfoLayerMethod(txt) {
    taskID = "";
    //将点击的设备ID赋值
    document.getElementById("Alter_CheckedDeviceID").value = txt;
    //根据驱动类型显示远程地址
    if (ChannelDeviceType == "SIEMENS-MPI" || ChannelDeviceType == "SIEMENS-PPI" || ChannelDeviceType == "Panasonic" || ChannelDeviceType == "MITSUBISHI-FXS" || ChannelDeviceType == "AB-Ethernet/IP" || ChannelDeviceType == "OMRON_NJNX" || ChannelDeviceType == "AB-MicroLogix" || ChannelDeviceType == "TwinCAT" || ChannelDeviceType == "SIEMENS-S7-PPI-Task") {
        document.getElementById("Alter_DeviceLocationTR").style.display = "";
        document.getElementById("Alter_NetportTR").style.display = "none";
        if (ChannelDeviceType == "SIEMENS-MPI") {
            document.getElementById("Alter_loc1").style.display = "none";
            document.getElementById("Alter_loc3").style.display = "none";
            document.getElementById("Alter_loc2").style.display = "";
            document.getElementById("Alter_Ip").style.display = "none";
        }
        // add by whc 
        if (ChannelDeviceType == "SIEMENS-S7-PPI-Task") {
            document.getElementById("Alter_loc1").style.display = "none";
            document.getElementById("Alter_loc3").style.display = "none";
            document.getElementById("Alter_loc2").style.display = "";
            document.getElementById("Alter_Ip").style.display = "none";
            $('#Add_DeviceLocation').val(2);
        }
        // add end
        if (ChannelDeviceType == "SIEMENS-PPI" || ChannelDeviceType == "Panasonic") {
            document.getElementById("Alter_loc1").style.display = "";
            document.getElementById("Alter_loc2").style.display = "none";
            document.getElementById("Alter_loc3").style.display = "none";
            document.getElementById("Alter_Ip").style.display = "none";
        }
        if (ChannelDeviceType == "AB-Ethernet/IP" || ChannelDeviceType == "AB-MicroLogix") {
            document.getElementById("Alter_loc1").style.display = "none";
            document.getElementById("Alter_loc3").style.display = "none";
            document.getElementById("Alter_loc2").style.display = "none";
            document.getElementById("Alter_Ip").style.display = "";
        }
        if (ChannelDeviceType == "OMRON_NJNX") {
            document.getElementById("Alter_loc1").style.display = "none";
            document.getElementById("Alter_loc3").style.display = "none";
            document.getElementById("Alter_loc2").style.display = "none";
            document.getElementById("Alter_Ip").style.display = "";
            document.getElementById("Alter_NetportTR").style.display = "none";
        }
        if (ChannelDeviceType == "MITSUBISHI-FXS") {
            document.getElementById("Alter_loc3").style.display = "";
            document.getElementById("Alter_loc1").style.display = "none";
            document.getElementById("Alter_loc2").style.display = "none";
            document.getElementById("Alter_Ip").style.display = "none";
            if (AnyLinkType == "RF") {
                document.getElementById("Alter_NetportTR").style.display = "";
                $("#DeviceInfo_PLC").css('height', '200px');
            } else {
                document.getElementById("Alter_NetportTR").style.display = "none";
            }
        }
        //add begin by x
        if (ChannelDeviceType == "TwinCAT") {
            $("#Alter_loc1").hide();
            $("#Alter_loc3").hide();
            $("#Alter_loc2").hide();
            $("#Alter_Ip").show();
            $("#Alter_AmsNetID").show();
            $("#Alter_AdsDeviceTypeTr").show();
            $("#DeviceInfo_PLC").css("height", "300px");
        }
        //end add
    } else if (ChannelDeviceType == "MITSUBISHI-FXP") {
        document.getElementById("Alter_DeviceLocationTR").style.display = "none";
        document.getElementById("Alter_Ip").style.display = "none";
        document.getElementById("Alter_NetportTR").style.display = "none";
    } else if (ChannelDeviceType == "OPC") {
        document.getElementById("Alter_DeviceLocationTR").style.display = "none";
        document.getElementById("Alter_NetportTR").style.display = "none";
    } else if (ChannelDeviceType == "YinHe") {
        document.getElementById("Alter_DeviceLocationTR").style.display = "none";
        document.getElementById("Alter_NetportTR").style.display = "none";
        document.getElementById("Alter_line_delayed").style.display = "";
    } else if (AnyLinkType == "RF" && ChannelDeviceType == "HKG-SERIAL") {
        document.getElementById("Alter_DeviceLocationTR").style.display = "none";
        document.getElementById("Alter_NetportTR").style.display = "";
        $("#Alter_ModelTR").show();
        $("#DeviceInfo_PLC").css("height", "210px");
    } else if (ChannelDeviceType == "Modbus-RTU-task" || ChannelDeviceType == "Modbus-ASCII-task" || ChannelDeviceType == "Modbus-TCP-task") {
        $("#Alter_loc1").hide();
        $("#Alter_loc2").hide();
        $("#Alter_loc3").hide();
        $("#Alter_loc4").hide();
        $("#Alter_DeviceLocationTR").hide();
        $("#Alter_NetportTR").hide();
        $("#Alter_line_slaveStationID").show();
        //rf界面显示，其他不显示且默认为0
        if (AnyLinkType == "RF") {
            $("#Alter_line_NetID").show();
        } else {
            $("#Alter_NetID").val(0);
        }
    }
    // add begin by x
    else if (ChannelDeviceType == "BacNet-IP-task" || ChannelDeviceType == "BacNet-MS/TP-task") {
        document.getElementById("Alter_DeviceLocationTR").style.display = "none";
        document.getElementById("Alter_NetportTR").style.display = "none";
        $("#Alter_line_DevceID2").show();
    }
    // end add
    // add by fyj, 新增KUKA驱动
    // add begin
    else if (ChannelDeviceType == 'KUKA') {
        document.getElementById("Alter_DeviceLocationTR").style.display = "none";
        document.getElementById("Alter_NetportTR").style.display = "none";

        $("#Alter_ServerPort").show();
        $("#Alter_Overtime").show();
        $("#Alter_DeviceNumber").show();
        $("#Alter_DeviceIP").show();

        $("#DeviceInfo_PLC div.InfoDiv2").css("width", '130px');
        $("#DeviceInfo_PLC").css({
            "height": "300px",
            "width": "361px"
        });
    }
    // add end
    // add by whc,新增DRACAL驱动
    else if (ChannelDeviceType == "DRACAL") {
        document.getElementById("Alter_DeviceLocationTR").style.display = "none";
        document.getElementById("Alter_NetportTR").style.display = "none";

        $("#Alter_SerialNumber").show();

        $("#DeviceInfo_PLC div.InfoDiv2").css("width", '124px');
        $("#DeviceInfo_PLC").css({
            "height": "234px",
            "width": "368px"
        });
    }
    // add end
    // add by fyj, 新增cloudweb驱动
    else if (ChannelDeviceType == 'CloudWeb') {
        document.getElementById("Alter_DeviceLocationTR").style.display = "none";
        document.getElementById("Alter_NetportTR").style.display = "none";

        $("#Alter_Line_SerialNumber").show();
        $("#Alter_Line_CloudName").show();

        $("#DeviceInfo_PLC div.InfoDiv2").css("width", '124px');
        $("#DeviceInfo_PLC").css({
            "height": "234px",
            "width": "368px"
        });
    }
    // add end
    // add by fyj，新增DLT645-2007驱动
    else if (ChannelDeviceType == 'DLT645-2007' || ChannelDeviceType == 'DLT645-1997') {
        document.getElementById("Alter_DeviceLocationTR").style.display = "none";
        document.getElementById("Alter_NetportTR").style.display = "none";

        $('#Alter_line_dltAddress').show();
    }
    // add by fyj, OMRON-HostLink-Task
    else if (ChannelDeviceType == 'OMRON-HostLink-Task' || ChannelDeviceType == 'OMRON-FINS-Task') {
        document.getElementById("Alter_DeviceLocationTR").style.display = "none";
        document.getElementById("Alter_NetportTR").style.display = "none";

        $('#Alter_line_hostLink_unitNumber').show();
        if (AnyLinkType == 'RF') {
            $('#Alter_line_hostLink_networkNumber').show();
            $("#DeviceInfo_PLC").css('height', '238px');
        }
    }
    // add by whc, 新增FATEK编程口驱动
    else if (ChannelDeviceType == 'FATEK编程口') {
        document.getElementById("Alter_DeviceLocationTR").style.display = "";
        document.getElementById("Alter_NetportTR").style.display = "none";
        document.getElementById("Alter_loc1").style.display = "none";
        document.getElementById("Alter_loc2").style.display = "none";
        document.getElementById("Alter_loc3").style.display = "";
        document.getElementById("Alter_Ip").style.display = "none";
        //$("#Alter_loc3").show();
    }
    //add end
    else if (ChannelDeviceType == 'R1R2') {
        $("#Alter_DeviceLocationTR").hide();
        $("#Alter_NetportTR").hide();
        $("#Alter_line_samsung_deviceType").show();
        $("#Alter_line_samsung_address").show();
        $("#DeviceInfo_PLC").css( "height","234px");
    }
    else {
        document.getElementById("Alter_DeviceLocationTR").style.display = "none";
        document.getElementById("Alter_NetportTR").style.display = "none";
    }
    //根据设备ID读信息
    $.get('../conf/config.xml', function (d1) {
        $(d1).find("agent").each(function () {
            var $agent = $(this);
            var serialId = $agent.attr("id");
            $agent.find("model[id='" + ChannelID + "']").each(function () {
                var $model = $(this);
                var devicedriver = $model.attr("devicedriver");
                var d = $model.attr("d")
                $model.find("device[id='" + txt + "']").each(function () {
                    var $device = $(this);
                    var n = $device.attr("n");
                    var ip = $device.attr("ip");
                    var deviceId = $device.attr("id");
                    document.getElementById("Alert_DeviceId").value = deviceId;
                    if (parseInt(serialId) > 1200000) {
                        document.getElementById("Alert_CloudDeviceId").value = serialId * Math.pow(2, 10) + parseInt(deviceId);
                    } else {
                        document.getElementById("Alert_CloudDeviceId").value = deviceId
                    }
                    document.getElementById("Alter_DeviceName").value = n;
                    document.getElementById("Alter_DeviceLocation").value = ip;
                    $device.find("driver[n='" + d + "']").each(function () {
                        var $driver = $(this);
                        Alter_Delete_CheckedDriverID = $driver.attr("id");
                        var config = $driver.attr('config');
                        //如果是有站号/站地址/远程地址的设备，则解析其地址，在config的最后一位，并赋值
                        if (ChannelDeviceType == "SIEMENS-MPI" || ChannelDeviceType == "SIEMENS-PPI" || ChannelDeviceType == "Panasonic" || ChannelDeviceType == "MITSUBISHI-FXS" || ChannelDeviceType == "SIEMENS-S7-PPI-Task") {
                            var configArr = new Array();
                            configArr = config.split(";");
                            var len = configArr.length;
                            DeviceRemoteAdd = configArr[len - 1];
                            $("#Alter_DeviceLocation").val(DeviceRemoteAdd);
                        } else if (ChannelDeviceType == "AB-Ethernet/IP" || ChannelDeviceType == "AB-MicroLogix" || ChannelDeviceType == "TwinCAT") {
                            var configArr = new Array();
                            configArr = config.split(";");
                            var len = configArr.length;
                            DeviceRemoteAdd = configArr[0];
                            $("#Alter_DeviceLocation").val(DeviceRemoteAdd);
                            //add begin by x
                            if (ChannelDeviceType == "TwinCAT") {
                                AmsNetID = configArr[1];
                                $("#Alter_iAmsNetID").val(AmsNetID);
                                $("#Alter_AdsDeviceType").val(configArr[2]);
                            }
                            //end add
                        } else if (ChannelDeviceType == "OMRON_NJNX") {
                            var configArr = new Array();
                            configArr = config.split(";");
                            DriverAddress = configArr[0];
                            $("#Alter_DeviceLocation").val(DriverAddress);
                        }
                        //三菱FX编程口和FX串口解析网络号
                        else if (ChannelDeviceType == "MITSUBISHI-FXS") {
                            if (AnyLinkType == "RF") {
                                var ary = config.split(";");
                                $("#Alter_DeviceLocation").val(ary[5]);
                                $("#Alter_Netport").val(ary[7]);
                            } else {
                                var configArr = new Array();
                                configArr = config.split(";");
                                var len = configArr.length;
                                DeviceRemoteAdd = configArr[len - 1];
                                $("#Alter_DeviceLocation").val(DeviceRemoteAdd);
                            }
                        } else if (ChannelDeviceType == "MITSUBISHI-FXP") {
                            if (AnyLinkType == "RF") {
                                var ary = config.split(";");
                                $("#Alter_Netport").val(ary[ary.length - 1]);
                            }
                        } else if (ChannelDeviceType == "YinHe") {
                            var configArr = new Array();
                            configArr = config.split(";");
                            $("#Alter_delayed").val(configArr[2]);
                        } else if (ChannelDeviceType == "HKG-SERIAL") {
                            var configArr = new Array();
                            configArr = config.split(";");
                            $("#Alter_Netport").val(configArr[0]);
                            $("#Alter_Model").empty();
                            if (configArr[1] == "1") {
                                if (coo == "English") {
                                    var option = "<option value=" + configArr[1] + " selected='selected'>DC/PG motor</option>";
                                } else {
                                    var option = "<option value=" + configArr[1] + " selected='selected'>直流/PG电机</option>";
                                }
                            } else {
                                if (coo == "English") {
                                    var option = "<option value=" + configArr[1] + " selected='selected'>Tap motor</option>";
                                } else {
                                    var option = "<option value=" + configArr[1] + " selected='selected'>抽头电机</option>";
                                }
                            }

                            $("#Alter_Model").append(option);
                            //modbus任务驱动
                        } else if (ChannelDeviceType == "Modbus-RTU-task" || ChannelDeviceType == "Modbus-ASCII-task" || ChannelDeviceType == "Modbus-TCP-task") {
                            $("#Alter_slaveStationID").val(config.split(";")[0]);
                            $("#Alter_NetID").val(config.split(";")[1]);
                        } else if (ChannelDeviceType == "BacNet-IP-task" || ChannelDeviceType == "BacNet-MS/TP-task") {
                            $("#Alter_DeviceID2").val(config);
                        }
                        // add by fyj , 新增KUKA驱动
                        // add begin
                        else if (ChannelDeviceType == 'KUKA') {
                            var configArr = config.split(";");
                            $("#Alter_ServerPortIpt").val(configArr[0]);
                            $("#Alter_OvertimeIpt").val(configArr[1]);
                            $("#Alter_DeviceNumberIpt").val(configArr[2]);
                            $("#Alter_DeviceIPIpt").val(configArr[3]);
                        }
                        // add end
                        // add by whc,新增DRACAL驱动
                        else if (ChannelDeviceType == "DRACAL") {
                            var configArr = config.split(";");
                            $("#Alter_SerialNumberIpt").val(configArr[0]);
                        }
                        // add by whc,新增OPC驱动
                        else if (ChannelDeviceType == 'OPC') {
                            var configArr = config.split(";");
                        }
                        // add end
                        // add by fyj, 新增cloudweb驱动
                        else if (ChannelDeviceType == 'CloudWeb') {
                            var configArr = new Array();
                            configArr = config.split(";");
                            $("#Alter_SerialNumber2").val(configArr[0]);
                            $("#Alter_CloudName").val(configArr[1]);
                        }
                        // add end
                        else if (ChannelDeviceType == 'DLT645-2007' || ChannelDeviceType == 'DLT645-1997') {
                            $('#Alter_dltAddress').val(config);
                        }
                        // add by fyj, OMRON-HostLink-Task
                        else if (ChannelDeviceType == 'OMRON-HostLink-Task' || ChannelDeviceType == 'OMRON-FINS-Task') {
                            var configArr = new Array();
                            configArr = config.split(";");
                            $("#Alter_hostLink_unitNumber").val(configArr[0]);
                            $("#Alter_hostLink_networkNumber").val(configArr[1]);
                        }
                        // add end
                        // add by whc, 新增FATEK编程口驱动
                        else if (ChannelDeviceType == 'FATEK编程口') {
                            var configArr = new Array();
                            configArr = config.split(";");
                            var len = configArr.length;
                            StationNum = configArr[len - 1];
                            $("#Alter_DeviceLocation").val(StationNum);

                        }
                        else if (ChannelDeviceType == 'R1R2') {
                            var configArr = new Array();
                            configArr = config.split(";");
                            $("#Alter_samsung_deviceType").val(configArr[0]);
                            $("#Alter_samsung_address").val(configArr[1]);
                        }
                        // add end
                    });
                    ReadAlterDeviceType(devicedriver);
                });
            });
        });
    });
    $.get('../conf/config.xml', function (data) {
        $(data).find("task").each(function () {
            var $task = $(this);
            $task.find("TaskDriver").each(function () {
                var $TaskDriver = $(this);
                $TaskDriver.find("driver").each(function () {
                    var $driver = $(this);
                    var id = $driver.attr("id");
                    if (id == undefined) {

                    } else {
                        taskID = id;
                    }
                });
            });
        });
    });
    //多设备动态改变信息div位置
    if (ChannelDeviceType == "HKG-SERIAL") {
        var X = $('#' + txt).offset().top;
        var Y = $('#' + txt).offset().left;
        X = X + 115;
        Y = Y - 116;
        $("#DevOperation").css("top", X);
        $("#DevOperation").css("left", Y);
        //$("DevOperation").offset({'top':'160px','left':'150px'});
    }
    if ($("#DevOperation").css("display") == "none") {
        $("#DevOperation").show();
        if (ChannelDeviceType == "HKG-SERIAL") {
            var newheight = $(".content").height() + 250;
            $(".content").css("height", newheight);
            $(".if").css("height", newheight);
        }

    } else {
        $("#DevOperation").hide();
        if (ChannelDeviceType == "HKG-SERIAL") {
            var newheight = $(".content").height() - 250;
            $(".content").css("height", newheight);
            $(".if").css("height", newheight);
        }
    }
}
//根据添加好的设备驱动和设备类型来查找中文以及远程地址

function ReadAlterDeviceType(txt) {
    $("#Alter_DeviceDriver").empty();
    if (coo == "English") {
        $.get('../conf/AllDeviceDriverEn.xml', function (d1) {
            $(d1).find("Fac").each(function () {
                var $Fac = $(this);
                $Fac.find("Agr[value='" + txt + "']").each(function () {
                    var $Agr = $(this);
                    var val_Driver = txt;
                    var text_Driver = $Agr.text();
                    var option = $("<option>").val(val_Driver).text(text_Driver);
                    $("#Alter_DeviceDriver").append(option);
                });
            });
        });
    } else {
        $.get('../conf/AllDeviceDriver.xml', function (d1) {
            $(d1).find("Fac").each(function () {
                var $Fac = $(this);
                $Fac.find("Agr[value='" + txt + "']").each(function () {
                    var $Agr = $(this);
                    var val_Driver = txt;
                    var text_Driver = $Agr.text();
                    var option = $("<option>").val(val_Driver).text(text_Driver);
                    $("#Alter_DeviceDriver").append(option);
                });
            });
        });
    }
}

//设备图标移动效果

function OverDeviceEffect(txt) {
    if (CheckedDeviceID == txt) {
        document.getElementById(txt).style.backgroundImage = "url( " + DevicePicHover + " )"
    } else {
        document.getElementById(txt).style.backgroundImage = "url(" + DevicePic1 + ")"
    }
}

function OutDeviceEffect(txt) {
    if (CheckedDeviceID == txt) {
        document.getElementById(txt).style.backgroundImage = "url(" + DevicePicHover + ")"
    } else {
        document.getElementById(txt).style.backgroundImage = "url(" + DevicePic + ")"
    }
}
//根据传的值读取通道ID

function initUI() {
    $("#device").empty();
    var string = decodeURIComponent(document.location.search).substr(1);
    var logArr = new Array();
    logArr = string.split("&")[0].split("=");
    //url有多个参数 需进行解析 例如Device_PLC_Change.html?id=1&t=1549862700138 先用&分离
    ChannelID = logArr[1];
    getIDinfo();
    $.get('../conf/config.xml', function (d1) {
        $(d1).find("model[id='" + ChannelID + "']").each(function () {
            var $model = $(this);
            ChannelName = $model.attr("n");
            $("#titlekind").html(ChannelName)
            $("#titlekind").attr("title", ChannelName);
            ChannelDevice = $model.attr("d");
            ChannelConfig = $model.attr("config")
            ChannelDeviceType = $model.attr("devicedriver");
            document.getElementById("Add_DeviceID").value = maxDeviceID;
            //读数据
            ReadCheckedDeviceDriver(ChannelDeviceType);

            //图标显示，PLC与Modbus的不同，根据locationhref.js中方法判断
            if (locationhref(ChannelDeviceType) == "2") {
                DevicePic = "assets/img/modbus_ico.png";
                DevicePic1 = "assets/img/modbus_ico1.png";
                DevicePicHover = "assets/img/modbus_ico_hover.png";
            } else {
                DevicePic = "assets/img/plc_ico.png";
                DevicePic1 = "assets/img/plc_ico1.png";
                DevicePicHover = "assets/img/plc_ico_hover.png";
            }
            if (ChannelDeviceType == "SIEMENS-MPI" || ChannelDeviceType == "SIEMENS-PPI" || ChannelDeviceType == "Panasonic" || ChannelDeviceType == "MITSUBISHI-FXS" || ChannelDeviceType == "AB-Ethernet/IP" || ChannelDeviceType == "OMRON_NJNX" || ChannelDeviceType == "AB-MicroLogix" || ChannelDeviceType == "SIEMENS-S7-PPI-Task") {
                document.getElementById("Add_DeviceLocationTR").style.display = "";
                document.getElementById("Add_NetportTR").style.display = "none";
                if (ChannelDeviceType == "SIEMENS-MPI" || ChannelDeviceType == "SIEMENS-S7-PPI-Task") {
                    document.getElementById("Add_loc1").style.display = "none";
                    document.getElementById("Add_loc3").style.display = "none";
                    document.getElementById("Add_loc2").style.display = "";
                    document.getElementById("Add_loc4").style.display = "none";
                    $('#Add_DeviceLocation').val(2);
                }
                if (ChannelDeviceType == "SIEMENS-PPI" || ChannelDeviceType == "Panasonic") {
                    document.getElementById("Add_loc1").style.display = "";
                    document.getElementById("Add_loc2").style.display = "none";
                    document.getElementById("Add_loc3").style.display = "none";
                    document.getElementById("Add_loc4").style.display = "none";
                }
                if (ChannelDeviceType == "OMRON_NJNX") {
                    document.getElementById("Add_loc1").style.display = "none";
                    document.getElementById("Add_loc3").style.display = "none";
                    document.getElementById("Add_loc2").style.display = "none";
                    document.getElementById("Add_loc4").style.display = "";
                    document.getElementById("Add_NetportTR").style.display = "none";
                }
                if (ChannelDeviceType == 'MITSUBISHI-FXS') {
                    document.getElementById("Add_loc3").style.display = "";
                    document.getElementById("Add_loc1").style.display = "none";
                    document.getElementById("Add_loc2").style.display = "none";
                    document.getElementById("Add_loc4").style.display = "none";
                    if (AnyLinkType == "RF") {
                        document.getElementById("Add_NetportTR").style.display = "";
                        $("#Add_DeviceLayer").css("height", "250px");
                    } else {
                        document.getElementById("Add_NetportTR").style.display = "none";
                    }
                }
                if (ChannelDeviceType == "AB-Ethernet/IP" || ChannelDeviceType == "AB-MicroLogix") {
                    document.getElementById("Add_loc1").style.display = "none";
                    document.getElementById("Add_loc3").style.display = "none";
                    document.getElementById("Add_loc2").style.display = "none";
                    document.getElementById("Add_loc4").style.display = "";
                }
            } else if (ChannelDeviceType == "MITSUBISHI-FXP" || ChannelDeviceType == "MITSUBISHI-FXS") {
                document.getElementById("Add_DeviceLocationTR").style.display = "none";
                document.getElementById("Add_NetportTR").style.display = "none";
            } else if (ChannelDeviceType == "YinHe") {
                document.getElementById("Add_NetportTR").style.display = "none";
                document.getElementById("Add_DeviceLocationTR").style.display = "none";
                document.getElementById("Add_line_delayed").style.display = "";
                $("#Add_delayed").val("5000");
            } else if (AnyLinkType == "RF" && ChannelDeviceType == "HKG-SERIAL") {
                document.getElementById("Add_DeviceLocationTR").style.display = "none";
                $("#Add_ModelTR").show();
                $("#Add_DeviceLayer").css("height", "300px");
            }
            //add begin by x
            //新增的TwinCAT的驱动
            else if (ChannelDeviceType == "TwinCAT") {
                $("#Add_NetportTR").hide();
                $("#Add_loc1").hide();
                $("#Add_loc3").hide();
                $("#Add_loc2").hide();
                $("#Add_loc4").show();
                $("#Add_AmsNetID").show();
                $("#Add_AdsDeviceTypeTr").show();
                $("#Add_DeviceLayer").css("height", "300px");
            }
            //and add
            //add begin by x
            else if (ChannelDeviceType == "Modbus-RTU-task" || ChannelDeviceType == "Modbus-ASCII-task" || ChannelDeviceType == "Modbus-TCP-task") {
                $("#Add_loc1").hide();
                $("#Add_loc2").hide();
                $("#Add_loc3").hide();
                $("#Add_loc4").hide();
                $("#Add_DeviceLocationTR").hide();
                $("#Add_NetportTR").hide();
                $("#Add_line_slaveStationID").show();
                //这个参数在rf下显示，其他是隐藏的并且默认是0
                if (AnyLinkType == "RF") {
                    $("#Add_line_NetID").show();
                } else {
                    $("#Add_line_NetID").hide();
                    $("#Add_NetID").val(0);
                }

                document.getElementById("Add_DeviceLayer").style.height = "300px";
            }
            //end add
            // add by x
            else if (ChannelDeviceType == "BacNet-IP-task" || ChannelDeviceType == "BacNet-MS/TP-task") {
                document.getElementById("Add_NetportTR").style.display = "none";
                document.getElementById("Add_DeviceLocationTR").style.display = "none";
                $("#Add_line_DeviceID2").show();
            }
            // end add
            // add by fyj, 新增KUKA驱动
            // add begin
            else if (ChannelDeviceType == 'KUKA') {
                $("#Add_line_ServerPort").show();
                $("#Add_line_Overtime").show();
                $("#Add_line_DeviceNumber").show();
                $("#Add_line_DeviceIP").show();

                $("#Add_DeviceLocationTR").hide();
                $("#Add_NetportTR").hide();

                document.getElementById("Add_DeviceLayer").style.height = "324px";
                document.getElementById("Add_DeviceLayer").style.width = "425px";

            }
            // add end
            // add by whc,新增DRACAL驱动
            else if (ChannelDeviceType == "DRACAL") {
                $("#Add_line_SerialNumber").show();

                $("#Add_DeviceLocationTR").hide();
                $("#Add_NetportTR").hide();

                document.getElementById("Add_DeviceLayer").style.height = "272px";
                document.getElementById("Add_DeviceLayer").style.width = "420px";
            }
            // add end
            // add by fyj, cloudweb
            else if (ChannelDeviceType == 'CloudWeb') {
                $("#Add_line_SerialNumber").show();
                $("#Add_line_CloudName").show();

                $("#Add_DeviceLocationTR").hide();
                $("#Add_NetportTR").hide();

                if (coo == "English") {
                    document.getElementById("Add_DeviceLayer").style.height = "330px";
                } else {
                    document.getElementById("Add_DeviceLayer").style.height = "272px";
                }
                document.getElementById("Add_DeviceLayer").style.width = "420px";
            }
            // add end
            // add by fyj, DLT645-2007
            else if (ChannelDeviceType == 'DLT645-2007' || ChannelDeviceType == 'DLT645-1997') {
                $('#Add_line_dltAddress').show();

                $("#Add_DeviceLocationTR").hide();
                $("#Add_NetportTR").hide();
            }
            // add end
            // add by fyj, OMRON-HostLink-Task
            else if (ChannelDeviceType == 'OMRON-HostLink-Task' || ChannelDeviceType == 'OMRON-FINS-Task') {

                $("#Add_DeviceLocationTR").hide();
                $("#Add_NetportTR").hide();

                $('#Add_line_hostLink_unitNumber').show();
                if (AnyLinkType == 'RF') {
                    $('#Add_line_hostLink_networkNumber').show();
                    document.getElementById("Add_DeviceLayer").style.height = "264px";
                } else {
                    document.getElementById("Add_DeviceLayer").style.height = "238px";
                }
                document.getElementById("Add_DeviceLayer").style.width = "334px";
            }
            // add end
            // add by whc, FATEK编程口
            else if (ChannelDeviceType == 'FATEK编程口') {
                document.getElementById("Add_DeviceLocationTR").style.display = "";
                document.getElementById("Add_NetportTR").style.display = "none";
                document.getElementById("Add_loc1").style.display = "none";
                document.getElementById("Add_loc2").style.display = "none";
                document.getElementById("Add_loc3").style.display = "";
                document.getElementById("Add_loc4").style.display = "none";
            }
            // add end
            // add by whc,OPC
            else if (ChannelDeviceType == 'OPC') {
                document.getElementById("Add_NetportTR").style.display = "none";
                document.getElementById("Add_DeviceLocationTR").style.display = "none";
            }
            // add end
            else if (ChannelDeviceType == 'R1R2') {
                $("#Add_NetportTR").hide();
                $("#Add_DeviceLocationTR").hide();
                $("#Add_line_samsung_deviceType").show();
                $("#Add_line_samsung_address").show();
                $("#Add_DeviceLayer").css("height", "265px");
            }
            else {
                document.getElementById("Add_NetportTR").style.display = "none";
                document.getElementById("Add_DeviceLocationTR").style.display = "none";
            }
            DeviceNum = 1000000000000;
            $model.find('device').each(function () {
                var $device = $(this);
                var deviceid = $device.attr('id');
                var name = $device.attr('n');
                DeviceNum++;
                if (ChannelDeviceType == "HKG-SERIAL") {
                    var list =
                        "<div style='width:106px; height:123px;float:left; margin-left:10px; margin-right:5px; cursor:pointer'>" +
                        "<div id='" + deviceid + "' style='width:106px; height:103px;background-image:url(" + DevicePic + ")' onClick='OpenDeviceInfoLayer(" + deviceid + ",this)' onMouseOver='OverDeviceEffect(id)' onMouseOut='OutDeviceEffect(id)'>" + "</div>" +
                        "<div style='margin-top:0px;width:106px;height:20px;line-height:20px;overflow:hidden' title='" + name + "' align='center'>" + name + "</div>" +
                        "</div>"
                    $("#device").append(list);
                } else {
                    var list =
                        "<div style='width:106px; height:123px;float:left; margin-left:10px; margin-right:5px; cursor:pointer'>" +
                        "<div id='" + DeviceNum + "' style='width:106px; height:103px;background-image:url(" + DevicePic + ")' onClick='OpenDeviceInfoLayer(" + deviceid + ",this)' onMouseOver='OverDeviceEffect(id)' onMouseOut='OutDeviceEffect(id)'>" + "</div>" +
                        "<div style='margin-top:0px;width:106px;height:20px;line-height:20px;overflow:hidden' title='" + name + "' align='center'>" + name + "</div>" +
                        "</div>"
                    $("#device").append(list);
                }
            });
            maxDeviceNum = DeviceNum;
        });
        var rh = $(".content").height();
        $(".if").css("height", rh);
        /*if(ChannelDeviceType == "HKG-SERIAL"){
            var rh = $(".content").height();
            $(".if").css("height",rh);
        }*/
    });
}

//点击导入按钮
function Import_Device(btn) {
    initUI()
    if (DeviceNum == 1000000000001 && ChannelDeviceType != "HKG-SERIAL" && ChannelDeviceType != "Modbus-RTU-task" && ChannelDeviceType != "Modbus-ASCII-task" && ChannelDeviceType != "Modbus-TCP-task" && ChannelDeviceType != "BacNet-IP-task" && ChannelDeviceType != "BacNet-MS/TP-task") {
        if (coo == "English") {
            alert("Only one device is allowed!");
        } else {
            alert("只允许存在一个设备！");
        }
        document.getElementById('Import_Button_Confirm').disabled = true;
        return;
    } else if (document.getElementById("FileName").value == "") {
        if (coo == "English") {
            alert("Please select the files to upload!");
        } else {
            alert("请选择需要上传的文件！");
        }
        document.getElementById('Import_Button_Confirm').disabled = true;
    } else {
        document.getElementById('Import_Button_Confirm').disabled = true;
        document.getElementById('Import_Button_Cancel').disabled = true;
        var type = locationhref(ChannelDeviceType);
        if (type == "1") {
            if (ChannelDeviceType == "OMRON_NJNX") {
                document.getElementById("ImportForm").action = "../cgi-bin/import/ImportOMRON_NJNXDataitem.py?deviceID=-1&channelid=" + ChannelID + "&ChannelDeviceType=" + ChannelDeviceType + "&maxDeviceID=-1&maxDriverID=" + maxDriverID;
            } else if (ChannelDeviceType == "HKG-SERIAL") {
                document.getElementById("ImportForm").action = "../cgi-bin/import/ImportHKG-SERIALDataitem.py?deviceID=-1&channelid=" + ChannelID + "&ChannelDeviceType=" + ChannelDeviceType + "&maxDeviceID=-1&maxDriverID=" + maxDriverID;
            } else if (ChannelDeviceType == "YinHe") {
                document.getElementById("ImportForm").action = "../cgi-bin/import/ImportYinHeDataitem.py?deviceID=-1&channelid=" + ChannelID + "&ChannelDeviceType=" + ChannelDeviceType + "&maxDeviceID=-1&maxDriverID=" + maxDriverID;
            } else if (ChannelDeviceType == "Zundar") {
                document.getElementById("ImportForm").action = "../cgi-bin/import/ImportZunDarDataitem.py?deviceID=-1&channelid=" + ChannelID + "&ChannelDeviceType=" + ChannelDeviceType + "&maxDeviceID=-1&maxDriverID=" + maxDriverID;
                // add by whc
            } else if (ChannelDeviceType == "FATEK编程口") {
                document.getElementById("ImportForm").action = "../cgi-bin/import/ImportFATEKDataitem.py?deviceID=-1&channelid=" + ChannelID + "&ChannelDeviceType=" + ChannelDeviceType + "&maxDeviceID=-1&maxDriverID=" + maxDriverID + "&stationNum=-1&stationNum=" + StationNum;
            } else if (ChannelDeviceType == "OPC") {
                document.getElementById("ImportForm").action = "../cgi-bin/import/ImportOPCDataitem.py?deviceID=-1&channelid=" + ChannelID + "&ChannelDeviceType=" + ChannelDeviceType + "&maxDeviceID=-1&maxDriverID=" + maxDriverID;
                // add end
            } else if (ChannelDeviceType == "DLT645-2007" || ChannelDeviceType == "DLT645-1997") {
                document.getElementById("ImportForm").action = "../cgi-bin/import/ImportDLT645Dataitem.py?deviceID=-1&channelid=" + ChannelID + "&ChannelDeviceType=" + ChannelDeviceType + "&maxDeviceID=-1&maxDriverID=" + maxDriverID;
                // add by whc
            } else if (ChannelDeviceType == "SIEMENS-S7-PPI-Task") {
                document.getElementById("ImportForm").action = "../cgi-bin/import/ImportS7200PPIDataitem.py?deviceID=-1&channelid=" + ChannelID + "&ChannelDeviceType=" + ChannelDeviceType + "&maxDeviceID=-1&maxDriverID=" + maxDriverID;
                // add end
            } else {
                document.getElementById("ImportForm").action = "../cgi-bin/import/ImportPlcDataitem.py?deviceID=-1&channelid=" + ChannelID + "&ChannelDeviceType=" + ChannelDeviceType + "&maxDeviceID=-1&maxDriverID=" + maxDriverID;
            }
        }
        if (type == "2") {
            if (AnyLinkType == "RF") {
                document.getElementById("ImportForm").action = "../cgi-bin/import/ImportModbusDataitemRF.py?deviceID=-1&channelid=" + ChannelID + "&ChannelDeviceType=" + ChannelDeviceType + "&AnyLinkType=" + AnyLinkType + "&maxDeviceID=-1&maxDriverID=" + maxDriverID;
            } else {
                document.getElementById("ImportForm").action = "../cgi-bin/import/ImportModbusDataitem.py?deviceID=-1&channelid=" + ChannelID + "&ChannelDeviceType=" + ChannelDeviceType + "&AnyLinkType=" + AnyLinkType + "&maxDeviceID=-1&maxDriverID=" + maxDriverID;
            }
        }
        if (type == "3") {
            if (ChannelDeviceType == "AB-Ethernet/IP" || ChannelDeviceType == "AB-MicroLogix") {
                document.getElementById("ImportForm").action = "../cgi-bin/import/ImportABEthernetIPDataitem.py?deviceID=-1&channelid=" + ChannelID + "&ChannelDeviceType=" + ChannelDeviceType + "&maxDeviceID=-1&maxDriverID=" + maxDriverID;
            } else {
                document.getElementById("ImportForm").action = "../cgi-bin/import/ImportMpiDataitem.py?deviceID=-1&channelid=" + ChannelID + "&ChannelDeviceType=" + ChannelDeviceType + "&maxDeviceID=-1&maxDriverID=" + maxDriverID;
            }
        }
        if (type == "4") {
            document.getElementById("ImportForm").action = "../cgi-bin/import/ImportBACnetDataitem.py?deviceID=-1&channelid=" + ChannelID + "&ChannelDeviceType=" + ChannelDeviceType + "&maxDeviceID=-1&maxDriverID=" + maxDriverID;
        }
        if (type == "5") {
            document.getElementById("ImportForm").action = "../cgi-bin/import/ImportMpiDataitem.py?deviceID=-1&channelid=" + ChannelID + "&ChannelDeviceType=" + ChannelDeviceType + "&maxDeviceID=-1&maxDriverID=" + maxDriverID;
        }
        // add by fyj,ocr
        if (type == '6') {
            document.getElementById("ImportForm").action = "../cgi-bin/import/ImportOCRDataitem.py?deviceID=-1&channelid=" + ChannelID + "&ChannelDeviceType=" + ChannelDeviceType + "&maxDeviceID=-1&maxDriverID=" + maxDriverID;
        }
        document.getElementById("Add_DeviceName").value = 'PresetDeviceName';
        document.getElementById("Add_Netport").value = "PresetNetport";
        document.getElementById("Add_delayed").value = "1";
        document.getElementById("Add_iAmsNetID").value = "1";
        $('#Add_dltAddress').val("1");
        if (ChannelDeviceType == "OMRON_NJNX") {
            document.getElementById("Add_DeviceLocation").value = "1.1.1.1";
        } else {
            document.getElementById("Add_DeviceLocation").value = "1";
        }
        AddDevice(btn)
    }
}
//导入结束之后点击确定按钮
function Import_Success_ReloadNewPage() {
    $("#popWindow").hide();
    $("#ImportLayer").hide();
    document.getElementById("Success_Import").style.display = 'none';
    document.getElementById("UpWord").style.display = '';
    document.getElementById("Import_Success_Button").style.display = 'none';
    document.getElementById('Import_Button_Confirm').style.display = '';
    document.getElementById('Import_Button_Cancel').style.display = '';
    document.getElementById('Import_Two_Button').style.display = '';
    document.getElementById('Import_Button_Confirm').disabled = true;
    document.getElementById('Import_Button_Cancel').disabled = true;
    initUI();
}
//点击添加设备按钮
function AddDevice(btn) {
    //给需要上传的input框赋值
    document.getElementById("Add_DeviceName_YuToXHZhang").value = document.getElementById("Add_DeviceName").value;
    document.getElementById("Add_ChannelModelType_YuToXHZhang").value = ChannelDevice;
    //四种有站地址的
    if (ChannelDeviceType == "Panasonic" || ChannelDeviceType == "SIEMENS-PPI" || ChannelDeviceType == "SIEMENS-MPI" || ChannelDeviceType == "MITSUBISHI-FXS") {
        document.getElementById("Add_ChannelConfig_YuToXHZhang").value = ChannelConfig + ";" + $("#Add_DeviceLocation").val();
    }
    //SIEMENS-S7-PPI-Task有站地址
    else if (ChannelDeviceType == "SIEMENS-S7-PPI-Task") {
        document.getElementById("Add_ChannelConfig_YuToXHZhang").value = $("#Add_DeviceLocation").val();
    }
    //RF下三菱FX编程口
    else if (ChannelDeviceType == "MITSUBISHI-FXP") {
        document.getElementById("Add_ChannelConfig_YuToXHZhang").value = ChannelConfig;
    }
    //三菱FX串口有站号，RF下有网络号
    else if (ChannelDeviceType == "MITSUBISHI-FXS") {
        if (AnyLinkType == "RF") {
            var ary = ChannelConfig.split(";");
            var config = "";
            config = ary[0] + ";" + ary[1] + ";" + ary[2] + ";" + ary[3] + ";" + ary[4] + ";" + $("#Add_DeviceLocation").val() + ";" + ary[5] + ";" + $("#Add_Netport").val();
            document.getElementById("Add_ChannelConfig_YuToXHZhang").value = config;
        } else {
            document.getElementById("Add_ChannelConfig_YuToXHZhang").value = ChannelConfig + ";" + $("#Add_DeviceLocation").val();
        }
    } else if (ChannelDeviceType == "AB-Ethernet/IP" || ChannelDeviceType == "AB-MicroLogix") {
        document.getElementById("Add_ChannelConfig_YuToXHZhang").value = $("#Add_DeviceLocation").val() + ";" + ChannelConfig;
    } else if (ChannelDeviceType == "YinHe") {
        document.getElementById("Add_ChannelConfig_YuToXHZhang").value = ChannelConfig + ";" + $("#Add_delayed").val();
    } else if (ChannelDeviceType == "OMRON_NJNX") {
        document.getElementById("Add_ChannelConfig_YuToXHZhang").value = $("#Add_DeviceLocation").val() + ";" + ChannelConfig;
    } else if (AnyLinkType == "RF" && ChannelDeviceType == "HKG-SERIAL") {
        document.getElementById("Add_ChannelConfig_YuToXHZhang").value = $("#Add_Netport").val() + ";" + $("#Add_Model").val();
    }
    //add begin by x
    else if (ChannelDeviceType == "TwinCAT") {
        document.getElementById("Add_ChannelConfig_YuToXHZhang").value = $("#Add_DeviceLocation").val() + ";" + $("#Add_iAmsNetID").val() + ";" + $("#Add_AdsDeviceType").val();
    }
    //end add
    //add begin by x
    else if (ChannelDeviceType == "Modbus-TCP-task" || ChannelDeviceType == "Modbus-ASCII-task" || ChannelDeviceType == "Modbus-RTU-task") {
        document.getElementById("Add_ChannelConfig_YuToXHZhang").value = $("#Add_slaveStationID").val() + ";" + $("#Add_NetID").val();
    }
    //end add
    //没有站地址的情况
    // add begin by x
    else if (ChannelDeviceType == "BacNet-IP-task" || ChannelDeviceType == "BacNet-MS/TP-task") {
        document.getElementById("Add_ChannelConfig_YuToXHZhang").value = $("#Add_DeviceID2").val();
    }
    //end add
    // add by fyj , 新增KUKA驱动
    else if (ChannelDeviceType == 'KUKA') {
        var conf = $("#Add_ServerPort").val() + ';' + $("#Add_Overtime").val() + ";" + $("#Add_DeviceNumber").val() + ';' + $("#Add_DeviceIP").val();
        document.getElementById("Add_ChannelConfig_YuToXHZhang").value = conf;
    }
    // add end
    // add by whc,新增DRACAL驱动
    else if (ChannelDeviceType == "DRACAL") {
        var conf = $("#Add_SerialNumber").val();
        document.getElementById("Add_ChannelConfig_YuToXHZhang").value = conf;
    }
    // add end
    // add by fyj, 新增cloudweb驱动
    else if (ChannelDeviceType == 'CloudWeb') {
        var conf = $("#Add_SerialNumber").val() + ";" + $("#Add_CloudName").val();
        document.getElementById("Add_ChannelConfig_YuToXHZhang").value = conf;
    }
    // add end
    // add by fyj, 新增DLT645-2007
    else if (ChannelDeviceType == 'DLT645-2007' || ChannelDeviceType == 'DLT645-1997') {
        var conf = $("#Add_dltAddress").val();
        document.getElementById("Add_ChannelConfig_YuToXHZhang").value = conf;
    }
    // add end
    // add by fyj, OMRON-HostLink-Task
    else if (ChannelDeviceType == 'OMRON-HostLink-Task' || ChannelDeviceType == 'OMRON-FINS-Task') {
        var conf = $("#Add_hostLink_unitNumber").val() + ';' + $("#Add_hostLink_networkNumber").val();
        document.getElementById("Add_ChannelConfig_YuToXHZhang").value = conf;
    }
    // add end
    // add by whc,新增FATEK编程口
    else if (ChannelDeviceType == 'FATEK编程口') {
        document.getElementById("Add_ChannelConfig_YuToXHZhang").value = ChannelConfig + ";" + $("#Add_DeviceLocation").val();
    }
    // add end
    else if (ChannelDeviceType == 'R1R2') {
        document.getElementById("Add_ChannelConfig_YuToXHZhang").value = $("#Add_samsung_deviceType").val() + ';' + $("#Add_samsung_address").val();
    }
    else {
        document.getElementById("Add_ChannelConfig_YuToXHZhang").value = ChannelConfig;
    }
    document.getElementById("Add_ChannelID_YuToXHZhang").value = ChannelID;
    if (btn.value == "导入" || btn.value == "Import") {
        document.getElementById("Add_DeviceID_YuToXHZhang").value = "-1"
    } else {
        document.getElementById("Add_DeviceID_YuToXHZhang").value = $("#Add_DeviceID").val();
    }
    document.getElementById("Add_DriverID_YuToXHZhang").value = maxDriverID;
    if (ChannelDeviceType == "Modbus-RTU-task" || ChannelDeviceType == "Modbus-ASCII-task" || ChannelDeviceType == "Modbus-TCP-task" || ChannelDeviceType == "BacNet-IP-task" || ChannelDeviceType == "BacNet-MS/TP-task") {
        document.getElementById("Add_DriverID_YuToXHZhang").value = ChannelID;
    }
    // add by fyj , 新增kuka任务驱动
    // add begin
    if (ChannelDeviceType == "KUKA") {
        document.getElementById("Add_DriverID_YuToXHZhang").value = ChannelID;
    }
    // add end
    // add by whc,新增DRACAL任务驱动
    if (ChannelDeviceType == "DRACAL") {
        document.getElementById("Add_DriverID_YuToXHZhang").value = ChannelID;
    }
    // add end
    // add by fyj, 新增cloudweb任务驱动
    if (ChannelDeviceType == 'CloudWeb') {
        document.getElementById("Add_DriverID_YuToXHZhang").value = ChannelID;
    }
    // add end
    // add by whc ,DLT645-2007
    if (ChannelDeviceType == 'DLT645-1997' || ChannelDeviceType == 'DLT645-2007') {
        document.getElementById("Add_DriverID_YuToXHZhang").value = ChannelID;
    }
    // add by whc,SIEMENS-S7-PPI-Task
    if (ChannelDeviceType == 'SIEMENS-S7-PPI-Task') {
        document.getElementById("Add_DriverID_YuToXHZhang").value = ChannelID;
    }
    // add by fyj, OMRON-HostLink-Task
    if (ChannelDeviceType == 'OMRON-HostLink-Task' || ChannelDeviceType == 'OMRON-FINS-Task') {
        document.getElementById("Add_DriverID_YuToXHZhang").value = ChannelID;
    }
    if (ChannelDeviceType == 'GPS') {
        document.getElementById("Add_DriverID_YuToXHZhang").value = ChannelID;
    }
    if (ChannelDeviceType == 'R1R2') {
        document.getElementById("Add_DriverID_YuToXHZhang").value = ChannelID;
    }
    document.getElementById("Add_DeviceRemoteAddress_YuToXHZhang").value = document.getElementById("Add_DeviceLocation").value;
    document.getElementById("Add_DeviceType_YuToXHZhang").value = "test";
    document.getElementById("Add_DeviceModel_YuToXHZhang").value = document.getElementById("Add_DeviceDriver").value;
    if (CheckAddDevice()) {} else {
        AddDeviceMethod(btn);
    }
}
//添加设备校验方法

function CheckAddDevice() {
    if (DeviceNum == 1000000000001 && ChannelDeviceType != "HKG-SERIAL" && ChannelDeviceType != "Modbus-RTU-task" && ChannelDeviceType != "Modbus-ASCII-task" && ChannelDeviceType != "Modbus-TCP-task" && ChannelDeviceType != "BacNet-IP-task" &&
        ChannelDeviceType != "BacNet-MS/TP-task" && ChannelDeviceType != "SIEMENS-S7-PPI-Task" && ChannelDeviceType != 'OMRON-HostLink-Task' && ChannelDeviceType != 'OMRON-FINS-Task' && ChannelDeviceType != 'DLT645-1997' && ChannelDeviceType != 'DLT645-2007' && ChannelDeviceType != "DRACAL" && ChannelDeviceType != "R1R2") {

        if (coo == "English") {
            alert("Only one device is allowed!");
        } else {
            alert("只允许存在一个设备！");
        }
        return true;
    } else {
        var regID = new RegExp("^[1-9]+[0-9]*$");
        CheckDeviceID();
        if ($("#Add_DeviceID_YuToXHZhang").val() == "error") {
            if (coo == "English") {
                alert("The device ID already exists, please replace it!")
            } else {
                alert("设备ID已存在，请更换！")
            }
            return true;
        } else if ($("#Add_DeviceID").val() == "" || !regID.test($("#Add_DeviceID").val())) {
            if (coo == "English") {
                alert("Please enter the correct device ID! ");
            } else {
                alert("请输入正确的设备ID! ");
            }
            return true;
        } else if (parseInt($("#Add_DeviceID").val()) > 1022 || parseInt($("#Add_DeviceID").val()) < 1) {
            if (coo == "English") {
                alert("Device ID must be between 1 and 1022! ");
            } else {
                alert("设备的ID必须在1到1022之间! ");
            }
            return true;
        } else if (document.getElementById("Add_DeviceName").value == "") {
            if (coo == "English") {
                alert("Please input device name!");
            } else {
                alert("请输入设备名称！");
            }
            return true;
        } else if (document.getElementById("Add_DeviceLocationTR").style.display == "") {
            // add by whc
            if ($("#Add_DeviceLocation").val() == "" && ChannelDeviceType == "FATEK编程口") {
                if (coo == "English") {
                    alert("Please enter station number!")
                } else {
                    alert("请输入站号！")
                }
                return true;
            }
            if ($("#Add_DeviceLocation").val() != "" && ChannelDeviceType == "FATEK编程口") {
                var str = $("#Add_DeviceLocation").val();
                if ((str > 1 || str == 1) && (str < 126 || str == 126)) {

                } else {
                    if (coo == "English") {
                        alert("Station number must be between 1 and 126!")
                    } else {
                        alert("站号不符合1-126之间的数字");
                    }
                    return true;
                }
            }
            if ($("#Add_DeviceLocation").val() == "" && ChannelDeviceType == "SIEMENS-S7-PPI-Task") {
                if (coo == "English") {
                    alert("Please enter station address!");
                } else {
                    alert("请输入站地址！");
                }
                return true;
            }
            if ($("#Add_DeviceLocation").val() != "" && ChannelDeviceType == "SIEMENS-S7-PPI-Task") {
                var str = $("#Add_DeviceLocation").val();
                if ((str > 1 || str == 1) && (str < 126 || str == 126)) {

                } else {
                    if (coo == "English") {
                        alert("Station number must be between 1 and 126!")
                    } else {
                        alert("站号不符合1-126之间的数字");
                    }
                    return true;
                }
            }
            if ($("#Add_DeviceLocation").val() == "" && ChannelDeviceType != "OMRON_NJNX" && ChannelDeviceType != "SIEMENS-S7-PPI-Task" && ChannelDeviceType != "FATEK编程口") {
                if (coo == "English") {
                    alert("Please input device id/ remote address/station address!")
                } else {
                    alert("请输入设备id/远程地址/站地址！")
                }
                return true;
            }
            //add end
            if (ChannelDeviceType == "AB-Ethernet/IP" || ChannelDeviceType == "OMRON_NJNX" || ChannelDeviceType == "AB-MicroLogix" || ChannelDeviceType == "TwinCAT") {
                if (!reg.test($("#Add_DeviceLocation").val())) {
                    if (coo == "English") {
                        alert("Please enter the correct IP format");
                    } else {
                        alert("请输入正确的ip格式");
                    }
                    return true;
                }
                //add begin by x
                if (document.getElementById("Add_AmsNetID").style.display == "" && document.getElementById("Add_iAmsNetID").value == "") {
                    if (coo == "English") {
                        alert("Please enter the AmsNetID");
                    } else {
                        alert("请输入AmsNetID");
                    }
                    return true;
                }
                //end add
            }
        } else if (document.getElementById("Add_NetportTR").style.display == "") {
            if ($("#Add_Netport").val() == "") {
                if (coo == "English") {
                    alert("Please enter network number!")
                } else {
                    alert("请输入网络号！")
                }
                return true;
            }
        } else if (ChannelDeviceType == "YinHe") {
            if (document.getElementById("Add_delayed").value == "") {
                if (coo == "English") {
                    alert("Please input delay");
                } else {
                    alert("请输入延时");
                }
                return true;
            }
            if (!regnum.test($("#Add_delayed").val())) {
                if (coo == "English") {
                    alert("Please enter a positive integer");
                } else {
                    alert("请输入正整数");
                }
                return true;
            }
        }
        // add by fyj, 新增KUKA驱动
        // add begin
        else if (ChannelDeviceType == "KUKA") {
            if ($("#Add_ServerPort").val() == '' || !regnum.test($("#Add_ServerPort").val())) {
                if (coo == "English") {
                    alert("Please enter the correct server port");
                } else {
                    alert("请输入正确的服务器端口");
                }
                return true;
            }
            if ($("#Add_Overtime").val() == '' || !regnum.test($("#Add_Overtime").val())) {
                if (coo == "English") {
                    alert("Please enter the correct read timeout period");
                } else {
                    alert("请输入正确的读取超时时间判断");
                }
                return true;
            }
            if ($("#Add_DeviceNumber").val() == '' || !regnum.test($("#Add_DeviceNumber").val())) {
                if (coo == "English") {
                    alert("Please enter the correct equipment number");
                } else {
                    alert("请输入正确的设备编号");
                }
                return true;
            }
            if ($("#Add_DeviceIP").val() == '' || !reg.test($("#Add_DeviceIP").val())) {
                if (coo == "English") {
                    alert("Please enter the correct device IP");
                } else {
                    alert("请输入正确的设备IP");
                }
                return true;
            }
        }
        // add end
        // add by whc, 新增DRACAL驱动
        else if (ChannelDeviceType == "DRACAL") {
            if ($("#Add_SerialNumber").val() == '') {
                alert('请输入序列号');
                return true;
            }
        }
        // add end
        // add by fyj, 新增cloudweb驱动
        else if (ChannelDeviceType == "CloudWeb") {
            if ($("#Add_SerialNumber").val() == '') {
                if (coo == "English") {
                    alert('Please enter the cloud platform gateway serial number');
                } else {
                    alert('请输入云平台网关序列号');
                }
                return true;
            }
            if ($("#Add_CloudName").val() == '') {
                if (coo == "English") {
                    alert('Please enter the name of the cloud platform device');
                } else {
                    alert('请输入云平台设备名称');
                }
                return true;
            }
        }
        // add end
        // add by fyj, 新增DLT645-2007驱动
        else if (ChannelDeviceType == 'DLT645-2007' || ChannelDeviceType == 'DLT645-1997') {
            var dltAddress = $('#Add_dltAddress').val();
            var reg2 = new RegExp("^[0-9]*$");
            if (dltAddress == '') {
                if (coo == "English") {
                    alert('Please enter the device address');
                } else {
                    alert('请输入设备地址');
                }
                return true;
            } else if (!reg2.test(dltAddress)) {
                if (coo == "English") {
                    alert('Device address input error');
                } else {
                    alert('设备地址输入错误');
                }
                return true;
            } else {
                return false;
            }
        }
        // add end
        // add by fyj, OMRON-HostLink-Task
        else if (ChannelDeviceType == 'OMRON-HostLink-Task' || ChannelDeviceType == 'OMRON-FINS-Task') {
            var unitNumber = $('#Add_hostLink_unitNumber').val();
            var networkNumber = $('#Add_hostLink_networkNumber').val();
            var posIntReg = /^[0-9]+[0-9]*$/;
            if (unitNumber == '') {
                if (coo == "English") {
                    alert('Please input unit number');
                } else {
                    alert('请输入单元号');
                }
                return true;
            } else if (networkNumber == '') {
                if (coo == "English") {
                    alert('Please input Mini network number');
                } else {
                    alert('请输入Mini网络号');
                }
                return true;
            } else if (!posIntReg.test(unitNumber)) {
                if (coo == "English") {
                    alert('Unit number must be a positive integer');
                } else {
                    alert('单元号只能是正整数');
                }
                return true;
            } else {
                return false;
            }
        } else if (ChannelDeviceType == "Modbus-TCP-task" || ChannelDeviceType == "Modbus-ASCII-task" || ChannelDeviceType == "Modbus-RTU-task") {
            var regNumber = new RegExp("^[0-9]+$");
            if ($("#Add_slaveStationID").val() == "") {
                if (coo == "English") {
                    alert("Please enter the Slave Station");
                } else {
                    alert("请输入从站地址");
                }
                return true;
            } else if (!regNumber.test($("#Add_slaveStationID").val())) {
                if (coo == "English") {
                    alert("The Slave Station must be number");
                } else {
                    alert("从站地址必须为数字");
                }
                return true;
            }
            return false;
        }
        // add end
        else if (ChannelDeviceType == "R1R2") {
            var regNumber = new RegExp("^[0-9]+$");
            if ($("#Add_samsung_address").val() == "") {
                if (coo == "English") {
                    alert("Please enter the Slave Address");
                } else {
                    alert("请输入从机地址");
                }
                return true;
            } else if (!regNumber.test($("#Add_samsung_address").val())) {
                if (coo == "English") {
                    alert("The Slave Address must be number");
                } else {
                    alert("从机地址必须为数字");
                }
                return true;
            }
            return false;
        }
        else {
            return false;
        }
    }
}

//验证设备ID是否唯一
function CheckDeviceID() {
    var deviceID = document.getElementById("Add_DeviceID_YuToXHZhang").value;
    $.ajax({
        type: "get",
        url: "../conf/config.xml",
        async: false,
        success: function (data) {
            $(data).find("model").each(function () {
                var $model = $(this);
                $model.find("device").each(function () {
                    var $device = $(this);
                    var id = $device.attr("id");
                    if (id != '1023' && id == deviceID) {
                        document.getElementById("Add_DeviceID_YuToXHZhang").value = "error";
                    }
                });
            });
        }
    });
}
//添加设备方法
function AddDeviceMethod(btn) {
    getIDinfo();
    if (ChannelDeviceType == "HKG-SERIAL") {
        GetHKGData();
    }
    var params = $("#Add_Device_YuToxhZhang").serialize();
    $("#Add_Devicel_Button_Confirm").attr("disabled", "disabled");
    $("#Add_Devicel_Button_Cancel").attr("disabled", "disabled");
    $.ajax({
        type: "post",
        url: "cgi-bin/device/AddDevice.py",
        data: params,
        async: true,
        success: function (data) {
            $("#Add_DeviceLayer").hide();
            $("#popWindow").hide();
            $("#Add_Devicel_Button_Confirm").attr("disabled", "");
            $("#Add_Devicel_Button_Cancel").attr("disabled", "");
            if (ChannelDeviceType == "HKG-SERIAL") {
                $("#popWindow").show();
                $("#wait").show();
                HKGparams = "addDataItem=" + HKGparams.substring(0, HKGparams.length - 1) + "&HKGDeviceID=" + maxDeviceID;
                $.ajax({
                    type: "post",
                    url: "cgi-bin/device/AddHKGDataitem.py",
                    async: true,
                    data: HKGparams,
                    success: function (data) {
                        $("#popWindow").hide();
                        $("#wait").hide();
                        initUI();
                    }
                });
            }

            if (btn.value == "导入" || btn.value == "Import") {
                $("#popWindow").show();
                document.getElementById("ImportForm").submit();
                var iframe01 = document.getElementById("Hide_ImportIframe");
                if (iframe01.attachEvent) {
                    iframe01.attachEvent("onload", function () {
                        document.getElementById("UpWord").style.display = 'none';
                        document.getElementById("Import_Two_Button").style.display = 'none';
                        document.getElementById("Success_Import").style.display = '';
                        document.getElementById("Import_Success_Button").style.display = '';
                        document.getElementById('Import_Button_Confirm').disabled = false;
                        document.getElementById('Import_Button_Cancel').disabled = false;
                    });
                } else {
                    iframe01.onload = function () {
                        document.getElementById("UpWord").style.display = 'none';
                        document.getElementById("Import_Two_Button").style.display = 'none';
                        document.getElementById("Success_Import").style.display = '';
                        document.getElementById("Import_Success_Button").style.display = '';
                        document.getElementById('Import_Button_Confirm').disabled = false;
                        document.getElementById('Import_Button_Cancel').disabled = false;
                    };
                }
                document.getElementById("ImportForm").action = "";
            }
            initUI();
        }
    });
}
//修改设备

function Alter_Device() {
    document.getElementById("Alter_DeviceName_YuToXHZhang").value = document.getElementById("Alter_DeviceName").value;
    document.getElementById("Alter_ChannelModelType_YuToXHZhang").value = ChannelDevice;
    if (ChannelDeviceType == "Panasonic" || ChannelDeviceType == "SIEMENS-PPI" || ChannelDeviceType == "SIEMENS-MPI" || ChannelDeviceType == "MITSUBISHI-FXS") {
        document.getElementById("Alter_ChannelConfig_YuToXHZhang").value = ChannelConfig + ";" + $("#Alter_DeviceLocation").val();
    }
    //SIEMENS-S7-PPI-Task有站地址
    else if (ChannelDeviceType == "SIEMENS-S7-PPI-Task") {
        document.getElementById("Alter_ChannelConfig_YuToXHZhang").value = $("#Alter_DeviceLocation").val();
    }
    //RF下三菱FX编程口
    else if (ChannelDeviceType == "MITSUBISHI-FXP") {
        document.getElementById("Alter_ChannelConfig_YuToXHZhang").value = ChannelConfig;
    }
    //三菱FX串口有站号，RF下有网络号
    else if (ChannelDeviceType == "MITSUBISHI-FXS") {
        if (AnyLinkType == "RF") {
            var ary = ChannelConfig.split(";");
            var config = "";
            config = ary[0] + ";" + ary[1] + ";" + ary[2] + ";" + ary[3] + ";" + ary[4] + ";" + $("#Alter_DeviceLocation").val() + ";" + ary[5] + ";" + $("#Alter_Netport").val();
            document.getElementById("Alter_ChannelConfig_YuToXHZhang").value = config;
        } else {
            document.getElementById("Alter_ChannelConfig_YuToXHZhang").value = ChannelConfig + ";" + $("#Alter_DeviceLocation").val();
        }
    } else if (ChannelDeviceType == "AB-Ethernet/IP" || ChannelDeviceType == "AB-MicroLogix") {
        document.getElementById("Alter_ChannelConfig_YuToXHZhang").value = $("#Alter_DeviceLocation").val() + ";" + ChannelConfig;
    } else if (ChannelDeviceType == "YinHe") {
        document.getElementById("Alter_ChannelConfig_YuToXHZhang").value = ChannelConfig + ";" + $("#Alter_delayed").val();
    } else if (ChannelDeviceType == "OMRON_NJNX") {
        document.getElementById("Alter_ChannelConfig_YuToXHZhang").value = $("#Alter_DeviceLocation").val() + ";" + ChannelConfig;
    } else if (AnyLinkType == "RF" && ChannelDeviceType == "HKG-SERIAL") {
        document.getElementById("Alter_ChannelConfig_YuToXHZhang").value = $("#Alter_Netport").val() + ";" + $("#Alter_Model").val();
    }
    //add begin by x
    else if (ChannelDeviceType == "TwinCAT") {
        document.getElementById("Alter_ChannelConfig_YuToXHZhang").value = $("#Alter_DeviceLocation").val() + ";" + $("#Alter_iAmsNetID").val() + ";" + $("#Alter_AdsDeviceType").val();
    }
    //end add
    else if (ChannelDeviceType == "Modbus-RTU-task" || ChannelDeviceType == "Modbus-ASCII-task" || ChannelDeviceType == "Modbus-TCP-task") {
        document.getElementById("Alter_ChannelConfig_YuToXHZhang").value = $("#Alter_slaveStationID").val() + ";" + $("#Alter_NetID").val();
    }
    // add begin by x
    else if (ChannelDeviceType == "BacNet-IP-task" || ChannelDeviceType == "BacNet-MS/TP-task") {
        document.getElementById("Alter_ChannelConfig_YuToXHZhang").value = $("#Alter_DeviceID2").val();
    }
    // end add
    // add by fyj, 新增KUKA驱动
    // add begin
    else if (ChannelDeviceType == 'KUKA') {
        var conf = $('#Alter_ServerPortIpt').val() + ';' + $("#Alter_OvertimeIpt").val() + ";" + $("#Alter_DeviceNumberIpt").val() + ";" + $("#Alter_DeviceIPIpt").val();
        document.getElementById("Alter_ChannelConfig_YuToXHZhang").value = conf;
    }
    // add end
    // add by whc, 新增DRACAL驱动
    else if (ChannelDeviceType == "DRACAL") {
        var conf = $('#Alter_SerialNumberIpt').val();
        document.getElementById("Alter_ChannelConfig_YuToXHZhang").value = conf;
    }
    // add end
    // add by fyj, 新增cloudweb驱动
    else if (ChannelDeviceType == 'CloudWeb') {
        var conf = $('#Alter_SerialNumber2').val() + ';' + $("#Alter_CloudName").val();
        document.getElementById("Alter_ChannelConfig_YuToXHZhang").value = conf;
    }
    // add end
    // add by fyj, 新增DLT645-2007
    else if (ChannelDeviceType == 'DLT645-2007' || ChannelDeviceType == 'DLT645-1997') {
        var conf = $('#Alter_dltAddress').val();
        document.getElementById("Alter_ChannelConfig_YuToXHZhang").value = conf;
    }
    // add end
    // add by fyj, OMRON-HostLink-Task
    else if (ChannelDeviceType == 'OMRON-HostLink-Task' || ChannelDeviceType == 'OMRON-FINS-Task') {
        var conf = $('#Alter_hostLink_unitNumber').val() + ';' + $('#Alter_hostLink_networkNumber').val();
        document.getElementById("Alter_ChannelConfig_YuToXHZhang").value = conf;
    }
    // add end
    // add by whc, 新增FATEK编程口
    else if (ChannelDeviceType == 'FATEK编程口') {
        // var conf = $('#Alter_StationNumIpt').val();
        document.getElementById("Alter_ChannelConfig_YuToXHZhang").value = ChannelConfig + ";" + $("#Alter_DeviceLocation").val();
    }
    else if (ChannelDeviceType == "R1R2") {
        document.getElementById("Alter_ChannelConfig_YuToXHZhang").value = $("#Alter_samsung_deviceType").val() + ";" + $("#Alter_samsung_address").val() ;
    }
    // add end
    else {
        document.getElementById("Alter_ChannelConfig_YuToXHZhang").value = ChannelConfig;
    }
    document.getElementById("Alter_ChannelID_YuToXHZhang").value = ChannelID;
    document.getElementById("Alter_DeviceID_YuToXHZhang").value = Alter_Delete_CheckedDeviceID;
    document.getElementById("Alter_DriverID_YuToXHZhang").value = Alter_Delete_CheckedDriverID;
    document.getElementById("Alter_DeviceRemoteAddress_YuToXHZhang").value = document.getElementById("Alter_DeviceLocation").value;
    document.getElementById("Alter_DeviceModel_YuToXHZhang").value = document.getElementById("Alter_DeviceDriver").value;
    document.getElementById("Alter_DeviceType_YuToXHZhang").value = "test";
    if (CheckAlterDevice()) {} else {
        AlterDeviceMethod();
    }

}

function CheckAlterDevice() {
    if (document.getElementById("Alter_DeviceName").value == "") {
        if (coo == "English") {
            alert("Please input device name!");
        } else {
            alert("请输入设备名称！");
        }
        return true;
        // add by whc
    } else if (document.getElementById("Alter_DeviceLocationTR").style.display == "") {
        if (document.getElementById("Alter_DeviceLocation").value == "" && ChannelDeviceType == "FATEK编程口") {
            if (coo == "English") {
                alert("Please enter station number!")
            } else {
                alert("请输入站号！")
            }
            return true;
        }
        if ($("#Alter_DeviceLocation").val() != "" && ChannelDeviceType == "FATEK编程口") {
            var str = $("#Alter_DeviceLocation").val();
            if ((str > 1 || str == 1) && (str < 126 || str == 126)) {

            } else {
                if (coo == "English") {
                    alert("Station number must be between 1 and 126!")
                } else {
                    alert("站号不符合1-126之间的数字");
                }
                return true;
            }
        }
        if ($("#Alter_DeviceLocation").val() == "" && ChannelDeviceType == "SIEMENS-S7-PPI-Task") {
            if (coo == "English") {
                alert("Please enter station address!");
            } else {
                alert("请输入站地址！");
            }
            return true;
        }
        if ($("#Alter_DeviceLocation").val() != "" && ChannelDeviceType == "SIEMENS-S7-PPI-Task") {
            var str = $("#Alter_DeviceLocation").val();
            if ((str > 1 || str == 1) && (str < 126 || str == 126)) {

            } else {
                if (coo == "English") {
                    alert("Station number must be between 1 and 126!")
                } else {
                    alert("站号不符合1-126之间的数字");
                }
                return true;
            }
        }

        if (document.getElementById("Alter_DeviceLocation").value == "" && ChannelDeviceType != "OMRON_NJNX" && ChannelDeviceType != "FATEK编程口" && ChannelDeviceType != "SIEMENS-S7-PPI-Task") {
            if (coo == "English") {
                alert("Please input device id/ remote address/station address!")
            } else {
                alert("请输入设备id/远程地址/站地址！")
            }
            return true;
        }
        // add end
        if (ChannelDeviceType == "AB-Ethernet/IP" || ChannelDeviceType == "OMRON_NJNX" || ChannelDeviceType == "AB-MicroLogix" || ChannelDeviceType == "TwinCAT") {
            if (!reg.test($("#Alter_DeviceLocation").val())) {
                if (coo == "English") {
                    alert("Please enter the correct IP format");
                } else {
                    alert("请输入正确的ip格式");
                }
                return true;
            }
            //add begin by x
            if (document.getElementById("Alter_AmsNetID").style.display == "" && document.getElementById("Alter_iAmsNetID").value == "") {
                if (coo == "English") {
                    alert("Please enter the AmsNetID");
                } else {
                    alert("请输入AmsNetID");
                }
                return true;
            }
            //end add
        }
    } else if (ChannelDeviceType == "Modbus-TCP-task" || ChannelDeviceType == "Modbus-ASCII-task" || ChannelDeviceType == "Modbus-RTU-task") {
        var regNumber = new RegExp("^[0-9]+$");
        if ($("#Alter_slaveStationID").val() == "") {
            if (coo == "English") {
                alert("Please enter the Slave Station");
            } else {
                alert("请输入从站地址");
            }
            return true;
        } else if (!regNumber.test($("#Alter_slaveStationID").val())) {
            if (coo == "English") {
                alert("The Slave Station must be number");
            } else {
                alert("从站地址必须为数字");
            }
            return true;
        }
        return false;
    } else if (document.getElementById("Alter_NetportTR").style.display == "") {
        if (document.getElementById("Alter_Netport").value == "") {
            if (coo == "English") {
                alert("Please enter network number!")
            } else {
                alert("请输入网络号！")
            }
            return true;
        }
    } else if (ChannelDeviceType == "YinHe") {
        if (document.getElementById("Alter_delayed").value == "") {
            if (coo == "English") {
                alert("Please input delay");
            } else {
                alert("请输入延时");
            }
            return true;
        }
        if (!regnum.test($("#Alter_delayed").val())) {
            if (coo == "English") {
                alert("Please enter a positive integer");
            } else {
                alert("请输入正整数");
            }
            return true;
        }
    }
    // add by fyj, 新增KUKA驱动
    // add begin
    else if (ChannelDeviceType == "KUKA") {
        if ($("#Alter_ServerPortIpt").val() == '' || !regnum.test($("#Alter_ServerPortIpt").val())) {
            if (coo == "English") {
                alert("Please enter the correct server port");
            } else {
                alert("请输入正确的服务器端口");
            }
            return true;
        }
        if ($("#Alter_OvertimeIpt").val() == '' || !regnum.test($("#Alter_OvertimeIpt").val())) {
            if (coo == "English") {
                alert("Please enter the correct read timeout period");
            } else {
                alert("请输入正确的读取超时时间判断");
            }
            return true;
        }
        if ($("#Alter_DeviceNumberIpt").val() == '' || !regnum.test($("#Alter_DeviceNumberIpt").val())) {
            if (coo == "English") {
                alert("Please enter the correct equipment number");
            } else {
                alert("请输入正确的设备编号");
            }
            return true;
        }
        if ($("#Alter_DeviceIPIpt").val() == '' || !reg.test($("#Alter_DeviceIPIpt").val())) {
            if (coo == "English") {
                alert("Please enter the correct device IP");
            } else {
                alert("请输入正确的设备IP");
            }
            return true;
        }
    }
    // add end
    // add by whc, 新增DRACAL驱动
    else if (ChannelDeviceType == "DRACAL") {
        if ($("#Alter_SerialNumberIpt").val() == '') {
            if (coo == "English") {
                alert("Please enter the serial number");
            } else {
                alert("请输入序列号");
            }
            return true;
        }
    }
    // add end
    // add by fyj, 新增cloudweb驱动
    else if (ChannelDeviceType == "CloudWeb") {
        if ($("#Alter_SerialNumber2").val() == '') {
            if (coo == "English") {
                alert('Please enter the cloud platform gateway serial number');
            } else {
                alert('请输入云平台网关序列号');
            }
            return true;
        }
        if ($("#Alter_CloudName").val() == '') {
            if (coo == "English") {
                alert('Please enter the name of the cloud platform device');
            } else {
                alert('请输入云平台设备名称');
            }
            return true;
        }
    }
    // add end
    // add by fyj, 新增DLT645-2007驱动
    else if (ChannelDeviceType == 'DLT645-2007' || ChannelDeviceType == 'DLT645-1997') {
        var dltAddress = $('#Alter_dltAddress').val();
        var reg2 = new RegExp("^[0-9]*$");
        if (dltAddress == '') {
            if (coo == "English") {
                alert('Please enter the device address');
            } else {
                alert('请输入设备地址');
            }
            return true;
        } else if (!reg2.test(dltAddress)) {
            if (coo == "English") {
                alert('Device address input error');
            } else {
                alert('设备地址输入错误');
            }
            return true;
        } else {
            return false;
        }
    }
    // add end
    // add by fyj, OMRON-HostLink-Task
    else if (ChannelDeviceType == 'OMRON-HostLink-Task' || ChannelDeviceType == 'OMRON-FINS-Task') {
        var unitNumber = $('#Alter_hostLink_unitNumber').val();
        var networkNumber = $('#Alter_hostLink_networkNumber').val();
        var posIntReg = /^[0-9]+[0-9]*$/;
        if (unitNumber == '') {
            if (coo == "English") {
                alert('Please input unit number');
            } else {
                alert('请输入单元号');
            }
            return true;
        } else if (networkNumber == '') {
            if (coo == "English") {
                alert('Please input Mini network number');
            } else {
                alert('请输入Mini网络号');
            }
            return true;
        } else if (!posIntReg.test(unitNumber)) {
            if (coo == "English") {
                alert('Unit number must be a positive integer');
            } else {
                alert('单元号只能是正整数');
            }
            return true;
        } else {
            return false;
        }
    }
    else if (ChannelDeviceType == 'R1R2' ) {
        var slaveDeviceAddress = $('#Alter_samsung_address').val();
        var reg2 = new RegExp("^[0-9]*$");
        if (slaveDeviceAddress == '') {
            if (coo == "English") {
                alert('Please enter the device address');
            } else {
                alert('请输入从机地址');
            }
            return true;
        } else if (!reg2.test(slaveDeviceAddress)) {
            if (coo == "English") {
                alert('Device address input error');
            } else {
                alert('从机地址输入错误');
            }
            return true;
        } else {
            return false;
        }
    }
    // add end
    else {
        return false;
    }

}

function AlterDeviceMethod() {
    var params = $("#Alter_Device_YuToxhZhang").serialize();
    $("#Alter_Device_Button_Confirm").attr("disabled", "disabled");
    $("#Delete_Device_Button_Confirm").attr("disabled", "disabled");
    $("#gotoItemConfig").attr("disabled", "disabled");
    $("#popWindow").show();
    $.ajax({
        type: "post",
        url: "cgi-bin/device/AlterDevice.py",
        data: params,
        async: true,
        success: function (data) {
            $("#popWindow").hide();
            $("#DevOperation").hide();
            $("#Alter_Device_Button_Confirm").attr("disabled", "");
            $("#Delete_Device_Button_Confirm").attr("disabled", "");
            $("#gotoItemConfig").attr("disabled", "");
            initUI();
        }
    });
}
//删除设备

function Delete_Device() {
    //taskID
    if (coo == "English") {
        if (confirm("Sure to delete?")) {
            if (taskID == "") {
                $("#Alter_TaskID_YuToXHZhang").val("NULL")
            } else {
                $("#Alter_TaskID_YuToXHZhang").val(taskID)
            }
            document.getElementById("Alter_ChannelID_YuToXHZhang").value = ChannelID;
            document.getElementById("Alter_DeviceID_YuToXHZhang").value = Alter_Delete_CheckedDeviceID;
            var params = $("#Alter_Device_YuToxhZhang").serialize();
            $("#Alter_Device_Button_Confirm").attr("disabled", "disabled");
            $("#Delete_Device_Button_Confirm").attr("disabled", "disabled");
            $("#gotoItemConfig").attr("disabled", "disabled");
            $.ajax({
                type: "post",
                url: "cgi-bin/device/DeleteDevice.py",
                data: params,
                async: true,
                success: function (data) {
                    $("#PLCInfo").hide();
                    $("#popWindow").hide();
                    $("#Alter_Device_Button_Confirm").attr("disabled", "");
                    $("#Delete_Device_Button_Confirm").attr("disabled", "");
                    $("#gotoItemConfig").attr("disabled", "");
                    DeviceNum = 1000000000000;
                    initUI();
                    $("#DevOperation").hide();
                }
            });
        }
    } else {
        if (confirm("确定删除？")) {
            if (taskID == "") {
                $("#Alter_TaskID_YuToXHZhang").val("NULL")
            } else {
                $("#Alter_TaskID_YuToXHZhang").val(taskID)
            }
            document.getElementById("Alter_ChannelID_YuToXHZhang").value = ChannelID;
            document.getElementById("Alter_DeviceID_YuToXHZhang").value = Alter_Delete_CheckedDeviceID;
            var params = $("#Alter_Device_YuToxhZhang").serialize();
            $("#Alter_Device_Button_Confirm").attr("disabled", "disabled");
            $("#Delete_Device_Button_Confirm").attr("disabled", "disabled");
            $("#gotoItemConfig").attr("disabled", "disabled");
            $.ajax({
                type: "post",
                url: "cgi-bin/device/DeleteDevice.py",
                data: params,
                async: true,
                success: function (data) {
                    $("#PLCInfo").hide();
                    $("#popWindow").hide();
                    $("#Alter_Device_Button_Confirm").attr("disabled", "");
                    $("#Delete_Device_Button_Confirm").attr("disabled", "");
                    $("#gotoItemConfig").attr("disabled", "");
                    DeviceNum = 1000000000000;
                    initUI();
                    $("#DevOperation").hide();
                }
            });
        }
    }
}
//增加设备效果
$(".add_device").hover(function () {
    $(this).attr("src", "assets/img/add_hover.png");
}, function () {
    $(this).attr("src", "assets/img/add.png");
});

//弹出层

function Add_Open_DeviceLayer() {
    document.getElementById("popWindow").style.display = "";
    document.getElementById("Add_DeviceLayer").style.display = "";
    $("#Add_DeviceName").val("");
    $("#Add_slaveStationID").val("");
}
//进入数据项按钮效果

function ButtonHighLight() {
    document.getElementById("gotoItemConfig").className = "gotoConfigHover";
}

function HideButtonHighLight() {
    document.getElementById("gotoItemConfig").className = "gotoConfig";
}

//获取HKG84个自动生成数据项
function GetHKGData() {
    $.get('../conf/AllHKGData.xml', function (d1) {
        $(d1).find("HKG").each(function () {
            $(this).find("dataItem").each(function () {
                var $data = $(this);
                var freq = $data.attr('freq');
                var n = $data.attr('n');
                var alias = $data.attr('alias');
                var rw = $data.attr('rw');
                var report = $data.attr('report');
                var type = $data.attr('type');
                var config = $data.attr('config');
                HKGparams += "{'Add_DeviceID':'" + maxDeviceID + "','Add_DataItemName':'" + n + "','Add_DataItemAlias':'" + alias + "','Add_DataItemFreq':'" + freq +
                    "','Add_DataItemType':'" + type + "','Add_DataItemRWmode':'" + rw + "','Add_DataItemReport':'" + report + "','Add_DataItemConfig':'" + config +
                    "','Add_DataItemID':'" + DataItemID + "'}$";
                DataItemID++;
            });
        });
    });
}