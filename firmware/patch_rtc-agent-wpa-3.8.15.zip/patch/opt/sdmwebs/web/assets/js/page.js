/**
 * Created with IntelliJ IDEA.
 * User: dinghaiyun
 * Date: 14-10-30
 * Time: 下午4:52
 * To change this template use File | Settings | File Templates.
 */
var pageVo = {};

function initPage(rows, pageSize) {
    $("#pageBar").empty();
    var totalPage = getTotalPage(rows, pageSize);
    if (totalPage < 1) {
        return;
    }

    pageVo.totalPage = totalPage;
    pageVo.pageSize = pageSize;
    pageVo.totalRows = rows.length;
    pageVo.data = rows;

    createPageBar(totalPage);

}

function getTotalPage(rows, pageSize) {
    if (!rows || rows.length < 1) {
        console.log("pageSize is 0");
        return 0;
    }
    return Math.ceil((rows.length / pageSize));
}

function createPageBar(totalPage) {
    if (totalPage < 1) {
        console.log("pageNum is 0");
        return;
    }
    console.log("page:" + totalPage);
    for (var i = 0; i < totalPage; i++) {
        $("#pageBar").append("<a href='javascript:page(" + (i + 1) + ")'>" + (i + 1) + "</a>");
    }
    page(1);
}

function page(currentPage) {
    if (pageVo.length < 1) {
        return;
    }
    var totalPage = pageVo.totalPage;
    var pageSize = pageVo.pageSize;
    pageVo.currentPage = currentPage;
    for (var i = 0; i < totalPage; i++) {
        if (currentPage == i + 1) {
            $("#pageBar a").eq(i).css({
                "background-color": "#3385FF",
                "color": "#000"
            });
            $("#pageBar a").eq(i).siblings().css({
                "background-color": "#fff",
                "color": "#3385FF"
            });
            var startIndex = (currentPage - 1) * pageSize;
            if (currentPage == totalPage) {
                var endIndex = pageVo.totalRows - 1;
            } else {
                var endIndex = currentPage * pageSize;
            }
            setDataToTable(pageVo.data, startIndex, endIndex);
        }
    }
}

function setDataToTable(rows, startIndex, endIndex) {
    var datas = rows.slice(startIndex, endIndex + 1);
    if (datas != null) {
        var html = "";
        for (var i = 0; i < datas.length; i++) {
            html += datas[i];
        }
        $("#table2").html(html);
    }
}