$(document).ready(function () {
    getAgentLog();
});
$("#refresh").click(function () {
    getAgentLog();
});

function getAgentLog() {
    //将AgentLog日志取过来
    $.ajax({
        type: "post",
        url: "cgi-bin/agent/cp_log.py",
        data: "cp",
        beforeSend: function () {
            $(".popWindow").show();
            $(".TestLayer").show();
        },
        complete: function () {
            //方法执行完毕，效果自己可以关闭，或者隐藏效果
            $(".popWindow").hide();
            $(".TestLayer").hide();
        },
        success: function (data) {}
    });
}
//点击不同的按钮读取不同的log文件
$("#aelog1").click(function () {
    $.ajax({
        type: "get",
        url: "log/AeLog-1.log",
        success: function (data) {
            $("#log").empty();
            $("#log").html(data)
        },
        error: function () {
            if (coo == "English") {
                alert("The log file was not found, please try to refresh")
            }
            else {
                alert("未找到log文件，请刷新重试")
            }
        }
    });
});
$("#aelog2").click(function () {
    $.ajax({
        type: "get",
        url: "log/AeLog-2.log",
        success: function (data) {
            $("#log").empty();
            $("#log").html(data)
        },
        error: function () {
            if (coo == "English") {
                alert("The log file was not found, please try to refresh")
            }
            else {
                alert("未找到log文件，请刷新重试")
            }
        }
    });
});
$("#aelog3").click(function () {
    $.ajax({
        type: "get",
        url: "log/AeLog-3.log",
        success: function (data) {
            $("#log").empty();
            $("#log").html(data)
        },
        error: function () {
            if (coo == "English") {
                alert("The log file was not found, please try to refresh")
            }
            else {
                alert("未找到log文件，请刷新重试")
            }
        }
    });
});
$("#aelog4").click(function () {
    $.ajax({
        type: "get",
        url: "log/AeLog-4.log",
        success: function (data) {
            $("#log").empty();
            $("#log").html(data)
        },
        error: function () {
            if (coo == "English") {
                alert("The log file was not found, please try to refresh")
            }
            else {
                alert("未找到log文件，请刷新重试")
            }
        }
    });
});
$("#aelog5").click(function () {
    $.ajax({
        type: "get",
        url: "log/AeLog-5.log",
        success: function (data) {
            $("#log").empty();
            $("#log").html(data)
        },
        error: function () {
            if (coo == "English") {
                alert("The log file was not found, please try to refresh")
            }
            else {
                alert("未找到log文件，请刷新重试")
            }
        }
    });
});