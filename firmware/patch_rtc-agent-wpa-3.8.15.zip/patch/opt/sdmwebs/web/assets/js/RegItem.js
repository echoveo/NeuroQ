document.writeln("<" + "script language='javascript' src='assets/js/language.js?t="+(new Date()).getTime()+"'></" + "script>");
var coo = getCookie("AnyLinkLan");
function regValidate11(category, address) {
    $("#addressTip").empty();
    if (category != "SIEMENS-PPI") {
        return true;
    }
    var item = address;
    var reg = new RegExp("^[a-z|A-Z]+\\d+([.]\\d*)?$");
    if (!reg.test(item)) {
        if (coo == "English") {
            $("#addressTipInfo").html("Incorrect data item address. Please input a correct value that matches the device and driver type. For example, a data address in Siemens PPI series is IB14, a combination of capital letters and numbers, starting with a letter.");
            $("#addressTip").html("Incorrect data item address. Please input a correct value that matches the device and driver type. For example, a data address in Siemens PPI series is IB14, a combination of capital letters and numbers, starting with a letter.");
        }
        else {
            $("#addressTipInfo").html("数据项地址不合法,请重新输入!请根据所用的设备类型和设备驱动进行填写。如西门子PPI系列的一个数据地址为IB14(格式为大写字母与数字的组合，并且以字母开头。)");
            $("#addressTip").html("数据项地址不合法,请重新输入!请根据所用的设备类型和设备驱动进行填写。如西门子PPI系列的一个数据地址为IB14(格式为大写字母与数字的组合，并且以字母开头。)");
        }
        return false;
    }
    //分解数据项地址
    var letter = item.match(/^[a-z|A-Z]+/gi);
    var num = item.match(/\d+.?\d*$/gi).toString();
    var numArray = num.split(".");
    var value = parseFloat(num);
    var numInt = parseInt(numArray[0]);
    var numFloat = parseInt(numArray[1]);

    //西门子PPI系列校验
    // modified by fyj
    // begin 
    if (category == "SIEMENS-PPI") {
        if (letter == "I") {
            if (coo == "English") {
                if (value < 0.0 || value > 15.7) {
                    $("#addressTip").html("Error! For Siemens PPI seires, the value of the BIT type input mapping register must be between I10.0 and I15.7. There can be at most one digit after the decimal point, and the tenth digit can be no more than 7.");
                    return false;
                }
                if (numArray[1] != undefined && numArray[1].length > 1) {
                    $("#addressTip").html("Error! There can be at most one digit after the decimal point, and the tenth digit can be no more than 7.");
                    return false;
                }
                if (numFloat > 7) {
                    $("#addressTip").html("The tenth digit can be no more than 7.");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "BIT") {
                    $("#Add_DataItemTypeTip").html("I开头的数据项地址只能为Boolean类型");
                    return false;
                } */
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            else {
                if (coo == "English") {
                    if (value < 0.0 || value > 15.7) {
                        $("#addressTip").html("Error! For Siemens PPI seires, the value of the BIT type input mapping register must be between I10.0 and I15.7. There can be at most one digit after the decimal point, and the tenth digit can be no more than 7.");
                        return false;
                    }
                    if (numArray[1] != undefined && numArray[1].length > 1) {
                        $("#addressTip").html("Error! There can be at most one digit after the decimal point, and the tenth digit can be no more than 7.");
                        return false;
                    }
                    if (numFloat > 7) {
                        $("#addressTip").html("The tenth digit can be no more than 7.");
                        return false;
                    }
                    /*
                    if (document.getElementById("Add_DataItemType").value != "BIT") {
                        $("#Add_DataItemTypeTip").html("I开头的数据项地址只能为Boolean类型");
                        return false;
                    } */
                    else {
                        $("#Add_DataItemTypeTip").html("");
                    }
                }
                else {
                    if (value < 0.0 || value > 15.7) {
                        $("#addressTip").html("错误！西门子PPI系列中,BIT类型的输入映像寄存器I范围为:I0.0~I15.7。如果有小数位，则只能有一位并且小数位最大为7");
                        return false;
                    }
                    if (numArray[1] != undefined && numArray[1].length > 1) {
                        $("#addressTip").html("错误！只能带一位小数，并且小数不大于7");
                        return false;
                    }
                    if (numFloat > 7) {
                        $("#addressTip").html("小数位最大为7");
                        return false;
                    }
                    /*
                    if (document.getElementById("Add_DataItemType").value != "BIT") {
                        $("#Add_DataItemTypeTip").html("I开头的数据项地址只能为Boolean类型");
                        return false;
                    } */
                    else {
                        $("#Add_DataItemTypeTip").html("");
                    }
                }
            }      
        } else if (letter == "IB") {
            if (coo == "English") {
                if (value < 0 || value > 15) {
                    $("#addressTip").html("Error! For Siemens PPI series, the value of the BYTE type input mapping register must be between IB0 and IB15.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTip").html("Error! Value must be an integer.");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "BYTE" && document.getElementById("Add_DataItemType").value != "INT8") {
                    $("#Add_DataItemTypeTip").html("IB开头的数据项地址只能为BYTE或者INT8类型");
                    return false;
                }*/ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0 || value > 15) {
                    $("#addressTip").html("错误！西门子PPI系列中,BYTE类型的输入映像寄存器I范围为:IB0~IB15。");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTip").html("错误！只能为整数");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "BYTE" && document.getElementById("Add_DataItemType").value != "INT8") {
                    $("#Add_DataItemTypeTip").html("IB开头的数据项地址只能为BYTE或者INT8类型");
                    return false;
                }*/ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }

        } else if (letter == "IW") {
            if (coo == "English") {
                if (value < 0 || value > 14) {
                    $("#addressTip").html("Error! For Siemens PPI series, the value of the WORD type input mapping register must be between IW0 and IW14.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTip").html("Error! Value must be an integer.");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "WORD" && document.getElementById("Add_DataItemType").value != "INT16") {
                    $("#Add_DataItemTypeTip").html("IW开头的数据项地址只能为WORD或者INT16类型");
                    return false;
                }*/ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0 || value > 14) {
                    $("#addressTip").html("错误！西门子PPI系列中,WORD类型的输入映像寄存器I范围为:IW0~IW14");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTip").html("错误！只能为整数");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "WORD" && document.getElementById("Add_DataItemType").value != "INT16") {
                    $("#Add_DataItemTypeTip").html("IW开头的数据项地址只能为WORD或者INT16类型");
                    return false;
                }*/ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
        } else if (letter == "ID") {
            if (coo == "English") {
                if (value < 0 || value > 12) {
                    $("#addressTip").html("Error! For Siemens PPI series, the value of DWORD type input mapping register must be between ID0 and ID12.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTip").html("Error! Value must be an integer.");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "DWORD" && document.getElementById("Add_DataItemType").value != "INT32" && document.getElementById("Add_DataItemType").value != "FLOAT") {
                    $("#Add_DataItemTypeTip").html("ID开头的数据项地址只能为DWORD,INT32或者float类型");
                    return false;
                }*/ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0 || value > 12) {
                    $("#addressTip").html("错误！西门子PPI系列中,DWORD类型的输入映像寄存器I范围为:ID0~ID12");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTip").html("错误！只能为整数");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "DWORD" && document.getElementById("Add_DataItemType").value != "INT32" && document.getElementById("Add_DataItemType").value != "FLOAT") {
                    $("#Add_DataItemTypeTip").html("ID开头的数据项地址只能为DWORD,INT32或者float类型");
                    return false;
                }*/ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
        } else if (letter == "Q") {
            if (coo == "English") {
                if (value < 0 || value > 15.7) {
                    $("#addressTip").html("Error! For Siemens PPI Series, the value of the BIT type output mapping register Q must be between Q0.0 and Q15.7. There can be at most one digit after the decimal point, and the tenth digit can be no more than 7.");
                    return false;
                }
                if (numArray[1] != undefined && numArray[1].length > 1) {
                    $("#addressTip").html("Error! There can be at most one digit after the decimal point, and the tenth digit can be no more than 7.");
                    return false;
                }
                if (numFloat > 7) {
                    $("#addressTip").html("The tenth digit can be no more than 7.");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "BIT") {
                    $("#Add_DataItemTypeTip").html("Q开头的数据项地址只能为Boolean类型");
                    return false;
                }*/ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0 || value > 15.7) {
                    $("#addressTip").html("错误！西门子PPI系列中,BIT类型的输出映像寄存器Q范围为:Q0.0~I15.7。如果有小数位，则只能有一位并且小数位最大为7");
                    return false;
                }
                if (numArray[1] != undefined && numArray[1].length > 1) {
                    $("#addressTip").html("错误！只能带一个小数点，并且不大于7");
                    return false;
                }
                if (numFloat > 7) {
                    $("#addressTip").html("小数位最大为7");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "BIT") {
                    $("#Add_DataItemTypeTip").html("Q开头的数据项地址只能为Boolean类型");
                    return false;
                }*/ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "QB") {
            if (coo == "English") {
                if (value < 0 || value > 15) {
                    $("#addressTip").html("Error! For Siemens PPI series, the value of the BIT type output mapping register Q must be between QB0 and QB15.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTip").html("Error! Value must be an integer.");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "BYTE" && document.getElementById("Add_DataItemType").value != "INT8") {
                    $("#Add_DataItemTypeTip").html("QB开头的数据项地址只能为BYTE或者INT8类型");
                    return false;
                } */ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0 || value > 15) {
                    $("#addressTip").html("错误！西门子PPI系列中,BIT类型的输出映像寄存器Q范围为:QB0~QB15");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTip").html("错误！只能为整数");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "BYTE" && document.getElementById("Add_DataItemType").value != "INT8") {
                    $("#Add_DataItemTypeTip").html("QB开头的数据项地址只能为BYTE或者INT8类型");
                    return false;
                } */ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "QW") {
            if (coo == "English") {
                if (value < 0 || value > 14) {
                    $("#addressTip").html("Error! For Siemens PPI series, the value of the WORD type output mapping register Q must be between QW0 and QW14.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTip").html("Error! Value must be an integer.");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "WORD" && document.getElementById("Add_DataItemType").value != "INT16") {
                    $("#Add_DataItemTypeTip").html("QW开头的数据项地址只能为Word或者Int16类型");
                    return false;
                }*/ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0 || value > 14) {
                    $("#addressTip").html("错误！西门子PPI系列中,WORD类型的输出映像寄存器Q范围为:QW0~QW14");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTip").html("错误！只能为整数");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "WORD" && document.getElementById("Add_DataItemType").value != "INT16") {
                    $("#Add_DataItemTypeTip").html("QW开头的数据项地址只能为Word或者Int16类型");
                    return false;
                }*/ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "QD") {
            if (coo == "English") {
                if (value < 0 || value > 12) {
                    $("#addressTip").html("Error! For Siemens PPI series, the value of the DWORD type output mapping register Q must be between QD0 and QD12.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTip").html("Error! Value must be an integer.");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "DWORD" && document.getElementById("Add_DataItemType").value != "INT32" && document.getElementById("Add_DataItemType").value != "FLOAT") {
                    $("#Add_DataItemTypeTip").html("QD开头的数据项地址只能为DWord,Int32或者float类型");
                    return false;
                } */ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0 || value > 12) {
                    $("#addressTip").html("错误！西门子PPI系列中,DWORD类型的输出映像寄存器Q范围为:QD0~QD12");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTip").html("错误！只能为整数");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "DWORD" && document.getElementById("Add_DataItemType").value != "INT32" && document.getElementById("Add_DataItemType").value != "FLOAT") {
                    $("#Add_DataItemTypeTip").html("QD开头的数据项地址只能为DWord,Int32或者float类型");
                    return false;
                } */ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "V") {
            if (coo == "English") {
                if (value < 0.0 || value > 5119.7) {
                    $("#addressTip").html("Error! For Siemens PPI series, the value of the BIT type memory variable V must be between V0.0 and V5119.7. There can be at most one digit after the decimal place, and the tenth digit can be no more than 7.");
                    return false;
                }
                if (numArray[1] != undefined && numArray[1].length > 1) {
                    $("#addressTip").html("Error! There can be at most one digit after the decimal point, and the tenth digit can be no more than 7.");
                    return false;
                }
                if (numFloat > 7) {
                    $("#addressTip").html("Error! The tenth digit can be no more than 7.");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "BIT") {
                    $("#Add_DataItemTypeTip").html("V开头的数据项地址只能为Boolean类型");
                    return false;
                } */ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0.0 || value > 5119.7) {
                    $("#addressTip").html("错误！西门子PPI系列中,BIT类型的变量存储器V范围为:V0.0~V5119.7。如果有小数位，只能有一位并且小数位最大为7");
                    return false;
                }
                if (numArray[1] != undefined && numArray[1].length > 1) {
                    $("#addressTip").html("错误！只能带一位小数，并且小数不大于7");
                    return false;
                }
                if (numFloat > 7) {
                    $("#addressTip").html("错误！小数位最大为7");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "BIT") {
                    $("#Add_DataItemTypeTip").html("V开头的数据项地址只能为Boolean类型");
                    return false;
                } */ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "VB") {
            if (coo ==  "English") {
                if (value < 0 || value > 5119) {
                    $("#addressTip").html("Error! For Siemens PPI series, the value of the BYTE type memory variable V must be between VB0 and VB5119.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTip").html("Error! Value must be an integer.");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "BYTE" && document.getElementById("Add_DataItemType").value != "INT8") {
                    $("#Add_DataItemTypeTip").html("VB开头的数据项地址只能为BYTE或者INT8类型");
                    return false;
                } */ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0 || value > 5119) {
                    $("#addressTip").html("错误！西门子PPI系列中,BYTE类型的变量存储器V范围为:VB0~VB5119");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTip").html("错误！只能为整数");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "BYTE" && document.getElementById("Add_DataItemType").value != "INT8") {
                    $("#Add_DataItemTypeTip").html("VB开头的数据项地址只能为BYTE或者INT8类型");
                    return false;
                } */ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "VW") {
            if (coo == "English") {
                if (value < 0 || value > 5118) {
                    $("#addressTip").html("Error! For Siemens PPI series, the value of the WORD type memory variable V must be between VW0 and VW5118.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTip").html("Error! Value must be an integer.");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "WORD" && document.getElementById("Add_DataItemType").value != "INT16") {
                    $("#Add_DataItemTypeTip").html("VW开头的数据项地址只能为Word或者Int16类型");
                    return false;
                } */ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0 || value > 5118) {
                    $("#addressTip").html("错误！西门子PPI系列中,WORD类型的变量存储器V范围为:VW0~VW5118");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTip").html("错误！只能为整数");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "WORD" && document.getElementById("Add_DataItemType").value != "INT16") {
                    $("#Add_DataItemTypeTip").html("VW开头的数据项地址只能为Word或者Int16类型");
                    return false;
                } */ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "VD") {
            if (coo == "English") {
                if (value < 0 || value > 5116) {
                    $("#addressTip").html("Error! For Siemens PPI series, the value of the DWORD type memory variable V must be between VD0 and VD5116.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTip").html("Error! Value must be an integer.");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "DWORD" && document.getElementById("Add_DataItemType").value != "INT32" && document.getElementById("Add_DataItemType").value != "FLOAT") {
                    $("#Add_DataItemTypeTip").html("VD开头的数据项地址只能为DWord,Int32或者float类型");
                    return false;
                } */ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0 || value > 5116) {
                    $("#addressTip").html("错误！西门子PPI系列中,DWORD类型的变量存储器V范围为:VD0~VD5116");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTip").html("错误！只能为整数");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "DWORD" && document.getElementById("Add_DataItemType").value != "INT32" && document.getElementById("Add_DataItemType").value != "FLOAT") {
                    $("#Add_DataItemTypeTip").html("VD开头的数据项地址只能为DWord,Int32或者float类型");
                    return false;
                } */ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "M") {
            if (coo == "English") {
                if (value < 0.0 || value > 31.7) {
                    $("#addressTip").html("Error! For Siemens PPI series, the value of the BIT type memory variable M must be between M0.0 and M31.7. There can be at most one digit after the decimal place, and the tenth digit can be no more than 7.");
                    return false;
                }
                if (numArray[1] != undefined && numArray[1].length > 1) {
                    $("#addressTip").html("Error! There can be at most one digit after the decimal point, and the tenth digit can be no more than 7.");
                    return false;
                }
                if (numFloat > 7) {
                    $("#addressTip").html("Error! The tenth digit can be no more than 7.");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "BIT") {
                    $("#Add_DataItemTypeTip").html("M开头的数据项地址只能为Boolean类型");
                    return false;
                } */ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0.0 || value > 31.7) {
                    $("#addressTip").html("错误！西门子PPI系列中,BIT类型的位存储器M范围为:M0.0~M31.7。如果有小数位，只能有一位并且小数位最大为7");
                    return false;
                }
                if (numArray[1] != undefined && numArray[1].length > 1) {
                    $("#addressTip").html("错误！只能带一位小数，并且小数不大于7");
                    return false;
                }
                if (numFloat > 7) {
                    $("#addressTip").html("错误！小数位最大为7");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "BIT") {
                    $("#Add_DataItemTypeTip").html("M开头的数据项地址只能为Boolean类型");
                    return false;
                } */ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "MB") {
            if (coo == "English") {
                if (value < 0 || value > 31) {
                    $("#addressTip").html("Error! For Siemens PPI series, the value of the BYTE type memory variable M must be between MB0 and MB31.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTip").html("Error! Value must be an integer.");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "BYTE" && document.getElementById("Add_DataItemType").value != "INT8") {
                    $("#Add_DataItemTypeTip").html("MB开头的数据项地址只能为BYTE或者INT8类型");
                    return false;
                } */ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0 || value > 31) {
                    $("#addressTip").html("错误！西门子PPI系列中,BYTE类型的位存储器M范围为:MB0~MB31");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTip").html("错误！只能为整数");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "BYTE" && document.getElementById("Add_DataItemType").value != "INT8") {
                    $("#Add_DataItemTypeTip").html("MB开头的数据项地址只能为BYTE或者INT8类型");
                    return false;
                } */ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "MW") {
            if (coo == "English") {
                if (value < 0 || value > 30) {
                    $("#addressTip").html("Error! For Siemens PPI series, the value of the WORD type memory variable M must be between MW0 and MW30.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTip").html("Error! Value must be an integer.");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "WORD" && document.getElementById("Add_DataItemType").value != "INT16") {
                    $("#Add_DataItemTypeTip").html("MW开头的数据项地址只能为Word或者Int16类型");
                    return false;
                } */ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0 || value > 30) {
                    $("#addressTip").html("错误！西门子PPI系列中,WORD类型的位存储器M范围为:MW0~MW30");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTip").html("错误！只能为整数");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "WORD" && document.getElementById("Add_DataItemType").value != "INT16") {
                    $("#Add_DataItemTypeTip").html("MW开头的数据项地址只能为Word或者Int16类型");
                    return false;
                } */ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "MD") {
            if (coo == "English") {
                if (value < 0 || value > 28) {
                    $("#addressTip").html("Error! For Siemens PPI series, the value of the DWORD type memory variable M must be between MD0 and MD28.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTip").html("Error! Value must be an integer.");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "DWORD" && document.getElementById("Add_DataItemType").value != "INT32" && document.getElementById("Add_DataItemType").value != "FLOAT") {
                    $("#Add_DataItemTypeTip").html("MD开头的数据项地址只能为DWord,Int32或者float类型");
                    return false;
                } */ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0 || value > 28) {
                    $("#addressTip").html("错误！西门子PPI系列中,DWORD类型的位存储器M范围为:MD0~MD28");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTip").html("错误！只能为整数");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "DWORD" && document.getElementById("Add_DataItemType").value != "INT32" && document.getElementById("Add_DataItemType").value != "FLOAT") {
                    $("#Add_DataItemTypeTip").html("MD开头的数据项地址只能为DWord,Int32或者float类型");
                    return false;
                } */ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "S") {
            if (coo == "English") {
                if (value < 0.0 || value > 31.7) {
                    $("#addressTip").html("Error! For Siemens PPI series, the value of the the BIT type sequence control relay (SCR) S must be between S0.0 and S31.7. There can be at most one digit after the decimal place, and the tenth digit can be no more than 7.");
                    return false;
                }
                if (numArray[1] != undefined && numArray[1].length > 1) {
                    $("#addressTip").html("Error! There can be at most one digit after the decimal point, and the tenth digit can be no more than 7.");
                    return false;
                }
                if (numFloat > 7) {
                    $("#addressTip").html("Error! The tenth digit can be no more than 7.");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "BIT") {
                    $("#Add_DataItemTypeTip").html("S开头的数据项地址只能为Boolean类型");
                    return false;
                } */ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0.0 || value > 31.7) {
                    $("#addressTip").html("错误！西门子PPI系列中,BIT类型的顺序控制继电器S范围为:S0.0~S31.7。如果有小数位，只能有一位并且小数位最大为7");
                    return false;
                }
                if (numArray[1] != undefined && numArray[1].length > 1) {
                    $("#addressTip").html("错误！只能带一位小数，并且小数不大于7");
                    return false;
                }
                if (numFloat > 7) {
                    $("#addressTip").html("错误！小数位最大为7");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "BIT") {
                    $("#Add_DataItemTypeTip").html("S开头的数据项地址只能为Boolean类型");
                    return false;
                } */ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "SB") {
            if (coo == "English") {
                if (value < 0.0 || value > 31) {
                    $("#addressTip").html("Error! For Siemens PPI series, the value of the the BYTE type sequence control relay (SCR) S must be between SB0 and SB31.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTip").html("Error! Value must be an integer.");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "BYTE" && document.getElementById("Add_DataItemType").value != "INT8") {
                    $("#Add_DataItemTypeTip").html("SB开头的数据项地址只能为BYTE或者INT8类型");
                    return false;
                } */ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0.0 || value > 31) {
                    $("#addressTip").html("错误！西门子PPI系列中,BYTE类型的顺序控制继电器S范围为:SB0~SB31");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTip").html("错误！只能是整数");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "BYTE" && document.getElementById("Add_DataItemType").value != "INT8") {
                    $("#Add_DataItemTypeTip").html("SB开头的数据项地址只能为BYTE或者INT8类型");
                    return false;
                } */ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "SW") {
            if (coo == "English") {
                if (value < 0.0 || value > 30) {
                    $("#addressTip").html("Error! For Siemens PPI series, the value of the the WORD type sequence control relay (SCR) S must be between SW0 and SW30.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTip").html("Error! Value must be an integer.");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "WORD" && document.getElementById("Add_DataItemType").value != "INT16") {
                    $("#Add_DataItemTypeTip").html("SW开头的数据项地址只能为Word或者Int16类型");
                    return false;
                } */ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0.0 || value > 30) {
                    $("#addressTip").html("错误！西门子PPI系列中,WORD类型的顺序控制继电器S范围为:SW0~SW30");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTip").html("错误！只能是整数");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "WORD" && document.getElementById("Add_DataItemType").value != "INT16") {
                    $("#Add_DataItemTypeTip").html("SW开头的数据项地址只能为Word或者Int16类型");
                    return false;
                } */ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "SD") {
            if (coo == "English") {
                if (value < 0.0 || value > 28) {
                    $("#addressTip").html("Error! For Siemens PPI series, the value of the the DWORD type sequence control relay (SCR) S must be between SD0 and SD28.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTip").html("Error! Value must be an integer.");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "DWORD" && document.getElementById("Add_DataItemType").value != "INT32" && document.getElementById("Add_DataItemType").value != "FLOAT") {
                    $("#Add_DataItemTypeTip").html("SD开头的数据项地址只能为DWord,Int32或者float类型");
                    return false;
                } */ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0.0 || value > 28) {
                    $("#addressTip").html("错误！西门子PPI系列中,DWORD类型的顺序控制继电器S范围为:SD0~SD28");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTip").html("错误！只能是整数");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "DWORD" && document.getElementById("Add_DataItemType").value != "INT32" && document.getElementById("Add_DataItemType").value != "FLOAT") {
                    $("#Add_DataItemTypeTip").html("SD开头的数据项地址只能为DWord,Int32或者float类型");
                    return false;
                } */ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "SM") {
            if (coo == "English") {
                if (value < 0.0 || value > 179.7) {
                    $("#addressTip").html("Error! For Siemens PPI series, the value of BIT type special memory SM must be between SM0.0 and SM 179.7. There can be at most one digit after the decimal place, and the tenth digit can be no more than 7.");
                    return false;
                }
                if (numArray[1] != undefined && numArray[1].length > 1) {
                    $("#addressTip").html("Error! There can be at most one digit after the decimal point, and the tenth digit can be no more than 7.");
                    return false;
                }
                if (numFloat > 7) {
                    $("#addressTip").html("Error! The tenth digit can be no more than 7.");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "BIT") {
                    $("#Add_DataItemTypeTip").html("SM开头的数据项地址只能为Boolean类型");
                    return false;
                } */ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0.0 || value > 179.7) {
                    $("#addressTip").html("错误！西门子PPI系列中,BIT类型的特殊存储器SM范围为:SM0.0~SM179.7。如果有小数位，只能有一位并且小数位最大为7");
                    return false;
                }
                if (numArray[1] != undefined && numArray[1].length > 1) {
                    $("#addressTip").html("错误！只能带一位小数，并且小数不大于7");
                    return false;
                }
                if (numFloat > 7) {
                    $("#addressTip").html("错误！小数位最大为7");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "BIT") {
                    $("#Add_DataItemTypeTip").html("SM开头的数据项地址只能为Boolean类型");
                    return false;
                } */ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "SMB") {
            if (coo == "English") {
                if (value < 0 || value > 179) {
                    $("#addressTip").html("Error! For Siemens PPI series, the value of BYTE type special memory SM must be between SMB0 and SMB179.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTip").html("Error! Value must be an integer.");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "BYTE" && document.getElementById("Add_DataItemType").value != "INT8") {
                    $("#Add_DataItemTypeTip").html("SMB开头的数据项地址只能为BYTE或者INT8类型");
                    return false;
                } */ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0 || value > 179) {
                    $("#addressTip").html("错误！西门子PPI系列中,BYTE类型的特殊存储器SM范围为:SMB0~SMB179");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTip").html("错误！只能是整数");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "BYTE" && document.getElementById("Add_DataItemType").value != "INT8") {
                    $("#Add_DataItemTypeTip").html("SMB开头的数据项地址只能为BYTE或者INT8类型");
                    return false;
                } */ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "SMW") {
            if (coo == "English") {
                if (value < 0 || value > 178) {
                    $("#addressTip").html("Error! For Siemens PPI series, the value of WORD type special memory SM must be between SMW0 and SMW178.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTip").html("Error! Value must be an integer.");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "WORD" && document.getElementById("Add_DataItemType").value != "INT16") {
                    $("#Add_DataItemTypeTip").html("SMW开头的数据项地址只能为Word或者Int16类型");
                    return false;
                } */ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0 || value > 178) {
                    $("#addressTip").html("错误！西门子PPI系列中,WORD类型的特殊存储器SM范围为:SMW0~SMW178");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTip").html("错误！只能是整数");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "WORD" && document.getElementById("Add_DataItemType").value != "INT16") {
                    $("#Add_DataItemTypeTip").html("SMW开头的数据项地址只能为Word或者Int16类型");
                    return false;
                } */ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "SMD") {
            if (coo == "English") {
                if (value < 0 || value > 176) {
                    $("#addressTip").html("Error! For Siemens PPI series, the value of DWORD type special memory SM must be between SMD0 and SMD176.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTip").html("Error! Value must be an integer.");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "DWORD" && document.getElementById("Add_DataItemType").value != "INT32" && document.getElementById("Add_DataItemType").value != "FLOAT") {
                    $("#Add_DataItemTypeTip").html("SMD开头的数据项地址只能为DWord,Int32或者float类型");
                    return false;
                } */ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0 || value > 176) {
                    $("#addressTip").html("错误！西门子PPI系列中,DWORD类型的特殊存储器SM范围为:SMD0~SMD176");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTip").html("错误！只能是整数");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "DWORD" && document.getElementById("Add_DataItemType").value != "INT32" && document.getElementById("Add_DataItemType").value != "FLOAT") {
                    $("#Add_DataItemTypeTip").html("SMD开头的数据项地址只能为DWord,Int32或者float类型");
                    return false;
                } */ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "T") {
            if (coo == "English") {
                if (value < 0 || value > 255) {
                    $("#addressTip").html("Error! For Siemens PPI series, the value of timer T must be between T0 and T255.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTip").html("Error! Value must be an integer.");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "BIT") {
                    $("#Add_DataItemTypeTip").html("T开头的数据项地址只能为Boolean类型");
                    return false;
                } */ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0 || value > 255) {
                    $("#addressTip").html("错误！西门子PPI系列中,定时器T范围为:T0~T255");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTip").html("错误！只能是整数");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "BIT") {
                    $("#Add_DataItemTypeTip").html("T开头的数据项地址只能为Boolean类型");
                    return false;
                } */ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "C") {
            if (coo == "English") {
                if (value < 0 || value > 255) {
                    $("#addressTip").html("Error! For Siemens PPI series, the value of counter C must be between C0 and C255.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTip").html("Error! Value must be an integer.");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "BIT") {
                    $("#Add_DataItemTypeTip").html("C开头的数据项地址只能为Boolean类型");
                    return false;
                } */ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0 || value > 255) {
                    $("#addressTip").html("错误！西门子PPI系列中,计数器C范围为:C0~C255");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTip").html("错误！只能是整数");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "BIT") {
                    $("#Add_DataItemTypeTip").html("C开头的数据项地址只能为Boolean类型");
                    return false;
                } */ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "AIW") {
            if (coo == "English") {
                if (value < 0 || value > 30) {
                    $("#addressTip").html("Error! For Siemens PPI series, the value of analog input AI must be between AIW0 and AIW30.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTip").html("Error! Value must be an integer.");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "WORD" && document.getElementById("Add_DataItemType").value != "INT16") {
                    $("#Add_DataItemTypeTip").html("AIW开头的数据项地址只能为Word或者Int16类型");
                    return false;
                } */ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0 || value > 30) {
                    $("#addressTip").html("错误！西门子PPI系列中,模拟输入AI范围为:AIW0~AIW30");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTip").html("错误！只能是整数");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "WORD" && document.getElementById("Add_DataItemType").value != "INT16") {
                    $("#Add_DataItemTypeTip").html("AIW开头的数据项地址只能为Word或者Int16类型");
                    return false;
                } */ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "AQW") {
            if (coo == "English") {
                if (value < 0 || value > 30) {
                    $("#addressTip").html("Error! For Siemens PPI series, the value of analog output AQ must be between AQW0 and AQW30.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTip").html("Error! Value must be an integer.");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "WORD" && document.getElementById("Add_DataItemType").value != "INT16") {
                    $("#Add_DataItemTypeTip").html("AQW开头的数据项地址只能为Word或者Int16类型");
                    return false;
                } */ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0 || value > 30) {
                    $("#addressTip").html("错误！西门子PPI系列中,模拟输出AQ范围为:AQW0~AQW30");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTip").html("错误！只能是整数");
                    return false;
                }
                /*
                if (document.getElementById("Add_DataItemType").value != "WORD" && document.getElementById("Add_DataItemType").value != "INT16") {
                    $("#Add_DataItemTypeTip").html("AQW开头的数据项地址只能为Word或者Int16类型");
                    return false;
                } */ 
                else {
                    $("#Add_DataItemTypeTip").html("");
                }
            }
            
        } else {
            if (coo == "English") {
                $("#addressTip").html("Can’t find a data item address starting with" + letter + "for Siemens PPI series.");
            }
            else {
                $("#addressTip").html("西门子PPI系列不存在以" + letter + "字母开头的数据项地址");
            }
            return false;
        }
        return true;
    }
}
// end

function regValidate(category, address) {
    $("#addressTipInfo").empty();
    var item = address;
    var reg = new RegExp("^[a-z|A-Z]+\\d+([.]\\d*)?$");
    if (!reg.test(item)) {
        if (coo == "English") {
            $("#addressTipInfo").html("Incorrect data item address. Please input a correct value that matches the device and driver type. For example, a data address in Siemens PPI series is IB14, a combination of capital letters and numbers, starting with a letter.");
            $("#addressTip").html("Incorrect data item address. Please input a correct value that matches the device and driver type. For example, a data address in Siemens PPI series is IB14, a combination of capital letters and numbers, starting with a letter.");
        }
        else {
            $("#addressTipInfo").html("数据项地址不合法,请重新输入!请根据所用的设备类型和设备驱动进行填写。如西门子PPI系列的一个数据地址为IB14(格式为大写字母与数字的组合，并且以字母开头。)");
            $("#addressTip").html("数据项地址不合法,请重新输入!请根据所用的设备类型和设备驱动进行填写。如西门子PPI系列的一个数据地址为IB14(格式为大写字母与数字的组合，并且以字母开头。)");
        }
        
        return false;
    }
    //分解数据项地址
    var letter = item.match(/^[a-z|A-Z]+/gi);
    var num = item.match(/\d+.?\d*$/gi).toString();
    var numArray = num.split(".");
    var value = parseFloat(num);
    var numInt = parseInt(numArray[0]);
    var numFloat = parseInt(numArray[1]);

    //西门子PPI系列校验
    if (category == "SIEMENS-PPI") {
        if (letter == "I") {
            if (coo == "English") {
                if (value < 0.0 || value > 15.7) {
                    $("#addressTipInfo").html("Error! For Siemens PPI seires, the value of the BIT type input mapping register must be between I10.0 and I15.7. There can be at most one digit after the decimal point, and the tenth digit can be no more than 7.");
                    return false;
                }
                if (numArray[1] != undefined && numArray[1].length > 1) {
                    $("#addressTipInfo").html("Error! There can be at most one digit after the decimal point, and the tenth digit can be no more than 7.");
                    return false;
                }
                if (numFloat > 7) {
                    $("#addressTipInfo").html("The tenth digit can be no more than 7.");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "BIT") {
                    $("#Alter_DataItemTypeTip").html("Data item address starting with “I” must be Boolean type.");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0.0 || value > 15.7) {
                    $("#addressTipInfo").html("错误！西门子PPI系列中,BIT类型的输入映像寄存器I范围为:I0.0~I15.7。如果有小数位，则只能有一位并且小数位最大为7");
                    return false;
                }
                if (numArray[1] != undefined && numArray[1].length > 1) {
                    $("#addressTipInfo").html("错误！只能带一位小数，并且小数不大于7");
                    return false;
                }
                if (numFloat > 7) {
                    $("#addressTipInfo").html("小数位最大为7");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "BIT") {
                    $("#Alter_DataItemTypeTip").html("I开头的数据项地址只能为Boolean类型");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "IB") {
            if (coo == "English") {
                if (value < 0 || value > 15) {
                    $("#addressTipInfo").html("Error! For Siemens PPI series, the value of the BYTE type input mapping register must be between IB0 and IB15.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("Error! Value must be an integer.");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "BYTE" && document.getElementById("Alter_DataItemType").value != "INT8") {
                    $("#Alter_DataItemTypeTip").html("Data item address starting with “IB” must be BYTE or INT8 type.");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0 || value > 15) {
                    $("#addressTipInfo").html("错误！西门子PPI系列中,BYTE类型的输入映像寄存器I范围为:IB0~IB15。");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("错误！只能为整数");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "BYTE" && document.getElementById("Alter_DataItemType").value != "INT8") {
                    $("#Alter_DataItemTypeTip").html("IB开头的数据项地址只能为BYTE或者INT8类型");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }

        } else if (letter == "IW") {
            if (coo == "English") {
                if (value < 0 || value > 14) {
                    $("#addressTipInfo").html("Error! For Siemens PPI series, the value of the WORD type input mapping register must be between IW0 and IW14.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("Error! Value must be an integer.");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "WORD" && document.getElementById("Alter_DataItemType").value != "INT16") {
                    $("#Alter_DataItemTypeTip").html("Data item address starting with “IW” must be WORD or INT16 type.");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0 || value > 14) {
                    $("#addressTipInfo").html("错误！西门子PPI系列中,WORD类型的输入映像寄存器I范围为:IW0~IW14");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("错误！只能为整数");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "WORD" && document.getElementById("Alter_DataItemType").value != "INT16") {
                    $("#Alter_DataItemTypeTip").html("IW开头的数据项地址只能为WORD或者INT16类型");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "ID") {
            if (coo == "English") {
                if (value < 0 || value > 12) {
                    $("#addressTipInfo").html("Error! For Siemens PPI series, the value of the DWORD type input mapping register must be between ID0 and ID12.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("Error! Value must be an integer.");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "DWORD" && document.getElementById("Alter_DataItemType").value != "INT32" && document.getElementById("Alter_DataItemType").value != "FLOAT") {
                    $("#Alter_DataItemTypeTip").html("Data item address starting with “ID” must be DWORD,INT32 or float type.");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0 || value > 12) {
                    $("#addressTipInfo").html("错误！西门子PPI系列中,DWORD类型的输入映像寄存器I范围为:ID0~ID12");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("错误！只能为整数");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "DWORD" && document.getElementById("Alter_DataItemType").value != "INT32" && document.getElementById("Alter_DataItemType").value != "FLOAT") {
                    $("#Alter_DataItemTypeTip").html("ID开头的数据项地址只能为DWORD,INT32或者float类型");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "Q") {
            if (coo == "English") {
                if (value < 0 || value > 15.7) {
                    $("#addressTipInfo").html("Error! For Siemens PPI Series, the value of the BIT type output mapping register Q must be between Q0.0 and Q15.7. There can be at most one digit after the decimal point, and the tenth digit can be no more than 7.");
                    return false;
                }
                if (numArray[1] != undefined && numArray[1].length > 1) {
                    $("#addressTipInfo").html("Error! There can be at most one digit after the decimal point, and the tenth digit can be no more than 7.");
                    return false;
                }
                if (numFloat > 7) {
                    $("#addressTipInfo").html("The tenth digit can be no more than 7.");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "BIT") {
                    $("#Alter_DataItemTypeTip").html("Data item address starting with “Q” must be Boolean type.");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0 || value > 15.7) {
                    $("#addressTipInfo").html("错误！西门子PPI系列中,BIT类型的输出映像寄存器Q范围为:Q0.0~Q15.7。如果有小数位，则只能有一位并且小数位最大为7");
                    return false;
                }
                if (numArray[1] != undefined && numArray[1].length > 1) {
                    $("#addressTipInfo").html("错误！只能带一个小数点，并且不大于7");
                    return false;
                }
                if (numFloat > 7) {
                    $("#addressTipInfo").html("小数位最大为7");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "BIT") {
                    $("#Alter_DataItemTypeTip").html("Q开头的数据项地址只能为Boolean类型");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "QB") {
            if (coo == "English") {
                if (value < 0 || value > 15) {
                    $("#addressTipInfo").html("Error! For Siemens PPI series, the value of the BIT type output mapping register Q must be between QB0 and QB15.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("Error! Value must be an integer.");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "BYTE" && document.getElementById("Alter_DataItemType").value != "INT8") {
                    $("#Alter_DataItemTypeTip").html("Data item address starting with “QB” must be BYTE or INT8 type.");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0 || value > 15) {
                    $("#addressTipInfo").html("错误！西门子PPI系列中,BIT类型的输出映像寄存器Q范围为:QB0~QB15");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("错误！只能为整数");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "BYTE" && document.getElementById("Alter_DataItemType").value != "INT8") {
                    $("#Alter_DataItemTypeTip").html("QB开头的数据项地址只能为BYTE或者INT8类型");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "QW") {
            if (coo == "English") {
                if (value < 0 || value > 14) {
                    $("#addressTipInfo").html("Error! For Siemens PPI series, the value of the WORD type output mapping register Q must be between QW0 and QW14.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("Error! Value must be an integer.");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "WORD" && document.getElementById("Alter_DataItemType").value != "INT16") {
                    $("#Alter_DataItemTypeTip").html("Data item address starting with “QW” must be Word or Int16 type.");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0 || value > 14) {
                    $("#addressTipInfo").html("错误！西门子PPI系列中,WORD类型的输出映像寄存器Q范围为:QW0~QW14");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("错误！只能为整数");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "WORD" && document.getElementById("Alter_DataItemType").value != "INT16") {
                    $("#Alter_DataItemTypeTip").html("QW开头的数据项地址只能为Word或者Int16类型");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "QD") {
            if (coo == "English") {
                if (value < 0 || value > 12) {
                    $("#addressTipInfo").html("Error! For Siemens PPI series, the value of the DWORD type output mapping register Q must be between QD0 and QD12.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("Error! Value must be an integer.");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "DWORD" && document.getElementById("Alter_DataItemType").value != "INT32" && document.getElementById("Alter_DataItemType").value != "FLOAT") {
                    $("#Alter_DataItemTypeTip").html("Data item address starting with “QD” must be DWord,Int32 or float type.");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0 || value > 12) {
                    $("#addressTipInfo").html("错误！西门子PPI系列中,DWORD类型的输出映像寄存器Q范围为:QD0~QD12");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("错误！只能为整数");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "DWORD" && document.getElementById("Alter_DataItemType").value != "INT32" && document.getElementById("Alter_DataItemType").value != "FLOAT") {
                    $("#Alter_DataItemTypeTip").html("QD开头的数据项地址只能为DWord,Int32或者float类型");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "V") {
            if (coo == "English") {
                if (value < 0.0 || value > 5119.7) {
                    $("#addressTipInfo").html("Error! For Siemens PPI series, the value of the BIT type memory variable V must be between V0.0 and V5119.7. There can be at most one digit after the decimal place, and the tenth digit can be no more than 7.");
                    return false;
                }
                if (numArray[1] != undefined && numArray[1].length > 1) {
                    $("#addressTipInfo").html("Error! There can be at most one digit after the decimal point, and the tenth digit can be no more than 7.");
                    return false;
                }
                if (numFloat > 7) {
                    $("#addressTipInfo").html("Error! The tenth digit can be no more than 7.");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "BIT") {
                    $("#Alter_DataItemTypeTip").html("Data item address starting with “V” must be Boolean type.");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0.0 || value > 5119.7) {
                    $("#addressTipInfo").html("错误！西门子PPI系列中,BIT类型的变量存储器V范围为:V0.0~V5119.7。如果有小数位，只能有一位并且小数位最大为7");
                    return false;
                }
                if (numArray[1] != undefined && numArray[1].length > 1) {
                    $("#addressTipInfo").html("错误！只能带一位小数，并且小数不大于7");
                    return false;
                }
                if (numFloat > 7) {
                    $("#addressTipInfo").html("错误！小数位最大为7");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "BIT") {
                    $("#Alter_DataItemTypeTip").html("V开头的数据项地址只能为Boolean类型");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "VB") {
            if (coo == "English") {
                if (value < 0 || value > 5119) {
                    $("#addressTipInfo").html("Error! For Siemens PPI series, the value of the BYTE type memory variable V must be between VB0 and VB5119.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("Error! Value must be an integer.");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "BYTE" && document.getElementById("Alter_DataItemType").value != "INT8") {
                    $("#Alter_DataItemTypeTip").html("Data item address starting with “VB” must be BYTE or INT8 type.");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0 || value > 5119) {
                    $("#addressTipInfo").html("错误！西门子PPI系列中,BYTE类型的变量存储器V范围为:VB0~VB5119");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("错误！只能为整数");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "BYTE" && document.getElementById("Alter_DataItemType").value != "INT8") {
                    $("#Alter_DataItemTypeTip").html("VB开头的数据项地址只能为BYTE或者INT8类型");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "VW") {
            if (coo == "English") {
                if (value < 0 || value > 5118) {
                    $("#addressTipInfo").html("Error! For Siemens PPI series, the value of the WORD type memory variable V must be between VW0 and VW5118.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("Error! Value must be an integer.");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "WORD" && document.getElementById("Alter_DataItemType").value != "INT16") {
                    $("#Alter_DataItemTypeTip").html("Data item address starting with “VW” must be Word or Int16 type.");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0 || value > 5118) {
                    $("#addressTipInfo").html("错误！西门子PPI系列中,WORD类型的变量存储器V范围为:VW0~VW5118");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("错误！只能为整数");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "WORD" && document.getElementById("Alter_DataItemType").value != "INT16") {
                    $("#Alter_DataItemTypeTip").html("VW开头的数据项地址只能为Word或者Int16类型");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "VD") {
            if (coo == "English") {
                if (value < 0 || value > 5116) {
                    $("#addressTipInfo").html("Error! For Siemens PPI series, the value of the DWORD type memory variable V must be between VD0 and VD5116.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("Error! Value must be an integer.");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "DWORD" && document.getElementById("Alter_DataItemType").value != "INT32" && document.getElementById("Alter_DataItemType").value != "FLOAT") {
                    $("#Alter_DataItemTypeTip").html("Data item address starting with “VD” must be DWord,Int32 or float type.");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0 || value > 5116) {
                    $("#addressTipInfo").html("错误！西门子PPI系列中,DWORD类型的变量存储器V范围为:VD0~VD5116");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("错误！只能为整数");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "DWORD" && document.getElementById("Alter_DataItemType").value != "INT32" && document.getElementById("Alter_DataItemType").value != "FLOAT") {
                    $("#Alter_DataItemTypeTip").html("VD开头的数据项地址只能为DWord,Int32或者float类型");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "M") {
            if (coo == "English") {
                if (value < 0.0 || value > 31.7) {
                    $("#addressTipInfo").html("Error! For Siemens PPI series, the value of the BIT type memory variable M must be between M0.0 and M31.7. There can be at most one digit after the decimal place, and the tenth digit can be no more than 7.");
                    return false;
                }
                if (numArray[1] != undefined && numArray[1].length > 1) {
                    $("#addressTipInfo").html("Error! There can be at most one digit after the decimal point, and the tenth digit can be no more than 7.");
                    return false;
                }
                if (numFloat > 7) {
                    $("#addressTipInfo").html("Error! The tenth digit can be no more than 7.");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "BIT") {
                    $("#Alter_DataItemTypeTip").html("Data item address starting with “M” must be Boolean type.");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0.0 || value > 31.7) {
                    $("#addressTipInfo").html("错误！西门子PPI系列中,BIT类型的位存储器M范围为:M0.0~M31.7。如果有小数位，只能有一位并且小数位最大为7");
                    return false;
                }
                if (numArray[1] != undefined && numArray[1].length > 1) {
                    $("#addressTipInfo").html("错误！只能带一位小数，并且小数不大于7");
                    return false;
                }
                if (numFloat > 7) {
                    $("#addressTipInfo").html("错误！小数位最大为7");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "BIT") {
                    $("#Alter_DataItemTypeTip").html("M开头的数据项地址只能为Boolean类型");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "MB") {
            if (coo == "English") {
                if (value < 0 || value > 31) {
                    $("#addressTipInfo").html("Error! For Siemens PPI series, the value of the BYTE type memory variable M must be between MB0 and MB31.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("Error! Value must be an integer.");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "BYTE" && document.getElementById("Alter_DataItemType").value != "INT8") {
                    $("#Alter_DataItemTypeTip").html("Data item address starting with “MB” must be BYTE or INT8 type.");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0 || value > 31) {
                    $("#addressTipInfo").html("错误！西门子PPI系列中,BYTE类型的位存储器M范围为:MB0~MB31");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("错误！只能为整数");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "BYTE" && document.getElementById("Alter_DataItemType").value != "INT8") {
                    $("#Alter_DataItemTypeTip").html("MB开头的数据项地址只能为BYTE或者INT8类型");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "MW") {
            if (coo == "English") {
                if (value < 0 || value > 30) {
                    $("#addressTipInfo").html("Error! For Siemens PPI series, the value of the WORD type memory variable M must be between MW0 and MW30.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("Error! Value must be an integer.");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "WORD" && document.getElementById("Alter_DataItemType").value != "INT16") {
                    $("#Alter_DataItemTypeTip").html("Data item address starting with “MW” must be Word or Int16 type.");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0 || value > 30) {
                    $("#addressTipInfo").html("错误！西门子PPI系列中,WORD类型的位存储器M范围为:MW0~MW30");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("错误！只能为整数");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "WORD" && document.getElementById("Alter_DataItemType").value != "INT16") {
                    $("#Alter_DataItemTypeTip").html("MW开头的数据项地址只能为Word或者Int16类型");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "MD") {
            if (coo == "English") {
                if (value < 0 || value > 28) {
                    $("#addressTipInfo").html("Error! For Siemens PPI series, the value of the DWORD type memory variable M must be between MD0 and MD28.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("Error! Value must be an integer.");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "DWORD" && document.getElementById("Alter_DataItemType").value != "INT32" && document.getElementById("Alter_DataItemType").value != "FLOAT") {
                    $("#Alter_DataItemTypeTip").html("Data item address starting with “MD” must be DWord,Int32 or float type.");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0 || value > 28) {
                    $("#addressTipInfo").html("错误！西门子PPI系列中,DWORD类型的位存储器M范围为:MD0~MD28");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("错误！只能为整数");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "DWORD" && document.getElementById("Alter_DataItemType").value != "INT32" && document.getElementById("Alter_DataItemType").value != "FLOAT") {
                    $("#Alter_DataItemTypeTip").html("MD开头的数据项地址只能为DWord,Int32或者float类型");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "S") {
            if (coo == "English") {
                if (value < 0.0 || value > 31.7) {
                    $("#addressTipInfo").html("Error! For Siemens PPI series, the value of the the BIT type sequence control relay (SCR) S must be between S0.0 and S31.7. There can be at most one digit after the decimal place, and the tenth digit can be no more than 7.");
                    return false;
                }
                if (numArray[1] != undefined && numArray[1].length > 1) {
                    $("#addressTipInfo").html("Error! There can be at most one digit after the decimal point, and the tenth digit can be no more than 7.");
                    return false;
                }
                if (numFloat > 7) {
                    $("#addressTipInfo").html("Error! The tenth digit can be no more than 7.");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "BIT") {
                    $("#Alter_DataItemTypeTip").html("Data item address starting with “S” must be Boolean type.");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0.0 || value > 31.7) {
                    $("#addressTipInfo").html("错误！西门子PPI系列中,BIT类型的顺序控制继电器S范围为:S0.0~S31.7。如果有小数位，只能有一位并且小数位最大为7");
                    return false;
                }
                if (numArray[1] != undefined && numArray[1].length > 1) {
                    $("#addressTipInfo").html("错误！只能带一位小数，并且小数不大于7");
                    return false;
                }
                if (numFloat > 7) {
                    $("#addressTipInfo").html("错误！小数位最大为7");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "BIT") {
                    $("#Alter_DataItemTypeTip").html("S开头的数据项地址只能为Boolean类型");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "SB") {
            if (coo == "English") {
                if (value < 0.0 || value > 31) {
                    $("#addressTipInfo").html("Error! For Siemens PPI series, the value of the the BYTE type sequence control relay (SCR) S must be between SB0 and SB31.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("Error! Value must be an integer.");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "BYTE" && document.getElementById("Alter_DataItemType").value != "INT8") {
                    $("#Alter_DataItemTypeTip").html("Data item address starting with “SB” must be BYTE or INT8 type.");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0.0 || value > 31) {
                    $("#addressTipInfo").html("错误！西门子PPI系列中,BYTE类型的顺序控制继电器S范围为:SB0~SB31");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("错误！只能是整数");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "BYTE" && document.getElementById("Alter_DataItemType").value != "INT8") {
                    $("#Alter_DataItemTypeTip").html("SB开头的数据项地址只能为BYTE或者INT8类型");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "SW") {
            if (coo == "English") {
                if (value < 0.0 || value > 30) {
                    $("#addressTipInfo").html("Error! For Siemens PPI series, the value of the the WORD type sequence control relay (SCR) S must be between SW0 and SW30.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("Error! Value must be an integer.");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "WORD" && document.getElementById("Alter_DataItemType").value != "INT16") {
                    $("#Alter_DataItemTypeTip").html("Data item address starting with “SW” must be Word or Int16 type.");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0.0 || value > 30) {
                    $("#addressTipInfo").html("错误！西门子PPI系列中,WORD类型的顺序控制继电器S范围为:SW0~SW30");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("错误！只能是整数");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "WORD" && document.getElementById("Alter_DataItemType").value != "INT16") {
                    $("#Alter_DataItemTypeTip").html("SW开头的数据项地址只能为Word或者Int16类型");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "SD") {
            if (coo == "English") {
                if (value < 0.0 || value > 28) {
                    $("#addressTipInfo").html("Error! For Siemens PPI series, the value of the the WORD type sequence control relay (SCR) S must be between SW0 and SW30.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("Error! Value must be an integer.");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "DWORD" && document.getElementById("Alter_DataItemType").value != "INT32" && document.getElementById("Alter_DataItemType").value != "FLOAT") {
                    $("#Alter_DataItemTypeTip").html("Data item address starting with “SD” must be DWord,Int32 or float type.");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0.0 || value > 28) {
                    $("#addressTipInfo").html("错误！西门子PPI系列中,DWORD类型的顺序控制继电器S范围为:SD0~SD28");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("错误！只能是整数");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "DWORD" && document.getElementById("Alter_DataItemType").value != "INT32" && document.getElementById("Alter_DataItemType").value != "FLOAT") {
                    $("#Alter_DataItemTypeTip").html("SD开头的数据项地址只能为DWord,Int32或者float类型");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "SM") {
            if (coo == "English") {
                if (value < 0.0 || value > 179.7) {
                    $("#addressTipInfo").html("Error! For Siemens PPI series, the value of BIT type special memory SM must be between SM0.0 and SM 179.7. There can be at most one digit after the decimal place, and the tenth digit can be no more than 7.");
                    return false;
                }
                if (numArray[1] != undefined && numArray[1].length > 1) {
                    $("#addressTipInfo").html("Error! There can be at most one digit after the decimal point, and the tenth digit can be no more than 7.");
                    return false;
                }
                if (numFloat > 7) {
                    $("#addressTipInfo").html("Error! The tenth digit can be no more than 7.");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "BIT") {
                    $("#Alter_DataItemTypeTip").html("Data item address starting with “SM” must be Boolean type.");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0.0 || value > 179.7) {
                    $("#addressTipInfo").html("错误！西门子PPI系列中,BIT类型的特殊存储器SM范围为:SM0.0~SM179.7。如果有小数位，只能有一位并且小数位最大为7");
                    return false;
                }
                if (numArray[1] != undefined && numArray[1].length > 1) {
                    $("#addressTipInfo").html("错误！只能带一位小数，并且小数不大于7");
                    return false;
                }
                if (numFloat > 7) {
                    $("#addressTipInfo").html("错误！小数位最大为7");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "BIT") {
                    $("#Alter_DataItemTypeTip").html("SM开头的数据项地址只能为Boolean类型");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "SMB") {
            if (coo == "English") {
                if (value < 0 || value > 179) {
                    $("#addressTipInfo").html("Error! For Siemens PPI series, the value of BYTE type special memory SM must be between SMB0 and SMB179.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("Error! Value must be an integer.");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "BYTE" && document.getElementById("Alter_DataItemType").value != "INT8") {
                    $("#Alter_DataItemTypeTip").html("Data item address starting with “SMB” must be BYTE or INT8 type.");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0 || value > 179) {
                    $("#addressTipInfo").html("错误！西门子PPI系列中,BYTE类型的特殊存储器SM范围为:SMB0~SMB179");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("错误！只能是整数");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "BYTE" && document.getElementById("Alter_DataItemType").value != "INT8") {
                    $("#Alter_DataItemTypeTip").html("SMB开头的数据项地址只能为BYTE或者INT8类型");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "SMW") {
            if (coo == "English") {
                if (value < 0 || value > 178) {
                    $("#addressTipInfo").html("Error! For Siemens PPI series, the value of WORD type special memory SM must be between SMW0 and SMW178.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("Error! Value must be an integer.");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "WORD" && document.getElementById("Alter_DataItemType").value != "INT16") {
                    $("#Alter_DataItemTypeTip").html("Data item address starting with “SMW” must be Word or Int16 type.");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0 || value > 178) {
                    $("#addressTipInfo").html("错误！西门子PPI系列中,WORD类型的特殊存储器SM范围为:SMW0~SMW178");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("错误！只能是整数");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "WORD" && document.getElementById("Alter_DataItemType").value != "INT16") {
                    $("#Alter_DataItemTypeTip").html("SMW开头的数据项地址只能为Word或者Int16类型");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "SMD") {
            if (coo == "English") {
                if (value < 0 || value > 176) {
                    $("#addressTipInfo").html("Error! For Siemens PPI series, the value of DWORD type special memory SM must be between SMD0 and SMD176.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("Error! Value must be an integer.");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "DWORD" && document.getElementById("Alter_DataItemType").value != "INT32" && document.getElementById("Alter_DataItemType").value != "FLOAT") {
                    $("#Alter_DataItemTypeTip").html("Data item address starting with “SMD” must be DWord,Int32 or float type.");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0 || value > 176) {
                    $("#addressTipInfo").html("错误！西门子PPI系列中,DWORD类型的特殊存储器SM范围为:SMD0~SMD176");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("错误！只能是整数");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "DWORD" && document.getElementById("Alter_DataItemType").value != "INT32" && document.getElementById("Alter_DataItemType").value != "FLOAT") {
                    $("#Alter_DataItemTypeTip").html("SMD开头的数据项地址只能为DWord,Int32或者float类型");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "T") {
            if (coo == "English") {
                if (value < 0 || value > 255) {
                    $("#addressTipInfo").html("Error! For Siemens PPI series, the value of timer T must be between T0 and T255.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("Error! Value must be an integer.");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "BIT") {
                    $("#Alter_DataItemTypeTip").html("Data item address starting with “T” must be Boolean type.");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0 || value > 255) {
                    $("#addressTipInfo").html("错误！西门子PPI系列中,定时器T范围为:T0~T255");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("错误！只能是整数");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "BIT") {
                    $("#Alter_DataItemTypeTip").html("T开头的数据项地址只能为Boolean类型");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "C") {
            if (coo == "English") {
                if (value < 0 || value > 255) {
                    $("#addressTipInfo").html("Error! For Siemens PPI series, the value of counter C must be between C0 and C255.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("Error! Value must be an integer.");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "BIT") {
                    $("#Alter_DataItemTypeTip").html("Data item address starting with “C” must be Boolean type.");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0 || value > 255) {
                    $("#addressTipInfo").html("错误！西门子PPI系列中,计数器C范围为:C0~C255");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("错误！只能是整数");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "BIT") {
                    $("#Alter_DataItemTypeTip").html("C开头的数据项地址只能为Boolean类型");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "AIW") {
            if (coo == "English") {
                if (value < 0 || value > 30) {
                    $("#addressTipInfo").html("Error! For Siemens PPI series, the value of analog input AI must be between AIW0 and AIW30.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("Error! Value must be an integer.");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "WORD" && document.getElementById("Alter_DataItemType").value != "INT16") {
                    $("#Alter_DataItemTypeTip").html("Data item address starting with “AIW” must be Word or Int16 type.");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0 || value > 30) {
                    $("#addressTipInfo").html("错误！西门子PPI系列中,模拟输入AI范围为:AIW0~AIW30");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("错误！只能是整数");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "WORD" && document.getElementById("Alter_DataItemType").value != "INT16") {
                    $("#Alter_DataItemTypeTip").html("AIW开头的数据项地址只能为Word或者Int16类型");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            
        } else if (letter == "AQW") {
            if (coo == "English") {
                if (value < 0 || value > 30) {
                    $("#addressTipInfo").html("Error! For Siemens PPI series, the value of analog output AQ must be between AQW0 and AQW30.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("Error! Value must be an integer.");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "WORD" && document.getElementById("Alter_DataItemType").value != "INT16") {
                    $("#Alter_DataItemTypeTip").html("Data item address starting with “AQW” must be Word or Int16 type.");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            else {
                if (value < 0 || value > 30) {
                    $("#addressTipInfo").html("错误！西门子PPI系列中,模拟输出AQ范围为:AQW0~AQW30");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("错误！只能是整数");
                    return false;
                }
                if (document.getElementById("Alter_DataItemType").value != "WORD" && document.getElementById("Alter_DataItemType").value != "INT16") {
                    $("#Alter_DataItemTypeTip").html("AQW开头的数据项地址只能为Word或者Int16类型");
                    return false;
                } else {
                    $("#Alter_DataItemTypeTip").html("");
                }
            }
            
        } else {
            if (coo == "English") {
                $("#addressTipInfo").html("Can’t find a data item address starting with" + letter + "for Siemens PPI series.");
            }
            else {
                $("#addressTipInfo").html("西门子PPI系列不存在以" + letter + "字母开头的数据项地址");
            }
            return false;
        }
        return true;
    }
    //三菱FX系列
    else if (category == "MITSUBISHI-FX") {
        if (coo == "English") {
            if (letter == "X") {
                if (value < 0 || value > 377) {
                    $("#addressTipInfo").html("Error! For Mitsubishi series, the value of the input relay X must be between X0 and X377 (X followed by an octal number).");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("Error! Value must be an integer.");
                    return false;
                }
                document.getElementById("Alter_DataItemType").value = "BIT";
            } else if (letter == "Y") {
                if (value < 0 || value > 377) {
                    $("#addressTipInfo").html("Error! For Mitsubishi series, the value of the output relay Y must be between Y0 and Y377 (Y followed by an octal number).");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("Error! Value must be an integer.");
                    return false;
                }
                document.getElementById("Alter_DataItemType").value = "BIT";
            } else if (letter == "M") {
                if (value < 0 || value > 3071) {
                    $("#addressTipInfo").html("Error! For Mitsubishi series, the value of the auxiliary relay M must be between M0 and M3071.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("Error! Value must be an integer.");
                    return false;
                }
                document.getElementById("Alter_DataItemType").value = "BIT";
            } else if (letter == "S") {
                if (value < 0 || value > 999) {
                    $("#addressTipInfo").html("Error! For Mitsubishi series, the value of the state relay S must be between S0 and S999.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("Error! Value must be an integer.");
                    return false;
                }
                document.getElementById("Alter_DataItemType").value = "BIT";
            } else if (letter == "T") {
                if (value < 0 || value > 255) {
                    $("#addressTipInfo").html("Error! For Mitsubishi series, the value of timer T must be between T0 and T255.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("Error! Value must be an integer.");
                    return false;
                }
            } else if (letter == "C") {
                if (value < 0 || value > 255) {
                    $("#addressTipInfo").html("Error! For Mitsubishi series, the value of counter C must be between C0 and C255.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("Error! Value must be an integer.");
                    return false;
                }
            } else if (letter == "D") {
                if (value < 0 || value > 8255) {
                    $("#addressTipInfo").html("Error! For Mitsubishi series, the value of data register D must be between D0 and D8255.");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("Error! Value must be an integer.");
                    return false;
                }
            }
        }
        else {
            if (letter == "X") {
                if (value < 0 || value > 377) {
                    $("#addressTipInfo").html("错误！三菱FX系列中,输入继电器X范围为:X0~X377(八进制)");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("错误！只能是整数");
                    return false;
                }
                document.getElementById("Alter_DataItemType").value = "BIT";
            } else if (letter == "Y") {
                if (value < 0 || value > 377) {
                    $("#addressTipInfo").html("错误！三菱FX系列中,输出继电器Y范围为:Y0~Y377(八进制)");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("错误！只能是整数");
                    return false;
                }
                document.getElementById("Alter_DataItemType").value = "BIT";
            } else if (letter == "M") {
                if (value < 0 || value > 3071) {
                    $("#addressTipInfo").html("错误！三菱FX系列中,辅助继电器M范围为:M0~M3071");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("错误！只能是整数");
                    return false;
                }
                document.getElementById("Alter_DataItemType").value = "BIT";
            } else if (letter == "S") {
                if (value < 0 || value > 999) {
                    $("#addressTipInfo").html("错误！三菱FX系列中,状态继电器S范围为:S0~S999");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("错误！只能是整数");
                    return false;
                }
                document.getElementById("Alter_DataItemType").value = "BIT";
            } else if (letter == "T") {
                if (value < 0 || value > 255) {
                    $("#addressTipInfo").html("错误！三菱FX系列中,定时器T范围为:T0~T255");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("错误！只能是整数");
                    return false;
                }
            } else if (letter == "C") {
                if (value < 0 || value > 255) {
                    $("#addressTipInfo").html("错误！三菱FX系列中,计数器C范围为:C0~C255");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("错误！只能是整数");
                    return false;
                }
            } else if (letter == "D") {
                if (value < 0 || value > 8255) {
                    $("#addressTipInfo").html("错误！三菱FX系列中,数据寄存器D范围为:D0~D8255");
                    return false;
                }
                if (numArray[1] != undefined) {
                    $("#addressTipInfo").html("错误！只能是整数");
                    return false;
                }
            }
        }  
    }
    //欧姆龙HostLinkX系列
    else if (category == "OMRON-HostLink") {

    }

}