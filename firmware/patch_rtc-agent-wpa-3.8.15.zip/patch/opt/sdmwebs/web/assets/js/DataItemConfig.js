document.writeln(
  '<script src="assets/js/effect_Com.js?t=' +
    new Date().getTime() +
    '" type="text/javascript" charset="utf-8" defer="defer"></script>'
);
document.writeln(
  "<" +
    "script language='javascript' src='assets/js/language.js?t=" +
    new Date().getTime() +
    "'></" +
    "script>"
);

CheckLogin();
$.ajaxSetup({
  cache: false,
});
//全局变量
var diffCol = 1000000000000;
var EditChange = 100000000000000;
//通道ID
var ChannelID = "";
//设备ID
var DeviceID = "";
//驱动ID
var DriverID = "";
//校验所需要的
var category = "";
//数据项总数
var DataItemNum = "";
//设备驱动类型
var ChannelDriver = "";
//设备的驱动类型
var ChannelDeviceType = "";
var ZundarConfig = "";
var coo = "";
var modeln = "";
//OPC-UA驱动所需标志位
var UA1 = 0;
var UA2 = 0;
//三菱重工海尔TX_15P模块数据与地址对应关系
var TX15PMap = {};
//三菱重工海尔TX_5HP模块数据与地址对应关系
var TX5HPMap = {};
//三菱重工海尔一拖三模块数据与地址对应关系
var TXMultiMap = {};

//根据传值获取通道ID和设备ID
function initUI() {
  //传值
  var string = decodeURIComponent(document.location.search).substr(1);
  var logArr = new Array();
  logArr = string.split("=");
  ChannelID = string.split("&")[0].split("=")[1];
  DeviceID = string.split("&")[1].split("=")[1];
  StationNum = string.split("&")[2].split("=")[1];
}

//根据value查找对应的key
function findKey(obj, value) {
  var compare =
    arguments.length > 2 && arguments[2] !== undefined
      ? arguments[2]
      : function (a, b) {
          return a === b;
        };
  return Object.keys(obj).find(function (k) {
    return compare(obj[k], value);
  });
}

//点击切告警和数据项
$("#dataTab").click(function () {
  window.location.href =
    "../DataItemConfig.html?channelid=" +
    ChannelID +
    "&deviceid=" +
    DeviceID +
    "&t=" +
    new Date().getTime();
});
$("#rulesTab").click(function () {
  window.location.href =
    "../Alarm.html?channelid=" +
    ChannelID +
    "&deviceid=" +
    DeviceID +
    "&t=" +
    new Date().getTime();
});
$("#computeTab").click(function () {
  window.location.href =
    "../ConditionalUpload.html?channelid=" +
    ChannelID +
    "&deviceid=" +
    DeviceID +
    "&t=" +
    new Date().getTime();
});

$(document).ready(function () {
  initUI();
  getID();
  getData();
  coo = getCookie("AnyLinkLan");
  if (coo == "English") {
    $(".AutoRefresh").css("left", "289px");
    $("#computeTab").css("width", "100px");
    if (ChannelDeviceType == "DRACAL") {
      $("#word42").html("Channel");
    }
  } else {
    $("#computeTab").css("width", "60px");
    $(".AutoRefresh").css("left", "77px");
    if (ChannelDeviceType == "DRACAL") {
      $("#word42").html("通道");
    }
  }

  $("#Add_TX_config").bind("input", function (e) {
    var $input = $(e.target),
      $options = $("#TXConfig option"),
      $hiddenInput = $("#Add_TX_config-hidden"),
      label = $input.val();
    $hiddenInput.val("error");
    for (var i = 0; i < $options.length; i++) {
      var $option = $options.eq(i);
      if ($option.text() === label) {
        $hiddenInput.val($option.attr("data-value"));
        break;
      }
    }
  });

  $("#Alter_TX_config").bind("input", function (e) {
    var $input = $(e.target),
      $options = $("#TXConfig2 option"),
      $hiddenInput = $("#Alter_TX_config-hidden"),
      label = $input.val();
    $hiddenInput.val("error");
    for (var i = 0; i < $options.length; i++) {
      var $option = $options.eq(i);
      if ($option.text() === label) {
        $hiddenInput.val($option.attr("data-value"));
        break;
      }
    }
  });
});
//根据通道ID、设备ID读数据项
function getData() {
  getID();
  document.getElementById("dataItemType").style.display = "";
  $("#allItemName").empty();
  DataItemNum = 0;
  $("#DataItemNum").empty();
  $("#info").empty();
  $("#itemTable tr").empty("");
  $("#itemTable  tr").css("display", "none");
  $.ajaxSettings.async = false;
  $.get("../conf/config.xml", function (d1) {
    $(d1)
      .find("model[id='" + ChannelID + "']")
      .each(function () {
        var $model = $(this);
        var modelid = $model.attr("id");
        modeln = $model.attr("n");
        var modeld = $model.attr("d");
        ChannelDriver = $model.attr("d");
        ChannelDeviceType = $model.attr("devicedriver");
        if (ChannelDeviceType == "YinHe") {
          document.getElementById("dataItemType").style.display = "none";
        }
        if (ChannelDeviceType == "Zundar") {
          document.getElementById("dataItemType").style.display = "none";
          document.getElementById("DataItemAddress").style.display = "none";
        }
        //    add by lh, IEC104
        if (ChannelDeviceType == "IEC104") {
          document.getElementById("DataItemAddress").style.display = "none";
          $("#Add_Line_DataItemAddress").hide();
          $("#aliasNameCol").css("width", "100px");
        }
        if (ChannelDeviceType == "device") {
          $("#aliasNameCol").css("width", "80px");
        }
        // if (ChannelDeviceType == "OPC") {
        //     document.getElementById("aliasNameCol").style.display = "none";
        // }
        if (ChannelDeviceType == "HKG-SERIAL") {
          $("#word42").html("ID");
        }
        if (ChannelDeviceType == "OMRON_NJNX") {
          if (coo == "English") {
            $("#word42").html("Name of the data points");
          } else {
            $("#word42").html("数据点名称");
          }
        }
        // add by whc
        if (ChannelDeviceType == "DRACAL") {
          if (coo == "English") {
            $("#word42").html("Channel");
          } else {
            $("#word42").html("通道");
          }
        }
        // add end
        // add begin by x
        // gps 数据项是只能修改采集频率
        if (ChannelDeviceType == "GPS") {
          $("#Add_Line_DataItemAddress2").show();
          $("#Add_Line_DataItemAddress").hide();
          $("#Add_Line_DataItemType").hide();
          $("#word22").parent().parent().parent().hide();
          $("#word25").parent().parent().parent().hide();
          $("#Alter_DataItem_Layer").css("min-height", "400px");
          $("#Add_DataItem_Layer").css("min-height", "400px");
        }
        // end add
        // add by fyj, 增加DLT645-2007
        if (
          ChannelDeviceType == "DLT645-2007" ||
          ChannelDeviceType == "DLT645-1997"
        ) {
          if (coo == "English") {
            $("#word42").text("Data address");
          } else {
            $("#word42").text("数据地址");
          }
        }
        if (ChannelDeviceType == "OPC-UA") {
          $("#word42").text("NodeID");
          // $('#aliasNameCol').css('width','60px');
          // $('#DataItemAddress').css('width','140px');
          // $('#freqCol').css('width','60px');
        }
        if (ChannelDeviceType == "MITSUBISHI-TX-15P") {
          $.get("conf/MITSUBISHI-TX-15P.json", function (mapping) {
            TX15PMap = JSON.parse(mapping);
          });
        }
        if (ChannelDeviceType == "MITSUBISHI-TX-5HP") {
          $.get("conf/MITSUBISHI-TX-5HP.json", function (mapping) {
            TX5HPMap = JSON.parse(mapping);
          });
        }
        if (ChannelDeviceType == "MITSUBISHI-TX-Multi-link") {
          $.get("conf/MITSUBISHI-TX-Multi-link.json", function (mapping) {
            TXMultiMap = JSON.parse(mapping);
          });
        }
        $("#ChannelName").html(modeln);
        $("#ChannelName").attr("title", modeln);
        $model.find("device[id='" + DeviceID + "']").each(function () {
          var $device = $(this);
          var deviceid = $device.attr("id");
          var deviceip = $device.attr("ip");
          var devicen = $device.attr("n");
          var type = $device.attr("type");
          var driverId = "";
          $device.find("driver").each(function () {
            var $driver = $(this);
            var config = $driver.attr("config");
            driverId = $driver.attr("id");
            var configArr = new Array();
            configArr = config.split(";");
            category = configArr[0];
          });
          $("#DeviceName").html(devicen);
          $("#DeviceName").attr("title", devicen);
          $device.find("commDataItems").each(function () {
            var $commDataItems = $(this);
            $commDataItems.find("dataItem").each(function () {
              var $dataItem = $(this);
              var dataItemN = $dataItem.attr("n");
              var dataItemA = $dataItem.attr("alias");
              var dataItemID = $dataItem.attr("id");
              var dataItemChannel = $dataItem.attr("config");
              var dataItemFreq = $dataItem.attr("freq");
              var dataItemReport1 = $dataItem.attr("report");
              var dataItemWR1 = $dataItem.attr("rw");
              var dataItemType_wang = $dataItem.attr("type");
              var dataItemReport = "";
              if (coo == "English") {
                if (dataItemReport1 == "0") {
                  dataItemReport = "Not report"
              } else if ( dataItemReport1 == "2") {
                  dataItemReport = "change report"
              } else {
                  dataItemReport = "Report"
              }
              } else {
                if (dataItemReport1 == "0") {
                  dataItemReport = "不上传"
              }  else if ( dataItemReport1 == "2") {
                  dataItemReport = "变化上传"
              } else {
                  dataItemReport = "全部上传"
              }
              }
              var dataItemConfig = $dataItem.attr("config");
              var ConfigArr = new Array();
              ConfigArr = dataItemConfig.split(";");
              var dataItemAdd = "";

              //var dataItemAdd = ConfigArr[0] + ConfigArr[2];]
              if (
                ChannelDeviceType == "MITSUBISHI-QS" ||
                ChannelDeviceType == "MITSUBISHI-QN"
              ) {
                dataItemAdd = ConfigArr[0];
                var dataItemType1 = ConfigArr[1];
                // add by whc
              } else if (ChannelDeviceType == "FATEK编程口") {
                dataItemAdd = ConfigArr[1];
                dataItemType1 = ConfigArr[0];
                // add end
              }
              // add by fyj, OMRON-HostLink-Task
              else if (
                ChannelDeviceType == "OMRON-HostLink-Task" ||
                ChannelDeviceType == "OMRON-FINS-Task"
              ) {
                dataItemAdd = ConfigArr[0];
                dataItemType1 = ConfigArr[1];
              }
              // add end
              // add by lh, IEC104
              else if (ChannelDeviceType == "IEC104") {
                var IECattr1 = ConfigArr[0];
                var IECattr2 = ConfigArr[1];
              }
              // add end
              // add by whc
              else if (ChannelDeviceType == "SIEMENS-S7-PPI-Task") {
                dataItemAdd = ConfigArr[0];
                var dataItemType1 = ConfigArr[1];
                // add end
              } else if (ChannelDeviceType == "AB-DF1") {
                //AB-DF1时候的config解析
                dataItemAdd = ConfigArr[0];
                var dataItemType1 = ConfigArr[1];
              } else if (
                ChannelDeviceType == "YinHe" ||
                ChannelDeviceType == "OMRON_NJNX" ||
                ChannelDeviceType == "HKG-SERIAL" ||
                ChannelDeviceType == "OPC-UA"
              ) {
                dataItemAdd = ConfigArr[0];
              } else if (ChannelDeviceType == "Custom-TCP") {
                dataItemAdd = dataItemConfig;
              } else if (ChannelDeviceType == "OPC") {
                dataItemAdd = ConfigArr[1];
              } else if (ChannelDeviceType == "MITSUBISHI-TXZ-MomMach" || ChannelDeviceType == "MITSUBISHI-TXZ-SubMach1" || ChannelDeviceType == "MITSUBISHI-TXZ-SubMach2") {
                dataItemAdd = ConfigArr[2];
              } else if (ChannelDeviceType == "MITSUBISHI-TX-15P") {
                dataItemAdd = findKey(TX15PMap, dataItemConfig);
              } else if (ChannelDeviceType == "MITSUBISHI-TX-5HP") {
                dataItemAdd = findKey(TX5HPMap, dataItemConfig);
              } else if (ChannelDeviceType == "MITSUBISHI-TX-Multi-link") {
                dataItemAdd = findKey(TXMultiMap, dataItemConfig);
              } else if (ChannelDeviceType == "R1R2") {
                dataItemAdd =ConfigArr[0]  ;
              }  else {
                if (
                  ChannelDeviceType == "MITSUBISHI-FX" &&
                  (ConfigArr[0] == "X" || ConfigArr[0] == "Y")
                )
                  dataItemAdd = ConfigArr[0] + Number(ConfigArr[2]).toString(8);
                else dataItemAdd = ConfigArr[0] + ConfigArr[2];
                var dataItemType1 = ConfigArr[1];
              }

              if (
                ChannelDeviceType != "YinHe" &&
                ChannelDeviceType != "Zundar" &&
                ChannelDeviceType != "OMRON_NJNX" &&
                ChannelDeviceType != "HKG-SERIAL" &&
                ChannelDeviceType != "Custom-TCP" &&
                ChannelDeviceType != "GPS" &&
                ChannelDeviceType != "JB3102" &&
                ChannelDeviceType != "JB3208" &&
                ChannelDeviceType != "KUKA" &&
                ChannelDeviceType != "DLT645-2007" &&
                ChannelDeviceType != "DLT645-1997" &&
                ChannelDeviceType != "OPC" &&
                ChannelDeviceType != "OPC-UA" &&
                ChannelDeviceType != "IEC104" &&
                ChannelDeviceType != "device" &&
                ChannelDeviceType != "MITSUBISHI-TXZ-MomMach" &&
                ChannelDeviceType != "MITSUBISHI-TXZ-SubMach1" &&
                ChannelDeviceType != "MITSUBISHI-TXZ-SubMach2" &&
                ChannelDeviceType != "MITSUBISHI-TX-15P" &&
                ChannelDeviceType != "MITSUBISHI-TX-5HP" &&
                ChannelDeviceType != "MITSUBISHI-TX-Multi-link" &&
                ChannelDeviceType != "R1R2" &&
                ChannelDeviceType != "DRACAL"
              ) {
                var dataItemWR = "";
                var dataItemType = "";
                if (dataItemType1 == "BIT") {
                  dataItemType = "Boolean";
                } else if (dataItemType1 == "BYTE") {
                  dataItemType = "Byte";
                } else if (dataItemType1 == "WORD") {
                  dataItemType = "Word";
                } else if (dataItemType1 == "SHORT") {
                  dataItemType = "Short";
                } else if (dataItemType1 == "DWORD") {
                  dataItemType = "DWord";
                } else if (dataItemType1 == "LONG") {
                  dataItemType = "Long";
                } else if (dataItemType1 == "FLOAT") {
                  dataItemType = "Float";
                } else if (dataItemType1.indexOf("STRING") != -1) {
                  dataItemType = "String";
                } else if (dataItemType1 == "INT8") {
                  dataItemType = "Int 8";
                } else if (dataItemType1 == "INT16") {
                  dataItemType = "Int 16";
                } else if (dataItemType1 == "INT32") {
                  dataItemType = "Int 32";
                } else {
                  // modifed by fyj
                  // begin
                  dataItemType = dataItemType1;
                }
                //end
              }

              // add by whc,SIEMENS-S7-PPI-Task驱动数据类型
              if (ChannelDeviceType == "SIEMENS-S7-PPI-Task") {
                var dataItemType = "";
                if (dataItemType1 == "BIT") {
                  dataItemType = "Bit";
                } else if (dataItemType1 == "INT8") {
                  dataItemType = "Int8";
                } else if (dataItemType1 == "UINT8") {
                  dataItemType = "UInt8";
                } else if (dataItemType1 == "INT16") {
                  dataItemType = "Int16";
                } else if (dataItemType1 == "UINT16") {
                  dataItemType = "UInt16";
                } else if (dataItemType1 == "INT32") {
                  dataItemType = "Int32";
                } else if (dataItemType1 == "UINT32") {
                  dataItemType = "UInt32";
                } else if (dataItemType1 == "FLOAT") {
                  dataItemType = "Float";
                } else if (dataItemType1 == "BCD") {
                  dataItemType = "BCD";
                } else {
                  dataItemType = dataItemType1;
                }
              }
              // add end
              if (
                ChannelDeviceType == "OMRON_NJNX" ||
                ChannelDeviceType == "HKG-SERIAL" ||
                ChannelDeviceType == "Custom-TCP" ||
                ChannelDeviceType == "DLT645-2007" ||
                ChannelDeviceType == "DLT645-1997" ||
                ChannelDeviceType == "OPC" ||
                ChannelDeviceType == "OPC-UA" ||
                ChannelDeviceType == "device" ||
                ChannelDeviceType == "IEC104" ||
                ChannelDeviceType == "MITSUBISHI-TXZ-MomMach" ||
                ChannelDeviceType == "MITSUBISHI-TXZ-SubMach1" ||
                ChannelDeviceType == "MITSUBISHI-TXZ-SubMach2" ||
                ChannelDeviceType == "MITSUBISHI-TX-15P" ||
                ChannelDeviceType == "MITSUBISHI-TX-5HP"||
                ChannelDeviceType == "MITSUBISHI-TX-Multi-link"||
                ChannelDeviceType == "R1R2"
              ) {
                var dataItemWR = "";
                var dataItemType = "";
                if (coo == "English") {
                  if (dataItemType_wang == "b")
                    dataItemType = "Switch quantity";
                  if (dataItemType_wang == "a")
                    dataItemType = "Numerical value";
                  if (dataItemType_wang == "s") dataItemType = "String";
                } else {
                  if (dataItemType_wang == "b") dataItemType = "开关量";
                  if (dataItemType_wang == "a") dataItemType = "数值量";
                  if (dataItemType_wang == "s") dataItemType = "字符串";
                }
              }

              if (
                ChannelDeviceType == "GPS" ||
                ChannelDeviceType == "JB3102" ||
                ChannelDeviceType == "JB3208"
              ) {
                dataItemAdd = dataItemConfig;
                if (coo == "English") {
                  dataItemType = "String";
                } else {
                  dataItemType = "字符串";
                }
              }

              if (coo == "English") {
                if (dataItemWR1 == "0") {
                  dataItemWR = "Read";
                }
                if (dataItemWR1 == "1") {
                  dataItemWR = "Read&Write";
                }
              } else {
                if (dataItemWR1 == "0") {
                  dataItemWR = "只读";
                }
                if (dataItemWR1 == "1") {
                  dataItemWR = "可写";
                }
              }
              diffCol++;
              EditChange++;
              DataItemNum++;
              var list;
              if (ChannelDeviceType == "Zundar") {
                list =
                  "<tr id=" +
                  diffCol +
                  " class='diffC' onMouseOver='Highlight(id)' onMouseOut='HideHighlight(id)' onDblClick='Open_Alter_DataItem_Layer(" +
                  dataItemID +
                  ")'>" +
                  "<td>" +
                  "<input name='tryadd' type='checkbox' value='" +
                  dataItemID +
                  "'>" +
                  "</td>" +
                  "<td>" +
                  dataItemID +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  dataItemN +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  dataItemA +
                  "</td>" +
                  "<td>" +
                  dataItemWR +
                  "</td>" +
                  "<td>" +
                  dataItemFreq / 1000 +
                  "s</td>" +
                  "<td>" +
                  dataItemReport +
                  "</td>" +
                  "<td>" +
                  "<img src='assets/img/bianji_ico.png'  onClick='Open_Alter_DataItem_Layer(" +
                  dataItemID +
                  ")' class='edit' title='编辑'>" +
                  "&nbsp;<img src='assets/img/xieru_ico.png'  onClick='open_write_layer(" +
                  JSON.stringify({
                    id: +deviceid,
                    dn: "",
                    vn: modeld.split(":")[1],
                    vid: +driverId,
                    cmds: [
                      {
                        dt: dataItemType_wang,
                        cfg: dataItemConfig,
                        itemid: dataItemID,
                        rw: dataItemWR1,
                      },
                    ],
                  }).replace(/"/g, "&quot;") +
                  ")' class='write i18n-input' selectname='WriteOperation' selectattr='title' >" +
                  "</td>" +
                  "</tr>";
              } else if (ChannelDeviceType == "YinHe") {
                list =
                  "<tr id=" +
                  diffCol +
                  " class='diffC' onMouseOver='Highlight(id)' onMouseOut='HideHighlight(id)' onDblClick='Open_Alter_DataItem_Layer(" +
                  dataItemID +
                  ")'>" +
                  "<td>" +
                  "<input name='tryadd' type='checkbox' value='" +
                  dataItemID +
                  "'>" +
                  "</td>" +
                  "<td>" +
                  dataItemID +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  dataItemN +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  dataItemA +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  dataItemAdd +
                  "</td>" +
                  "<td>" +
                  dataItemWR +
                  "</td>" +
                  "<td>" +
                  dataItemFreq / 1000 +
                  "s</td>" +
                  "<td>" +
                  dataItemReport +
                  "</td>" +
                  "<td>" +
                  "<img src='assets/img/bianji_ico.png'  onClick='Open_Alter_DataItem_Layer(" +
                  dataItemID +
                  ")' class='edit' title='编辑'>" +
                  "&nbsp;<img src='assets/img/xieru_ico.png'  onClick='open_write_layer(" +
                  JSON.stringify({
                    id: +deviceid,
                    dn: "",
                    vn: modeld.split(":")[1],
                    vid: +driverId,
                    cmds: [
                      {
                        dt: dataItemType_wang,
                        cfg: dataItemConfig,
                        itemid: dataItemID,
                        rw: dataItemWR1,
                      },
                    ],
                  }).replace(/"/g, "&quot;") +
                  ")' class='write i18n-input' selectname='WriteOperation' selectattr='title' >" +
                  "</td>" +
                  "</tr>";
              } else if (ChannelDeviceType == "HKG-SERIAL") {
                list =
                  "<tr id=" +
                  diffCol +
                  " class='diffC' onMouseOver='Highlight(id)' onMouseOut='HideHighlight(id)' onDblClick='Open_Alter_DataItem_Layer(" +
                  dataItemID +
                  ")' style='overflow:false;'>" +
                  "<td>" +
                  "<input name='tryadd' type='checkbox' value='" +
                  dataItemID +
                  "'>" +
                  "</td>" +
                  "<td>" +
                  dataItemID +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  dataItemN +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  dataItemA +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  dataItemAdd +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  dataItemType +
                  "</td>" +
                  "<td>" +
                  dataItemWR +
                  "</td>" +
                  "<td>" +
                  dataItemFreq / 1000 +
                  "s</td>" +
                  "<td>" +
                  dataItemReport +
                  "</td>" +
                  "<td>" +
                  "<img src='assets/img/bianji_ico.png'  onClick='Open_Alter_DataItem_Layer(" +
                  dataItemID +
                  ")' class='edit' title='编辑'>" +
                  "&nbsp;<img src='assets/img/xieru_ico.png'  onClick='open_write_layer(" +
                  JSON.stringify({
                    id: +deviceid,
                    dn: "",
                    vn: modeld.split(":")[1],
                    vid: +driverId,
                    cmds: [
                      {
                        dt: dataItemType_wang,
                        cfg: dataItemConfig,
                        itemid: dataItemID,
                        rw: dataItemWR1,
                      },
                    ],
                  }).replace(/"/g, "&quot;") +
                  ")' class='write i18n-input' selectname='WriteOperation' selectattr='title' >" +
                  "</td>" +
                  "</tr>";
              }
              // add begin by x
              else if (ChannelDeviceType == "JB3102") {
                if (coo == "English") {
                  $("#word42").html("Data points");
                } else {
                  $("#word42").html("数据点");
                }
                list =
                  "<tr id=" +
                  diffCol +
                  " class='diffC' onMouseOver='Highlight(id)' onMouseOut='HideHighlight(id)' onDblClick='Open_Alter_DataItem_Layer(" +
                  dataItemID +
                  ")'>" +
                  "<td>" +
                  "<input name='tryadd' type='checkbox' value='" +
                  dataItemID +
                  "'>" +
                  "</td>" +
                  "<td>" +
                  dataItemID +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  dataItemN +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  dataItemA +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  $("#Add_DataItemAddress3")
                    .find('option[value="' + dataItemAdd.split(";")[0] + '"]')
                    .text() +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  dataItemType +
                  "</td>" +
                  "<td>" +
                  dataItemWR +
                  "</td>" +
                  "<td>" +
                  dataItemFreq / 1000 +
                  "s</td>" +
                  "<td>" +
                  dataItemReport +
                  "</td>" +
                  "<td>" +
                  "<img src='assets/img/bianji_ico.png'  onClick='Open_Alter_DataItem_Layer(" +
                  dataItemID +
                  ")' class='edit' title='编辑'>" +
                  "&nbsp;<img src='assets/img/xieru_ico.png'  onClick='open_write_layer(" +
                  JSON.stringify({
                    id: +deviceid,
                    dn: "",
                    vn: modeld.split(":")[1],
                    vid: +driverId,
                    cmds: [
                      {
                        dt: dataItemType_wang,
                        cfg: dataItemConfig,
                        itemid: dataItemID,
                        rw: dataItemWR1,
                      },
                    ],
                  }).replace(/"/g, "&quot;") +
                  ")' class='write i18n-input' selectname='WriteOperation' selectattr='title' >" +
                  "</td>" +
                  "</tr>";
              } else if (ChannelDeviceType == "JB3208") {
                if (coo == "English") {
                  $("#word42").html("Data points");
                } else {
                  $("#word42").html("数据点");
                }
                list =
                  "<tr id=" +
                  diffCol +
                  " class='diffC' onMouseOver='Highlight(id)' onMouseOut='HideHighlight(id)' onDblClick='Open_Alter_DataItem_Layer(" +
                  dataItemID +
                  ")'>" +
                  "<td>" +
                  "<input name='tryadd' type='checkbox' value='" +
                  dataItemID +
                  "'>" +
                  "</td>" +
                  "<td>" +
                  dataItemID +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  dataItemN +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  dataItemA +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  $("#Add_DataItemAddress4")
                    .find('option[value="' + dataItemAdd.split(";")[0] + '"]')
                    .text() +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  dataItemType +
                  "</td>" +
                  "<td>" +
                  dataItemWR +
                  "</td>" +
                  "<td>" +
                  dataItemFreq / 1000 +
                  "s</td>" +
                  "<td>" +
                  dataItemReport +
                  "</td>" +
                  "<td>" +
                  "<img src='assets/img/bianji_ico.png'  onClick='Open_Alter_DataItem_Layer(" +
                  dataItemID +
                  ")' class='edit' title='编辑'>" +
                  "&nbsp;<img src='assets/img/xieru_ico.png'  onClick='open_write_layer(" +
                  JSON.stringify({
                    id: +deviceid,
                    dn: "",
                    vn: modeld.split(":")[1],
                    vid: +driverId,
                    cmds: [
                      {
                        dt: dataItemType_wang,
                        cfg: dataItemConfig,
                        itemid: dataItemID,
                        rw: dataItemWR1,
                      },
                    ],
                  }).replace(/"/g, "&quot;") +
                  ")' class='write i18n-input' selectname='WriteOperation' selectattr='title' >" +
                  "</td>" +
                  "</tr>";
              }
              // end add
              // add by whc
              else if (ChannelDeviceType == "OPC") {
                //modify by bzyang
                var dataItemAdd = ConfigArr[0];
                if (ConfigArr.length > 1) {
                  dataItemAdd = ConfigArr[1];
                }
                list =
                  "<tr id=" +
                  diffCol +
                  " class='diffC' onMouseOver='Highlight(id)' onMouseOut='HideHighlight(id)' onDblClick='Open_Alter_DataItem_Layer(" +
                  dataItemID +
                  ")'>" +
                  "<td>" +
                  "<input name='tryadd' type='checkbox' value='" +
                  dataItemID +
                  "'>" +
                  "</td>" +
                  "<td>" +
                  dataItemID +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  dataItemN +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  dataItemA +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  dataItemAdd +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  dataItemType +
                  "</td>" +
                  "<td>" +
                  dataItemWR +
                  "</td>";
                if (coo == "English") {
                  list += "<td>" + dataItemFreq / 1000 + "s</td>";
                } else {
                  list += "<td>" + dataItemFreq / 1000 + "秒</td>";
                }
                list =
                  list +
                  "<td>" +
                  dataItemReport +
                  "</td>" +
                  "<td>" +
                  "<img src='assets/img/bianji_ico.png'  onClick='Open_Alter_DataItem_Layer(" +
                  dataItemID +
                  ")' class='edit' title='编辑'>" +
                  "&nbsp;<img src='assets/img/xieru_ico.png'  onClick='open_write_layer(" +
                  JSON.stringify({
                    id: +deviceid,
                    dn: "",
                    vn: modeld.split(":")[1],
                    vid: +driverId,
                    cmds: [
                      {
                        dt: dataItemType_wang,
                        cfg: dataItemConfig,
                        itemid: dataItemID,
                        rw: dataItemWR1,
                      },
                    ],
                  }).replace(/"/g, "&quot;") +
                  ")' class='write i18n-input' selectname='WriteOperation' selectattr='title' >" +
                  "</td>" +
                  "</tr>";
              }
              // add by fyj, 新增kuka
              // add begin
              else if (ChannelDeviceType == "KUKA") {
                var kukaAddr = ConfigArr[1];
                var kukaDataType = ConfigArr[2].split(":")[1];
                if (kukaDataType == "0") {
                  kukaDataType = "bool";
                } else if (kukaDataType == "1") {
                  kukaDataType = "int";
                } else if (kukaDataType == "2") {
                  kukaDataType = "double";
                } else if (kukaDataType == "3") {
                  kukaDataType = "string";
                } else if (kukaDataType == "4") {
                  kukaDataType = "frame";
                } else if (kukaDataType == "5") {
                  kukaDataType = "structure";
                }
                $("#PLC #aliasNameCol").css("width", "88px");
                $("#PLC #DataItemAddress").css("width", "123px");
                $("#PLC #freqCol").css("width", "100px");
                $("#PLC #dataItemType").css("width", "75px");
                $("#notknow").css("width", "0px");
                list =
                  "<tr id=" +
                  diffCol +
                  " class='diffC' onMouseOver='Highlight(id)' onMouseOut='HideHighlight(id)' onDblClick='Open_Alter_DataItem_Layer(" +
                  dataItemID +
                  ")'>" +
                  "<td>" +
                  "<input name='tryadd' type='checkbox' value='" +
                  dataItemID +
                  "'>" +
                  "</td>" +
                  "<td>" +
                  dataItemID +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  dataItemN +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  dataItemA +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  kukaAddr +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  kukaDataType +
                  "</td>" +
                  "<td >" +
                  dataItemWR +
                  "</td>" +
                  "<td>" +
                  dataItemFreq / 1000 +
                  "s</td>" +
                  "<td>" +
                  dataItemReport +
                  "</td>" +
                  "<td>" +
                  "<img src='assets/img/bianji_ico.png'  onClick='Open_Alter_DataItem_Layer(" +
                  dataItemID +
                  ")' class='edit' title='编辑'>" +
                  "&nbsp;<img src='assets/img/xieru_ico.png'  onClick='open_write_layer(" +
                  JSON.stringify({
                    id: +deviceid,
                    dn: "",
                    vn: modeld.split(":")[1],
                    vid: +driverId,
                    cmds: [
                      {
                        dt: dataItemType_wang,
                        cfg: dataItemConfig,
                        itemid: dataItemID,
                        rw: dataItemWR1,
                      },
                    ],
                  }).replace(/"/g, "&quot;") +
                  ")' class='write i18n-input' selectname='WriteOperation' selectattr='title' >" +
                  "</td>" +
                  "</tr>";
              }
              // add end
              // add by whc
              else if (ChannelDeviceType == "DRACAL") {
                var dataItemType = "";
                if (dataItemType_wang == "a") dataItemType = "数值";
                if (coo == "English") {
                  dataItemType = "Numerical";
                }
                list =
                  "<tr id=" +
                  diffCol +
                  " class='diffC' onMouseOver='Highlight(id)' onMouseOut='HideHighlight(id)' onDblClick='Open_Alter_DataItem_Layer(" +
                  dataItemID +
                  ")'>" +
                  "<td>" +
                  "<input name='tryadd' type='checkbox' value='" +
                  dataItemID +
                  "'>" +
                  "</td>" +
                  "<td>" +
                  dataItemID +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  dataItemN +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  dataItemA +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  dataItemChannel +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  dataItemType +
                  "</td>" +
                  "<td>" +
                  dataItemWR +
                  "</td>";
                if (coo == "English") {
                  list += "<td>" + dataItemFreq / 1000 + "s</td>";
                } else {
                  list += "<td>" + dataItemFreq / 1000 + "秒</td>";
                }
                list =
                  list +
                  "<td>" +
                  dataItemReport +
                  "</td>" +
                  "<td>" +
                  "<img src='assets/img/bianji_ico.png'  onClick='Open_Alter_DataItem_Layer(" +
                  dataItemID +
                  ")' class='edit' title='编辑'>" +
                  "&nbsp;<img src='assets/img/xieru_ico.png'  onClick='open_write_layer(" +
                  JSON.stringify({
                    id: +deviceid,
                    dn: "",
                    vn: modeld.split(":")[1],
                    vid: +driverId,
                    cmds: [
                      {
                        dt: dataItemType_wang,
                        cfg: dataItemConfig,
                        itemid: dataItemID,
                        rw: dataItemWR1,
                      },
                    ],
                  }).replace(/"/g, "&quot;") +
                  ")' class='write i18n-input' selectname='WriteOperation' selectattr='title' >" +
                  "</td>" +
                  "</tr>";
              }
              // add end
              // add by fyj. DLT645-2007
              else if (
                ChannelDeviceType == "DLT645-2007" ||
                ChannelDeviceType == "DLT645-1997"
              ) {
                list =
                  "<tr id=" +
                  diffCol +
                  " class='diffC' onMouseOver='Highlight(id)' onMouseOut='HideHighlight(id)' onDblClick='Open_Alter_DataItem_Layer(" +
                  dataItemID +
                  ")'>" +
                  "<td>" +
                  "<input name='tryadd' type='checkbox' value='" +
                  dataItemID +
                  "'>" +
                  "</td>" +
                  "<td>" +
                  dataItemID +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  dataItemN +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  dataItemA +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  dataItemConfig +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  dataItemType +
                  "</td>" +
                  "<td>" +
                  dataItemWR +
                  "</td>";
                if (coo == "English") {
                  list += "<td>" + dataItemFreq / 1000 + "s</td>";
                } else {
                  list += "<td>" + dataItemFreq / 1000 + "秒</td>";
                }
                list =
                  list +
                  "<td>" +
                  dataItemReport +
                  "</td>" +
                  "<td>" +
                  "<img src='assets/img/bianji_ico.png'  onClick='Open_Alter_DataItem_Layer(" +
                  dataItemID +
                  ")' class='edit' title='编辑'>" +
                  "&nbsp;<img src='assets/img/xieru_ico.png'  onClick='open_write_layer(" +
                  JSON.stringify({
                    id: +deviceid,
                    dn: "",
                    vn: modeld.split(":")[1],
                    vid: +driverId,
                    cmds: [
                      {
                        dt: dataItemType_wang,
                        cfg: dataItemConfig,
                        itemid: dataItemID,
                        rw: dataItemWR1,
                      },
                    ],
                  }).replace(/"/g, "&quot;") +
                  ")' class='write i18n-input' selectname='WriteOperation' selectattr='title' >" +
                  "</td>" +
                  "</tr>";
              } else if (ChannelDeviceType == "OPC-UA") {
                var freqUnit = dataItemFreq / 1000;
                if (freqUnit < 1) {
                  if (coo == "English") {
                    list =
                      "<tr id=" +
                      diffCol +
                      " class='diffC' onMouseOver='Highlight(id)' onMouseOut='HideHighlight(id)' onDblClick='Open_Alter_DataItem_Layer(" +
                      dataItemID +
                      ")'>" +
                      "<td>" +
                      "<input name='tryadd' type='checkbox' value='" +
                      dataItemID +
                      "'>" +
                      "</td>" +
                      "<td>" +
                      dataItemID +
                      "</td>" +
                      "<td class='nameAliasWidth'>" +
                      dataItemN +
                      "</td>" +
                      "<td class='nameAliasWidth'>" +
                      dataItemA +
                      "</td>" +
                      "<td class='nameAliasWidth'>" +
                      dataItemAdd +
                      "</td>" +
                      "<td class='nameAliasWidth'>" +
                      dataItemType +
                      "</td>" +
                      "<td>" +
                      dataItemWR +
                      "</td>" +
                      "<td>" +
                      dataItemFreq +
                      "ms</td>" +
                      "<td>" +
                      dataItemReport +
                      "</td>" +
                      "<td>" +
                      "<img src='assets/img/bianji_ico.png'  onClick='Open_Alter_DataItem_Layer(" +
                      dataItemID +
                      ")' class='edit' title='编辑'>" +
                      "&nbsp;<img src='assets/img/xieru_ico.png'  onClick='open_write_layer(" +
                      JSON.stringify({
                        id: +deviceid,
                        dn: "",
                        vn: modeld.split(":")[1],
                        vid: +driverId,
                        cmds: [
                          {
                            dt: dataItemType_wang,
                            cfg: dataItemConfig,
                            itemid: dataItemID,
                            rw: dataItemWR1,
                          },
                        ],
                      }).replace(/"/g, "&quot;") +
                      ")' class='write i18n-input' selectname='WriteOperation' selectattr='title' >" +
                      "</td>" +
                      "</tr>";
                  } else {
                    list =
                      "<tr id=" +
                      diffCol +
                      " class='diffC' onMouseOver='Highlight(id)' onMouseOut='HideHighlight(id)' onDblClick='Open_Alter_DataItem_Layer(" +
                      dataItemID +
                      ")'>" +
                      "<td>" +
                      "<input name='tryadd' type='checkbox' value='" +
                      dataItemID +
                      "'>" +
                      "</td>" +
                      "<td>" +
                      dataItemID +
                      "</td>" +
                      "<td class='nameAliasWidth'>" +
                      dataItemN +
                      "</td>" +
                      "<td class='nameAliasWidth'>" +
                      dataItemA +
                      "</td>" +
                      "<td class='nameAliasWidth'>" +
                      dataItemAdd +
                      "</td>" +
                      "<td class='nameAliasWidth'>" +
                      dataItemType +
                      "</td>" +
                      "<td>" +
                      dataItemWR +
                      "</td>" +
                      "<td>" +
                      dataItemFreq +
                      "毫秒</td>" +
                      "<td>" +
                      dataItemReport +
                      "</td>" +
                      "<td>" +
                      "<img src='assets/img/bianji_ico.png'  onClick='Open_Alter_DataItem_Layer(" +
                      dataItemID +
                      ")' class='edit' title='编辑'>" +
                      "&nbsp;<img src='assets/img/xieru_ico.png'  onClick='open_write_layer(" +
                      JSON.stringify({
                        id: +deviceid,
                        dn: "",
                        vn: modeld.split(":")[1],
                        vid: +driverId,
                        cmds: [
                          {
                            dt: dataItemType_wang,
                            cfg: dataItemConfig,
                            itemid: dataItemID,
                            rw: dataItemWR1,
                          },
                        ],
                      }).replace(/"/g, "&quot;") +
                      ")' class='write i18n-input' selectname='WriteOperation' selectattr='title' >" +
                      "</td>" +
                      "</tr>";
                  }
                } else {
                  if (coo == "English") {
                    list =
                      "<tr id=" +
                      diffCol +
                      " class='diffC' onMouseOver='Highlight(id)' onMouseOut='HideHighlight(id)' onDblClick='Open_Alter_DataItem_Layer(" +
                      dataItemID +
                      ")'>" +
                      "<td>" +
                      "<input name='tryadd' type='checkbox' value='" +
                      dataItemID +
                      "'>" +
                      "</td>" +
                      "<td>" +
                      dataItemID +
                      "</td>" +
                      "<td class='nameAliasWidth'>" +
                      dataItemN +
                      "</td>" +
                      "<td class='nameAliasWidth'>" +
                      dataItemA +
                      "</td>" +
                      "<td class='nameAliasWidth'>" +
                      dataItemAdd +
                      "</td>" +
                      "<td class='nameAliasWidth'>" +
                      dataItemType +
                      "</td>" +
                      "<td>" +
                      dataItemWR +
                      "</td>" +
                      "<td>" +
                      dataItemFreq / 1000 +
                      "s</td>" +
                      "<td>" +
                      dataItemReport +
                      "</td>" +
                      "<td>" +
                      "<img src='assets/img/bianji_ico.png'  onClick='Open_Alter_DataItem_Layer(" +
                      dataItemID +
                      ")' class='edit' title='编辑'>" +
                      "&nbsp;<img src='assets/img/xieru_ico.png'  onClick='open_write_layer(" +
                      JSON.stringify({
                        id: +deviceid,
                        dn: "",
                        vn: modeld.split(":")[1],
                        vid: +driverId,
                        cmds: [
                          {
                            dt: dataItemType_wang,
                            cfg: dataItemConfig,
                            itemid: dataItemID,
                            rw: dataItemWR1,
                          },
                        ],
                      }).replace(/"/g, "&quot;") +
                      ")' class='write i18n-input' selectname='WriteOperation' selectattr='title' >" +
                      "</td>" +
                      "</tr>";
                  } else {
                    list =
                      "<tr id=" +
                      diffCol +
                      " class='diffC' onMouseOver='Highlight(id)' onMouseOut='HideHighlight(id)' onDblClick='Open_Alter_DataItem_Layer(" +
                      dataItemID +
                      ")'>" +
                      "<td>" +
                      "<input name='tryadd' type='checkbox' value='" +
                      dataItemID +
                      "'>" +
                      "</td>" +
                      "<td>" +
                      dataItemID +
                      "</td>" +
                      "<td class='nameAliasWidth'>" +
                      dataItemN +
                      "</td>" +
                      "<td class='nameAliasWidth'>" +
                      dataItemA +
                      "</td>" +
                      "<td class='nameAliasWidth'>" +
                      dataItemAdd +
                      "</td>" +
                      "<td class='nameAliasWidth'>" +
                      dataItemType +
                      "</td>" +
                      "<td>" +
                      dataItemWR +
                      "</td>" +
                      "<td>" +
                      dataItemFreq / 1000 +
                      "秒</td>" +
                      "<td>" +
                      dataItemReport +
                      "</td>" +
                      "<td>" +
                      "<img src='assets/img/bianji_ico.png'  onClick='Open_Alter_DataItem_Layer(" +
                      dataItemID +
                      ")' class='edit' title='编辑'>" +
                      "&nbsp;<img src='assets/img/xieru_ico.png'  onClick='open_write_layer(" +
                      JSON.stringify({
                        id: +deviceid,
                        dn: "",
                        vn: modeld.split(":")[1],
                        vid: +driverId,
                        cmds: [
                          {
                            dt: dataItemType_wang,
                            cfg: dataItemConfig,
                            itemid: dataItemID,
                            rw: dataItemWR1,
                          },
                        ],
                      }).replace(/"/g, "&quot;") +
                      ")' class='write i18n-input' selectname='WriteOperation' selectattr='title' >" +
                      "</td>" +
                      "</tr>";
                  }
                }
              }
              // add by lh. IEC104
              else if (ChannelDeviceType == "IEC104") {
                //展示列表中没有数据项地址
                list =
                  "<tr id=" +
                  diffCol +
                  " class='diffC' onMouseOver='Highlight(id)' onMouseOut='HideHighlight(id)' onDblClick='Open_Alter_DataItem_Layer(" +
                  dataItemID +
                  ")'>" +
                  "<td>" +
                  "<input name='tryadd' type='checkbox' value='" +
                  dataItemID +
                  "'>" +
                  "</td>" +
                  "<td>" +
                  dataItemID +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  dataItemN +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  dataItemA +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  dataItemType +
                  "</td>" +
                  "<td>" +
                  dataItemWR +
                  "</td>";
                if (coo == "English") {
                  list += "<td>" + dataItemFreq / 1000 + "s</td>";
                } else {
                  list += "<td>" + dataItemFreq / 1000 + "秒</td>";
                }
                list =
                  list +
                  "<td>" +
                  dataItemReport +
                  "</td>" +
                  "<td>" +
                  "<img src='assets/img/bianji_ico.png'  onClick='Open_Alter_DataItem_Layer(" +
                  dataItemID +
                  ")' class='edit' title='编辑'>" +
                  "&nbsp;<img src='assets/img/xieru_ico.png'  onClick='open_write_layer(" +
                  JSON.stringify({
                    id: +deviceid,
                    dn: "",
                    vn: modeld.split(":")[1],
                    vid: +driverId,
                    cmds: [
                      {
                        dt: dataItemType_wang,
                        cfg: dataItemConfig,
                        itemid: dataItemID,
                        rw: dataItemWR1,
                      },
                    ],
                  }).replace(/"/g, "&quot;") +
                  ")' class='write i18n-input' selectname='WriteOperation' selectattr='title' >" +
                  "</td>" +
                  "</tr>";
              } else if (ChannelDeviceType == "device") {
                list =
                  "<tr id=" +
                  diffCol +
                  " class='diffC' onMouseOver='Highlight(id)' onMouseOut='HideHighlight(id)' onDblClick='Open_Alter_DataItem_Layer(" +
                  dataItemID +
                  ")'>" +
                  "<td>" +
                  "<input name='tryadd' type='checkbox' value='" +
                  dataItemID +
                  "'>" +
                  "</td>" +
                  "<td>" +
                  dataItemID +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  dataItemN +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  dataItemA +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  dataItemConfig +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  dataItemType +
                  "</td>" +
                  "<td>" +
                  dataItemWR +
                  "</td>";
                if (coo == "English") {
                  list += "<td>" + dataItemFreq / 1000 + "s</td>";
                } else {
                  list += "<td>" + dataItemFreq / 1000 + "秒</td>";
                }
                list =
                  list +
                  "<td>" +
                  dataItemReport +
                  "</td>" +
                  "<td>" +
                  "<img src='assets/img/bianji_ico.png'  onClick='Open_Alter_DataItem_Layer(" +
                  dataItemID +
                  ")' class='edit' title='编辑'>" +
                  "&nbsp;<img src='assets/img/xieru_ico.png'  onClick='open_write_layer(" +
                  JSON.stringify({
                    id: +deviceid,
                    dn: "",
                    vn: modeld.split(":")[1],
                    vid: +driverId,
                    cmds: [
                      {
                        dt: dataItemType_wang,
                        cfg: dataItemConfig,
                        itemid: dataItemID,
                        rw: dataItemWR1,
                      },
                    ],
                  }).replace(/"/g, "&quot;") +
                  ")' class='write i18n-input' selectname='WriteOperation' selectattr='title' >" +
                  "</td>" +
                  "</tr>";
              } else if (ChannelDeviceType == "HMI") {
                list =
                  "<tr id=" +
                  diffCol +
                  " class='diffC' onMouseOver='Highlight(id)' onMouseOut='HideHighlight(id)' onDblClick='Open_Alter_DataItem_Layer(" +
                  dataItemID +
                  ")'>" +
                  "<td>" +
                  "<input name='tryadd' type='checkbox' value='" +
                  dataItemID +
                  "'>" +
                  "</td>" +
                  "<td>" +
                  dataItemID +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  dataItemN +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  dataItemA +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  ConfigArr[0] +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  dataItemType +
                  "</td>" +
                  "<td>" +
                  dataItemWR +
                  "</td>";
                if (coo == "English") {
                  list += "<td>" + dataItemFreq / 1000 + "s</td>";
                } else {
                  list += "<td>" + dataItemFreq / 1000 + "秒</td>";
                }
                list =
                  list +
                  "<td>" +
                  dataItemReport +
                  "</td>" +
                  "<td>" +
                  "<img src='assets/img/bianji_ico.png'  onClick='Open_Alter_DataItem_Layer(" +
                  dataItemID +
                  ")' class='edit' title='编辑'>" +
                  "</td>" +
                  "</tr>";
              } else {
                list =
                  "<tr id=" +
                  diffCol +
                  " class='diffC' onMouseOver='Highlight(id)' onMouseOut='HideHighlight(id)' onDblClick='Open_Alter_DataItem_Layer(" +
                  dataItemID +
                  ")'>" +
                  "<td>" +
                  "<input name='tryadd' type='checkbox' value='" +
                  dataItemID +
                  "'>" +
                  "</td>" +
                  "<td>" +
                  dataItemID +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  dataItemN +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  dataItemA +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  dataItemAdd +
                  "</td>" +
                  "<td class='nameAliasWidth'>" +
                  dataItemType +
                  "</td>" +
                  "<td>" +
                  dataItemWR +
                  "</td>";
                if (coo == "English") {
                  list += "<td>" + dataItemFreq / 1000 + "s</td>";
                } else {
                  list += "<td>" + dataItemFreq / 1000 + "秒</td>";
                }
                list =
                  list +
                  "<td>" +
                  dataItemReport +
                  "</td>" +
                  "<td>" +
                  "<img src='assets/img/bianji_ico.png'  onClick='Open_Alter_DataItem_Layer(" +
                  dataItemID +
                  ")' class='edit' title='编辑'>" +
                  "&nbsp;<img src='assets/img/xieru_ico.png'  onClick='open_write_layer(" +
                  JSON.stringify({
                    id: +deviceid,
                    dn: "",
                    vn: modeld.split(":")[1],
                    vid: +driverId,
                    cmds: [
                      {
                        dt: dataItemType_wang,
                        cfg: dataItemConfig,
                        itemid: dataItemID,
                        rw: dataItemWR1,
                      },
                    ],
                  }).replace(/"/g, "&quot;") +
                  ")' class='write i18n-input' selectname='WriteOperation' selectattr='title' >" +
                  "</td>" +
                  "</tr>";
              }
              $("#itemTable").append(list);
              if (coo == "English") {
                $(".edit").attr("title", "Edit");
                $(".write").attr("title", "Write");
              } else {
                $(".edit").attr("title", "编辑");
                $(".write").attr("title", "写入");
              }
              if (diffCol % 2 == "0")
                document.getElementById(diffCol).className = "diffC1";
              if (coo == "English") {
                document.getElementById("DataItemNum").innerHTML =
                  "Total number of dataItems: " +
                  "<strong>" +
                  DataItemNum +
                  "</strong>" +
                  " &nbsp; ";
              } else {
                document.getElementById("DataItemNum").innerHTML =
                  "数据项总数： " +
                  "<strong>" +
                  DataItemNum +
                  "</strong>" +
                  " &nbsp; ";
              }
              var allName = dataItemN + ";";
              $("#allItemName").append(allName);
            });
            $(".edit").mouseover(function () {
              $(this).attr("src", "assets/img/bianji_hover_ico.png");
              this.myTitle = this.title;
              this.title = "";
              var tooltip = "<div id='tooltip'>" + this.myTitle + "</div>";
              $("body").append(tooltip);
              var width = parseInt($("#tooltip").css("width")) + 10;
              $("#tooltip").css("top", y + "px");
              $("#tooltip").css("left", x + "px");
              $("#tooltip").css("width", width + "px");
            });
            $(".edit").mouseout(function () {
              $(this).attr("src", "assets/img/bianji_ico.png");
              this.title = this.myTitle;
              $("#tooltip").remove();
            });
          });
        });
      });
  });
  $.ajaxSettings.async = true;
}

//点击返回效果
function ReturnToDevice() {
  window.location.href =
    "../Device_PLC_Change.html?id=" + ChannelID + "&t=" + new Date().getTime();
}

//移动高亮显示
function Highlight(txt) {
  document.getElementById(txt).className = "diffC2";
}

function HideHighlight(txt) {
  if (txt % 2 == "0") document.getElementById(txt).className = "diffC1";
  else document.getElementById(txt).className = "diffC";
}

//全局变量当前编辑的名称
var NowItemName = "";
//根据设备ID和数据项ID查找数据项信息并显示
function Open_Alter_DataItem_Layer(txt) {
  document.getElementById("Alter_Line_DataItemType").style.display = "";
  //将ID赋值给表单
  document.getElementById("Alter_DataItemID_YuToXHZhang").value = txt;
  document.getElementById("idTipInfo").innerHTML = "";
  document.getElementById("nameTipInfo").innerHTML = "";
  document.getElementById("AliasTipInfo").innerHTML = "";
  document.getElementById("addressTipInfo").innerHTML = "";
  document.getElementById("checkTwoInfo").innerHTML = "";
  document.getElementById("Alter_stringMsg").innerHTML = "";

  $("#freqTipInfo").html("");
  // add by fyj
  // add begin
  $("#Alter_DataItemTypeTip").html("");
  // add end
  // add by fyj, hostlink add datahandler
  // document.getElementById("Alter_DataItemDHParamTip").innerHTML = "";
  $("#Alter_DataItemDHParamTip").html("");
  // add end
  // add by fyj , 新增KUKA
  // add begin
  if (ChannelDeviceType == "KUKA") {
    $("#Alter_Line_DataItemAddress").hide();
    $("#Alter_Line_DataItemType").hide();
    $("#line_addressTipInfo").hide();
    $("#line_Alter_DataItemTypeTip").hide();
    $("#Alter_DataItem_Layer tr.second-last").hide();

    $("#Alter_DataItem_Layer tr.driver_kuka").show();

    $("#Alter_Line_DataItemKukaParam1").hide();
    $("#Alter_Line_DataItemKukaParam1Tip").hide();
    $("#Alter_Line_DataItemKukaParam2").hide();
    $("#Alter_Line_DataItemKukaParam2Tip").hide();

    $("#Alter_DataItemKukaR").attr("checked", "checked");
    $("#Alter_DataItemKukaNodeName").val("");
    $("#Alter_DataItemKukaNodeNameTip").html("");
    $("#Alter_DataItemKukaNodeIndex").val("");
    $("#Alter_DataItemKukaNodeIndexTip").html("");
    $("#Alter_DataItemKukaNodeAttr1").val("");
    $("#Alter_DataItemKukaNodeAttr1Tip").html("");
    $("#Alter_DataItemKukaNodeAttr2").val("");
    $("#Alter_DataItemKukaNodeAttr2Tip").html("");
    $("#Alter_DataItemKukaDataType").val();
    $("#Alter_DataItemKukaDataType").val("0");
    if (coo == "English") {
      $("#Alter_DataItemKukaParam1Text").text("Parameters:");
    } else {
      $("#Alter_DataItemKukaParam1Text").text("参数：");
    }

    $("#Alter_DataItemKukaParam1").val("").hide();
    $("#Alter_DataItemKukaParam1Tip").html("").hide();
    $("#Alter_DataItemKukaParam2").val("").hide();
    $("#Alter_DataItemKukaParam2Tip").html("").hide();

    $("#Alter_DataItemKukaDataOperator").val("0");

    $("#Alter_DataItemKukaDataOperator")
      .unbind()
      .bind("change", function () {
        var $selVal = $(this).val();
        if ($selVal == "0") {
          // 无, 无参数
          $("#Alter_Line_DataItemKukaParam1").hide();
          $("#Alter_Line_DataItemKukaParam1Tip").hide();
          $("#Alter_Line_DataItemKukaParam2").hide();
          $("#Alter_Line_DataItemKukaParam2Tip").hide();
          $("#Alter_DataItemKukaParam1").val("").hide();
          $("#Alter_DataItemKukaParam1Tip").html("").hide();
          $("#Alter_DataItemKukaParam2").val("").hide();
          $("#Alter_DataItemKukaParam2Tip").html("").hide();
        } else if ($selVal == "1") {
          // 掩码, 1个参数
          $("#Alter_Line_DataItemKukaParam1").show();
          $("#Alter_Line_DataItemKukaParam1Tip").show();
          $("#Alter_Line_DataItemKukaParam2").hide();
          $("#Alter_Line_DataItemKukaParam2Tip").hide();
          $("#Alter_DataItemKukaParam1").val("").show();
          $("#Alter_DataItemKukaParam1Tip").html("").show();
          if (coo == "English") {
            $("#Alter_DataItemKukaParam1Text").text("Parameters:");
          } else {
            $("#Alter_DataItemKukaParam1Text").text("参数：");
          }
          $("#Alter_DataItemKukaParam2").val("").hide();
          $("#Alter_DataItemKukaParam2Tip").html("").hide();
        } else if ($selVal == "2") {
          // 倍率, 2个参数
          $("#Alter_Line_DataItemKukaParam1").show();
          $("#Alter_Line_DataItemKukaParam1Tip").show();
          $("#Alter_Line_DataItemKukaParam2").show();
          $("#Alter_Line_DataItemKukaParam2Tip").show();
          $("#Alter_DataItemKukaParam1").val("").show();
          $("#Alter_DataItemKukaParam1Tip").html("").show();
          if (coo == "English") {
            $("#Alter_DataItemKukaParam1Text").text("Parameters1:");
          } else {
            $("#Alter_DataItemKukaParam1Text").text("参数1：");
          }
          $("#Alter_DataItemKukaParam2").val("").show();
          $("#Alter_DataItemKukaParam2Tip").html("").show();
        } else if ($selVal == "3") {
          // 线性, 2个参数
          $("#Alter_Line_DataItemKukaParam1").show();
          $("#Alter_Line_DataItemKukaParam1Tip").show();
          $("#Alter_Line_DataItemKukaParam2").show();
          $("#Alter_Line_DataItemKukaParam2Tip").show();
          $("#Alter_DataItemKukaParam1").val("").show();
          $("#Alter_DataItemKukaParam1Tip").html("").show();
          if (coo == "English") {
            $("#Alter_DataItemKukaParam1Text").text("Parameters1:");
          } else {
            $("#Alter_DataItemKukaParam1Text").text("参数1：");
          }
          $("#Alter_DataItemKukaParam2").val("").show();
          $("#Alter_DataItemKukaParam2Tip").html("").show();
        }
      });
  }
  // add end
  // add by fyj, DLT645-2007
  if (
    ChannelDeviceType == "DLT645-2007" ||
    ChannelDeviceType == "DLT645-1997"
  ) {
    $("#Alter_Line_DataItemAddress").hide();
    $("#line_addressTipInfo").hide();

    $("#Alter_Line_DataItemDltEnergy").show();
    $("#Alter_Line_DataItemDltEnergyTip").show();
    if (coo == "English") {
      $("#Alter_DataItemType").html(
        "<option value='b'>Switch quantity</option><option value='a'>Numerical value</option><option value='s'>String</option>"
      );
    } else {
      $("#Alter_DataItemType").html(
        "<option value='b'>开关量</option><option value='a'>数值量</option><option value='s'>字符串</option>"
      );
    }
  }
  // add end
  // add by whc, 新增DRACAL
  if (ChannelDeviceType == "DRACAL") {
    $("#Alter_Line_DataItemDRACALChannel").show();
    $("#Alter_Line_DataItemDRACALChannelTip").show();
    $("#Alter_Line_DataItemAddress").hide();
    $("#ChannelTip").show();
    $("#line_addressTipInfo").hide();
    $("#Alter_DataItemType").empty();
    var str = "<option value='FLOAT'>数值</option>";
    if (coo == "English") {
      str = "<option value='FLOAT'>Numerical</option>";
    }
    $("#Alter_DataItemType").append(str);
  }
  // add end
  // add by lh, IEC104
  if (ChannelDeviceType == "IEC104") {
    $("#Alter_Line_DataItemAddress").hide();
    $("#line_addressTipInfo").hide();
    $("#Alter_Line_DataItemType").hide();
    $("#Alter_Line_DataItemIECAttr").show();
    $("#Alter_Line_DataItemIECAttr2").show();
    $("#Alter_Line_DataItemIECNodeNameTip").show();
    $("#Alter_Line_DataItemIECDataType").show();

    $("#line_Add_DataItemTypeTip").hide();

    $("#additional_line4").show();
    $("#additional_line5").show();
  }
  // add end
  $(document).ready(function () {
    if (ChannelDeviceType == "YinHe") {
      document.getElementById("Alter_Line_DataItemType").style.display = "none";
      $("#line_checkTwoInfo").hide();
      $("#Alter_ID_wang").hide();
      $("#notknow").hide();
      $("#Alter_DataItem_Layer").css("min-height", "300px");
      $("#Alter_DataItem_Layer").css("max-height", "550px");
    }
    if (ChannelDeviceType == "Zundar") {
      document.getElementById("Alter_Line_DataItemAddress").style.display =
        "none";
      document.getElementById("Alter_Line_DataItemType").style.display = "none";
      $("#line_addressTipInfo").hide();
      $("#line_checkTwoInfo").hide();
      $("#notknow").hide();
      $("#Alter_DataItem_Layer").css("min-height", "300px");
      $("#Alter_DataItem_Layer").css("max-height", "370px");
    }
    if (ChannelDeviceType == "OMRON_NJNX") {
      $("#Alter_Line_DataItemName").show();
      $("#Alter_Line_DataItemAddress").hide();
      $("#line_dataPnameTipInfo").show();
      $("#line_addressTipInfo").hide();
      $("#Alter_DataItemType").empty();
      if (coo == "English") {
        var str =
          "<option value='BIT' selected>Switch quantity</option><option value='FLOAT'>Numerical value</option><option value='STRING'>String</option>";
      } else {
        var str =
          "<option value='BIT' selected>开关量</option><option value='FLOAT'>数值</option><option value='STRING'>字符串</option>";
      }
      $("#Alter_DataItemType").append(str);
    }
    if (ChannelDeviceType == "HKG-SERIAL") {
      $("#Alter_Line_DataItemAddress").hide();
      $("#Alter_Line_DataItemAddress").hide();
      $("#notknow").hide();
      $("#Alter_ID_msg_wang").show();
      $("#Alter_ID_wang").show();
      $("#Alter_DataItemType").empty();
      if (coo == "English") {
        var str =
          "<option value='BIT' selected>Switch quantity</option><option value='FLOAT'>Numerical value</option><option value='STRING'>String</option>";
      } else {
        var str =
          "<option value='BIT' selected>开关量</option><option value='FLOAT'>数值</option><option value='STRING'>字符串</option>";
      }
      $("#Alter_DataItemType").append(str);
      $("#Alter_DataItem_Layer").css("min-height", "400px");
      $("#Alter_DataItem_Layer").css("max-height", "470px");
    }
    if (ChannelDeviceType == "Custom-TCP" || ChannelDeviceType == "OPC") {
      $("#Alter_DataItemType").empty();
      if (coo == "English") {
        var str =
          "<option value='BIT' selected>Switch quantity</option><option value='FLOAT'>Numerical value</option><option value='STRING'>String</option>";
      } else {
        var str =
          "<option value='BIT' selected>开关量</option><option value='FLOAT'>数值</option><option value='STRING'>字符串</option>";
      }
      $("#Alter_DataItemType").append(str);
    }
    if (ChannelDeviceType == "GPS") {
      $("#Alter_Line_DataItemAddress2").show();
      $("#Alter_Line_DataItemAddress").hide();
      $("#Alter_Line_DataItemType").hide();
      $("#word35").parent().parent().parent().hide();
      $("#word32").parent().parent().parent().hide();
    }
    //  OMRON 数据类型增加BCD
    if (
      ChannelDeviceType == "OMRON-HostLink" ||
      ChannelDeviceType == "OMRON-TCP" ||
      ChannelDeviceType == "OMRON-FINS"
    ) {
      var isExit = false;
      var count = $("#Alter_DataItemType").find("option").length;
      for (var i = 0; i < count; i++) {
        if ($("#Alter_DataItemType").get(0).options[i].value == "BCD") {
          isExit = true;
          break;
        }
      }
      if (!isExit) {
        $("#Alter_DataItemType").append('<option value="BCD">BCD</option>');
      }
    }
    // add end
    if (ChannelDeviceType == "OPC-UA") {
      $("#Alter_Line_DataItemUAattr1").show();
      $("#Alter_Line_DataItemType").hide();
      $("#Alter_Line_DataItemUAType").show();
      $("#Alter_Line_DataItemAddress").hide();
      $("#line_addressTipInfo").hide();
      $("#line_Alter_DataItemTypeTip").show();
      $("#additional_line2").show();
      //OPC-UA驱动采集频率支持毫秒 为了不重复进行append 需设置标志位  有时间需要修改
      if (UA2 == 0) {
        if (coo == "English") {
          $("#Alter_DataItemUnit").append("<option value='ms'>ms</option>");
        } else {
          $("#Alter_DataItemUnit").append("<option value='ms'>毫秒</option>");
        }
        UA2++;
      }
    }
    if (ChannelDeviceType == "device") {
      $("#Alter_Line_DataItemType").hide();
      $("#Alter_Line_DataItemIECDataType").show();
    }
    if (ChannelDeviceType == "OPC" || ChannelDeviceType == "FATEK编程口") {
      $("#additional_line").show();
    }
    // add by bzyang, OMRON-hostlink任务数据类型增加BCD
    if (
      ChannelDeviceType == "OMRON-HostLink-Task" ||
      ChannelDeviceType == "OMRON-FINS-Task"
    ) {
      $("#Alter_DataItemType").empty();
      var str = "";
      if (coo == "English") {
        str =
          "<option value='BIT' selected>Bool</option><option value='UINT16'>UInt16</option><option value='INT16'>Int16</option>\
                <option value='UINT32' selected>UInt32</option><option value='INT32'>Int32</option><option value='FLOAT'>Float</option><option value='BCD'>BCD</option>";
      } else {
        str =
          "<option value='BIT' selected>Boolean</option><option value='UINT16'>UInt16</option><option value='INT16'>Int16</option>\
                <option value='UINT32' selected>UInt32</option><option value='INT32'>Int32</option><option value='FLOAT'>Float</option><option value='BCD'>BCD</option>";
      }

      $("#Alter_DataItemType").append(str);
    }
    // add end

    //add begin by x
    if (ChannelDeviceType == "JB3102") {
      $("#Alter_Line_DataItemAddress").hide();
      $("#Alter_Line_DataItemType").hide();
      $("#Alter_Line_DataItemAddress3").show();
      $("#Alter_DataItemType")
        .find('option[value="STRING"]')
        .attr("selected", "selected");
      $("#Alter_Line_DataItemType").hide().next().hide();
      //绑定事件
      $("#Alter_DataItemAddress3")
        .unbind()
        .bind("change", function () {
          if ($(this).val() === "205") {
            $("#Alter_Line_huiluhao").show().next().show();
            $("#Alter_Line_dianhao").show().next().show();
          } else {
            $("#Alter_Line_huiluhao").hide().next().hide();
            $("#Alter_Line_dianhao").hide().next().hide();
          }
        });
    }
    // add by whc,SIEMENS-S7-PPI-Task驱动增加自定义数据项类型
    if (
      ChannelDeviceType == "SIEMENS-S7-PPI-Task" &&
      $("#Alter_DataItemTypeIpt".length == 0)
    ) {
      var typeMap = {
        BIT: "Bit",
        INT8: "Int8",
        UINT8: "UInt8",
        INT16: "Int16",
        UINT16: "UInt16",
        INT32: "Int32",
        UINT32: "UInt32",
        FLOAT: "Float",
        BCD: "BCD",
      };
      var str =
        '<option value="BIT" selected>Bit</option>' +
        '<option value="INT8">Int8</option>' +
        '<option value="UINT8">UInt8</option>' +
        '<option value="INT16">Int16</option>' +
        '<option value="UINT16">UInt16</option>' +
        '<option value="INT32">Int32</option>' +
        '<option value="UINT32">UInt32</option>' +
        '<option value="FLOAT">Float</option>' +
        '<option value="BCD">BCD</option>';

      var $div = $("<div>").css({
        position: "relative",
      });

      var $input = $("<input>")
        .attr({
          value: "BIT",
          id: "Alter_DataItemTypeIpt",
        })
        .css({
          width: 170,
          height: 18.5,
          position: "absolute",
          left: 0,
          top: 3.5,
        });

      var $sel = $("<select>")
        .attr({
          name: "Alter_DataItemType",
          id: "Alter_DataItemType",
        })
        .css({
          width: 195,
          height: 25,
        })
        .html(str)
        .change(function () {
          $input.val(typeMap[$(this).val()]);
        });

      $("#Alter_DataItemType").remove();

      $sel.appendTo($div);
      $input.appendTo($div);

      $("#Alter_Line_DataItemType div[align=left]").empty().append($div);
    }
    // add end
    // modified by fyj , SIEMENS-PPI驱动增加自定义数据项类型控件
    // begin
    if (
      ChannelDeviceType == "SIEMENS-PPI" &&
      $("#Alter_DataItemTypeIpt").length == 0
    ) {
      // $("#Add_DataItemType").empty();
      var typeMap = {
        BIT: "Boolean",
        BYTE: "Byte",
        WORD: "Word",
        SHORT: "Short",
        DWORD: "DWord",
        LONG: "Long",
        FLOAT: "Float",
        STRING: "String",
        INT8: "Int 8",
        INT16: "Int 16",
        INT32: "Int 32",
        BCD: "BCD",
      };
      var str =
        '<option value="BIT" selected>Boolean</option>' +
        '<option value="BYTE">Byte</option>' +
        '<option value="WORD">Word</option>' +
        '<option value="SHORT">Short</option>' +
        '<option value="DWORD">DWord</option>' +
        '<option value="LONG">Long</option>' +
        '<option value="FLOAT">Float</option>' +
        '<option value="STRING">String</option>' +
        '<option value="INT8">Int 8</option>' +
        '<option value="INT16">Int 16</option>' +
        '<option value="INT32">Int 32</option>' +
        '<option value="BCD">BCD</option>';
      // $("#Add_DataItemType").append(str);

      var $div = $("<div>").css({
        position: "relative",
      });

      var $input = $("<input>")
        .attr({
          value: "Boolean",
          id: "Alter_DataItemTypeIpt",
        })
        .css({
          width: 170,
          height: 18.5,
          position: "absolute",
          left: 0,
          top: 3.5,
        });

      var $sel = $("<select>")
        .attr({
          name: "Alter_DataItemType",
          id: "Alter_DataItemType",
        })
        .css({
          width: 195,
          height: 25,
        })
        .html(str)
        .change(function () {
          $input.val(typeMap[$(this).val()]);
        })
        .change(function () {
          if (
            $(this).val() == "STRING" &&
            ChannelDeviceType != "OMRON_NJNX" &&
            ChannelDeviceType != "HKG-SERIAL" &&
            ChannelDeviceType != "Custom-TCP" &&
            ChannelDeviceType != "OPC"
          ) {
            $("#Alter_tr_string").show();
            $("#Alter_tr_string_msg").show();
          } else {
            $("#Alter_tr_string").hide();
            $("#Alter_tr_string_msg").hide();
          }
        });

      $("#Alter_DataItemType").remove();

      $sel.appendTo($div);
      $input.appendTo($div);

      $("#Alter_Line_DataItemType div[align=left]").empty().append($div);
    }
    // end
    if (ChannelDeviceType == "JB3208") {
      $("#Alter_Line_DataItemAddress").hide();
      $("#Alter_Line_DataItemType").hide();
      $("#Alter_Line_DataItemAddress4").show();
      $("#Alter_DataItemType")
        .find('option[value="STRING"]')
        .attr("selected", "selected");
      $("#Alter_Line_DataItemType").hide().next().hide();
      //绑定事件
      $("#Alter_DataItemAddress4")
        .unbind()
        .bind("change", function () {
          if ($(this).val() === "104") {
            $("#Alter_Line_huiluhao").show().next().show();
            $("#Alter_Line_dianhao").show().next().show();
          } else {
            $("#Alter_Line_huiluhao").hide().next().hide();
            $("#Alter_Line_dianhao").hide().next().hide();
          }
        });
    }

    if (ChannelDeviceType == "MITSUBISHI-TXZ-MomMach" || ChannelDeviceType == "MITSUBISHI-TXZ-SubMach1" ||  ChannelDeviceType == "MITSUBISHI-TXZ-SubMach2" ) {
      $("#Alter_DataItem_Layer").css("top", "3px");
      $("#Alter_Line_DataItemAddress").hide();
      $("#Alter_Line_DataItemType").hide();
      $("#line_addressTipInfo").hide();
      $("#Alter_Line_CommandType").show();
      $("#Alter_Line_TXZ_address1").show();
      $("#Alter_Line_TXZ_address2").show();
      $("#Alter_Line_DataItemUAType").show();

      $("#Alter_CommandType").change(function () {
        var val = $(this).val();
        if (val == "G9") {
          if (coo == "English") {
            $(".MITSUBISHI-TXZ-address1").html("Indoor unit address:");
          } else {
            $(".MITSUBISHI-TXZ-address1").html("室内机地址：");
          }
        } else {
          if (coo == "English") {
            $(".MITSUBISHI-TXZ-address1").html("Machine Type:");
          } else {
            $(".MITSUBISHI-TXZ-address1").html("机器类型：");
          }
        }
      });
    }
    if (ChannelDeviceType == "MITSUBISHI-TX-15P") {
      $("#Alter_DataItem_Layer").css("top", "3px");
      $("#Alter_Line_DataItemAddress").hide();
      $("#Alter_Line_DataItemType").hide();
      $("#Alter_Line_DataItemTXType").show();
      $("#line_Alter_DataItemTypeTip").hide();
      $("#line_addressTipInfo").hide();
      $("#Alter_Line_TX_Config").show();
      $("#AlterTXConfigTipLine").show();
      $("#TXConfig2").empty();
      $("#Alter_TX_config").val("");
      $("#AlterTXConfigTip").val("");
      for (var key in TX15PMap) {
        $("#TXConfig2").append(
          '<option data-value="' + TX15PMap[key] + '">' + key + "</option>"
        );
      }
    }
    if (ChannelDeviceType == "MITSUBISHI-TX-5HP") {
      $("#Alter_DataItem_Layer").css("top", "3px");
      $("#Alter_Line_DataItemAddress").hide();
      $("#Alter_Line_DataItemType").hide();
      $("#Alter_Line_DataItemTXType").show();
      $("#line_Alter_DataItemTypeTip").hide();
      $("#line_addressTipInfo").hide();
      $("#Alter_Line_TX_Config").show();
      $("#AlterTXConfigTipLine").show();
      $("#TXConfig2").empty();
      $("#Alter_TX_config").val("");
      $("#AlterTXConfigTip").val("");
      for (var key in TX5HPMap) {
        $("#TXConfig2").append(
          '<option data-value="' + TX5HPMap[key] + '">' + key + "</option>"
        );
      }
    }
    if (ChannelDeviceType == "MITSUBISHI-TX-Multi-link") {
      $("#Alter_DataItem_Layer").css("top", "3px");
      $("#Alter_Line_DataItemAddress").hide();
      $("#Alter_Line_DataItemType").hide();
      $("#Alter_Line_DataItemTXType").show();
      $("#line_Alter_DataItemTypeTip").hide();
      $("#line_addressTipInfo").hide();
      $("#Alter_Line_TX_Config").show();
      $("#AlterTXConfigTipLine").show();
      $("#TXConfig2").empty();
      $("#Alter_TX_config").val("");
      $("#AlterTXConfigTip").val("");
      for (var key in TXMultiMap) {
        $("#TXConfig2").append(
          '<option data-value="' + TXMultiMap[key] + '">' + key + "</option>"
        );
      }
    }
    if (ChannelDeviceType == "R1R2") {
      $("#Alter_Line_DataItemAddress").hide();
      $("#Alter_Line_DataItemType").hide();
      $("#line_addressTipInfo").hide();

      $("#Alter_Line_Samsung_Address").show();
      $("#line_Alter_Samsung_AddressTip").show();
      $("#Alter_Line_Samsung_Mode").show();
      $("#additional_line10").show();
      $("#Alter_Line_Samsung_DataItemType").show();
      $("#additional_line11").show();
    }
    // add by fyj , hostlink add datahandler
    $("#Alter_DataItemDHParam").show();
    $("#Alter_DHFunctionParam1").hide();
    $("#Alter_DHFunctionParam2").hide();
    $("#line_Alter_DataItemDHEnable").show();
    $("#DHMode1_alter").attr("checked", "checked");
    $("#RWmode2Info").attr("disabled", false);
    $("#Alter_DataItemDHSelect").val("1");
    $("#Alter_DataItemDHParam").val("");
    $("#Alter_DHFunctionParam1").val("");
    $("#Alter_DHFunctionParam2").val("");
    $("#line_Alter_DataItemDHOpt").hide();
    $("#line_Alter_DataItemDHParamTip").hide();
    // add end
    //end add
    $.get("../conf/config.xml", function (d1) {
      $(d1)
        .find("model")
        .each(function () {
          var $model = $(this);
          $model.find("device[id='" + DeviceID + "']").each(function () {
            var $device = $(this);
            $device.find("commDataItems").each(function () {
              var $commDataItems = $(this);
              $commDataItems
                .find("dataItem[id='" + txt + "']")
                .each(function () {
                  var $dataItem = $(this);
                  var dataItemN = $dataItem.attr("n");
                  NowItemName = dataItemN;
                  var dataItemA = $dataItem.attr("alias");
                  var dataItemID = $dataItem.attr("id");
                  ZundarConfig = dataItemID;
                  var dataItemFreq = $dataItem.attr("freq");
                  var dataItemReport = $dataItem.attr("report");
                  var type_wang = $dataItem.attr("type");
                  var dataItemWR = $dataItem.attr("rw");
                  if (dataItemReport == "3") {
                    $("input[name='Alter_ReportType']").each(function(){
                        if($(this).val()=='1'){
                            $(this).attr("checked",true);
                        }
                    })
                } else {
                    $("input[name='Alter_ReportType']").each(function(){
                        if($(this).val()==dataItemReport){
                            $(this).attr("checked",true);
                        }
                    })
                }

                  var dataItemConfig = $dataItem.attr("config");
                  var ConfigArr = new Array();
                  ConfigArr = dataItemConfig.split(";");
                  //var dataItemAdd = ConfigArr[0] + ConfigArr[2];
                  if (ChannelDeviceType == "GPS") {
                    $("#Alter_DataItemAddress2").val(dataItemConfig);
                  }
                  if (ChannelDeviceType == "JB3102") {
                    $("#Alter_DataItemAddress3").val(
                      dataItemConfig.split(";").length > 0 &&
                        dataItemConfig.split(";")[0]
                    );
                    if (
                      dataItemConfig.split(";").length > 0 &&
                      dataItemConfig.split(";")[0] == "205"
                    ) {
                      $("#Alter_Line_huiluhao").show().next().show();
                      $("#Alter_huiluhao").val(dataItemConfig.split(";")[1]);
                      $("#Alter_Line_dianhao").show().next().show();
                      $("#Alter_dianhao").val(dataItemConfig.split(";")[2]);
                    }
                  }
                  if (ChannelDeviceType == "JB3208") {
                    $("#Alter_DataItemAddress4").val(
                      dataItemConfig.split(";").length > 0 &&
                        dataItemConfig.split(";")[0]
                    );
                    if (
                      dataItemConfig.split(";").length > 0 &&
                      dataItemConfig.split(";")[0] == "104"
                    ) {
                      $("#Alter_Line_huiluhao").show().next().show();
                      $("#Alter_huiluhao").val(dataItemConfig.split(";")[1]);
                      $("#Alter_Line_dianhao").show().next().show();
                      $("#Alter_dianhao").val(dataItemConfig.split(";")[2]);
                    }
                  }
                  var dataItemAdd = "";
                  if (ChannelDeviceType == "HKG-SERIAL") {
                    $("#Alter_ID").val(ConfigArr[0]);
                  }
                  if (
                    ChannelDeviceType == "MITSUBISHI-QS" ||
                    ChannelDeviceType == "MITSUBISHI-QN" ||
                    ChannelDeviceType == "AB-DF1"
                  ) {
                    dataItemAdd = ConfigArr[0];
                    var dataItemType = ConfigArr[1];
                    // add by whc
                  } else if (ChannelDeviceType == "FATEK编程口") {
                    dataItemAdd = ConfigArr[1];
                    dataItemType = ConfigArr[0];
                  } else if (ChannelDeviceType == "SIEMENS-S7-PPI-Task") {
                    dataItemAdd = ConfigArr[0];
                    dataItemType = ConfigArr[1];
                  } else if (ChannelDeviceType == "OPC") {
                    dataItemAdd =
                      ConfigArr.length > 1 ? ConfigArr[1] : ConfigArr[0]; //modfy by bzyang
                    // add end
                  }
                  // add by lh. IEC104
                  else if (ChannelDeviceType == "IEC104") {
                    $("#Alter_DataItemIECAttr").val(ConfigArr[0]);
                    $("#Alter_DataItemIECAttr2").val(ConfigArr[1]);

                    $("#Alter_DataItemIECDataType").val(type_wang);
                  } else if (ChannelDeviceType == "device") {
                    $("#Alter_DataItemIECDataType").val(type_wang);
                  }
                  // add end
                  // add by fyj, OMRON-HostLink-Task
                  else if (
                    ChannelDeviceType == "OMRON-HostLink-Task" ||
                    ChannelDeviceType == "OMRON-FINS-Task"
                  ) {
                    dataItemAdd = ConfigArr[0];
                    dataItemType = ConfigArr[1];
                  } else {
                    if (
                      ChannelDeviceType == "MITSUBISHI-FX" &&
                      (ConfigArr[0] == "X" || ConfigArr[0] == "Y")
                    )
                      dataItemAdd =
                        ConfigArr[0] + Number(ConfigArr[2]).toString(8);
                    else dataItemAdd = ConfigArr[0] + ConfigArr[2];
                    var dataItemType = ConfigArr[1];
                  }
                  // add by fyj , 新增kuka
                  // add begin
                  if (ChannelDeviceType == "KUKA") {
                    var kukaRW = ConfigArr[0];
                    if (kukaRW == "R") {
                      $("#Alter_DataItemKukaR").attr("checked", "checked");
                    } else {
                      $("#Alter_DataItemKukaW").attr("checked", "checked");
                    }
                    var nodeArr = ConfigArr[1].split(":")[1].split(",");
                    var nodeName = nodeArr[0];
                    var nodeIndex = nodeArr[1];
                    var nodeAttr1 = nodeArr[2] || "";
                    var nodeAttr2 = nodeArr[3] || "";
                    $("#Alter_DataItemKukaNodeName").val(nodeName);
                    $("#Alter_DataItemKukaNodeIndex").val(nodeIndex);
                    $("#Alter_DataItemKukaNodeAttr1").val(nodeAttr1);
                    $("#Alter_DataItemKukaNodeAttr2").val(nodeAttr2);

                    var kukaType = ConfigArr[2].split(":")[1];
                    $("#Alter_DataItemKukaDataType").val(kukaType);

                    var kukaOperArr = ConfigArr[3].split(":")[1].split(",");
                    $("#Alter_DataItemKukaDataOperator").val(kukaOperArr[0]);
                    if (!kukaOperArr[1]) {
                      // 没有参数
                      $("#Alter_Line_DataItemKukaParam1").hide();
                      $("#Alter_Line_DataItemKukaParam1Tip").hide();
                      $("#Alter_Line_DataItemKukaParam2").hide();
                      $("#Alter_Line_DataItemKukaParam2Tip").hide();
                      $("#Alter_DataItemKukaParam1").val("").hide();
                      $("#Alter_DataItemKukaParam1Tip").html("").hide();
                      $("#Alter_DataItemKukaParam2").val("").hide();
                      $("#Alter_DataItemKukaParam2Tip").html("").hide();
                    } else if (kukaOperArr[1] && !kukaOperArr[2]) {
                      // 有一个参数
                      $("#Alter_Line_DataItemKukaParam1").show();
                      $("#Alter_Line_DataItemKukaParam1Tip").show();
                      $("#Alter_Line_DataItemKukaParam2").hide();
                      $("#Alter_Line_DataItemKukaParam2Tip").hide();
                      $("#Alter_DataItemKukaParam1").val(kukaOperArr[1]).show();
                      $("#Alter_DataItemKukaParam1Tip").html("").show();
                      if (coo == "English") {
                        $("#Alter_DataItemKukaParam1Text").text("Parameters:");
                      } else {
                        $("#Alter_DataItemKukaParam1Text").text("参数：");
                      }
                      $("#Alter_DataItemKukaParam2").val("").hide();
                      $("#Alter_DataItemKukaParam2Tip").html("").hide();
                    } else {
                      // 有两个参数
                      $("#Alter_Line_DataItemKukaParam1").show();
                      $("#Alter_Line_DataItemKukaParam1Tip").show();
                      $("#Alter_Line_DataItemKukaParam2").show();
                      $("#Alter_Line_DataItemKukaParam2Tip").show();
                      $("#Alter_DataItemKukaParam1").val(kukaOperArr[1]).show();
                      $("#Alter_DataItemKukaParam1Tip").html("").show();
                      if (coo == "English") {
                        $("#Alter_DataItemKukaParam1Text").text("Parameters1:");
                      } else {
                        $("#Alter_DataItemKukaParam1Text").text("参数1：");
                      }
                      $("#Alter_DataItemKukaParam2").val(kukaOperArr[2]).show();
                      $("#Alter_DataItemKukaParam2Tip").html("").show();
                    }
                  }
                  // add by fyj. DLT645-2007
                  if (
                    ChannelDeviceType == "DLT645-2007" ||
                    ChannelDeviceType == "DLT645-1997"
                  ) {
                    $("#Alter_DataItemDltEnergy").val(dataItemConfig);
                    $("#Alter_DataItemType").val(type_wang);
                  }
                  // add end
                  // add by lh, OPC-UA
                  if (ChannelDeviceType == "OPC-UA") {
                    $("#Alter_DataItemDataItemUAattr1").val(ConfigArr[0]);
                    $("#Alter_DataItemUAType").val(type_wang);
                  }
                  if (ChannelDeviceType == "MITSUBISHI-TXZ-MomMach" || ChannelDeviceType == "MITSUBISHI-TXZ-SubMach1" || ChannelDeviceType == "MITSUBISHI-TXZ-SubMach2") {
                    $("#Alter_DataItemUAType").val(type_wang);
                    $("#Alter_CommandType").val(ConfigArr[0]);
                    $("#Alter_TXZAddress1").val(ConfigArr[1]);
                    $("#Alter_TXZAddress2").val(ConfigArr[2]);
                    if (ConfigArr[0] == "G9") {
                      if (coo == "English") {
                        $(".MITSUBISHI-TXZ-address1").html(
                          "Indoor unit address:"
                        );
                      } else {
                        $(".MITSUBISHI-TXZ-address1").html("室内机地址：");
                      }
                    } else {
                      if (coo == "English") {
                        $(".MITSUBISHI-TXZ-address1").html("Machine Type:");
                      } else {
                        $(".MITSUBISHI-TXZ-address1").html("机器类型：");
                      }
                    }
                  }
                  // add end
                  if (ChannelDeviceType == "MITSUBISHI-TX-15P") {
                    $("#Alter_DataItemTXType").val(type_wang);
                    $("#Alter_TX_config-hidden").val(dataItemConfig);
                    $("#Alter_TX_config").val(
                      findKey(TX15PMap, dataItemConfig)
                    );
                  }
                  if (ChannelDeviceType == "MITSUBISHI-TX-5HP") {
                    $("#Alter_DataItemTXType").val(type_wang);
                    $("#Alter_TX_config-hidden").val(dataItemConfig);
                    $("#Alter_TX_config").val(
                      findKey(TX5HPMap, dataItemConfig)
                    );
                  }
                  if (ChannelDeviceType == "MITSUBISHI-TX-Multi-link") {
                    $("#Alter_DataItemTXType").val(type_wang);
                    $("#Alter_TX_config-hidden").val(dataItemConfig);
                    $("#Alter_TX_config").val(
                      findKey(TXMultiMap, dataItemConfig)
                    );
                  }
                  if (ChannelDeviceType == "R1R2") {
                    $("#Alter_Samsung_DataItemType").val(type_wang);
                    $("#Alter_Samsung_Address").val(ConfigArr[0]);
                    $("#Alter_Samsung_Mode").val(ConfigArr[1]);
                  }
                  // add end
                  if (dataItemWR == "0")
                    document.getElementById("RWmode1Info").checked = "checked";
                  if (dataItemWR == "1")
                    document.getElementById("RWmode2Info").checked = "checked";
                  document.getElementById(
                    "Alter_DataItemID"
                  ).value = dataItemID;
                  document.getElementById(
                    "Alter_DataItemName"
                  ).value = dataItemN;
                  document.getElementById(
                    "Alter_DataItemAlias"
                  ).value = dataItemA;
                  if (
                    ChannelDeviceType == "OMRON_NJNX" ||
                    ChannelDeviceType == "HKG-SERIAL" ||
                    ChannelDeviceType == "Custom-TCP" ||
                    ChannelDeviceType == "OPC"
                  ) {
                    $("#Alter_DatasName").val(ConfigArr[0]);
                    if (type_wang == "a") {
                      type_wang = "FLOAT";
                    } else if (type_wang == "b") {
                      type_wang = "BIT";
                    } else {
                      type_wang = "STRING";
                    }
                    $("#Alter_DataItemType").val(type_wang);
                  }
                  // add by whc
                  if (ChannelDeviceType == "DRACAL") {
                    if (type_wang == "a") {
                      type_wang = "FLOAT";
                    }
                    $("#Alter_DataItemType").val(type_wang);
                    $("#Alter_DataItemDRACALChannel").val(dataItemConfig);
                  }
                  // add end
                  if (
                    ChannelDeviceType == "YinHe" ||
                    ChannelDeviceType == "Custom-TCP"
                  ) {
                    document.getElementById("Alter_DataItemAddress").value =
                      ConfigArr[0];
                  } else if (ChannelDeviceType == "OPC-UA") {
                    $("#Alter_DataItemAddress").val(ConfigArr[1]);
                  } else if (ChannelDeviceType == "device") {
                    $("#Alter_DataItemAddress").val(dataItemConfig);
                  } else if (ChannelDeviceType == "HMI") {
                    $("#Alter_DataItemAddress").val(ConfigArr[0]);
                  } else {
                    document.getElementById(
                      "Alter_DataItemAddress"
                    ).value = dataItemAdd;
                  }

                  if (
                    ChannelDeviceType != "YinHe" &&
                    ChannelDeviceType != "Zundar" &&
                    ChannelDeviceType != "OMRON_NJNX" &&
                    ChannelDeviceType != "HKG-SERIAL" &&
                    ChannelDeviceType != "Custom-TCP" &&
                    ChannelDeviceType != "GPS" &&
                    ChannelDeviceType != "JB3102" &&
                    ChannelDeviceType != "JB3208" &&
                    ChannelDeviceType != "DLT645-2007" &&
                    ChannelDeviceType != "DLT645-1997" &&
                    ChannelDeviceType != "OPC" &&
                    ChannelDeviceType != "IEC104" &&
                    ChannelDeviceType != "device" &&
                    ChannelDeviceType != "MITSUBISHI-TXZ-MomMach" &&
                    ChannelDeviceType != "MITSUBISHI-TXZ-SubMach1" &&
                    ChannelDeviceType != "MITSUBISHI-TXZ-SubMach2" &&
                    ChannelDeviceType != "MITSUBISHI-TX-15P" &&
                    ChannelDeviceType != "MITSUBISHI-TX-5HP" &&
                    ChannelDeviceType != "MITSUBISHI-TX-Multi-link" &&
                    ChannelDeviceType != "R1R2" &&
                    ChannelDeviceType != "DRACAL"
                  ) {
                    // modified by fyj
                    // begin
                    if (ChannelDeviceType == "SIEMENS-PPI") {
                      var typeMap = {
                        BIT: "Boolean",
                        BYTE: "Byte",
                        WORD: "Word",
                        SHORT: "Short",
                        DWORD: "DWord",
                        LONG: "Long",
                        FLOAT: "Float",
                        STRING: "String",
                        INT8: "Int 8",
                        INT16: "Int 16",
                        INT32: "Int 32",
                        BCD: "BCD",
                      };
                    }
                    // end

                    // add by whc
                    if (ChannelDeviceType == "SIEMENS-S7-PPI-Task") {
                      var typeMap = {
                        BIT: "Bit",
                        INT8: "Int 8",
                        UINT8: "UInt8",
                        INT16: "Int16",
                        UINT16: "UInt16",
                        INT32: "Int32",
                        UINT32: "UInt32",
                        FLOAT: "Float",
                        BCD: "BCD",
                      };
                    }
                    // add end

                    if (dataItemType.indexOf("STRING") != -1) {
                      // modified by fyj
                      // begin
                      //document.getElementById("Alter_DataItemType").value = "STRING";
                      if (ChannelDeviceType == "SIEMENS-PPI") {
                        $("#Alter_DataItemTypeIpt").val("String");
                      } else {
                        document.getElementById("Alter_DataItemType").value =
                          "STRING";
                      }
                      // end
                      $("#Alter_tr_string").show();
                      $("#Alter_tr_string_msg").show();
                      $("#Alter_stringLength").val(dataItemType.substr(6));
                    } else {
                      // modified by fyj
                      // begin
                      // document.getElementById("Alter_DataItemType").value = dataItemType;
                      if (
                        ChannelDeviceType == "SIEMENS-PPI" ||
                        ChannelDeviceType == "SIEMENS-S7-PPI-Task"
                      ) {
                        var typeStr = typeMap[dataItemType] || dataItemType;
                        $("#Alter_DataItemTypeIpt").val(typeStr);
                      } else {
                        document.getElementById(
                          "Alter_DataItemType"
                        ).value = dataItemType;
                      }
                      $("#Alter_tr_string").hide();
                      $("#Alter_tr_string_msg").hide();
                    }
                  }
                  var Freq = "";
                  if (dataItemFreq % 60000 == 0) {
                    Freq = dataItemFreq / 60000;
                    $("#Alter_DataItemUnit").val("minute");
                  } else {
                    Freq = dataItemFreq / 1000;
                    $("#Alter_DataItemUnit").val("second");
                  }
                  document.getElementById("Alter_DataItemFreq").value = Freq;
                  // document.getElementById("Alter_DataItemReport").value = dataItemReport;
                });
            });
          });
        });
      // add by fyj, OMRON-HostLink增加datahandler驱动

      $(d1)
        .find('task dataHandler item[id="' + txt + '"]')
        .each(function () {
          $("#line_Alter_DataItemDHEnable").show();
          $("#line_Alter_DataItemDHOpt").show();
          $("#line_Alter_DataItemDHParamTip").show();
          var dhItem = $(this);
          $("#DHMode2_alter").attr("checked", "checked");
          var dhOptType = dhItem.attr("op");
          var dhOptParam = dhItem.attr("coe");
          if (dhOptType == "+") {
            dhOptType = "1";
          } else if (dhOptType == "-") {
            dhOptType = "2";
          } else if (dhOptType == "*") {
            dhOptType = "3";
          } else if (dhOptType == "/") {
            dhOptType = "4";
          } else if (dhOptType == "b") {
            dhOptType = "5";
            // $('#RWmode2Info').attr('disabled', true);
          }
          $("#Alter_DataItemDHSelect").val(dhOptType);
          if (dhOptType == "#") {
            $("#Alter_DataItemDHParam").hide();
            $("#Alter_DHFunctionParam1").show();
            $("#Alter_DHFunctionParam2").show();
            var reBrackets = /\([^\)]+\)/g;
            var coeList = dhOptParam.match(reBrackets);
            $("#Alter_DHFunctionParam1").val(
              coeList[0].substring(1, coeList[0].length - 1)
            );
            $("#Alter_DHFunctionParam2").val(
              coeList[1].substring(1, coeList[1].length - 1)
            );
          } else {
            $("#Alter_DataItemDHParam").show();
            $("#Alter_DHFunctionParam1").hide();
            $("#Alter_DHFunctionParam2").hide();
            $("#Alter_DataItemDHParam").val(dhOptParam);
          }
        });
      // add end
    });
    document.getElementById("popWindow").style.display = "";
    document.getElementById("Alter_DataItem_Layer").style.display = "";
  });
}

// add by fyj, OMRON-HostLink增加datahandler驱动
function DHEnableClicked(radioVal) {
  if (radioVal == "0") {
    $("#line_Add_DataItemDHOpt").hide();
    $("#line_Add_DataItemDHParamTip").hide();
  } else {
    $("#line_Add_DataItemDHOpt").show();
    $("#line_Add_DataItemDHParamTip").show();
  }
}

function DHEnableClicked_alter(radioVal) {
  if (radioVal == "0") {
    $("#line_Alter_DataItemDHOpt").hide();
    $("#line_Alter_DataItemDHParamTip").hide();
  } else {
    $("#line_Alter_DataItemDHOpt").show();
    $("#line_Alter_DataItemDHParamTip").show();
  }
}

function ChangeDHSelect(dhSelect) {
  var optType = $(dhSelect).val();
  if (optType == "#") {
    $("#Add_DataItemDHParam").hide();
    $("#Add_DHFunctionParam1").show();
    $("#Add_DHFunctionParam2").show();
  } else {
    $("#Add_DataItemDHParam").show();
    $("#Add_DHFunctionParam1").hide();
    $("#Add_DHFunctionParam2").hide();
  }
}

function ChangeDHSelect_alter(dhSelect) {
  var optType = $(dhSelect).val();
  if (optType == "#") {
    $("#Alter_DataItemDHParam").hide();
    $("#Alter_DHFunctionParam1").show();
    $("#Alter_DHFunctionParam2").show();
  } else {
    $("#Alter_DataItemDHParam").show();
    $("#Alter_DHFunctionParam1").hide();
    $("#Alter_DHFunctionParam2").hide();
  }
}
// add end

//弹出PLC数据项添加层
function openPLCadd() {
  getID();
  document.getElementById("Add_Line_DataItemType").style.display = "";
  document.getElementById("Add_DataItemName").value = "";
  document.getElementById("Add_DataItemAddress").value = "";
  document.getElementById("idTip").innerHTML = "";
  document.getElementById("nameTip").innerHTML = "";
  document.getElementById("AliasTip").innerHTML = "";
  document.getElementById("addressTip").innerHTML = "";
  document.getElementById("checkTwo").innerHTML = "";
  document.getElementById("stringMsg").innerHTML = "";
  // add by fyj, hostlink add datahandler
  // document.getElementById("Add_DataItemDHParamTip").innerHTML = "";
  $("#Add_DataItemDHParamTip").html("");
  // add end

  $("#freqTip").html("");
  document.getElementsByName("Add_DataItemRWmode").value = "0";
  // document.getElementById("Add_DataItemReport").value = "1";
  $("input[name='Add_ReportType']").each(function(){
    if($(this).val()=="1"){
        $(this).attr("checked",true);
    }
})
  document.getElementById("popWindow").style.display = "";
  document.getElementById("Add_DataItem_Layer").style.display = "";
  $("#Add_DataItemAlias").val("");
  //add begin by x
  if (ChannelDeviceType == "GPS") {
    $("#Add_Line_DataItemType").hide();
  }
  //end add
  // add begin by x
  // 火警控制器数据项地址只能从已有的选择,数据项类型为string类型
  if (ChannelDeviceType == "JB3102") {
    $("#Add_Line_DataItemAddress3").show();
    $("#Add_Line_DataItemAddress").hide();
    $("#Add_Line_DataItemType").hide();
    $("#Add_DataItemType")
      .find('option[value="STRING"]')
      .attr("selected", "selected");
    $("#Add_Line_DataItemType").hide().next().hide();
    //绑定事件
    $("#Add_DataItemAddress3")
      .unbind()
      .bind("change", function () {
        if ($(this).val() === "205") {
          $("#Add_Line_huiluhao").show().next().show();
          $("#Add_Line_dianhao").show().next().show();
        } else {
          $("#Add_Line_huiluhao").hide().next().hide();
          $("#Add_Line_dianhao").hide().next().hide();
        }
      });
  }
  if (ChannelDeviceType == "JB3208") {
    $("#Add_Line_DataItemAddress4").show();
    $("#Add_Line_DataItemAddress").hide();
    $("#Add_Line_DataItemType").hide();
    $("#Add_DataItemType")
      .find('option[value="STRING"]')
      .attr("selected", "selected");
    $("#Add_Line_DataItemType").hide().next().hide();
    //绑定事件
    $("#Add_DataItemAddress4")
      .unbind()
      .bind("change", function () {
        if ($(this).val() === "104") {
          $("#Add_Line_huiluhao").show().next().show();
          $("#Add_Line_dianhao").show().next().show();
        } else {
          $("#Add_Line_huiluhao").hide().next().hide();
          $("#Add_Line_dianhao").hide().next().hide();
        }
      });
  }
  //end add
  if (ChannelDeviceType == "YinHe") {
    document.getElementById("Add_Line_DataItemType").style.display = "none";
    $("#line_checkTwo").hide();
    $("#nouse").hide();

    $("#Add_DataItem_Layer").css("min-height", "300px");
    $("#Add_DataItem_Layer").css("max-height", "550px");
  }
  if (ChannelDeviceType == "Zundar") {
    document.getElementById("Add_Line_DataItemType").style.display = "none";
    document.getElementById("Add_Line_DataItemAddress").style.display = "none";
    $("#line_checkTwo").hide();
    $("#line_addressTip").hide();
    $("#nouse").hide();
    $("#Add_DataItem_Layer").css("min-height", "300px");
    $("#Add_DataItem_Layer").css("max-height", "450px");
  }
  if (ChannelDeviceType == "OMRON_NJNX") {
    $("#Add_Line_DataItemName").show();
    $("#Add_Line_DataItemAddress").hide();
    $("#line_dataPnameTip").show();
    $("#line_addressTip").hide();
    $("#Add_DataItemType").empty();
    if (coo == "English") {
      var str =
        "<option value='BIT' selected>Switch quantity</option><option value='FLOAT'>Numerical value</option><option value='STRING'>String</option>";
    } else {
      var str =
        "<option value='BIT' selected>开关量</option><option value='FLOAT'>数值</option><option value='STRING'>字符串</option>";
    }
    $("#Add_DataItemType").append(str);
  }
  // add by whc
  if (ChannelDeviceType == "DRACAL") {
    $("#Add_Line_DataItemDRACALChannel").show();
    $("#Add_Line_DataItemDRACALChannelTip").show();
    $("#Add_Line_DataItemAddress").hide();
    $("#ChannelTip").show();
    $("#line_addressTip").hide();
    $("#Add_DataItemType").empty();
    var str = "<option value='FLOAT'>数值</option>";
    if (coo == "English") {
      str = "<option value='FLOAT'>Numerical</option>";
    }
    $("#Add_DataItemType").append(str);
  }
  // add end
  if (ChannelDeviceType == "HKG-SERIAL") {
    document.getElementById("Add_Line_DataItemAddress").style.display = "none";
    $("#line_checkTwo").hide();
    $("#line_addressTip").hide();
    $("#line_addressTipInfo").hide();
    $("#Add_ID_msg_wang").show();
    $("#Add_ID_wang").show();
    $("#Add_DataItemType").empty();
    if (coo == "English") {
      var str =
        "<option value='BIT' selected>Switch quantity</option><option value='FLOAT'>Numerical value</option><option value='STRING'>String</option>";
    } else {
      var str =
        "<option value='BIT' selected>开关量</option><option value='FLOAT'>数值</option><option value='STRING'>字符串</option>";
    }
    $("#Add_DataItemType").append(str);
    $("#Add_DataItem_Layer").css("min-height", "400px");
    $("#Add_DataItem_Layer").css("max-height", "470px");
  }
  if (ChannelDeviceType == "Custom-TCP" || ChannelDeviceType == "OPC") {
    $("#Add_DataItemType").empty();
    if (coo == "English") {
      var str =
        "<option value='BIT' selected>Switch quantity</option><option value='FLOAT'>Numerical value</option><option value='STRING'>String</option>";
    } else {
      var str =
        "<option value='BIT' selected>开关量</option><option value='FLOAT'>数值</option><option value='STRING'>字符串</option>";
    }
    $("#Add_DataItemType").append(str);
  }

  if (
    ChannelDeviceType == "OMRON-HostLink" ||
    ChannelDeviceType == "OMRON-TCP" ||
    ChannelDeviceType == "OMRON-FINS"
  ) {
    var isExit = false;
    var count = $("#Add_DataItemType").find("option").length;
    for (var i = 0; i < count; i++) {
      if ($("#Add_DataItemType").get(0).options[i].value == "BCD") {
        isExit = true;
        break;
      }
    }
    if (!isExit) {
      $("#Add_DataItemType").append('<option value="BCD">BCD</option>');
    }
  }

  // add by bzyang, OMRON-hostlink任务数据类型增加BCD
  if (
    ChannelDeviceType == "OMRON-HostLink-Task" ||
    ChannelDeviceType == "OMRON-FINS-Task"
  ) {
    $("#Add_DataItemType").empty();
    var str = "";
    if (coo == "English") {
      str =
        "<option value='BIT' selected>Bool</option><option value='UINT16'>UInt16</option><option value='INT16'>Int16</option>\
            <option value='UINT32' selected>UInt32</option><option value='INT32'>Int32</option><option value='FLOAT'>Float</option><option value='BCD'>BCD</option>";
    } else {
      str =
        "<option value='BIT' selected>Boolean</option><option value='UINT16'>UInt16</option><option value='INT16'>Int16</option>\
        <option value='UINT32' selected>UInt32</option><option value='INT32'>Int32</option><option value='FLOAT'>Float</option><option value='BCD'>BCD</option>";
    }
    $("#Add_DataItemType").append(str);
  }
  // add end

  // add by fyj, OMRON-HostLink增加datahandler驱动
  if (
    ChannelDeviceType == "OMRON-HostLink" ||
    ChannelDeviceType == "OMRON-HostLink-Task" ||
    ChannelDeviceType == "OMRON-FINS-Task"
  ) {
    $("#line_Add_DataItemDHEnable").show();
    $("#DHMode1").attr("checked", "checked");
    $("#RWmode2").attr("disabled", false);
    $("#line_Add_DataItemDHOpt").hide();
    $("#line_Add_DataItemDHParamTip").hide();
    $("#Add_DataItemDHParam").val("");
    $("#Add_DataItemDHSelect").val("1");
  }

  // add by whc,SIEMENS-S7-PPI-Task驱动增加自定义数据项类型
  if (
    ChannelDeviceType == "SIEMENS-S7-PPI-Task" &&
    $("#Alter_DataItemTypeIpt".length == 0)
  ) {
    var typeMap = {
      BIT: "Bit",
      INT8: "Int8",
      UINT8: "UInt8",
      INT16: "Int16",
      UINT16: "UInt16",
      INT32: "Int32",
      UINT32: "UInt32",
      FLOAT: "Float",
      BCD: "BCD",
    };
    var str =
      '<option value="BIT" selected>Bit</option>' +
      '<option value="INT8">Int8</option>' +
      '<option value="UINT8">UInt8</option>' +
      '<option value="INT16">Int16</option>' +
      '<option value="UINT16">UInt16</option>' +
      '<option value="INT32">Int32</option>' +
      '<option value="UINT32">UInt32</option>' +
      '<option value="FLOAT">Float</option>' +
      '<option value="BCD">BCD</option>';

    var $div = $("<div>").css({
      position: "relative",
    });

    var $input = $("<input>")
      .attr({
        value: "BIT",
        id: "Add_DataItemTypeIpt",
      })
      .css({
        width: 170,
        height: 18.5,
        position: "absolute",
        left: 0,
        top: 3.5,
      });

    var $sel = $("<select>")
      .attr({
        name: "Add_DataItemType",
        id: "Add_DataItemType",
      })
      .css({
        width: 195,
        height: 25,
      })
      .html(str)
      .change(function () {
        $input.val(typeMap[$(this).val()]);
      });

    $("#Add_DataItemType").remove();

    $sel.appendTo($div);
    $input.appendTo($div);

    $("#Add_Line_DataItemType div[align=left]").empty().append($div);
  }
  // add end
  // add begin by fyj
  // 数据项类型改成用户可以自定义的
  if (ChannelDeviceType == "SIEMENS-PPI") {
    // $("#Add_DataItemType").empty();
    var typeMap = {
      BIT: "Boolean",
      BYTE: "Byte",
      WORD: "Word",
      SHORT: "Short",
      DWORD: "DWord",
      LONG: "Long",
      FLOAT: "Float",
      STRING: "String",
      INT8: "Int 8",
      INT16: "Int 16",
      INT32: "Int 32",
      BCD: "BCD",
    };
    var str =
      '<option value="BIT" selected>Boolean</option>' +
      '<option value="BYTE">Byte</option>' +
      '<option value="WORD">Word</option>' +
      '<option value="SHORT">Short</option>' +
      '<option value="DWORD">DWord</option>' +
      '<option value="LONG">Long</option>' +
      '<option value="FLOAT">Float</option>' +
      '<option value="STRING">String</option>' +
      '<option value="INT8">Int 8</option>' +
      '<option value="INT16">Int 16</option>' +
      '<option value="INT32">Int 32</option>' +
      '<option value="BCD">BCD</option>';
    // $("#Add_DataItemType").append(str);

    var $div = $("<div>").css({
      position: "relative",
    });

    var $input = $("<input>")
      .attr({
        value: "Boolean",
        id: "Add_DataItemTypeIpt",
      })
      .css({
        width: 170,
        height: 18.5,
        position: "absolute",
        left: 0,
        top: 3.5,
      });

    var $sel = $("<select>")
      .attr({
        name: "Add_DataItemType",
        id: "Add_DataItemType",
      })
      .css({
        width: 195,
        height: 25,
      })
      .html(str)
      .change(function () {
        $input.val(typeMap[$(this).val()]);
      })
      .change(function () {
        if (
          $(this).val() == "STRING" &&
          ChannelDeviceType != "OMRON_NJNX" &&
          ChannelDeviceType != "HKG-SERIAL" &&
          ChannelDeviceType != "Custom-TCP" &&
          ChannelDeviceType != "OPC" &&
          ChannelDeviceType != "DRACAL"
        ) {
          $("#tr_string").show();
          $("#tr_string_msg").show();
        } else {
          $("#tr_string").hide();
          $("#tr_string_msg").hide();
        }
      });

    $("#Add_DataItemType").remove();

    $sel.appendTo($div);
    $input.appendTo($div);
    $("#Add_Line_DataItemType div[align=left]").empty().append($div);
  }
  // add end
  // add by whc, 新增OPC驱动
  // if (ChannelDeviceType == 'OPC') {
  //     $("#Add_Line_DataItemAlias").hide();
  //     $("#Alter_Line_DataItemAlias").hide();
  // }
  // add end
  // add by fyj, 新增KUKA驱动
  // add begin
  if (ChannelDeviceType == "KUKA") {
    $("#Add_Line_DataItemAddress").hide();
    $("#Add_Line_DataItemType").hide();
    $("#line_addressTip").hide();
    $("#line_Add_DataItemTypeTip").hide();
    $("#Add_DataItem_Layer tr.second-last").hide();

    $("#Add_DataItem_Layer tr.driver_kuka").show();
    $("#Add_Line_DataItemKukaParam1").hide();
    $("#Add_Line_DataItemKukaParam1Tip").hide();
    $("#Add_Line_DataItemKukaParam2").hide();
    $("#Add_Line_DataItemKukaParam2Tip").hide();

    $("#Add_DataItemKukaR").attr("checked", "checked");
    $("#Add_DataItemKukaNodeName").val("");
    $("#Add_DataItemKukaNodeNameTip").html("");
    $("#Add_DataItemKukaNodeIndex").val("");
    $("#Add_DataItemKukaNodeIndexTip").html("");
    $("#Add_DataItemKukaNodeAttr1").val("");
    $("#Add_DataItemKukaNodeAttr1Tip").html("");
    $("#Add_DataItemKukaNodeAttr2").val("");
    $("#Add_DataItemKukaNodeAttr2Tip").html("");
    $("#Add_DataItemKukaDataType").val();
    $("#Add_DataItemKukaDataType").val("0");
    if (coo == "English") {
      $("#Add_DataItemKukaParam1Text").text("Parameters:");
    } else {
      $("#Add_DataItemKukaParam1Text").text("参数：");
    }

    $("#Add_DataItemKukaParam1").val("").hide();
    $("#Add_DataItemKukaParam1Tip").html("").hide();
    $("#Add_DataItemKukaParam2").val("").hide();
    $("#Add_DataItemKukaParam2Tip").html("").hide();

    $("#Add_DataItemKukaDataOperator")
      .val("0")
      .change(function () {
        var $selVal = $(this).val();
        if ($selVal == "0") {
          // 无, 无参数
          $("#Add_Line_DataItemKukaParam1").hide();
          $("#Add_Line_DataItemKukaParam1Tip").hide();
          $("#Add_Line_DataItemKukaParam2").hide();
          $("#Add_Line_DataItemKukaParam2Tip").hide();
          $("#Add_DataItemKukaParam1").val("").hide();
          $("#Add_DataItemKukaParam1Tip").html("").hide();
          $("#Add_DataItemKukaParam2").val("").hide();
          $("#Add_DataItemKukaParam2Tip").html("").hide();
        } else if ($selVal == "1") {
          // 掩码, 1个参数
          $("#Add_Line_DataItemKukaParam1").show();
          $("#Add_Line_DataItemKukaParam1Tip").show();
          $("#Add_Line_DataItemKukaParam2").hide();
          $("#Add_Line_DataItemKukaParam2Tip").hide();
          $("#Add_DataItemKukaParam1").val("").show();
          $("#Add_DataItemKukaParam1Tip").html("").show();
          if (coo == "English") {
            $("#Add_DataItemKukaParam1Text").text("Parameters:");
          } else {
            $("#Add_DataItemKukaParam1Text").text("参数：");
          }
          $("#Add_DataItemKukaParam2").val("").hide();
          $("#Add_DataItemKukaParam2Tip").html("").hide();
        } else if ($selVal == "2") {
          // 倍率, 2个参数
          $("#Add_Line_DataItemKukaParam1").show();
          $("#Add_Line_DataItemKukaParam1Tip").show();
          $("#Add_Line_DataItemKukaParam2").show();
          $("#Add_Line_DataItemKukaParam2Tip").show();
          $("#Add_DataItemKukaParam1").val("").show();
          $("#Add_DataItemKukaParam1Tip").html("").show();
          if (coo == "English") {
            $("#Add_DataItemKukaParam1Text").text("Parameters1:");
          } else {
            $("#Add_DataItemKukaParam1Text").text("参数1：");
          }
          $("#Add_DataItemKukaParam2").val("").show();
          $("#Add_DataItemKukaParam2Tip").html("").show();
        } else if ($selVal == "3") {
          // 线性, 2个参数
          $("#Add_Line_DataItemKukaParam1").show();
          $("#Add_Line_DataItemKukaParam1Tip").show();
          $("#Add_Line_DataItemKukaParam2").show();
          $("#Add_Line_DataItemKukaParam2Tip").show();
          $("#Add_DataItemKukaParam1").val("").show();
          $("#Add_DataItemKukaParam1Tip").html("").show();
          if (coo == "English") {
            $("#Add_DataItemKukaParam1Text").text("Parameters1:");
          } else {
            $("#Add_DataItemKukaParam1Text").text("参数1：");
          }
          $("#Add_DataItemKukaParam2").val("").show();
          $("#Add_DataItemKukaParam2Tip").html("").show();
        }
      });
  }
  // add end
  if (ChannelDeviceType == "OPC-UA") {
    $("#Add_Line_DataItemUAattr1").show();
    $("#Add_Line_DataItemType").hide();
    $("#Add_Line_DataItemUAType").show();
    $("#Add_Line_DataItemAddress").hide();
    $("#line_addressTip").hide();
    $("#line_Add_DataItemTypeTip").show();
    $("#additional_line3").show();
    //OPC-UA驱动采集频率支持毫秒 为了不重复进行append 需设置标志位
    if (UA1 == 0) {
      if (coo == "English") {
        $("#Add_DataItemUnit").append("<option value='ms'>ms</option>");
      } else {
        $("#Add_DataItemUnit").append("<option value='ms'>毫秒</option>");
      }
      UA1++;
    }
  }
  // add by fyj, DLT645-2007
  if (
    ChannelDeviceType == "DLT645-2007" ||
    ChannelDeviceType == "DLT645-1997"
  ) {
    $("#Add_Line_DataItemAddress").hide();
    $("#line_addressTip").hide();
    $("#Add_Line_DataItemDltEnergy").show();
    $("#Add_Line_DataItemDltEnergyTip").show();
    $("#Add_DataItemType").html("");
    $("#Add_DataItemDltEnergy").val("");
    if (coo == "English") {
      $("#Add_DataItemType").append(
        "<option value='b'>Switch quantity</option><option value='a' selected>Numerical value</option><option value='s'>String</option>"
      );
    } else {
      $("#Add_DataItemType").append(
        "<option value='b'>开关量</option><option value='a' selected>数值量</option><option value='s'>字符串</option>"
      );
    }
  }
  // add end
  // add by lh, IEC104
  if (ChannelDeviceType == "IEC104") {
    $("#Add_Line_DataItemAddress").hide();
    $("#Add_Line_DataItemType").hide();
    $("#Add_Line_DataItemIECAttr").show();
    $("#Add_Line_DataItemIECAttr2").show();
    $("#Add_Line_DataItemIECDataType").show();

    $("#line_Add_DataItemTypeTip").hide();
    $("#additional_line6").show();
    $("#additional_line7").show();
  }
  if (ChannelDeviceType == "device") {
    $("#Add_Line_DataItemType").hide();
    $("#Add_Line_DataItemIECDataType").show();
  }
  if (ChannelDeviceType == "MITSUBISHI-TXZ-MomMach" || ChannelDeviceType == "MITSUBISHI-TXZ-SubMach1" || ChannelDeviceType == "MITSUBISHI-TXZ-SubMach2" ) {
    $("#Add_DataItem_Layer").css("top", "3px");
    $("#Add_Line_DataItemAddress").hide();
    $("#Add_Line_DataItemType").hide();
    $("#Add_Line_CommandType").show();
    $("#Add_Line_TXZ_address1").show();
    $("#Add_Line_TXZ_address2").show();
    $("#line_addressTip").hide();
    $("#line_Add_DataItemTypeTip").hide();
    $("#Add_Line_DataItemUAType").show();
    if (coo == "English") {
      $(".MITSUBISHI-TXZ-address1").html("Machine Type:");
    } else {
      $(".MITSUBISHI-TXZ-address1").html("机器类型：");
    }
    $("#Add_CommandType").val("G0");
    $("#Add_TXZAddress1").val("");
    $("#Add_TXZAddress2").val("");
    $("#Add_CommandType").change(function () {
      var val = $(this).val();
      if (val == "G9") {
        if (coo == "English") {
          $(".MITSUBISHI-TXZ-address1").html("Indoor unit address:");
        } else {
          $(".MITSUBISHI-TXZ-address1").html("室内机地址：");
        }
      } else {
        if (coo == "English") {
          $(".MITSUBISHI-TXZ-address1").html("Machine Type:");
        } else {
          $(".MITSUBISHI-TXZ-address1").html("机器类型：");
        }
      }
    });
  }
  if (ChannelDeviceType == "MITSUBISHI-TX-15P") {
    $("#Add_DataItem_Layer").css("top", "3px");
    $("#Add_Line_DataItemAddress").hide();
    $("#line_addressTip").hide();
    $("#Add_Line_DataItemType").hide();
    $("#Add_Line_DataItemTXType").show();
    $("#line_Add_DataItemTypeTip").hide();
    $("#Add_Line_TX_Config").show();
    $("#TXConfigTipLine").show();
    $("#TXConfig").empty();
    $("#Add_TX_config").val("");
    $("#TXConfigTip").html("");
    for (var key in TX15PMap) {
      $("#TXConfig").append(
        '<option data-value="' + TX15PMap[key] + '">' + key + "</option>"
      );
    }
  }
  if (ChannelDeviceType == "MITSUBISHI-TX-5HP") {
    $("#Add_DataItem_Layer").css("top", "3px");
    $("#Add_Line_DataItemAddress").hide();
    $("#line_addressTip").hide();
    $("#Add_Line_DataItemType").hide();
    $("#Add_Line_DataItemTXType").show();
    $("#line_Add_DataItemTypeTip").hide();
    $("#Add_Line_TX_Config").show();
    $("#TXConfigTipLine").show();
    $("#TXConfig").empty();
    $("#Add_TX_config").val("");
    $("#TXConfigTip").html("");
    for (var key in TX5HPMap) {
      $("#TXConfig").append(
        '<option data-value="' + TX5HPMap[key] + '">' + key + "</option>"
      );
    }
  }
  if (ChannelDeviceType == "MITSUBISHI-TX-Multi-link") {
    $("#Add_DataItem_Layer").css("top", "3px");
    $("#Add_Line_DataItemAddress").hide();
    $("#line_addressTip").hide();
    $("#Add_Line_DataItemType").hide();
    $("#Add_Line_DataItemTXType").show();
    $("#line_Add_DataItemTypeTip").hide();
    $("#Add_Line_TX_Config").show();
    $("#TXConfigTipLine").show();
    $("#TXConfig").empty();
    $("#Add_TX_config").val("");
    $("#TXConfigTip").html("");
    for (var key in TXMultiMap) {
      $("#TXConfig").append(
        '<option data-value="' + TXMultiMap[key] + '">' + key + "</option>"
      );
    }
  }
  if (ChannelDeviceType == "R1R2") {
    $("#Add_Line_DataItemAddress").hide();
    $("#Add_Line_DataItemType").hide();
    $("#Add_Line_Samsung_Address").show();
    $("#Add_Line_Samsung_Mode").show();
    $("#Add_Line_Samsung_DataItemType").show();
    $("#line_addressTip").hide();
    $("#line_Add_DataItemTypeTip").hide();
    $("#line_Add_Samsung_AddressTip").show();
    $("#additional_line8").show();
    $("#additional_line9").show();
  }
  // add end
  $("#line_Add_DataItemDHEnable").show();
  $("#DHMode1").attr("checked", "checked");
  $("#RWmode2").attr("disabled", false);
  $("#Add_DataItemDHParam").show();
  $("#Add_DHFunctionParam1").hide();
  $("#Add_DHFunctionParam2").hide();

  $("#line_Add_DataItemDHOpt").hide();
  $("#line_Add_DataItemDHParamTip").hide();
  $("#Add_DataItemDHParam").val("");
  $("#Add_DataItemDHSelect").val("1");
  $("#Add_DHFunctionParam1").val("");
  $("#Add_DHFunctionParam2").val("");
}

//弹出删除层
function openDeleteLayer() {
  CheckedLength();
  document.getElementById("popWindow").style.display = "";
  document.getElementById("DeleteDataItemLayer").style.display = "";
  if (document.getElementById("AllDataitemID").value == "") {
    document.getElementById("NoDataItemChecked").style.display = "";
    document.getElementById("DeleteChecked").style.display = "none";
    document.getElementById("DeleteDataItem_Button_Confim").style.display =
      "none";
    document.getElementById("DeleteDataItem_Button_Cancel").style.display =
      "none";
    document.getElementById(
      "DeleteDataItem_Success_Button_Confim"
    ).style.display = "";
  } else {
    document.getElementById("NoDataItemChecked").style.display = "none";
    document.getElementById("DeleteChecked").style.display = "";
    if (coo == "English") {
      document.getElementById("DeleteChecked").innerHTML =
        "Make sure to delete the selected<strong> &nbsp;" +
        checkLength +
        "&nbsp; </strong>dataItems?";
    } else {
      document.getElementById("DeleteChecked").innerHTML =
        "确定要删除选中的<strong> &nbsp;" +
        checkLength +
        "&nbsp; </strong>个数据项吗？";
    }
    document.getElementById("DeleteDataItem_Button_Confim").style.display = "";
    document.getElementById("DeleteDataItem_Button_Cancel").style.display = "";
    document.getElementById(
      "DeleteDataItem_Success_Button_Confim"
    ).style.display = "none";
  }
}

//弹出帮助层
function Open_DataItemHelpLayer() {
  if (document.getElementById("Help_DataItemLayer").style.display == "none")
    document.getElementById("Help_DataItemLayer").style.display = "";
  else document.getElementById("Help_DataItemLayer").style.display = "none";
}

//缺省 单选按钮

function changeReport() {
  if (document.getElementById("DataItemReport1").checked)
    document.getElementById("Add_DataItemReport").value = "1";
  else document.getElementById("Add_DataItemReport").value = "0";
}

function changeReportInfo() {
  if (document.getElementById("Alter_DataItemReport1").checked)
    document.getElementById("Alter_DataItemReport").value = "1";
  else document.getElementById("Alter_DataItemReport").value = "0";
}

//检查重名
function CheckReName(txt) {
  var string = document.getElementById("allItemName").innerHTML;
  var NameArr = new Array();
  NameArr = string.split(";");
  for (var i = 0; i < NameArr.length - 1; i++) {
    //alert(NameArr[i])
    if (txt != NameArr[i]) {
    } else {
      return false;
    }
  }
  return true;
}
//检查数据项名称输入格式

function Check_Chinese_Character(txt) {
  var str = txt;
  var re = /^[A-Za-z]\w*$/;
  if (re.test(str)) {
    return true;
  } else {
    return false;
  }
}

//添加数据项的校验
function Check_Add_DataItem() {
  // 数据项类型是否有效
  var isDataTypeValid = true;
  var CheckID = $("#Add_DataItemID").val();
  var CheckName = $("#Add_DataItemName").val();
  var Alies = $("#Add_DataItemAlias").val();
  $("#addressTip").html("");
  // modified by fyj
  // begin
  if (ChannelDeviceType != "KUKA") {
    var Address =
      (ChannelDeviceType == "GPS" && $("#Add_DataItemAddress2").val()) ||
      $("#Add_DataItemAddress").val();
    var FirAdd = Address.substr(0, 1);
  }
  // end
  var Freq = $("#Add_DataItemFreq").val();
  // add by whc
  if (ChannelDeviceType == "SIEMENS-S7-PPI-Task") {
    var typeMap = {
      BIT: "Bit",
      INT8: "Int 8",
      UINT8: "UInt8",
      INT16: "Int16",
      UINT16: "UInt16",
      INT32: "Int32",
      UINT32: "UInt32",
      FLOAT: "Float",
      BCD: "BCD",
    };
    var dateItemTypeStr = $("#Add_DataItemTypeIpt").val();
    var DataItemType = typeMap[dateItemTypeStr];

    // 校验数据类型
    if (
      (!DataItemType || DataItemType.length == 0) &&
      (!dateItemTypeStr || dateItemTypeStr.length == 0)
    ) {
      //没有输入数据类型
      isDataTypeValid = false;
      if (coo == "English") {
        $test = $("#Add_DataItemTypeTip").html(
          "*Please fill in the data item type"
        );
      } else {
        $test = $("#Add_DataItemTypeTip").html("*请填写数据项类型");
      }
      return;
    } else if (dateItemTypeStr.length > 0) {
      // 自定义数据类型
      DataItemType = dateItemTypeStr;
    }
  }
  // add end
  // add begin by fyj
  if (ChannelDeviceType == "SIEMENS-PPI") {
    var typeMap = {
      Boolean: "BIT",
      Byte: "BYTE",
      Word: "WORD",
      Short: "SHORT",
      DWord: "DWORD",
      Long: "LONG",
      Float: "FLOAT",
      String: "STRING",
      "Int 8": "INT8",
      "Int 16": "INT16",
      "Int 32": "INT32",
      BCD: "BCD",
    };
    var dateItemTypeStr = $("#Add_DataItemTypeIpt").val();
    var DataItemType = typeMap[dateItemTypeStr];

    // 校验数据类型
    if (
      (!DataItemType || DataItemType.length == 0) &&
      (!dateItemTypeStr || dateItemTypeStr.length == 0)
    ) {
      //没有输入数据类型
      isDataTypeValid = false;
      if (coo == "English") {
        var $test = $("#Add_DataItemTypeTip").html(
          "*Please fill in the data item type"
        );
      } else {
        var $test = $("#Add_DataItemTypeTip").html("*请填写数据项类型");
      }
      return;
    } else if (dateItemTypeStr.length > 0) {
      // 自定义数据类型
      DataItemType = dateItemTypeStr;
    }
  } else {
    var DataItemType =
      (ChannelDeviceType == "GPS" && "STRING") || $("#Add_DataItemType").val();
  }
  // add end

  var StringLength = $("#stringLength").val();
  var reg = new RegExp("^[0-9]+$");
  var regID = new RegExp("^[1-9]+[0-9]*$");
  //校验数据项ID输入格式
  if (CheckID == "" || !regID.test(CheckID)) {
    if (coo == "English") {
      $("#idTip").html("The data item ID must be a non-negative integer");
    } else {
      $("#idTip").html("数据项ID必须为非负整数");
    }
  } else {
    $.ajax({
      type: "get",
      url: "../conf/config.xml",
      async: false,
      success: function (data) {
        var flag = true;
        $(data)
          .find("model")
          .each(function () {
            var $model = $(this);
            $model.find("device").each(function () {
              var $device = $(this);
              $device.find("commDataItems").each(function () {
                var $commDataItems = $(this);
                $commDataItems.find("dataItem").each(function () {
                  var $dataItem = $(this);
                  var dataItemID = $dataItem.attr("id");
                  if (dataItemID == CheckID) {
                    if (coo == "English") {
                      $("#idTip").html(
                        "The data item ID is repeated, please change"
                      );
                    } else {
                      $("#idTip").html("数据项ID已重复，请更改");
                    }
                    flag = false;
                  }
                });
              });
            });
          });
        if (flag) {
          $("#idTip").html("");
        }
      },
    });
  }

  //校验数据项名称输入格式
  if (CheckName == "") {
    if (coo == "English") {
      $("#nameTip").html("*The data item name cannot be empty");
    } else {
      $("#nameTip").html("*数据项名称不能为空");
    }
  } else {
    //校验数据项名称是否重名
    if (!CheckReName(CheckName)) {
      if (coo == "English") {
        $("#nameTip").html("The data item name is repeated");
      } else {
        $("#nameTip").html("数据项名称重复");
      }
    } else {
      $("#nameTip").html("");
    }
  }
  //校验数据项别名不为空
  if (Alies == "") {
    if (coo == "English") {
      $("#AliasTip").html("*Please fill in the alias");
    } else {
      $("#AliasTip").html("*请填写别名");
    }
  } else {
    $("#AliasTip").html("");
  }
  if (ChannelDeviceType == "HKG-SERIAL") {
    if ($("#Add_ID").val() == "") {
      if (coo == "English") {
        $("#Add_ID_msg").html("*Please fill in ID");
      } else {
        $("#Add_ID_msg").html("*请填写ID");
      }
    } else {
      if (!reg.test($("#Add_ID").val()) || $("#Add_ID").val() == 0) {
        if (coo == "English") {
          $("#Add_ID_msg").html("*The ID must be a positive integer");
        } else {
          $("#Add_ID_msg").html("*ID必须为正整数");
        }
      } else {
        $("#Add_ID_msg").html("");
      }
    }
  }
  var Address = $("#Add_DataItemAddress").val();
  if (ChannelDeviceType == "SIEMENS-PPI") {
    regValidate11(ChannelDeviceType, Address);
  } else if (ChannelDeviceType == "IEC104") {
    var ASDU = $("#Add_DataItemIECAttr").val();
    var IOB = $("#Add_DataItemIECAttr2").val();
    if (ASDU == "") {
      if (coo == "English") {
        $("#addressTip").html("*Please input ASDU parameter.");
      } else {
        $("#addressTip").html("*请输入ASDU参数");
      }
    } else {
      if (IOB == "") {
        if (coo == "English") {
          $("#addressTip").html("*Please input IOB parameter.");
        } else {
          $("#addressTip").html("*请输入IOB参数");
        }
      }
    }
  } else if (ChannelDeviceType == "MITSUBISHI-TXZ-MomMach" || ChannelDeviceType == "MITSUBISHI-TXZ-SubMach1" || ChannelDeviceType == "MITSUBISHI-TXZ-SubMach2") {
  } else if (ChannelDeviceType == "MITSUBISHI-TX-15P" || ChannelDeviceType == "MITSUBISHI-TX-5HP" || ChannelDeviceType == "MITSUBISHI-TX-Multi-link") {
    if ($("#Add_TX_config-hidden").val() == "error") {
      if (coo == "English") {
        $("#TXConfigTip").html("*Please choose the correct address");
      } else {
        $("#TXConfigTip").html("*请选择正确的地址");
      }
      return false;
    }
  } else if (
    Address == "" &&
    ChannelDeviceType != "Zundar" &&
    ChannelDeviceType != "OMRON_NJNX" &&
    ChannelDeviceType != "HKG-SERIAL" &&
    ChannelDeviceType != "JB3102" &&
    ChannelDeviceType != "JB3208" &&
    ChannelDeviceType != "DLT645-2007" &&
    ChannelDeviceType != "DLT645-1997" &&
    ChannelDeviceType != "GPS" &&
    ChannelDeviceType != "R1R2" &&
    ChannelDeviceType != "DRACAL" &&
    ChannelDeviceType != "OPC-UA"
  ) {
    if (coo == "English") {
      $("#addressTip").html("*Please fill in the data item address");
    } else {
      $("#addressTip").html("*请填写数据项地址");
    }
  }
  // add by whc
  else if (Address == "" && ChannelDeviceType == "SIEMENS-S7-PPI-Task") {
    if (coo == "English") {
      $("#addressTip").html("*Please fill in the data item address");
    } else {
      $("#addressTip").html("*请填写数据项地址");
    }
  } else if (Address != "" && ChannelDeviceType == "SIEMENS-S7-PPI-Task") {
    var reg1 = /^[A-Z]+[0-9]+(\.[0-9]+)?$/;
    if (!reg1.test(Address)) {
      if (coo == "English") {
        $("#addressTip").html(
          "Address must start with capital letters followed by letters and numbers, i.e. M5.1, MW10"
        );
      } else {
        $("#addressTip").html(
          "数据项地址不匹配,应包含字母和数字，并以大写字母开头，参考格式“M5.1”或者“MW10”"
        );
      }
      return false;
    }
  } else if (ChannelDeviceType == "OPC") {
    if (Address == "") {
      if (coo == "English") {
        $("#addressTip").html("*Please fill in the data item address");
      } else {
        $("#addressTip").html("*请填写数据项地址");
      }
    }
  }

  // else if (Address != "" && ChannelDeviceType == "OPC") {
  //     // var rege=/^[\a-\z\A-\Z0-9\\u4E00-\\u9FA5\_]\.[\a-\z\A-\Z0-9\\u4E00-\\u9FA5\_]\.[\a-\z\A-\Z0-9\\u4E00-\\u9FA5\_]$/;
  //     var rege=/^[^\x2e]+\.[^\x2e]+\.[^\x2e]+$/;
  //     if(!rege.test(Address)){
  //         $("#addressTip").html("数据项地址要以“.”分隔，参考格式为“Channel_1.Device_1.Tag_1”");
  //         return false;
  //     }
  // }
  // add end
  //add begin by x
  //GPS JB3102 JB3208对地址不再判断
  else if (ChannelDeviceType == "GPS") {
    $("#addressTip").html("");
  }
  //end add
  // add by fyj , 新增KUKA驱动
  // add begin
  else if (ChannelDeviceType == "KUKA") {
    if ($("#Add_DataItemKukaNodeName").val() == "") {
      if (coo == "English") {
        $("#Add_DataItemKukaNodeNameTip").html("*Please fill in the node name");
      } else {
        $("#Add_DataItemKukaNodeNameTip").html("*请填写节点名称");
      }
    } else {
      $("#Add_DataItemKukaNodeNameTip").html("");
    }
    var myReg = new RegExp("^-?\\d+$");
    var nodeIndex = $("#Add_DataItemKukaNodeIndex").val();
    if (nodeIndex == "" || !myReg.test(nodeIndex)) {
      if (coo == "English") {
        $("#Add_DataItemKukaNodeIndexTip").html(
          "*Please enter the correct node index"
        );
      } else {
        $("#Add_DataItemKukaNodeIndexTip").html("*请输入正确的节点索引");
      }
    } else {
      $("#Add_DataItemKukaNodeIndexTip").html("");
    }

    if (
      $("#Add_DataItemKukaParam1").css("display") != "none" &&
      $("#Add_DataItemKukaParam1").val() == ""
    ) {
      if (coo == "English") {
        $("#Add_DataItemKukaParam1Tip").html(
          "*Please enter the correct parameters"
        );
      } else {
        $("#Add_DataItemKukaParam1Tip").html("*请输入正确的参数");
      }
    } else {
      $("#Add_DataItemKukaParam1Tip").html("");
    }

    if (
      $("#Add_DataItemKukaParam2").css("display") != "none" &&
      $("#Add_DataItemKukaParam2").val() == ""
    ) {
      if (coo == "English") {
        $("#Add_DataItemKukaParam2Tip").html(
          "*Please enter the correct parameters"
        );
      } else {
        $("#Add_DataItemKukaParam2Tip").html("*请输入正确的参数");
      }
    } else {
      $("#Add_DataItemKukaParam2Tip").html("");
    }
  }
  // add end
  // add by fyj, 新增DLT645-2007
  else if (
    ChannelDeviceType == "DLT645-2007" ||
    ChannelDeviceType == "DLT645-1997"
  ) {
    var val = $("#Add_DataItemDltEnergy").val();
    if (val == "") {
      if (coo == "English") {
        $("#Add_DataItemDltEnergyTip").html("*Please fill in the data address");
      } else {
        $("#Add_DataItemDltEnergyTip").html("*请填写数据地址");
      }
    } else {
      $("#Add_DataItemDltEnergyTip").html("");
    }
  }
  // add end
  else if (ChannelDeviceType == "OPC-UA") {
    var UAattr1 = $("#Add_DataItemDataItemUAattr1").val();
    if (UAattr1 == "") {
      if (coo == "English") {
        $("#Add_DataItemTypeTip").html("*Please input NodeID");
      } else {
        $("#Add_DataItemTypeTip").html("*请填写NodeID");
      }
    } else {
      // if(!reg.test(UAattr1)){
      //     if (coo == "English") {
      //         $('#Add_DataItemTypeTip').html('*Please enter the correct NodeID');
      //     }else{
      //         $('#Add_DataItemTypeTip').html('*请填写正确的NodeID');
      //     }
      // }else {
      $("#Add_DataItemTypeTip").html("");
      // }
    }
  } else if (  ChannelDeviceType == "R1R2") {
    $("#addressTip").html("");
    var address = $("#Add_Samsung_Address").val();
    if (!reg.test(address) ) {
      if (coo == "English") {
        $("#Add_Samsung_AddressTip").html(
          "Address must be numbers"
        );
      } else {
        $("#Add_Samsung_AddressTip").html(
          "数据项地址应为数值"
        );
      }
      return false;
    }else{
      $("#Add_Samsung_AddressTip").html("");
    }
  } else if (
    ChannelDeviceType == "OMRON-HostLink-Task" ||
    ChannelDeviceType == "OMRON-FINS-Task"
  ) {
    var reg1 = /^[A-Z]+[0-9_]+(\.[0-9]+)?$/;
    if (!reg1.test(Address)) {
      if (coo == "English") {
        $("#addressTip").html(
          "Address must start with capital letters followed by letters and numbers, i.e. W00.0, AR448"
        );
      } else {
        $("#addressTip").html(
          "数据项地址不匹配,应包含字母和数字，并以大写字母开头，参考格式“W00.0”或者“AR448”"
        );
      }
    }
  } else {
    if (
      ChannelDeviceType != "YinHe" &&
      ChannelDeviceType != "Zundar" &&
      ChannelDeviceType != "OMRON_NJNX" &&
      ChannelDeviceType != "HKG-SERIAL" &&
      ChannelDeviceType != "Custom-TCP" &&
      ChannelDeviceType != "JB3102" &&
      ChannelDeviceType != "JB3208" &&
      ChannelDeviceType != "KUKA" &&
      ChannelDeviceType != "SIEMENS-S7-PPI-Task" &&
      ChannelDeviceType != "OPC-UA" &&
      ChannelDeviceType != "device" &&
      ChannelDeviceType != "R1R2" &&
      ChannelDeviceType != "DRACAL"
    ) {
      //校验地址第一位不为数字
      var flag = regValidate(ChannelDeviceType, Address);
      if (flag == false) {
      } else {
        if (
          reg.test(FirAdd) == 1 &&
          ChannelDeviceType != "YinHe" &&
          ChannelDeviceType != "Zundar" &&
          ChannelDeviceType != "OMRON_NJNX" &&
          ChannelDeviceType != "HKG-SERIAL" &&
          ChannelDeviceType != "OPC" &&
          ChannelDeviceType != "SIEMENS-S7-PPI-Task" &&
          ChannelDeviceType != "DRACAL"
        ) {
          if (coo == "English") {
            $("#addressTip").html(
              "*The first data item address cannot be a positive integer"
            );
          } else {
            $("#addressTip").html("*数据项地址第一位不能为正整数");
          }
        } else {
          $("#addressTip").html("");
        }
      }
    } else {
      $("#addressTip").html("");
    }
  }
  //校验频率不为空
  if (Freq == "") {
    if (coo == "English") {
      $("#freqTip").html("*Please fill in the sample frequency");
    } else {
      $("#freqTip").html("*请填写采集频率");
    }
  } else {
    if (!reg.test(Freq) || Freq == 0) {
      if (coo == "English") {
        $("#freqTip").html("*The frequencies must be positive integers");
      } else {
        $("#freqTip").html("*频率必须为正整数");
      }
    } else {
      $.ajax({
        type: "get",
        url: "../conf/Common.xml",
        async: false,
        success: function (data) {
          var minFrequency = $(data).find("MinFrequency").text();
          var currentFreq = 0;
          if ($("#Add_DataItemUnit").val() == "second") {
            currentFreq = parseInt(Freq) * 1000;
          } else {
            currentFreq = parseInt(Freq) * 1000 * 60;
          }

          if (currentFreq < parseInt(minFrequency)) {
            if (coo == "English") {
              $("#freqTip").html(
                "*The lowest frequency currently supported is" +
                  minFrequency / 1000 +
                  "seconds"
              );
            } else {
              $("#freqTip").html(
                "*当前支持的最低频率为" + minFrequency / 1000 + "秒"
              );
            }
          } else {
            $("#freqTip").html("");
          }
        },
      });
    }
  }
  //OPC-UA
  if (ChannelDeviceType == "OPC-UA") {
    var a = $("#Add_DataItemUnit").val();
    if (a == "ms") {
      if (Freq < 100) {
        if (coo == "English") {
          $("#freqTip").html("*The frequencies must be more than 100ms.");
        } else {
          $("#freqTip").html("*要求频率大于100ms");
        }
      } else {
        $("#freqTip").html("");
      }
    }
  }

  //如果数据项类型为String，则校验长度是否为整数且为偶数
  if (
    DataItemType.toUpperCase() == "STRING" &&
    ChannelDeviceType != "OMRON_NJNX" &&
    ChannelDeviceType != "HKG-SERIAL" &&
    ChannelDeviceType != "Custom-TCP" &&
    ChannelDeviceType != "GPS" &&
    ChannelDeviceType != "JB3102" &&
    ChannelDeviceType != "JB3208" &&
    ChannelDeviceType != "OPC" &&
    ChannelDeviceType != "SIEMENS-S7-PPI-Task" &&
    ChannelDeviceType != "DRACAL"
  ) {
    if (StringLength == "") {
      if (coo == "English") {
        $("#stringMsg").html("*Please input length");
      } else {
        $("#stringMsg").html("*请输入长度");
      }
    } else {
      if (reg.test(StringLength) && parseInt(StringLength) % 2 == 0) {
        $("#stringMsg").html("");
      } else {
        if (coo == "English") {
          $("#stringMsg").html("*The length must be numeric and even");
        } else {
          $("#stringMsg").html("*长度必须为数字且为偶数");
        }
      }
    }
  } else {
    $("#stringMsg").html("");
  }
  if (ChannelDeviceType == "OMRON_NJNX" && $("#Add_DatasName").val() == "") {
    if (coo == "English") {
      $("#dataPnameTip").html("Please enter the data point name");
    } else {
      $("#dataPnameTip").html("请输入数据点名称");
    }
  } else {
    $("#dataPnameTip").html("");
  }
  // add by whc
  if (
    ChannelDeviceType == "DRACAL" &&
    $("#Add_DataItemDRACALChannel").val() == ""
  ) {
    $("#ChannelTip").html("请输入通道名称");
  } else {
    $("#ChannelTip").html("");
  }
  // add end
  //判断是否通过
  // var idTipHtml = $("#idTip").html();
  // var nameTipHtml = $("#nameTip").html();
  // var AliasTipHtml = $("#AliasTip").html();
  // var addressTipHtml = $("#addressTip").html();
  // var freqTipHtml = $("#freqTip").html();
  // var stringMsgHtml =  $("#stringMsg").html();
  // var Add_ID_msgHtml = $("#Add_ID_msg").html();
  // var dataPnameTipHtml = $("#dataPnameTip").html();
  // var Add_DataItemTypeTipHtml = $("#Add_DataItemTypeTip").html();
  // var Add_DataItemKukaNodeIndexTipHtml = $("#Add_DataItemKukaNodeIndexTip").html();
  // var Add_DataItemKukaNodeNameTipHtml = $("#Add_DataItemKukaNodeNameTip").html();
  // var Add_DataItemKukaParam1TipHtml = $("#Add_DataItemKukaParam1Tip").html();
  // var Add_DataItemKukaParam2TipHtml = $("#Add_DataItemKukaParam2Tip").html();

  // add by fyj, OMRON-HostLink增加datahandler驱动

  $("#Add_DataItemDHParamTip").html("");
  var isChecked = $("input[name='Add_DataItemDHEnable']:checked").val();
  if (isChecked == "1") {
    var paramVal = $("#Add_DataItemDHParam").val();
    if ($("#Add_DataItemDHSelect").val() == "#") {
      var linearParam1 = $("#Add_DHFunctionParam1").val();
      var linearParam2 = $("#Add_DHFunctionParam2").val();
      if (linearParam1 == "" || linearParam2 == "") {
        if (coo == "English") {
          $("#Add_DataItemDHParamTip").html(
            "Please fill in the value operation parameters"
          );
        } else {
          $("#Add_DataItemDHParamTip").html("请填写值运算参数");
        }
      } else {
        var dhReg = /^-?[0-9]+.?[0-9]*$/;
        if (!dhReg.test(linearParam1) || !dhReg.test(linearParam2)) {
          if (coo == "English") {
            $("#Add_DataItemDHParamTip").html(
              "The value operation parameter must be a number"
            );
          } else {
            $("#Add_DataItemDHParamTip").html("值运算参数必须是数字");
          }
        }
      }
    } else if (paramVal == "") {
      if (coo == "English") {
        $("#Add_DataItemDHParamTip").html(
          "Please fill in the value operation parameters"
        );
      } else {
        $("#Add_DataItemDHParamTip").html("请填写值运算参数");
      }
    } else {
      // 校验输入的操作数是否是数字
      var dhReg = /^-?[0-9]+.?[0-9]*$/;
      if (!dhReg.test(paramVal)) {
        if (coo == "English") {
          $("#Add_DataItemDHParamTip").html(
            "The value operation parameter must be a number"
          );
        } else {
          $("#Add_DataItemDHParamTip").html("值运算参数必须是数字");
        }
      } else if ($("#Add_DataItemDHSelect").val() == "5") {
        var dhReg = /^[0-9]+$/;
        if (!dhReg.test(paramVal)) {
          if (coo == "English") {
            $("#Add_DataItemDHParamTip").html(
              "The parameter of the fetch operation must be an integer"
            );
          } else {
            $("#Add_DataItemDHParamTip").html("取位运算的参数必须是整数");
          }
        } else {
          var paramVal = Number(paramVal);
          if (paramVal < 0 || paramVal > 31) {
            if (coo == "English") {
              $("#Add_DataItemDHParamTip").html(
                "The range of parameters for the fetch operation must be 0 to 31"
              );
            } else {
              $("#Add_DataItemDHParamTip").html(
                "取位运算的参数的范围必须是0到31"
              );
            }
          }
        }
      }
    }
  }

  // add end
  if (
    $("#idTip").html() == "" &&
    $("#nameTip").html() == "" &&
    $("#AliasTip").html() == "" &&
    $("#addressTip").html() == "" &&
    $("#freqTip").html() == "" &&
    $("#stringMsg").html() == "" &&
    $("#Add_ID_msg").html() == "" &&
    $("#dataPnameTip").html() == "" &&
    $("#Add_DataItemTypeTip").html() == "" &&
    isDataTypeValid &&
    $("#Add_DataItemKukaNodeIndexTip").html() == "" &&
    $("#Add_DataItemKukaNodeNameTip").html() == "" &&
    $("#Add_DataItemKukaParam1Tip").html() == "" &&
    $("#Add_DataItemKukaParam2Tip").html() == "" &&
    ($("#Add_DataItemDHParamTip").html() == "" ||
      $("#Add_DataItemDHParamTip").html() == null) &&
    ($("#Add_DataItemDltEnergyTip").html() == "" ||
      $("#Add_DataItemDltEnergyTip").html() == null)
  ) {
    //        全部通过
    Add_DataItemMethod();
  } else {
  }
}

//添加数据点方法
function Add_DataItemMethod() {
  //赋值
  document.getElementById("checkTwo").innerHTML = "";
  var reg = /[a-zA-Z]/g;
  var str = document.getElementById("Add_DataItemAddress").value;

  //增加String类型。如果是String，则config中写入STRING+长度
  // modified by fyj   为SIEMENS-PPI驱动增加自定义数据项类型功能
  // begin
  if (ChannelDeviceType == "SIEMENS-PPI") {
    var typeMap = {
      Boolean: "BIT",
      Byte: "BYTE",
      Word: "WORD",
      Short: "SHORT",
      DWord: "DWORD",
      Long: "LONG",
      Float: "FLOAT",
      String: "STRING",
      "Int 8": "INT8",
      "Int 16": "INT16",
      "Int 32": "INT32",
      BCD: "BCD",
    };
    var DataItemTypeStr = $("#Add_DataItemTypeIpt").val();
    var DataItemType = typeMap[DataItemTypeStr] || DataItemTypeStr;
  }
  // add by whc
  else if (ChannelDeviceType == "SIEMENS-S7-PPI-Task") {
    var typeMap = {
      BIT: "Bit",
      INT8: "Int 8",
      UINT8: "UInt8",
      INT16: "Int16",
      UINT16: "UInt16",
      INT32: "Int32",
      UINT32: "UInt32",
      FLOAT: "Float",
      BCD: "BCD",
    };
    var DataItemTypeStr = $("#Add_DataItemTypeIpt").val();
    var DataItemType = typeMap[DataItemTypeStr] || DataItemTypeStr;
  } else {
    var DataItemType = $("#Add_DataItemType").val();
  }
  // end
  var StringLength = $("#stringLength").val();
  //IEC驱动无数据项地址  需在if判断中添加iec
  if (
    ChannelDeviceType != "YinHe" &&
    ChannelDeviceType != "Zundar" &&
    ChannelDeviceType != "OMRON_NJNX" &&
    ChannelDeviceType != "HKG-SERIAL" &&
    ChannelDeviceType != "Custom-TCP" &&
    ChannelDeviceType != "GPS" &&
    ChannelDeviceType != "JB3102" &&
    ChannelDeviceType != "JB3208" &&
    ChannelDeviceType != "KUKA" &&
    ChannelDeviceType != "DLT645-2007" &&
    ChannelDeviceType != "DLT645-1997" &&
    ChannelDeviceType != "OPC" &&
    ChannelDeviceType != "SIEMENS-S7-PPI-Task" &&
    ChannelDeviceType != "OPC-UA" &&
    ChannelDeviceType != "IEC104" &&
    ChannelDeviceType != "MITSUBISHI-TXZ-MomMach" &&
    ChannelDeviceType != "MITSUBISHI-TXZ-SubMach1" &&
    ChannelDeviceType != "MITSUBISHI-TXZ-SubMach2" &&
    ChannelDeviceType != "MITSUBISHI-TX-15P" &&
    ChannelDeviceType != "MITSUBISHI-TX-5HP" &&
    ChannelDeviceType != "MITSUBISHI-TX-Multi-link" &&
    ChannelDeviceType != "R1R2" &&
    ChannelDeviceType != "device" &&
    ChannelDeviceType != "DRACAL"
  ) {
    var length = str.match(reg).length;
  }
  // modified by fyj
  if (ChannelDeviceType == "KUKA") {
    var kukaDataType = $("#Add_DataItemKukaDataType").val();
    if (kukaDataType == "3") {
      document.getElementById("Add_DataItemType_YuToXHZhang").value = "s";
    } else {
      document.getElementById("Add_DataItemType_YuToXHZhang").value = "a";
    }
  } else if (
    ChannelDeviceType == "DLT645-2007" ||
    ChannelDeviceType == "DLT645-1997"
  ) {
    document.getElementById("Add_DataItemType_YuToXHZhang").value = $(
      "#Add_DataItemType"
    ).val();
  } else if (
    ChannelDeviceType == "OPC-UA" ||
    ChannelDeviceType == "MITSUBISHI-TXZ-MomMach" ||
    ChannelDeviceType == "MITSUBISHI-TXZ-SubMach1" ||
    ChannelDeviceType == "MITSUBISHI-TXZ-SubMach2" 
  ) {
    document.getElementById("Add_DataItemType_YuToXHZhang").value = $(
      "#Add_DataItemUAType"
    ).val();
  } else if (ChannelDeviceType == "MITSUBISHI-TX-15P" ||ChannelDeviceType == "MITSUBISHI-TX-5HP" ||ChannelDeviceType == "MITSUBISHI-TX-Multi-link" ) {
    document.getElementById("Add_DataItemType_YuToXHZhang").value = $(
      "#Add_DataItemTXType"
    ).val();
  } else if (ChannelDeviceType == "device") {
    document.getElementById("Add_DataItemType_YuToXHZhang").value = $(
      "#Add_DataItemIECDataType"
    ).val();
  } else if (ChannelDeviceType == "IEC104") {
    var IECDataType = $("#Add_DataItemIECDataType").val();
    if (IECDataType == "a") {
      document.getElementById("Add_DataItemType_YuToXHZhang").value = "a";
    } else if (IECDataType == "b") {
      document.getElementById("Add_DataItemType_YuToXHZhang").value = "b";
    } else {
      document.getElementById("Add_DataItemType_YuToXHZhang").value = "s";
    }
  } else if (ChannelDeviceType == "R1R2") {
    document.getElementById("Add_DataItemType_YuToXHZhang").value = $(
      "#Add_Samsung_DataItemType"
    ).val();
  } else {
    if (DataItemType == "BIT")
      document.getElementById("Add_DataItemType_YuToXHZhang").value = "b";
    else if (DataItemType == "STRING")
      document.getElementById("Add_DataItemType_YuToXHZhang").value = "s";
    else document.getElementById("Add_DataItemType_YuToXHZhang").value = "a";
  }
  var Freq = document.getElementById("Add_DataItemFreq").value;
  var Unit = document.getElementById("Add_DataItemUnit").value;
  if (Unit == "minute") {
    Freq = Freq * 60000;
  } else {
    Freq = Freq * 1000;
  }

  //OPC-UA驱动支持毫秒级采集
  if (ChannelDeviceType == "OPC-UA") {
    if (Unit == "ms") {
      Freq = Freq / 1000;
    }
  }
  //数据项ID
  document.getElementById(
    "Add_DataItemID_YuToXHZhang"
  ).value = document.getElementById("Add_DataItemID").value;
  //数据项名称
  document.getElementById(
    "Add_DataItemName_YuToXHZhang"
  ).value = document.getElementById("Add_DataItemName").value;
  //别名
  document.getElementById(
    "Add_DataItemAlias_YuToXHZhang"
  ).value = document.getElementById("Add_DataItemAlias").value;
  //频率
  document.getElementById("Add_DataItemFreq_YuToXHZhang").value = Freq;
  //读写模式
  document.getElementById("Add_DataItemRWmode_YuToXHZhang").value = $(
    "input[name='Add_DataItemRWmode']:checked"
  ).val();
  //是否上报
  $("#Add_DataItemReport_YuToXHZhang").val( $("input[name='Add_ReportType']:checked").val()  );
  //数据项信息

  var isChecked = $("input[name='Add_DataItemDHEnable']:checked").val();
  $("#Add_DataItemDHEnable_YuToXHZhang").val(isChecked);
  if (isChecked == "1") {
    $("#Add_DataItemDHOptType_YuToXHZhang").val(
      $("#Add_DataItemDHSelect").val()
    );
    if ($("#Add_DataItemDHSelect").val() === "#") {
      $("#Add_DataItemDHOptParam_YuToXHZhang").val(
        $("#Add_DHFunctionParam1").val() +
          "|" +
          $("#Add_DHFunctionParam2").val()
      );
    } else {
      $("#Add_DataItemDHOptParam_YuToXHZhang").val(
        $("#Add_DataItemDHParam").val()
      );
    }
  }

  if (
    ChannelDeviceType == "MITSUBISHI-FX" &&
    (str.substr(0, length) == "X" || str.substr(0, length) == "Y")
  ) {
    var m = str.substr(length);
    document.getElementById("Add_DataItemConfig_YuToXHZhang").value =
      str.substr(0, length) +
      ";" +
      (DataItemType == "STRING" ? "STRING" + StringLength : DataItemType) +
      ";" +
      parseInt(m, 8) +
      ";" +
      $("input[name='Add_DataItemRWmode']:checked").val();
  } else if (
    ChannelDeviceType == "MITSUBISHI-QS" ||
    ChannelDeviceType == "MITSUBISHI-QN"
  ) {
    document.getElementById("Add_DataItemConfig_YuToXHZhang").value =
      str +
      ";" +
      (DataItemType == "STRING" ? "STRING" + StringLength : DataItemType) +
      ";" +
      $("input[name='Add_DataItemRWmode']:checked").val();
    // add by whc
  } else if (ChannelDeviceType == "FATEK编程口") {
    document.getElementById("Add_DataItemConfig_YuToXHZhang").value =
      (DataItemType == "STRING" ? "STRING" + StringLength : DataItemType) +
      ";" +
      str;
    // add end
  } else if (ChannelDeviceType == "AB-DF1") {
    str = str.toUpperCase();
    document.getElementById("Add_DataItemConfig_YuToXHZhang").value =
      str +
      ";" +
      (DataItemType == "STRING" ? "STRING" + StringLength : DataItemType) +
      ";" +
      $("input[name='Add_DataItemRWmode']:checked").val();
  } else if (ChannelDeviceType == "YinHe") {
    document.getElementById("Add_DataItemConfig_YuToXHZhang").value = $(
      "#Add_DataItemAddress"
    ).val();
  } else if (ChannelDeviceType == "Zundar") {
    document.getElementById("Add_DataItemConfig_YuToXHZhang").value = DeviceID;
  } else if (ChannelDeviceType == "OMRON_NJNX") {
    document.getElementById("Add_DataItemConfig_YuToXHZhang").value = $(
      "#Add_DatasName"
    ).val();
  } else if (ChannelDeviceType == "DRACAL") {
    document.getElementById("Add_DataItemConfig_YuToXHZhang").value = $(
      "#Add_DataItemDRACALChannel"
    ).val();
  } else if (ChannelDeviceType == "HKG-SERIAL") {
    document.getElementById("Add_DataItemConfig_YuToXHZhang").value = $(
      "#Add_ID"
    ).val();
  } else if (ChannelDeviceType == "Custom-TCP") {
    document.getElementById("Add_DataItemConfig_YuToXHZhang").value = str;
  }
  // add begin by x
  else if (ChannelDeviceType == "GPS") {
    document.getElementById("Add_DataItemConfig_YuToXHZhang").value = $(
      "#Add_DataItemAddress2"
    ).val();
  }
  // end add
  // add by whc
  else if (ChannelDeviceType == "OPC") {
    var reg = new RegExp("[^\x00-\xff]+", "g");
    if (reg.test(str)) {
      document.getElementById("Add_DataItemConfig_YuToXHZhang").value =
        "gb2312" + ";" + $("#Add_DataItemAddress").val();
    } else {
      document.getElementById("Add_DataItemConfig_YuToXHZhang").value = $(
        "#Add_DataItemAddress"
      ).val();
    }
    // document.getElementById("Add_DataItemAlias_YuToXHZhang").value = "1";
  } else if (ChannelDeviceType == "OPC-UA") {
    document.getElementById("Add_DataItemConfig_YuToXHZhang").value =
      $("#Add_DataItemDataItemUAattr1").val() + ";" + 13;
    //默认地址为13 可以会改动
  } else if (ChannelDeviceType == "SIEMENS-S7-PPI-Task") {
    document.getElementById("Add_DataItemConfig_YuToXHZhang").value =
      $("#Add_DataItemAddress").val() + ";" + DataItemType;
  }
  // end add
  // add begin by x
  else if (ChannelDeviceType == "JB3102") {
    if ($("#Add_DataItemAddress3").val() == "205") {
      document.getElementById("Add_DataItemConfig_YuToXHZhang").value =
        $("#Add_DataItemAddress3").val() +
        ";" +
        $("#Add_huiluhao").val() +
        ";" +
        $("#Add_dianhao").val();
    } else {
      document.getElementById("Add_DataItemConfig_YuToXHZhang").value = $(
        "#Add_DataItemAddress3"
      ).val();
    }
  } else if (ChannelDeviceType == "JB3208") {
    if ($("#Add_DataItemAddress4").val() == "104") {
      document.getElementById("Add_DataItemConfig_YuToXHZhang").value =
        $("#Add_DataItemAddress4").val() +
        ";" +
        $("#Add_huiluhao").val() +
        ";" +
        $("#Add_dianhao").val();
    } else {
      document.getElementById("Add_DataItemConfig_YuToXHZhang").value = $(
        "#Add_DataItemAddress4"
      ).val();
    }
  }
  //end add
  // add by fyj, 新增KUKA
  // add begin
  else if (ChannelDeviceType == "KUKA") {
    var kukaRW =
      $("input[name='Add_DataItemKukaRW']:checked").val() == "0" ? "R" : "W";
    var kukaNodeName = $("#Add_DataItemKukaNodeName").val();
    var kukaNodeIndex = $("#Add_DataItemKukaNodeIndex").val();
    var kukaNodeAttr1 = $("#Add_DataItemKukaNodeAttr1").val();
    var kukaNodeAttr2 = $("#Add_DataItemKukaNodeAttr2").val();
    var kukaDataType = $("#Add_DataItemKukaDataType").val();
    var kukaOperator = $("#Add_DataItemKukaDataOperator").val();
    var kukaParam1 = $("#Add_DataItemKukaParam1").val();
    var kukaParam2 = $("#Add_DataItemKukaParam2").val();

    kukaNodeAttr1 = kukaNodeAttr1.length > 0 ? "," + kukaNodeAttr1 : "";
    kukaNodeAttr2 = kukaNodeAttr2.length > 0 ? "," + kukaNodeAttr2 : "";

    if (kukaOperator == "0") {
      var kukaParam = "";
    } else if (kukaOperator == "1") {
      var kukaParam = "," + kukaParam1;
    } else {
      var kukaParam = "," + kukaParam1 + "," + kukaParam2;
    }

    var conf =
      kukaRW +
      ";" +
      "A:" +
      kukaNodeName +
      "," +
      kukaNodeIndex +
      kukaNodeAttr1 +
      kukaNodeAttr2 +
      ";V:" +
      kukaDataType +
      ";EX:" +
      kukaOperator +
      kukaParam;
    document.getElementById("Add_DataItemConfig_YuToXHZhang").value = conf;
  }
  // add end
  // add by fyj, OMRON-HostLink增加datahandler驱动
  else if (ChannelDeviceType == "OMRON-HostLink") {
    var isChecked = $("input[name='Add_DataItemDHEnable']:checked").val();
    $("#Add_DataItemDHEnable_YuToXHZhang").val(isChecked);
    if (isChecked == "1") {
      $("#Add_DataItemDHOptType_YuToXHZhang").val(
        $("#Add_DataItemDHSelect").val()
      );
      $("#Add_DataItemDHOptParam_YuToXHZhang").val(
        $("#Add_DataItemDHParam").val()
      );
    }
    document.getElementById("Add_DataItemConfig_YuToXHZhang").value =
      str.substr(0, length) +
      ";" +
      (DataItemType == "STRING" ? "STRING" + StringLength : DataItemType) +
      ";" +
      str.substr(length) +
      ";" +
      $("input[name='Add_DataItemRWmode']:checked").val();
  }
  // add end
  // add by fyj, OMRON-HostLink-Task
  else if (
    ChannelDeviceType == "OMRON-HostLink-Task" ||
    ChannelDeviceType == "OMRON-FINS-Task"
  ) {
    var isChecked = $("input[name='Add_DataItemDHEnable']:checked").val();
    $("#Add_DataItemDHEnable_YuToXHZhang").val(isChecked);
    if (isChecked == "1") {
      $("#Add_DataItemDHOptType_YuToXHZhang").val(
        $("#Add_DataItemDHSelect").val()
      );
      $("#Add_DataItemDHOptParam_YuToXHZhang").val(
        $("#Add_DataItemDHParam").val()
      );
    }
    document.getElementById("Add_DataItemConfig_YuToXHZhang").value =
      $("#Add_DataItemAddress").val() +
      ";" +
      (DataItemType == "STRING" ? "STRING" + StringLength : DataItemType);
  }
  // add end
  // add by fyj, DLT645-2007
  else if (
    ChannelDeviceType == "DLT645-2007" ||
    ChannelDeviceType == "DLT645-1997"
  ) {
    document.getElementById("Add_DataItemConfig_YuToXHZhang").value = $(
      "#Add_DataItemDltEnergy"
    ).val();
  }
  // add end
  // add by lh, IEC
  else if (ChannelDeviceType == "IEC104") {
    document.getElementById("Add_DataItemConfig_YuToXHZhang").value =
      $("#Add_DataItemIECAttr").val() + ";" + $("#Add_DataItemIECAttr2").val();
  } else if (ChannelDeviceType == "device") {
    document.getElementById("Add_DataItemConfig_YuToXHZhang").value = $(
      "#Add_DataItemAddress"
    ).val();
  }
  // add end
  else if (ChannelDeviceType == "HMI") {
    document.getElementById("Add_DataItemConfig_YuToXHZhang").value =
      $("#Add_DataItemAddress").val() +
      ";" +
      (DataItemType == "STRING" ? "STRING" + StringLength : DataItemType);
  } else if (ChannelDeviceType == "MITSUBISHI-TXZ-MomMach" || ChannelDeviceType == "MITSUBISHI-TXZ-SubMach1" || ChannelDeviceType == "MITSUBISHI-TXZ-SubMach2") {
    document.getElementById("Add_DataItemConfig_YuToXHZhang").value =
      $("#Add_CommandType").val() +
      ";" +
      $("#Add_TXZAddress1").val() +
      ";" +
      $("#Add_TXZAddress2").val();
  } else if (ChannelDeviceType == "MITSUBISHI-TX-15P" || ChannelDeviceType == "MITSUBISHI-TX-5HP"  || ChannelDeviceType == "MITSUBISHI-TX-Multi-link") {
    document.getElementById("Add_DataItemConfig_YuToXHZhang").value = $(
      "#Add_TX_config-hidden"
    ).val();
  } else if (ChannelDeviceType == "R1R2") {
    document.getElementById("Add_DataItemConfig_YuToXHZhang").value =
      $("#Add_Samsung_Address").val() +
      ";" +
      $("#Add_Samsung_Mode").val() ;
  }else {
    document.getElementById("Add_DataItemConfig_YuToXHZhang").value =
      str.substr(0, length) +
      ";" +
      (DataItemType == "STRING" ? "STRING" + StringLength : DataItemType) +
      ";" +
      str.substr(length);
  }

  //设备ID
  document.getElementById("Add_DeviceID_YuToXHZhang").value = DeviceID;

  if (ChannelDeviceType == "GPS") {
    document.getElementById("Add_DataItemType_YuToXHZhang").value = "s";
  }
  //var FinnalConfig = '{"DateItemAdd":' + '"' + document.getElementById("Add_DataItemAddress").value + '"' + ',' +  '"Add_DataItemType":' + '"' + document.getElementById("Add_DataItemType").value + '"' + '}';
  //alert(FinnalConfig)
  //document.getElementById("DataItemConfigUP").value = FinnalConfig;
  //alert(document.getElementById("DataItemConfigUP").value)
  $("#return3").attr("disabled", "disabled");
  $("#return4").attr("disabled", "disabled");
  var params = $("#Add_DataItemForm_YuToXHZhang").serialize();
  $.ajax({
    type: "post",
    url: "cgi-bin/device/AddDataitem.py",
    data: params,
    async: true,
    success: function (data) {
      $("#popWindow").hide();
      $("#Add_DataItem_Layer").hide();
      $("#return3").attr("disabled", "");
      $("#return4").attr("disabled", "");
      getData();
    },
  });
}

//修改数据项校验
function Check_Alter_DataItem() {
  // 数据项类型是否有效
  var isDataTypeValid = true;
  var CheckID = $("#Alter_DataItemID").val();
  var CheckName = $("#Alter_DataItemName").val();
  var Alies = $("#Alter_DataItemAlias").val();
  $("#addressTipInfo").html("");
  // modified by fyj
  // begin
  if (ChannelDeviceType != "KUKA") {
    var Address =
      (ChannelDeviceType == "GPS" && $("#Alter_DataItemAddress2").val()) ||
      $("#Alter_DataItemAddress").val();
    var FirAdd = Address.substr(0, 1);
  }
  // end
  var Freq = $("#Alter_DataItemFreq").val();
  var reg = new RegExp("^[0-9]+$");
  var regID = new RegExp("^[1-9]+[0-9]*$");
  // var DataItemType = ChannelDeviceType == "GPS" && "STRING" || $("#Alter_DataItemType").val();
  // add begin by fyj
  if (ChannelDeviceType == "SIEMENS-PPI") {
    var typeMap = {
      Boolean: "BIT",
      Byte: "BYTE",
      Word: "WORD",
      Short: "SHORT",
      DWord: "DWORD",
      Long: "LONG",
      Float: "FLOAT",
      String: "STRING",
      "Int 8": "INT8",
      "Int 16": "INT16",
      "Int 32": "INT32",
      BCD: "BCD",
    };
    var dateItemTypeStr = $("#Alter_DataItemTypeIpt").val();
    var DataItemType = typeMap[dateItemTypeStr];

    // 校验数据类型
    if (
      (!DataItemType || DataItemType.length == 0) &&
      (!dateItemTypeStr || dateItemTypeStr.length == 0)
    ) {
      //没有输入数据类型
      isDataTypeValid = false;
      if (coo == "English") {
        var $test = $("#Alter_DataItemTypeTip").html(
          "*Please fill in the data item type"
        );
      } else {
        var $test = $("#Alter_DataItemTypeTip").html("*请填写数据项类型");
      }
      return;
    } else if (dateItemTypeStr.length > 0) {
      // 自定义数据类型
      DataItemType = dateItemTypeStr;
    }
  }
  // add by whc
  if (ChannelDeviceType == "SIEMENS-S7-PPI-Task") {
    var typeMap = {
      BIT: "Bit",
      INT8: "Int8",
      UINT8: "UInt8",
      INT16: "Int16",
      UINT16: "UInt16",
      INT32: "Int32",
      UINT32: "UInt32",
      FLOAT: "Float",
      BCD: "BCD",
    };
    var dateItemTypeStr = $("#Alter_DataItemTypeIpt").val();
    var DataItemType = typeMap[dateItemTypeStr];

    // 校验数据类型
    if (
      (!DataItemType || DataItemType.length == 0) &&
      (!dateItemTypeStr || dateItemTypeStr.length == 0)
    ) {
      //没有输入数据类型
      isDataTypeValid = false;
      if (coo == "English") {
        var $test = $("#Alter_DataItemTypeTip").html(
          "*Please fill in the data item type"
        );
      } else {
        var $test = $("#Alter_DataItemTypeTip").html("*请填写数据项类型");
      }
      return;
    } else if (dateItemTypeStr.length > 0) {
      // 自定义数据类型
      DataItemType = dateItemTypeStr;
    }
  }
  // add end
  else {
    var DataItemType =
      (ChannelDeviceType == "GPS" && "STRING") || $("#Add_DataItemType").val();
  }
  // add end
  //校验数据项ID输入格式
  if (CheckID == "" || !regID.test(CheckID)) {
    if (coo == "English") {
      $("#idTipInfo").html("The data item ID must be a non-negative integer");
    } else {
      $("#idTipInfo").html("数据项ID必须为非负整数");
    }
  } else {
    $.ajax({
      type: "get",
      url: "../conf/config.xml",
      async: false,
      success: function (data) {
        var flag = 0;
        $(data)
          .find("model")
          .each(function () {
            var $model = $(this);
            $model.find("device").each(function () {
              var $device = $(this);
              $device.find("commDataItems").each(function () {
                var $commDataItems = $(this);
                $commDataItems.find("dataItem").each(function () {
                  var $dataItem = $(this);
                  var dataItemID = $dataItem.attr("id");
                  if (dataItemID == CheckID) {
                    var dataItemName = $dataItem.attr("n");
                    if (dataItemName == NowItemName) {
                      //跳过
                    } else {
                      flag = flag + 1;
                    }
                  }
                });
              });
            });
          });
        if (flag < 1) {
          $("#idTipInfo").html("");
        } else {
          if (coo == "English") {
            $("#idTipInfo").html("The data item ID is repeated, please change");
          } else {
            $("#idTipInfo").html("数据项ID已重复，请更改");
          }
        }
      },
    });
  }

  //校验数据项名称输入格式
  if (CheckName == "") {
    if (coo == "English") {
      $("#nameTipInfo").html("*The data item name cannot be empty");
    } else {
      $("#nameTipInfo").html("*数据项名称不能为空");
    }
  } else {
    //名字未修改时，不校验重名
    if (CheckName == NowItemName) {
      $("#nameTipInfo").html("");
    } else {
      //校验数据项名称是否重名
      if (!CheckReName(CheckName)) {
        if (coo == "English") {
          $("#nameTipInfo").html("The data item name is repeated");
        } else {
          $("#nameTipInfo").html("数据项名称重复");
        }
      } else {
        $("#nameTipInfo").html("");
      }
    }
  }
  //校验数据项别名不为空
  if (Alies == "") {
    if (coo == "English") {
      $("#AliasTipInfo").html("*Please fill in the alias");
    } else {
      $("#AliasTipInfo").html("*请填写别名");
    }
  } else {
    $("#AliasTipInfo").html("");
  }
  var Address = $("#Alter_DataItemAddress").val();
  if (ChannelDeviceType == "SIEMENS-PPI") {
    regValidate11(ChannelDeviceType, Address);
  } else if (
    Address == "" &&
    ChannelDeviceType != "Zundar" &&
    ChannelDeviceType != "OMRON_NJNX" &&
    ChannelDeviceType != "HKG-SERIAL" &&
    ChannelDeviceType != "KUKA" &&
    ChannelDeviceType != "OPC-UA" &&
    ChannelDeviceType != "IEC104" &&
    ChannelDeviceType != "DRACAL"
  ) {
    if (coo == "English") {
      $("#addressTipInfo").html("*Please fill in the data item address");
    } else {
      $("#addressTipInfo").html("*请填写数据项地址");
    }
  }
  //add begin by x
  //GPS 对地址不再判断
  else if (ChannelDeviceType == "GPS") {
    $("#addressTipInfo").html("");
  }
  //end add
  //add by lh IEC驱动无数据地址
  else if (ChannelDeviceType == "IEC104") {
    var DataItemType = $("#Alter_DataItemIECDataType").val();
    $("#addressTipInfo").html("");
    if ($("#Alter_DataItemIECAttr").val() == "") {
      if (coo == "English") {
        $("#Alter_DataItemIECNodeNameTip").html(
          "*Please input ASDU parameter."
        );
      } else {
        $("#Alter_DataItemIECNodeNameTip").html("*请填写ASDU参数");
      }
    } else {
      if ($("#Alter_DataItemIECAttr2").val() == "") {
        if (coo == "English") {
          $("#Alter_DataItemIECNodeNameTip").html(
            "*Please input IOB parameter."
          );
        } else {
          $("#Alter_DataItemIECNodeNameTip").html("*请填写IOB参数");
        }
      } else {
        $("#Alter_DataItemIECNodeNameTip").html("");
      }
    }
  } else if (ChannelDeviceType == "MITSUBISHI-TXZ-MomMach" ||ChannelDeviceType == "MITSUBISHI-TXZ-SubMach1" || ChannelDeviceType == "MITSUBISHI-TXZ-SubMach2" ) {
  } else if (ChannelDeviceType == "MITSUBISHI-TX-15P" || ChannelDeviceType == "MITSUBISHI-TX-5HP"  || ChannelDeviceType == "MITSUBISHI-TX-Multi-link") {
    if ($("#Alter_TX_config-hidden").val() == "error") {
      if (coo == "English") {
        $("#AlterTXConfigTip").html("*Please choose the correct address");
      } else {
        $("#AlterTXConfigTip").html("*请选择正确的地址");
      }
      return false;
    }
  }
  // add by whc,新增OPC驱动
  else if (ChannelDeviceType == "OPC") {
    if (Address == "") {
      if (coo == "English") {
        $("#addressTipInfo").html("*Please fill in the data item address");
      } else {
        $("#addressTipInfo").html("*请填写数据项地址");
      }
    }
  }

  // else if (Address != "" && ChannelDeviceType == "OPC") {
  //     var rege=/^[^\x2e]+\.[^\x2e]+\.[^\x2e]+$/;
  //     if(!rege.test(Address)){
  //         $("#addressTipInfo").html("数据项地址要以“.”分隔，参考格式为“Channel_1.Device_1.Tag_1”");
  //         return false;
  //     }
  // }
  // add end
  // add by whc,SIEMENS-S7-PPI-Task
  else if (Address == "" && ChannelDeviceType == "SIEMENS-S7-PPI-Task") {
    if (coo == "English") {
      $("#addressTipInfo").html("*Please fill in the data item address");
    } else {
      $("#addressTipInfo").html("*请填写数据项地址");
    }
  } else if (Address != "" && ChannelDeviceType == "SIEMENS-S7-PPI-Task") {
    var reg1 = /^[A-Z]+[0-9]+(\.[0-9]+)?$/;
    if (!reg1.test(Address)) {
      if (coo == "English") {
        $("#addressTipInfo").html(
          "Address must start with capital letters followed by letters and numbers, i.e. M5.1, MW10"
        );
      } else {
        $("#addressTipInfo").html(
          "数据项地址不匹配,应包含字母和数字，并以大写字母开头，参考格式“M5.1”或者“MW10”"
        );
      }
      return false;
    }
  }
  // add end
  // add by fyj , 新增KUKA驱动
  // add begin
  else if (ChannelDeviceType == "KUKA") {
    if ($("#Alter_DataItemKukaNodeName").val() == "") {
      if (coo == "English") {
        $("#Alter_DataItemKukaNodeNameTip").html(
          "*Please fill in the node name"
        );
      } else {
        $("#Alter_DataItemKukaNodeNameTip").html("*请填写节点名称");
      }
    } else {
      $("#Alter_DataItemKukaNodeNameTip").html("");
    }
    var myReg = new RegExp("^-?\\d+$");
    var nodeIndex = $("#Alter_DataItemKukaNodeIndex").val();
    if (nodeIndex == "" || !myReg.test(nodeIndex)) {
      if (coo == "English") {
        $("#Alter_DataItemKukaNodeIndexTip").html(
          "*Please enter the correct node index"
        );
      } else {
        $("#Alter_DataItemKukaNodeIndexTip").html("*请输入正确的节点索引");
      }
    } else {
      $("#Alter_DataItemKukaNodeIndexTip").html("");
    }

    if (
      $("#Alter_DataItemKukaParam1").css("display") != "none" &&
      $("#Alter_DataItemKukaParam1").val() == ""
    ) {
      if (coo == "English") {
        $("#Alter_DataItemKukaParam1Tip").html(
          "*Please enter the correct parameters"
        );
      } else {
        $("#Alter_DataItemKukaParam1Tip").html("*请输入正确的参数");
      }
    } else {
      $("#Alter_DataItemKukaParam1Tip").html("");
    }

    if (
      $("#Alter_DataItemKukaParam2").css("display") != "none" &&
      $("#Alter_DataItemKukaParam2").val() == ""
    ) {
      if (coo == "English") {
        $("#Alter_DataItemKukaParam2Tip").html(
          "*Please enter the correct parameters"
        );
      } else {
        $("#Alter_DataItemKukaParam2Tip").html("*请输入正确的参数");
      }
    } else {
      $("#Alter_DataItemKukaParam2Tip").html("");
    }
  }
  // add end
  // add by fyj, 新增DLT645-2007
  else if (
    ChannelDeviceType == "DLT645-2007" ||
    ChannelDeviceType == "DLT645-1997"
  ) {
    var val = $("#Alter_DataItemDltEnergy").val();
    if (val == "") {
      if (coo == "English") {
        $("#Alter_DataItemDltEnergyTip").html(
          "*Please fill in the data address"
        );
      } else {
        $("#Alter_DataItemDltEnergyTip").html("*请填写数据地址");
      }
    } else {
      $("#Alter_DataItemDltEnergyTip").html("");
    }
  }
  // add end
  else if (ChannelDeviceType == "OPC-UA") {
    var UAattr1 = $("#Alter_DataItemDataItemUAattr1").val();
    if (UAattr1 == "") {
      if (coo == "English") {
        $("#Alter_DataItemTypeTip").html("*Please input NodeID");
      } else {
        $("#Alter_DataItemTypeTip").html("*请填写NodeID");
      }
    } else {
      // if(!reg.test(UAattr1)){
      //     if (coo == "English") {
      //         $('#Alter_DataItemTypeTip').html('*Please enter the correct NodeID');
      //     }else{
      //         $('#Alter_DataItemTypeTip').html('*请填写正确的NodeID');
      //     }

      // }else {
      $("#Alter_DataItemTypeTip").html("");
      // }
    }
  } else if (
    ChannelDeviceType == "OMRON-HostLink-Task" ||
    ChannelDeviceType == "OMRON-FINS-Task"
  ) {
    var reg1 = /^[A-Z]+[0-9_]+(\.[0-9]+)?$/;
    if (!reg1.test(Address)) {
      if (coo == "English") {
        $("#addressTipInfo").html(
          "Address must start with capital letters followed by letters and numbers, i.e. W00.0, AR448"
        );
      } else {
        $("#addressTipInfo").html(
          "数据项地址不匹配,应包含字母和数字，并以大写字母开头，参考格式“W00.0”或者“AR448”"
        );
      }
    }
  } else if (  ChannelDeviceType == "R1R2") {
    $("#addressTipInfo").html("");
    var address = $("#Alter_Samsung_Address").val();
    if (!reg.test(address) ) {
      if (coo == "English") {
        $("#Alter_Samsung_AddressTip").html(
          "Address must be numbers"
        );
      } else {
        $("#Alter_Samsung_AddressTip").html(
          "数据项地址应为数值"
        );
      }
      return false;
    }else{
      $("#Alter_Samsung_AddressTip").html("");
    }
  } else {
    //校验地址第一位不为数字
    if (
      ChannelDeviceType != "YinHe" &&
      ChannelDeviceType != "Zundar" &&
      ChannelDeviceType != "OMRON_NJNX" &&
      ChannelDeviceType != "HKG-SERIAL" &&
      ChannelDeviceType != "Custom-TCP" &&
      ChannelDeviceType != "JB3102" &&
      ChannelDeviceType != "JB3208" &&
      ChannelDeviceType != "OPC" &&
      ChannelDeviceType != "SIEMENS-S7-PPI-Task" &&
      ChannelDeviceType != "device" &&
      ChannelDeviceType != "IEC104" &&
      ChannelDeviceType != "MITSUBISHI-TXZ-MomMach" &&
      ChannelDeviceType != "MITSUBISHI-TXZ-SubMach1" &&
      ChannelDeviceType != "MITSUBISHI-TXZ-SubMach2" &&
      ChannelDeviceType != "MITSUBISHI-TX-15P" &&
      ChannelDeviceType != "MITSUBISHI-TX-5HP" &&
      ChannelDeviceType != "MITSUBISHI-TX-Multi-link" &&
      ChannelDeviceType != "DRACAL"
    ) {
      regValidate(ChannelDeviceType, Address);
    } else {
      $("#addressTipInfo").html("");
    }
    if (
      ChannelDeviceType == "YinHe" ||
      ChannelDeviceType == "Custom-TCP" ||
      ChannelDeviceType == "OPC" ||
      ChannelDeviceType == "SIEMENS-S7-PPI-Task" ||
      ChannelDeviceType == "IEC104" ||
      ChannelDeviceType == "device"
    ) {
      $("#addressTipInfo").html("");
    }
  }

  //海信有ID
  if (ChannelDeviceType == "HKG-SERIAL") {
    if ($("#Alter_ID").val() == "") {
      if (coo == "English") {
        $("#Alter_ID_msg").html("*Please fill out the ID");
      } else {
        $("#Alter_ID_msg").html("*请填写ID");
      }
    } else {
      if (!reg.test($("#Alter_ID").val()) || $("#Alter_ID").val() == 0) {
        if (coo == "English") {
          $("#Alter_ID_msg").html("*The ID must be a positive integer");
        } else {
          $("#Alter_ID_msg").html("*ID必须为正整数");
        }
      } else {
        $("#Alter_ID_msg").html("");
      }
    }
  }
  //校验频率不为空
  if (Freq == "") {
    if (coo == "English") {
      $("#freqTipInfo").html("*Please fill in the sample frequency");
    } else {
      $("#freqTipInfo").html("*请填写采集频率");
    }
  } else {
    if (!reg.test(Freq) || Freq == 0) {
      if (coo == "English") {
        $("#freqTipInfo").html("*The frequencies must be positive integers");
      } else {
        $("#freqTipInfo").html("*频率必须为正整数");
      }
    } else {
       $.ajax({
         type: "get",
         url: "../conf/Common.xml",
         async: false,
         success: function (data) {
           var minFrequency = $(data).find("MinFrequency").text();
           var currentFreq = 0;
           if ($("#Alter_DataItemUnit").val() == "second") {
             currentFreq = parseInt(Freq) * 1000;
           } else {
             currentFreq = parseInt(Freq) * 1000 * 60;
           }

           if (currentFreq < parseInt(minFrequency)) {
             if (coo == "English") {
               $("#freqTipInfo").html(
                 "*The lowest frequency currently supported is" +
                   minFrequency / 1000 +
                   "seconds"
               );
             } else {
               $("#freqTipInfo").html(
                 "*当前支持的最低频率为" + minFrequency / 1000 + "秒"
               );
             }
           } else {
             $("#freqTipInfo").html("");
           }
         },
       });
    }
  }
  if (ChannelDeviceType == "OPC-UA") {
    var a = $("#Alter_DataItemUnit").val();
    if (a == "ms") {
      if (Freq < 100) {
        if (coo == "English") {
          $("#freqTipInfo").html("*The frequencies must be more than 100ms.");
        } else {
          $("#freqTipInfo").html("*要求频率大于100ms");
        }
      } else {
        $("#freqTipInfo").html("");
      }
    }
  }
  //如果数据项类型为String，则校验长度是否为整数且为偶数
  if (
    DataItemType == "STRING" &&
    ChannelDeviceType != "OMRON_NJNX" &&
    ChannelDeviceType != "HKG-SERIAL" &&
    ChannelDeviceType != "Custom-TCP" &&
    ChannelDeviceType != "GPS" &&
    ChannelDeviceType != "JB3102" &&
    ChannelDeviceType != "JB3208" &&
    ChannelDeviceType != "OPC" &&
    ChannelDeviceType != "SIEMENS-S7-PPI-Task" &&
    ChannelDeviceType != "DRACAL"
  ) {
    var StringLength = $("#Alter_stringLength").val();
    if (StringLength == "") {
      if (coo == "English") {
        $("#Alter_stringMsg").html("*Please input length");
      } else {
        $("#Alter_stringMsg").html("*请输入长度");
      }
    } else {
      if (reg.test(StringLength) && parseInt(StringLength) % 2 == 0) {
        $("#Alter_stringMsg").html("");
      } else {
        if (coo == "English") {
          $("#Alter_stringMsg").html("*The length must be numeric and even");
        } else {
          $("#Alter_stringMsg").html("*长度必须为数字且为偶数");
        }
      }
    }
  } else {
    $("#Alter_stringMsg").html("");
  }
  if (ChannelDeviceType == "OMRON_NJNX" && $("#Alter_DatasName").val() == "") {
    if (coo == "English") {
      $("#dataPnameTipInfo").html("Please enter the data point name");
    } else {
      $("#dataPnameTipInfo").html("请输入数据点名称");
    }
  } else {
    $("#dataPnameTipInfo").html("");
  }
  // add by whc
  if (
    ChannelDeviceType == "DRACAL" &&
    $("#Alter_DataItemDRACALChannel").val() == ""
  ) {
    $("#ChannelTipInfo").html("请输入通道名称");
  } else {
    $("#ChannelTipInfo").html("");
  }
  // add end

  $("#Alter_DataItemDHParamTip").html("");
  var isChecked = $("input[name='Alter_DataItemDHEnable']:checked").val();
  if (isChecked == "1") {
    var paramVal = $("#Alter_DataItemDHParam").val();
    if ($("#Alter_DataItemDHSelect").val() == "#") {
      var linearParam1 = $("#Alter_DHFunctionParam1").val();
      var linearParam2 = $("#Alter_DHFunctionParam2").val();
      if (linearParam1 == "" || linearParam2 == "") {
        if (coo == "English") {
          $("#Alter_DataItemDHParamTip").html(
            "Please fill in the value operation parameters"
          );
        } else {
          $("#Alter_DataItemDHParamTip").html("请填写值运算参数");
        }
      } else {
        var dhReg = /^-?[0-9]+.?[0-9]*$/;
        if (!dhReg.test(linearParam1) || !dhReg.test(linearParam2)) {
          if (coo == "English") {
            $("#Alter_DataItemDHParamTip").html(
              "The value operation parameter must be a number"
            );
          } else {
            $("#Alter_DataItemDHParamTip").html("值运算参数必须是数字");
          }
        }
      }
    } else if (paramVal == "") {
      if (coo == "English") {
        $("#Alter_DataItemDHParamTip").html(
          "Please fill in the value operation parameters"
        );
      } else {
        $("#Alter_DataItemDHParamTip").html("请填写值运算参数");
      }
    } else {
      // 校验输入的操作数是否是数字
      var dhReg = /^-?[0-9]+.?[0-9]*$/;
      if (!dhReg.test(paramVal)) {
        if (coo == "English") {
          $("#Alter_DataItemDHParamTip").html(
            "The value operation parameter must be a number"
          );
        } else {
          $("#Alter_DataItemDHParamTip").html("值运算参数必须是数字");
        }
      } else if ($("#Alter_DataItemDHSelect").val() == "5") {
        var dhReg = /^[0-9]+$/;
        if (!dhReg.test(paramVal)) {
          if (coo == "English") {
            $("#Alter_DataItemDHParamTip").html(
              "The parameter of the fetch operation must be an integer"
            );
          } else {
            $("#Alter_DataItemDHParamTip").html("取位运算的参数必须是整数");
          }
        } else {
          var paramVal = Number(paramVal);
          if (paramVal < 0 || paramVal > 31) {
            if (coo == "English") {
              $("#Alter_DataItemDHParamTip").html(
                "The range of parameters for the fetch operation must be 0 to 31"
              );
            } else {
              $("#Alter_DataItemDHParamTip").html(
                "取位运算的参数的范围必须是0到31"
              );
            }
          }
        }
      }
    }
  }
  // add end

  //判断是否通过
  if (
    $("#idTipInfo").html() == "" &&
    $("#nameTipInfo").html() == "" &&
    $("#AliasTipInfo").html() == "" &&
    $("#addressTipInfo").html() == "" &&
    $("#freqTipInfo").html() == "" &&
    $("#Alter_stringMsg").html() == "" &&
    $("#Alter_ID_msg").html() == "" &&
    $("#dataPnameTipInfo").html() == "" &&
    $("#Alter_DataItemTypeTip").html() == "" &&
    isDataTypeValid &&
    $("#Alter_DataItemKukaNodeIndexTip").html() == "" &&
    $("#Alter_DataItemKukaNodeNameTip").html() == "" &&
    $("#Alter_DataItemKukaParam1Tip").html() == "" &&
    $("#Alter_DataItemKukaParam2Tip").html() == "" &&
    $("#Alter_DataItemDHParamTip").html() == "" &&
    $("#Alter_DataItemDltEnergyTip").html() == ""
  ) {
    //        全部通过
    Alter_DataItemMethod();
  } else {
  }
}

//修改数据项方法
function Alter_DataItemMethod() {
  document.getElementById("checkTwoInfo").innerHTML = "";
  var reg = /[a-zA-Z]/g;
  var str = document.getElementById("Alter_DataItemAddress").value;
  if (
    ChannelDeviceType != "YinHe" &&
    ChannelDeviceType != "Custom-TCP" &&
    ChannelDeviceType != "JB3102" &&
    ChannelDeviceType != "JB3208" &&
    ChannelDeviceType != "OPC" &&
    ChannelDeviceType != "SIEMENS-S7-PPI-Task" &&
    ChannelDeviceType != "OPC-UA" &&
    ChannelDeviceType != "IEC104" &&
    ChannelDeviceType != "device" &&
    ChannelDeviceType != "MITSUBISHI-TX-15P"&&
    ChannelDeviceType != "MITSUBISHI-TX-5HP"&&
    ChannelDeviceType != "MITSUBISHI-TX-Multi-link"&&
    ChannelDeviceType != "R1R2"
  ) {
    var length = str.match(reg).length;
  }
  // var DataItemType = $("#Alter_DataItemType").val();
  // modified by fyj   为SIEMENS-PPI驱动增加自定义数据项类型功能
  // begin
  if (ChannelDeviceType == "SIEMENS-PPI") {
    var typeMap = {
      Boolean: "BIT",
      Byte: "BYTE",
      Word: "WORD",
      Short: "SHORT",
      DWord: "DWORD",
      Long: "LONG",
      Float: "FLOAT",
      String: "STRING",
      "Int 8": "INT8",
      "Int 16": "INT16",
      "Int 32": "INT32",
      BCD: "BCD",
    };
    var DataItemTypeStr = $("#Alter_DataItemTypeIpt").val();
    var DataItemType = typeMap[DataItemTypeStr] || DataItemTypeStr;
    // add by whc
  } else if (ChannelDeviceType == "SIEMENS-S7-PPI-Task") {
    var typeMap = {
      BIT: "Bit",
      INT8: "Int8",
      UINT8: "UInt8",
      INT16: "Int16",
      UINT16: "UInt16",
      INT32: "Int32",
      UINT32: "UInt32",
      FLOAT: "Float",
      BCD: "BCD",
    };
    var DataItemTypeStr = $("#Alter_DataItemTypeIpt").val();
    var DataItemType = typeMap[DataItemTypeStr] || DataItemTypeStr;
    // add end
  } else if (ChannelDeviceType == "IEC104") {
    var DataItemType = $("#Alter_DataItemIECDataType").val();
    // add by lh
  } else if (ChannelDeviceType == "device") {
    var DataItemType = $("#Alter_DataItemIECDataType").val();
  } else {
    var DataItemType = $("#Alter_DataItemType").val();
  }
  var StringLength = $("#Alter_stringLength").val();
  var Freq = document.getElementById("Alter_DataItemFreq").value;
  var Unit = document.getElementById("Alter_DataItemUnit").value;
  if (Unit == "minute") {
    Freq = Freq * 60000;
  } else {
    Freq = Freq * 1000;
  }

  //add by lh,OPC-UA驱动支持毫秒级采集
  if (ChannelDeviceType == "OPC-UA") {
    if (Unit == "ms") {
      Freq = Freq / 1000;
    }
  }
  // modified by fyj
  if (ChannelDeviceType == "KUKA") {
    var kukaDataType = $("#Alter_DataItemKukaDataType").val();
    if (kukaDataType == "3") {
      document.getElementById("Alter_DataItemType_YuToXHZhang").value = "s";
    } else {
      document.getElementById("Alter_DataItemType_YuToXHZhang").value = "a";
    }
  } else if (
    ChannelDeviceType == "DLT645-2007" ||
    ChannelDeviceType == "DLT645-1997"
  ) {
    document.getElementById("Alter_DataItemType_YuToXHZhang").value = $(
      "#Alter_DataItemType"
    ).val();
  } else if (
    ChannelDeviceType == "OPC-UA" ||
    ChannelDeviceType == "MITSUBISHI-TXZ-MomMach" ||
    ChannelDeviceType == "MITSUBISHI-TXZ-SubMach1" ||
    ChannelDeviceType == "MITSUBISHI-TXZ-SubMach2" 
  ) {
    var UADataType = $("#Alter_DataItemUAType").val();
    document.getElementById(
      "Alter_DataItemType_YuToXHZhang"
    ).value = UADataType;
  } else if (ChannelDeviceType == "R1R2") {
    document.getElementById(
      "Alter_DataItemType_YuToXHZhang"
    ).value = $("#Alter_Samsung_DataItemType").val();
  } else if (ChannelDeviceType == "MITSUBISHI-TX-15P" || ChannelDeviceType == "MITSUBISHI-TX-5HP" || ChannelDeviceType == "MITSUBISHI-TX-Multi-link") {
    document.getElementById("Alter_DataItemType_YuToXHZhang").value = $(
      "#Alter_DataItemTXType"
    ).val();
  } else {
    //数据项类型
    if (DataItemType == "BIT")
      document.getElementById("Alter_DataItemType_YuToXHZhang").value = "b";
    else if (DataItemType == "STRING")
      document.getElementById("Alter_DataItemType_YuToXHZhang").value = "s";
    else document.getElementById("Alter_DataItemType_YuToXHZhang").value = "a";
  }
  //设备ID
  document.getElementById("Alter_DeviceID_YuToXHZhang").value = DeviceID;
  //数据项ID
  document.getElementById(
    "Alter_DataItemID_after"
  ).value = document.getElementById("Alter_DataItemID").value;
  //数据项名称
  document.getElementById(
    "Alter_DataItemName_YuToXHZhang"
  ).value = document.getElementById("Alter_DataItemName").value;
  //数据项别名
  document.getElementById(
    "Alter_DataItemAlias_YuToXHZhang"
  ).value = document.getElementById("Alter_DataItemAlias").value;
  //读写模式
  document.getElementById("Alter_DataItemRWmode_YuToXHZhang").value = $(
    "input[name='Alter_DataItemRWmode']:checked"
  ).val();
  //频率
  document.getElementById("Alter_DataItemFreq_YuToXHZhang").value = Freq;
  //是否上报
  $("#Alter_DataItemReport_YuToXHZhang").val( $("input[name='Alter_ReportType']:checked").val() );
  //数据项配置字符串

  var isChecked = $("input[name='Alter_DataItemDHEnable']:checked").val();
  $("#Alter_DataItemDHEnable_YuToXHZhang").val(isChecked);
  if (isChecked == "1") {
    $("#Alter_DataItemDHOptType_YuToXHZhang").val(
      $("#Alter_DataItemDHSelect").val()
    );
    if ($("#Alter_DataItemDHSelect").val() === "#") {
      $("#Alter_DataItemDHOptParam_YuToXHZhang").val(
        $("#Alter_DHFunctionParam1").val() +
          "|" +
          $("#Alter_DHFunctionParam2").val()
      );
    } else {
      $("#Alter_DataItemDHOptParam_YuToXHZhang").val(
        $("#Alter_DataItemDHParam").val()
      );
    }
  }
  if (
    ChannelDeviceType == "MITSUBISHI-FX" &&
    (str.substr(0, length) == "X" || str.substr(0, length) == "Y")
  ) {
    var m = str.substr(length);
    document.getElementById("Alter_DataItemConfig_YuToXHZhang").value =
      str.substr(0, length) +
      ";" +
      (DataItemType == "STRING" ? "STRING" + StringLength : DataItemType) +
      ";" +
      parseInt(m, 8) +
      ";" +
      $("input[name='Alter_DataItemRWmode']:checked").val();
  } else if (
    ChannelDeviceType == "MITSUBISHI-QS" ||
    ChannelDeviceType == "MITSUBISHI-QN"
  ) {
    document.getElementById("Alter_DataItemConfig_YuToXHZhang").value =
      str +
      ";" +
      (DataItemType == "STRING" ? "STRING" + StringLength : DataItemType) +
      ";" +
      $("input[name='Alter_DataItemRWmode']:checked").val();
    // add by whc
  } else if (ChannelDeviceType == "FATEK编程口") {
    document.getElementById("Alter_DataItemConfig_YuToXHZhang").value =
      (DataItemType == "STRING" ? "STRING" + StringLength : DataItemType) +
      ";" +
      str;
    // add end
  } else if (ChannelDeviceType == "AB-DF1") {
    str = str.toUpperCase();
    document.getElementById("Alter_DataItemConfig_YuToXHZhang").value =
      str +
      ";" +
      (DataItemType == "STRING" ? "STRING" + StringLength : DataItemType) +
      ";" +
      $("input[name='Alter_DataItemRWmode']:checked").val();
  } else if (ChannelDeviceType == "YinHe") {
    document.getElementById("Alter_DataItemConfig_YuToXHZhang").value = $(
      "#Alter_DataItemAddress"
    ).val();
  } else if (ChannelDeviceType == "Zundar") {
    document.getElementById(
      "Alter_DataItemConfig_YuToXHZhang"
    ).value = ZundarConfig;
  } else if (ChannelDeviceType == "OMRON_NJNX") {
    document.getElementById("Alter_DataItemConfig_YuToXHZhang").value = $(
      "#Alter_DatasName"
    ).val();
  } else if (ChannelDeviceType == "DRACAL") {
    document.getElementById("Alter_DataItemConfig_YuToXHZhang").value = $(
      "#Alter_DataItemDRACALChannel"
    ).val();
  } else if (ChannelDeviceType == "HKG-SERIAL") {
    document.getElementById("Alter_DataItemConfig_YuToXHZhang").value = $(
      "#Alter_ID"
    ).val();
  } else if (ChannelDeviceType == "Custom-TCP") {
    document.getElementById("Alter_DataItemConfig_YuToXHZhang").value = str;
  }
  //add begin by x
  else if (ChannelDeviceType == "GPS") {
    document.getElementById("Alter_DataItemConfig_YuToXHZhang").value = $(
      "#Alter_DataItemAddress2"
    ).val();
  }
  //end add
  // add by whc
  else if (ChannelDeviceType == "OPC") {
    var reg = new RegExp("[^\x00-\xff]+", "g");
    if (reg.test(str)) {
      document.getElementById("Alter_DataItemConfig_YuToXHZhang").value =
        "gb2312" + ";" + $("#Alter_DataItemAddress").val();
    } else {
      document.getElementById("Alter_DataItemConfig_YuToXHZhang").value = $(
        "#Alter_DataItemAddress"
      ).val();
    }
    // document.getElementById("Alter_DataItemAlias_YuToXHZhang").value = "1";
  }
  // end add
  // add by whc
  else if (ChannelDeviceType == "SIEMENS-S7-PPI-Task") {
    document.getElementById("Alter_DataItemConfig_YuToXHZhang").value =
      $("#Alter_DataItemAddress").val() + ";" + DataItemType;
  }
  // add end
  // add begin by x
  else if (ChannelDeviceType == "JB3102") {
    if ($("#Alter_DataItemAddress3").val() == "205") {
      document.getElementById("Alter_DataItemConfig_YuToXHZhang").value =
        $("#Alter_DataItemAddress3").val() +
        ";" +
        $("#Alter_huiluhao").val() +
        ";" +
        $("#Alter_dianhao").val();
    } else {
      document.getElementById("Alter_DataItemConfig_YuToXHZhang").value = $(
        "#Alter_DataItemAddress3"
      ).val();
    }
  } else if (ChannelDeviceType == "JB3208") {
    if ($("#Alter_DataItemAddress4").val() == "104") {
      document.getElementById("Alter_DataItemConfig_YuToXHZhang").value =
        $("#Alter_DataItemAddress4").val() +
        ";" +
        $("#Alter_huiluhao").val() +
        ";" +
        $("#Alter_dianhao").val();
    } else {
      document.getElementById("Alter_DataItemConfig_YuToXHZhang").value = $(
        "#Alter_DataItemAddress4"
      ).val();
    }
  }
  // end add
  // add by fyj, 新增KUKA
  // add begin
  else if (ChannelDeviceType == "KUKA") {
    var kukaRW =
      $("input[name='Alter_DataItemKukaRW']:checked").val() == "0" ? "R" : "W";
    var kukaNodeName = $("#Alter_DataItemKukaNodeName").val();
    var kukaNodeIndex = $("#Alter_DataItemKukaNodeIndex").val();
    var kukaNodeAttr1 = $("#Alter_DataItemKukaNodeAttr1").val();
    var kukaNodeAttr2 = $("#Alter_DataItemKukaNodeAttr2").val();
    var kukaDataType = $("#Alter_DataItemKukaDataType").val();
    var kukaOperator = $("#Alter_DataItemKukaDataOperator").val();
    var kukaParam1 = $("#Alter_DataItemKukaParam1").val();
    var kukaParam2 = $("#Alter_DataItemKukaParam2").val();

    kukaNodeAttr1 = kukaNodeAttr1.length > 0 ? "," + kukaNodeAttr1 : "";
    kukaNodeAttr2 = kukaNodeAttr2.length > 0 ? "," + kukaNodeAttr2 : "";

    if (kukaOperator == "0") {
      var kukaParam = "";
    } else if (kukaOperator == "1") {
      var kukaParam = "," + kukaParam1;
    } else {
      var kukaParam = "," + kukaParam1 + "," + kukaParam2;
    }

    var conf =
      kukaRW +
      ";" +
      "A:" +
      kukaNodeName +
      "," +
      kukaNodeIndex +
      kukaNodeAttr1 +
      kukaNodeAttr2 +
      ";V:" +
      kukaDataType +
      ";EX:" +
      kukaOperator +
      kukaParam;
    document.getElementById("Alter_DataItemConfig_YuToXHZhang").value = conf;
  }
  // add end
  // add by fyj, hostlink add datahandler
  else if (ChannelDeviceType == "OMRON-HostLink") {
    document.getElementById("Alter_DataItemConfig_YuToXHZhang").value =
      str.substr(0, length) +
      ";" +
      (DataItemType == "STRING" ? "STRING" + StringLength : DataItemType) +
      ";" +
      str.substr(length) +
      ";" +
      $("input[name='Alter_DataItemRWmode']:checked").val();
  }
  // add end
  // add by lh, IEC
  else if (ChannelDeviceType == "IEC104") {
    var IECDataType = $("#Alter_DataItemIECDataType").val();
    document.getElementById(
      "Alter_DataItemType_YuToXHZhang"
    ).value = IECDataType;

    document.getElementById("Alter_DataItemConfig_YuToXHZhang").value =
      $("#Alter_DataItemIECAttr").val() +
      ";" +
      $("#Alter_DataItemIECAttr2").val();
  } else if (ChannelDeviceType == "device") {
    var IECDataType = $("#Alter_DataItemIECDataType").val();
    document.getElementById(
      "Alter_DataItemType_YuToXHZhang"
    ).value = IECDataType;
    document.getElementById("Alter_DataItemConfig_YuToXHZhang").value = $(
      "#Alter_DataItemAddress"
    ).val();
  }
  // add end
  // add by fyj, OMRON-HostLink-Task
  else if (
    ChannelDeviceType == "OMRON-HostLink-Task" ||
    ChannelDeviceType == "OMRON-FINS-Task"
  ) {
    document.getElementById("Alter_DataItemConfig_YuToXHZhang").value =
      $("#Alter_DataItemAddress").val() +
      ";" +
      (DataItemType == "STRING" ? "STRING" + StringLength : DataItemType);
  }
  // add end
  // add by fyj, DLT645-2007
  else if (
    ChannelDeviceType == "DLT645-2007" ||
    ChannelDeviceType == "DLT645-1997"
  ) {
    document.getElementById("Alter_DataItemConfig_YuToXHZhang").value = $(
      "#Alter_DataItemDltEnergy"
    ).val();
  }
  // add end
  else if (ChannelDeviceType == "OPC-UA") {
    document.getElementById("Alter_DataItemConfig_YuToXHZhang").value =
      $("#Alter_DataItemDataItemUAattr1").val() + ";" + 13;
    //默认地址13 可能会改
  } else if (ChannelDeviceType == "HMI") {
    document.getElementById("Alter_DataItemConfig_YuToXHZhang").value =
      $("#Alter_DataItemAddress").val() +
      ";" +
      (DataItemType == "STRING" ? "STRING" + StringLength : DataItemType);
  } else if (ChannelDeviceType == "MITSUBISHI-TXZ-MomMach" || ChannelDeviceType == "MITSUBISHI-TXZ-SubMach1" || ChannelDeviceType == "MITSUBISHI-TXZ-SubMach2") {
    document.getElementById("Alter_DataItemConfig_YuToXHZhang").value =
      $("#Alter_CommandType").val() +
      ";" +
      $("#Alter_TXZAddress1").val() +
      ";" +
      $("#Alter_TXZAddress2").val();
  } else if (ChannelDeviceType == "MITSUBISHI-TX-15P" || ChannelDeviceType == "MITSUBISHI-TX-5HP" || ChannelDeviceType == "MITSUBISHI-TX-Multi-link") {
    document.getElementById("Alter_DataItemConfig_YuToXHZhang").value = $(
      "#Alter_TX_config-hidden"
    ).val();
  } else if (ChannelDeviceType == "R1R2") {
    document.getElementById("Alter_DataItemConfig_YuToXHZhang").value =
      $("#Alter_Samsung_Address").val() +
      ";" +
      $("#Alter_Samsung_Mode").val();
  } else {
    document.getElementById("Alter_DataItemConfig_YuToXHZhang").value =
      str.substr(0, length) +
      ";" +
      (DataItemType == "STRING" ? "STRING" + StringLength : DataItemType) +
      ";" +
      str.substr(length);
  }
  if (ChannelDeviceType == "GPS") {
    document.getElementById("Alter_DataItemType_YuToXHZhang").value = "s";
  }
  $("#return5").attr("disabled", "disabled");
  $("#return6").attr("disabled", "disabled");
  var params = $("#Alter_DataItemForm_YuToXHZhang").serialize();
  $.ajax({
    type: "post",
    url: "cgi-bin/device/AlterDataitem.py",
    data: params,
    async: true,
    success: function (data) {
      $("#popWindow").hide();
      $("#Alter_DataItem_Layer").hide();
      $("#return5").attr("disabled", "");
      $("#return6").attr("disabled", "");
      getData();
    },
  });
}

//全局一个需要删除的长度
var checkLength = "";

function CheckedLength() {
  checkLength = 0;
  document.getElementById("AllDataitemID").value = "";
  document.getElementById("Delete_DataItemAllID_YuToXHZhang").value = "";
  var inputs = document.getElementsByName("tryadd");
  var length = inputs.length;
  for (var i = 0; i < length; i++) {
    if (inputs[i].checked) {
      document.getElementById("AllDataitemID").value += inputs[i].value + ";";
      checkLength++;
    }
  }
  var str = document.getElementById("AllDataitemID").value;
  var strArr = new Array();
  strArr = str.split(";");
  var maxlength = strArr.length;
  for (var j = 0; j < maxlength - 2; j++) {
    document.getElementById("Delete_DataItemAllID_YuToXHZhang").value +=
      strArr[j] + ",";
  }
  document.getElementById("Delete_DataItemAllID_YuToXHZhang").value +=
    strArr[maxlength - 2];
}

//删除数据项
function DeleteConfig() {
  document.getElementById("Delete_DeviceID_YuToXHZhang").value = DeviceID;
  CheckedLength();
  $("#DeleteDataItem_Button_Confim").attr("disabled", "disabled");
  $("#DeleteDataItem_Button_Cancel").attr("disabled", "disabled");
  var params = $("#Delete_DataItemForm_YuToXHZhang").serialize();
  $.ajax({
    type: "post",
    url: "cgi-bin/device/DeleteDataitem.py",
    data: params,
    async: true,
    success: function (data) {
      $("#popWindow").hide();
      $("#DeleteDataItemLayer").hide();
      $("#DeleteDataItem_Button_Confim").attr("disabled", "");
      $("#DeleteDataItem_Button_Cancel").attr("disabled", "");
      getData();
      $("#selectAll").attr("checked", "");
    },
  });
}

//全选和反选
function addTry() {
  if (document.getElementById("selectAll").checked) {
    var inputs = document.getElementsByName("tryadd");
    for (var i = 0; i < inputs.length; i++) {
      inputs[i].checked = true;
    }
  } else {
    var inputs = document.getElementsByName("tryadd");
    for (var i = 0; i < inputs.length; i++) {
      inputs[i].checked = false;
    }
  }
}
//下发数据项
function Open_IssuedLayer() {
  document.getElementById("popWindow").style.display = "";
  document.getElementById("IssuedLayer").style.display = "";
  document.getElementById("ConUp1").style.display = "";
  $("#up_success").hide();
  //      document.getElementById("Hide_IssuedIframe").style.display = 'none'
  document.getElementById("Issued_Button_Confim").style.display = "";
  document.getElementById("Issued_Button_Cancel").style.display = "";
  document.getElementById("Issued_Success_Button_Confim").style.display =
    "none";
  //动态图隐藏
  document.getElementById("Loading").style.display = "none";
}

function UpConfigCon() {
  times = 0;
  document.getElementById("IssuedLayer").style.display = "none";
  window.parent.document.getElementById("IssuedLayer").style.display = "";
  document.getElementById("ConUp1").style.display = "none";
  // document.getElementById("Loading").style.display = '';
  // document.getElementById("Hide_IssuedIframe").style.display = "none"
  $("#Issued_Button_Confim").attr("disabled", "disabled");
  $("#Issued_Button_Cancel").attr("disabled", "disabled");
  $.ajax({
    type: "post",
    url: "cgi-bin/agent/GiveToAgent.py",
    data: "up=1",
    async: false,
    success: function (data) {
      $("#up_success").html(data);
      document.getElementById("popWindow").style.backgroundColor = "#ddd";
      window.parent.document.getElementById("popWindow").style.display = "";
      window.parent.document.getElementById("IssuedLayer").style.display = "";
      getagent = setInterval("getAgentStatue()", 5000);
    },
  });
}
//全局一个发送次数
var times = 0;
var getagent = "";

function getAgentStatue() {
  //获取测试字符串
  var value = getFirstID();
  $("#Test_Value_YuToXHZhang").val(value);
  var params = $("#Test_DataItemForm_YuToXHZhang").serialize();
  times++;
  //两分钟超时
  if (times < 18) {
    $.ajax({
      type: "post",
      url: "cgi-bin/RealTimeData/GetAgentStatue.py",
      data: params,
      async: true,
      success: function (data) {
        //如果测试返回结果正确，即返回为1，则可以关闭下发窗口
        if (data == 1) {
          $("#up_success").show();
          $("#Loading").hide();
          $("#Issued_Button_Confim").attr("disabled", "");
          $("#Issued_Button_Cancel").attr("disabled", "");
          $("#Issued_Button_Confim").hide();
          $("#Issued_Button_Cancel").hide();
          $("#Issued_Success_Button_Confim").show();
          $("#ConUp1").hide();
          window.parent.document.getElementById("popWindow").style.display =
            "none";
          document.getElementById("popWindow").style.backgroundColor =
            "#9D9D9D";
          window.parent.document.getElementById("IssuedLayer").style.display =
            "none";
          document.getElementById("IssuedLayer").style.display = "";
          clearInterval(getagent);
        } else {
        }
      },
    });
  } else {
    $("#Issued_Button_Confim").attr("disabled", "");
    $("#Issued_Button_Cancel").attr("disabled", "");
    document.getElementById("IssuedLayer").style.display = "";
    window.parent.document.getElementById("popWindow").style.display = "none";
    document.getElementById("popWindow").style.backgroundColor = "#9D9D9D";
    window.parent.document.getElementById("IssuedLayer").style.display = "none";
    if (coo == "English") {
      document.getElementById("up_success").innerHTML =
        "Agent startup timeout, please try again later";
    } else {
      document.getElementById("up_success").innerHTML =
        "agent启动超时，请稍后再试";
    }
    document.getElementById("up_success").style.display = "";
    document.getElementById("ConUp1").style.display = "none";
    document.getElementById("Issued_Button_Confim").style.display = "none";
    document.getElementById("Issued_Success_Button_Confim").style.display = "";
    clearInterval(getagent);
  }
}

function getFirstID() {
  var id = "";
  $.ajax({
    type: "get",
    url: "../conf/config.xml",
    async: false,
    success: function (data) {
      $(data)
        .find("model[id='" + ChannelID + "']")
        .each(function () {
          var $model = $(this);
          $model.find("device[id='" + DeviceID + "']").each(function () {
            var $device = $(this);
            $device.find("driver").each(function () {
              var $driver = $(this);
              DriverID = $driver.attr("id");
              $driver.find("commDataItems").each(function () {
                var $commDataItems = $(this);
                $commDataItems.find("dataItem:first-child").each(function () {
                  var $dataItem = $(this);
                  var dataItemID = $dataItem.attr("id");
                  id = dataItemID;
                });
              });
            });
          });
        });
    },
  });
  //拼出测试字符串

  var value = "";
  var ChannelDriverArr = new Array();
  ChannelDriverArr = ChannelDriver.split(":");
  var ChannelDriverShort = ChannelDriverArr[1];
  if (id == "") {
    //没有数据时候
    value =
      '{"id":' +
      DeviceID +
      ',"dn":"","vid":' +
      DriverID +
      ',"vn":"' +
      ChannelDriverShort +
      '", "cmds":{"read":1}}';
  } else {
    value =
      '{"id":' +
      DeviceID +
      ',"dn":"","vid":' +
      DriverID +
      ',"vn":"' +
      ChannelDriverShort +
      '", "cmds":{"read":0,"ids":[' +
      id +
      "]}}";
  }
  return value;
}
//读数据项ID最大值并赋值
function getID() {
  $.get("../conf/IDinfo.xml", function (d1) {
    $(d1)
      .find("IDALL")
      .each(function () {
        var $IDALL = $(this);
        var DataitemID = $IDALL.find("ItemID").text();
        document.getElementById(
          "Add_DataItemID_YuToXHZhang"
        ).value = DataitemID;
        document.getElementById("Add_DataItemID").value = DataitemID;
      });
  });
}

function Import_Success_ReloadNewPage() {
  getData();
  $("#popWindow").hide();
  $("#ImportLayer").hide();
}

function Import_DataItem() {
  if (document.getElementById("FileName").value == "") {
    if (coo == "English") {
      alert("Please select the files to upload!");
    } else {
      alert("请选择需要上传的文件！");
    }
  } else {
    // $("#importDeviceID").val(DeviceID);
    document.getElementById("Import_Button_Confirm").disabled = true;
    document.getElementById("Import_Button_Cancel").disabled = true;
    if (ChannelDeviceType == "OMRON_NJNX") {
      document.getElementById("ImportForm_YuToXHZhang").action =
        "../cgi-bin/import/ImportOMRON_NJNXDataitem.py?deviceID=" + DeviceID;
    } else if (ChannelDeviceType == "OMRON-TCP") {
      document.getElementById("ImportForm_YuToXHZhang").action =
        "../cgi-bin/import/ImportFINSTcp.py?deviceID=" + DeviceID;
    } else if (ChannelDeviceType == "GPS") {
      document.getElementById("ImportForm_YuToXHZhang").action =
        "../cgi-bin/import/ImportGps.py?deviceID=" + DeviceID;
      //end add
      // add begin by x
    } else if (ChannelDeviceType == "DRACAL") {
      document.getElementById("ImportForm_YuToXHZhang").action =
        "../cgi-bin/import/ImportDRACALDataitem.py?deviceID=" + DeviceID;
    }
    // add by whc
    else if (ChannelDeviceType == "FATEK编程口") {
      document.getElementById("ImportForm_YuToXHZhang").action =
        "../cgi-bin/import/ImportFATEKDataitem.py?deviceID=" + DeviceID;
    }
    // add end
    // add by whc
    else if (ChannelDeviceType == "OPC") {
      document.getElementById("ImportForm_YuToXHZhang").action =
        "../cgi-bin/import/ImportOPCDataitem.py?deviceID=" + DeviceID;
    }
    // add end
    else if (ChannelDeviceType == "OPC-UA") {
      document.getElementById("ImportForm_YuToXHZhang").action =
        "../cgi-bin/import/ImportOPCUADataitem.py?deviceID=" + DeviceID;
    }
    // add by whc
    else if (ChannelDeviceType == "SIEMENS-S7-PPI-Task") {
      document.getElementById("ImportForm_YuToXHZhang").action =
        "../cgi-bin/import/ImportS7200PPIDataitem.py?deviceID=" + DeviceID;
    }
    // add end
    else if (
      ChannelDeviceType == "DLT645-2007" ||
      ChannelDeviceType == "DLT645-1997"
    ) {
      document.getElementById("ImportForm_YuToXHZhang").action =
        "../cgi-bin/import/ImportDLT645Dataitem.py?deviceID=" + DeviceID;
    }
    // add by whc
    else if (ChannelDeviceType == "Custom-TCP") {
      document.getElementById("ImportForm_YuToXHZhang").action =
        "../cgi-bin/import/ImportCustomTcpDataitem.py?deviceID=" + DeviceID;
    }
    // add by fyj, OMRON-HostLink-Task
    else if (
      ChannelDeviceType == "OMRON-HostLink-Task" ||
      ChannelDeviceType == "OMRON-FINS-Task"
    ) {
      document.getElementById("ImportForm_YuToXHZhang").action =
        "../cgi-bin/import/ImportHostLinkTaskDataitem.py?deviceID=" + DeviceID;
    }
    // add by lh
    else if (ChannelDeviceType == "IEC104") {
      document.getElementById("ImportForm_YuToXHZhang").action =
        "../cgi-bin/import/ImportIECDataitem.py?deviceID=" + DeviceID;
    } else if (ChannelDeviceType == "device") {
      document.getElementById("ImportForm_YuToXHZhang").action =
        "../cgi-bin/import/ImportCommonDevDataitem.py?deviceID=" + DeviceID;
    } else if (ChannelDeviceType == "HMI") {
      document.getElementById("ImportForm_YuToXHZhang").action =
        "../cgi-bin/import/ImportHMIDataitem.py?deviceID=" + DeviceID;
    } else if (ChannelDeviceType == "test") {
      document.getElementById("ImportForm_YuToXHZhang").action =
        "../cgi-bin/import/ImportTest.py?deviceID=" + DeviceID;
    } else if (ChannelDeviceType == "MITSUBISHI-TXZ-MomMach" || ChannelDeviceType == "MITSUBISHI-TXZ-SubMach1" || ChannelDeviceType == "MITSUBISHI-TXZ-SubMach2")  {
      document.getElementById("ImportForm_YuToXHZhang").action =
        "../cgi-bin/import/ImportTXZ.py?deviceID=" + DeviceID;
    } else if (ChannelDeviceType == "MITSUBISHI-TX-15P") {
      document.getElementById("ImportForm_YuToXHZhang").action =
        "../cgi-bin/import/ImportTX15P.py?deviceID=" + DeviceID;
    }else if (ChannelDeviceType == "MITSUBISHI-TX-5HP") {
      document.getElementById("ImportForm_YuToXHZhang").action =
        "../cgi-bin/import/ImportTX5HP.py?deviceID=" + DeviceID;
    }else if (ChannelDeviceType == "MITSUBISHI-TX-Multi-link") {
      document.getElementById("ImportForm_YuToXHZhang").action =
        "../cgi-bin/import/ImportTXMulti.py?deviceID=" + DeviceID;
    } else if (ChannelDeviceType == "R1R2") {
      document.getElementById("ImportForm_YuToXHZhang").action =
        "../cgi-bin/import/ImportSamsung.py?deviceID=" + DeviceID;
    }
    // add end
    else {
      document.getElementById("ImportForm_YuToXHZhang").action =
        "../cgi-bin/import/ImportPlcDataitem.py?deviceID=" + DeviceID;
    }
    document.getElementById("ImportForm_YuToXHZhang").submit();
    var iframe01 = document.getElementById("Hide_ImportIframe");
    if (iframe01.attachEvent) {
      iframe01.attachEvent("onload", function () {
        document.getElementById("UpWord").style.display = "none";
        document.getElementById("Import_Two_Button").style.display = "none";
        document.getElementById("Success_Import").style.display = "";
        document.getElementById("Import_Success_Button").style.display = "";
        document.getElementById("Import_Button_Confirm").disabled = false;
        document.getElementById("Import_Button_Cancel").disabled = false;
      });
    } else {
      iframe01.onload = function () {
        document.getElementById("UpWord").style.display = "none";
        document.getElementById("Import_Two_Button").style.display = "none";
        document.getElementById("Success_Import").style.display = "";
        document.getElementById("Import_Success_Button").style.display = "";
        document.getElementById("Import_Button_Confirm").disabled = false;
        document.getElementById("Import_Button_Cancel").disabled = false;
      };
    }
  }
}

function Close_ExportLayer() {
  document.getElementById("popWindow").style.display = "none";
  document.getElementById("ExprotLayer").style.display = "none";
  document.getElementById("Exportout").disabled = false;
  document.getElementById("ExSucc").disabled = false;
}

function ExportInfo() {
  if (ChannelDeviceType == "OMRON_NJNX") {
    document.getElementById("ExportForm_YuToXHZhang").action =
      "../cgi-bin/export/ExportOMRON_NJNXDataitem.py?deviceID=" + DeviceID;
  } else if (ChannelDeviceType == "GPS") {
    document.getElementById("ExportForm_YuToXHZhang").action =
      "../cgi-bin/export/ExportGps.py?deviceID=" + DeviceID;
    //end add
    //add begin by x
  } else if (ChannelDeviceType == "OMRON-TCP") {
    document.getElementById("ExportForm_YuToXHZhang").action =
      "../cgi-bin/export/ExportFINSTcp.py?deviceID=" + DeviceID;
  } else if (ChannelDeviceType == "DRACAL") {
    document.getElementById("ExportForm_YuToXHZhang").action =
      "../cgi-bin/export/ExportDRACALDataitem.py?deviceID=" + DeviceID;
  } else if (ChannelDeviceType == "OPC-UA") {
    document.getElementById("ExportForm_YuToXHZhang").action =
      "../cgi-bin/export/ExportOPCUADataitem.py?deviceID=" + DeviceID;
  } else if (
    ChannelDeviceType == "DLT645-2007" ||
    ChannelDeviceType == "DLT645-1997"
  ) {
    document.getElementById("ExportForm_YuToXHZhang").action =
      "../cgi-bin/export/ExportDLT645Dataitem.py?deviceID=" + DeviceID;
  }
  // add by whc,新增FATEK编程口
  else if (ChannelDeviceType == "FATEK编程口") {
    document.getElementById("ExportForm_YuToXHZhang").action =
      "../cgi-bin/export/ExportFATEKDataitem.py?deviceID=" + DeviceID;
  }
  // add end
  // add by whc ,新增OPC
  else if (ChannelDeviceType == "OPC") {
    document.getElementById("ExportForm_YuToXHZhang").action =
      "../cgi-bin/export/ExportOPCDataitem.py?deviceID=" + DeviceID;
  }
  // add end
  // add by whc
  else if (ChannelDeviceType == "SIEMENS-S7-PPI-Task") {
    document.getElementById("ExportForm_YuToXHZhang").action =
      "../cgi-bin/export/ExportS7200PPI.py?deviceID=" + DeviceID;
  }
  // add end
  // add by whc
  else if (ChannelDeviceType == "Custom-TCP") {
    document.getElementById("ExportForm_YuToXHZhang").action =
      "../cgi-bin/export/ExportCustomTcpDataitem.py?deviceID=" + DeviceID;
  }
  // add end
  // add by fyj, OMRON-HostLink-Task
  else if (
    ChannelDeviceType == "OMRON-HostLink-Task" ||
    ChannelDeviceType == "OMRON-FINS-Task"
  ) {
    document.getElementById("ExportForm_YuToXHZhang").action =
      "../cgi-bin/export/ExportHostLinkTask.py?deviceID=" + DeviceID;
  }
  // add end
  // add by lh, IEC104
  else if (ChannelDeviceType == "IEC104") {
    document.getElementById("ExportForm_YuToXHZhang").action =
      "../cgi-bin/export/ExportIECDataitem.py?deviceID=" + DeviceID;
  } else if (ChannelDeviceType == "device") {
    document.getElementById("ExportForm_YuToXHZhang").action =
      "../cgi-bin/export/ExportCommonDevDataitem.py?deviceID=" + DeviceID;
  }
  // add end
  else if (ChannelDeviceType == "HMI") {
    document.getElementById("ExportForm_YuToXHZhang").action =
      "../cgi-bin/export/ExportHMIDataitem.py?deviceID=" + DeviceID;
  } else if (ChannelDeviceType == "test") {
    document.getElementById("ExportForm_YuToXHZhang").action =
      "../cgi-bin/export/ExportTest.py?deviceID=" + DeviceID;
  } else if (ChannelDeviceType == "MITSUBISHI-TXZ-MomMach" || ChannelDeviceType == "MITSUBISHI-TXZ-SubMach1"  ||ChannelDeviceType == "MITSUBISHI-TXZ-SubMach2" ) {
    document.getElementById("ExportForm_YuToXHZhang").action =
      "../cgi-bin/export/ExportTXZ.py?deviceID=" + DeviceID;
  } else if (ChannelDeviceType == "MITSUBISHI-TX-15P") {
    document.getElementById("ExportForm_YuToXHZhang").action =
      "../cgi-bin/export/ExportTX15P.py?deviceID=" + DeviceID;
  } else if (ChannelDeviceType == "MITSUBISHI-TX-5HP") {
    document.getElementById("ExportForm_YuToXHZhang").action =
      "../cgi-bin/export/ExportTX5HP.py?deviceID=" + DeviceID;
  } else if (ChannelDeviceType == "MITSUBISHI-TX-Multi-link") {
    document.getElementById("ExportForm_YuToXHZhang").action =
      "../cgi-bin/export/ExportTXMulti.py?deviceID=" + DeviceID;
  } else if (ChannelDeviceType == "R1R2") {
    document.getElementById("ExportForm_YuToXHZhang").action =
      "../cgi-bin/export/ExportSamsung.py?deviceID=" + DeviceID;
  } else {
    document.getElementById("ExportForm_YuToXHZhang").action =
      "../cgi-bin/export/ExportPlcDataitem.py?deviceID=" + DeviceID;
  }
  document.getElementById("ExportForm_YuToXHZhang").submit();
  document.getElementById("ExportForm_YuToXHZhang").target =
    "Hide_ExportIframe";
  document.getElementById("Exportout").disabled = true;
  document.getElementById("ExSucc").disabled = true;
  window.setTimeout(Close_ExportLayer, 3000);
}

//切换到测试
function Open_TestLayer() {
  //alert(ChannelDriver)
  var value = "";
  var idArr = "";
  var ChannelDriverArr = new Array();
  ChannelDriverArr = ChannelDriver.split(":");
  var ChannelDriverShort = ChannelDriverArr[1];
  if (ChannelDeviceType == "HKG-SERIAL") {
    $("#address_test").html("ID");
  }
  if (ChannelDeviceType == "OPC") {
    // document.getElementById("alias_test").style.display = "none";
  }
  CheckedLength();
  if (document.getElementById("AllDataitemID").value == "") {
    value =
      '{"id":' +
      DeviceID +
      ',"dn":"", "vn":"' +
      ChannelDriverShort +
      '", "cmds":{"read":1}}';
  } else {
    var str = document.getElementById("AllDataitemID").value;
    var strArr = new Array();
    strArr = str.split(";");
    var maxlength = strArr.length;
    for (var j = 0; j < maxlength - 2; j++) {
      idArr += strArr[j] + ",";
    }
    idArr += strArr[maxlength - 2];
    value =
      '{"id":' +
      DeviceID +
      ',"dn":"", "vn":"' +
      ChannelDriverShort +
      '", "cmds":{"read":0,"ids":[' +
      idArr +
      "]}}";
    //alert(strArr[1])
  }

  TestDateItem(value);

  if (window.testTimer) {
    clearInterval(window.testTimer);
    window.testTimer = null;
  }

  window.testTimer = setInterval(function () {
    var testWindowVisable = $("#TestLayer").is(":hidden");
    var popWindowVisable = $("#popWindow").is(":hidden");
    var autoTest = $("#onoffswitch").is(":checked");
    if (testWindowVisable || popWindowVisable) {
      clearInterval(window.testTimer);
      window.testTimer = null;
    } else if (autoTest) {
      console.log("刷新！");
      TestDateItem(value);
    }
  }, 10000);
}

function TestDateItem(txt) {
  $("#testInfomation").empty();
  document.getElementById("Test_Value_YuToXHZhang").value = txt;
  document.getElementById("popWindow").style.display = "";
  var params = $("#Test_DataItemForm_YuToXHZhang").serialize();
  $.ajax({
    type: "post",
    url: "cgi-bin/RealTimeData/GetRealTimeData.py",
    data: params,
    async: true,
    datatype: "xml",
    beforeSend: function () {
      $("#wait").show();
    },
    complete: function () {
      $("#wait").hide();
      //方法执行完毕，效果自己可以关闭，或者隐藏效果
    },
    success: function (data) {
      if (data.substr(1, 3) != "All") {
        $("#wait").hide();
        $("#popWindow").hide();
        alert(data);
      } else {
        $("#TestLayer").show();
        $(data)
          .find("dataItem")
          .each(function () {
            var $dataitem = $(this);
            var name = $dataitem.attr("n");
            var config = $dataitem.attr("config");
            var id = $dataitem.attr("id");
            var typeshort = $dataitem.attr("type");
            var freq = $dataitem.attr("freq");
            var report = $dataitem.attr("report");
            var value = $dataitem.attr("value");
            var alias = $dataitem.attr("alias");
            var quality1 = $dataitem.attr("quality");
            var configArr = new Array();
            configArr = config.split(";");
            //欧姆龙NJ驱动地址
            if (
              ChannelDeviceType == "OMRON_NJNX" ||
              ChannelDeviceType == "YinHe" ||
              ChannelDeviceType == "Custom-TCP" ||
              ChannelDeviceType == "GPS" ||
              ChannelDeviceType == "DRACAL"
            ) {
              var add = configArr[0];
            } else if (ChannelDeviceType == "HKG-SERIAL") {
              var dataid = configArr[0];
            } else if (ChannelDeviceType == "OMRON-HostLink-Task") {
              var add = configArr[0];
            } else if (ChannelDeviceType == "Zundar") {
              var add = "none";
              // add by whc
            } else if (ChannelDeviceType == "FATEK编程口") {
              var add = configArr[1];
              var type1 = configArr[0];
              // add end
              // add by whc
            } else if (ChannelDeviceType == "SIEMENS-S7-PPI-Task") {
              var add = configArr[0];
              var type1 = configArr[1];
              // add end
              // add by bzyang
            } else if (ChannelDeviceType == "OPC") {
              var add = configArr.length < 2 ? configArr[0] : configArr[1];
            } else if (ChannelDeviceType == "OPC-UA") {
              var add = configArr.length < 2 ? configArr[0] : configArr[1];
            } else if (ChannelDeviceType == "MITSUBISHI-TXZ-MomMach" ||ChannelDeviceType == "MITSUBISHI-TXZ-SubMach1"||ChannelDeviceType == "MITSUBISHI-TXZ-SubMach2" ) {
              var add = configArr[2];
            } else if (ChannelDeviceType == "MITSUBISHI-TX-15P") {
              var add = findKey(TX15PMap, config);
            } else if (ChannelDeviceType == "MITSUBISHI-TX-5HP") {
              var add = findKey(TX5HPMap, config);
            } else if (ChannelDeviceType == "MITSUBISHI-TX-Multi-link") {
              var add = findKey(TXMultiMap, config);
            } else if (ChannelDeviceType == "R1R2") {
              var add = configArr[0];
            } else {
              var add = configArr[0] + configArr[2];
            }
            if (configArr.length > 2) {
              var type1 = configArr[1];
              // add by whc
            } else if (
              configArr.length == 2 &&
              ChannelDeviceType == "FATEK编程口"
            ) {
              var type1 = configArr[0];
              // add end
            } else if (
              (configArr.length == 2 &&
                ChannelDeviceType == "SIEMENS-S7-PPI-Task") ||
              ChannelDeviceType == "OMRON-HostLink-Task"
            ) {
              var type1 = configArr[1];
            } else {
              var type1 = "none";
            }
            var type = "";
            var quality = "";
            if (quality1 == 1) {
              quality = "good";
            }
            if (quality1 != 1) {
              quality = "bad";
            }
            if (
              ChannelDeviceType == "OMRON_NJNX" ||
              ChannelDeviceType == "HKG-SERIAL" ||
              ChannelDeviceType == "Custom-TCP" ||
              ChannelDeviceType == "GPS" ||
              ChannelDeviceType == "OPC" ||
              ChannelDeviceType == "OPC-UA" ||
              ChannelDeviceType == "IEC104" ||
              ChannelDeviceType == "device" ||
              ChannelDeviceType == "MITSUBISHI-TXZ-MomMach" ||
              ChannelDeviceType == "MITSUBISHI-TXZ-SubMach1" ||
              ChannelDeviceType == "MITSUBISHI-TXZ-SubMach2" ||
              ChannelDeviceType == "MITSUBISHI-TX-15P"||
              ChannelDeviceType == "MITSUBISHI-TX-5HP"||
              ChannelDeviceType == "MITSUBISHI-TX-Multi-link"||
              ChannelDeviceType == "R1R2"
            ) {
              if (coo == "English") {
                if (typeshort == "s") type = "String";
                if (typeshort == "a") type = "Numerical value";
                if (typeshort == "b") type = "Switch quantity";
              } else {
                if (typeshort == "s") type = "字符串";
                if (typeshort == "a") type = "数值";
                if (typeshort == "b") type = "开关量";
              }
            } else {
              if (type1 == "BIT") type = "Boolean";
              if (type1 == "BYTE") type = "Byte";
              if (type1 == "WORD") type = "Word";
              if (type1 == "SHORT") type = "Short";
              if (type1 == "DWORD") type = "DWord";
              if (type1 == "LONG") type = "Long";
              if (type1 == "FLOAT") type = "Float";
              if (type1.indexOf("STRING") != -1)
                //(type1.indexOf("STRING") != -1)
                type = "String";
              if (type1 == "INT8") type = "Int 8";
              if (type1 == "INT16") type = "Int 16";
              if (type1 == "INT32") type = "Int 32";
              if (type1 == "none") type = "null";
              if (type1 == "BCD") type = "BCD";
              if (type1 == "UINT16") type = "UInt16";
              if (type1 == "UINT32") type = "UInt32";
            }
            if (ChannelDeviceType == "HKG-SERIAL") {
              var list =
                "<div style='width:678px;height:25px;border: 1px solid #D7D7D7;border-top:none'>" +
                "<div align='center' style='width:150px;float:left;height:25px;line-height:25px;overflow:hidden' title='" +
                name +
                "'>" +
                name +
                "</div>" +
                "<div align='center' style='width:150px;float:left;height:25px;line-height:25px;overflow:hidden' title='" +
                alias +
                "'>" +
                alias +
                "</div>" +
                "<div align='center' style='width:80px;float:left;height:25px;line-height:25px'>" +
                dataid +
                "</div>" +
                "<div align='center' style='width:80px;float:left;height:25px;line-height:25px'>" +
                type +
                "</div>" +
                "<div align='center' style='width:130px;float:left;height:25px;line-height:25px'>" +
                value +
                "</div>" +
                "<div align='center' style='width:68px;float:left;height:25px;line-height:25px'>" +
                quality +
                "</div>" +
                "</div>";
            }
            // add by fyj, DLT645-2007
            else if (
              ChannelDeviceType == "DLT645-2007" ||
              ChannelDeviceType == "DLT645-1997"
            ) {
              var add = configArr[0];
              if (coo == "English") {
                $("#address_test").text("Data address");
                if (typeshort == "b") {
                  typeshort = "Switch quantity";
                } else if (typeshort == "a") {
                  typeshort = "Numerical value";
                } else if (typeshort == "s") {
                  typeshort = "String";
                }
              } else {
                $("#address_test").text("数据地址");
                if (typeshort == "b") {
                  type = "开关量";
                } else if (typeshort == "a") {
                  type = "数值";
                } else if (typeshort == "s") {
                  type = "字符串";
                }
              }

              var list =
                "<div style='width:678px;height:25px;border: 1px solid #D7D7D7;border-top:none'>" +
                "<div align='center' style='width:150px;float:left;height:25px;line-height:25px;overflow:hidden' title='" +
                name +
                "'>" +
                name +
                "</div>" +
                "<div align='center' style='width:150px;float:left;height:25px;line-height:25px;overflow:hidden' title='" +
                alias +
                "'>" +
                alias +
                "</div>" +
                "<div align='center' style='width:80px;float:left;height:25px;line-height:25px'>" +
                add +
                "</div>" +
                "<div align='center' style='width:80px;float:left;height:25px;line-height:25px'>" +
                type +
                "</div>" +
                "<div align='center' style='width:130px;float:left;height:25px;line-height:25px'>" +
                value +
                "</div>" +
                "<div align='center' style='width:68px;float:left;height:25px;line-height:25px'>" +
                quality +
                "</div>" +
                "</div>";
            }
            // add end
            else if (ChannelDeviceType == "DRACAL") {
              if (typeshort == "a") type = "数值";
              if (coo == "English") {
                type = "Numerical";
              }
              var list =
                "<div style='width:678px;height:25px;border: 1px solid #D7D7D7;border-top:none'>" +
                "<div align='center' style='width:150px;float:left;height:25px;line-height:25px;overflow:hidden' title='" +
                name +
                "'>" +
                name +
                "</div>" +
                "<div align='center' style='width:150px;float:left;height:25px;line-height:25px;overflow:hidden' title='" +
                alias +
                "'>" +
                alias +
                "</div>" +
                "<div align='center' style='width:80px;float:left;height:25px;line-height:25px'>" +
                config +
                "</div>" +
                "<div align='center' style='width:80px;float:left;height:25px;line-height:25px'>" +
                type +
                "</div>" +
                "<div align='center' style='width:130px;float:left;height:25px;line-height:25px'>" +
                value +
                "</div>" +
                "<div align='center' style='width:68px;float:left;height:25px;line-height:25px'>" +
                quality +
                "</div>" +
                "</div>";
              // add end
            }
            // add by whc
            else if (ChannelDeviceType == "OPC") {
              var list =
                "<div style='width:678px;height:25px;border: 1px solid #D7D7D7;border-top:none'>" +
                "<div align='center' style='width:150px;float:left;height:25px;line-height:25px;overflow:hidden' title='" +
                name +
                "'>" +
                name +
                "</div>" +
                "<div align='center' style='width:150px;float:left;height:25px;line-height:25px;overflow:hidden' title='" +
                alias +
                "'>" +
                alias +
                "</div>" +
                "<div align='center' style='width:80px;float:left;height:25px;line-height:25px'>" +
                add +
                "</div>" +
                "<div align='center' style='width:80px;float:left;height:25px;line-height:25px'>" +
                type +
                "</div>" +
                "<div align='center' style='width:130px;float:left;height:25px;line-height:25px'>" +
                value +
                "</div>" +
                "<div align='center' style='width:88px;float:left;height:25px;line-height:25px'>" +
                quality +
                "</div>" +
                "</div>";
            }
            // add end
            else if (ChannelDeviceType == "device") {
              var list =
                "<div style='width:678px;height:25px;border: 1px solid #D7D7D7;border-top:none'>" +
                "<div align='center' style='width:150px;float:left;height:25px;line-height:25px;overflow:hidden' title='" +
                name +
                "'>" +
                name +
                "</div>" +
                "<div align='center' style='width:150px;float:left;height:25px;line-height:25px;overflow:hidden' title='" +
                alias +
                "'>" +
                alias +
                "</div>" +
                "<div align='center' style='width:80px;float:left;height:25px;line-height:25px'>" +
                config +
                "</div>" +
                "<div align='center' style='width:80px;float:left;height:25px;line-height:25px'>" +
                type +
                "</div>" +
                "<div align='center' style='width:130px;float:left;height:25px;line-height:25px'>" +
                value +
                "</div>" +
                "<div align='center' style='width:68px;float:left;height:25px;line-height:25px'>" +
                quality +
                "</div>" +
                "</div>";
            } else {
              var list =
                "<div style='width:678px;height:25px;border: 1px solid #D7D7D7;border-top:none'>" +
                "<div align='center' style='width:150px;float:left;height:25px;line-height:25px;overflow:hidden' title='" +
                name +
                "'>" +
                name +
                "</div>" +
                "<div align='center' style='width:150px;float:left;height:25px;line-height:25px;overflow:hidden' title='" +
                alias +
                "'>" +
                alias +
                "</div>" +
                "<div align='center' style='width:80px;float:left;height:25px;line-height:25px'>" +
                add +
                "</div>" +
                "<div align='center' style='width:80px;float:left;height:25px;line-height:25px'>" +
                type +
                "</div>" +
                "<div align='center' style='width:130px;float:left;height:25px;line-height:25px'>" +
                value +
                "</div>" +
                "<div align='center' style='width:68px;float:left;height:25px;line-height:25px'>" +
                quality +
                "</div>" +
                "</div>";
            }
            $("#testInfomation").append(list);
          });
      }
    },
    error: function () {
      $("#popWindow").hide();
      if (coo == "English") {
        alert("Test fails, please contact your administrator");
      } else {
        alert("测试失败，请联系管理员");
      }
    },
  });
}

//切换到导入
function Open_ImportLayer() {
  $("#popWindow").show();
  $("#ImportLayer").show();
  $("#FileName").val("");
  // $("#importDeviceID").val("");
  $("#UpWord").show();
  $("#Import_Two_Button").show();
  $("#Success_Import").hide();
  $("#Import_Success_Button").hide();
  $("#Import_Button_Confirm").show();
  $("#Import_Button_Cancel").show();
}

//切换到导出
function Open_ExportLayer() {
  document.getElementById("popWindow").style.display = "";
  document.getElementById("ExprotLayer").style.display = "";
}

$("#Add_DataItemType").change(function () {
  if (
    $(this).val() == "STRING" &&
    ChannelDeviceType != "OMRON_NJNX" &&
    ChannelDeviceType != "HKG-SERIAL" &&
    ChannelDeviceType != "Custom-TCP" &&
    ChannelDeviceType != "OPC" &&
    ChannelDeviceType != "DRACAL"
  ) {
    $("#tr_string").show();
    $("#tr_string_msg").show();
  } else {
    $("#tr_string").hide();
    $("#tr_string_msg").hide();
  }
});

$("#Alter_DataItemType").change(function () {
  if (
    $(this).val() == "STRING" &&
    ChannelDeviceType != "OMRON_NJNX" &&
    ChannelDeviceType != "HKG-SERIAL" &&
    ChannelDeviceType != "Custom-TCP" &&
    ChannelDeviceType != "OPC" &&
    ChannelDeviceType != "DRACAL"
  ) {
    $("#Alter_tr_string").show();
    $("#Alter_tr_string_msg").show();
  } else {
    $("#Alter_tr_string").hide();
    $("#Alter_tr_string_msg").hide();
  }
});

function open_write_layer(data) {
  $("#write_layer").css("display", "");
  $("#popWindow").css("display", "");
  //
  $("#Write_Button_Confirm")
    .unbind("click")
    .click(function () {
      //构造参数
      data.cmds[0]["userid"] = "1493282026529"; //userid 可以随便填写
      data.cmds[0]["cmd"] = $("#write_input").val();
      //验证非空
      if (data.cmds[0]["cmd"] == "" || data.cmds[0]["cmd"] == null) {
        if (coo == "English") {
          alert("Write value cannot be empty");
        } else {
          alert("写入值不能为空");
        }
        return;
      }
      if (data.cmds[0]["rw"] == "0") {
        if (coo == "English") {
          alert("Please set the R/W type to be Read&Write first.");
        } else {
          alert("请先设置读写类型为可写");
        }
        return;
      }
      //验证bool 类型(dt == b)只能为0或1
      if (
        data.cmds[0]["dt"] == "b" &&
        ["0", "1"].indexOf(data.cmds[0]["cmd"]) == -1
      ) {
        if (coo == "English") {
          alert("Boolean type can only fill 0 or 1");
        } else {
          alert("Boolean类型只能填写0或者1");
        }
        return;
      }
      //直接提交json cgi无法收到，这里把json字符串放到一个伪造的表单里,key是'Write_Value_command'
      var $form = $("<form></form>");
      var $input = $("<input tyle='text' name='Write_Value_command'>");
      $input.val(JSON.stringify(data));
      $form.append($input);
      var param = $form.serialize();
      $.ajax({
        type: "post",
        url: "cgi-bin/RealTimeData/WriteItemValue.py",
        data: param,
        // dataType: 'xml',
        beforeSend: function (request) {
          $("#Write_Button_Confirm").attr("disabled", "disabled");
          $("#write_Button_Cancel").attr("disabled", "disabled");
        },
        complete: function () {
          $("#Write_Button_Confirm").removeAttr("disabled");
          $("#write_Button_Cancel").removeAttr("disabled");
          $("#write_layer").css("display", "none");
          $("#popWindow").css("display", "none");
          $("#write_input").val("");
        },
        success: function (data) {
          alert(data);
        },
        error: function () {
          alert("error");
        },
      });
    });
}

function clocs_write_layer() {
  $("#write_layer").css("display", "none");
  $("#popWindow").css("display", "none");
  $("#write_input").val("");
}
