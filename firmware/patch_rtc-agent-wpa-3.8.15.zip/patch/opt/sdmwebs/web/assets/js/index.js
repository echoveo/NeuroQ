document.writeln(
  "<" +
    "script language='javascript' src='assets/js/language.js?t=" +
    new Date().getTime() +
    "'></" +
    "script>"
);

//验证是否登陆 利用session
CheckLogin();

//禁用缓存
$.ajaxSetup({
  cache: false,
});
//全局一个通道数量
var ChannelNum = 0;
var MagicID = 10000000000;
var MaxMagicID = "";
//通道ID
var ChannelID = "";
//设备ID
var DeviceID = "";
//数据ID
var dataItemID = "";
//全局driverid
var driverID = "";
//全局taskid
var taskID = "";
//设备驱动类型
var ChannelDriver = "";
//获取盒子版本
var HardwareName = "";
//AnyLink 版本  DA还是 RF,true为RF，false为DA；
var AnyLinkType = "";
//网关状态页面的脚本版本
var ScriptVersion = "";
//网关状态页面的Iccid
var Iccid = "";
//网关状态页面的IMEI
var IMEI = "";

var coo = "";

//是否打开驱动参数配置项
var g_DriverConfigUI = 1;

//页面加载完成执行方法
$(document).ready(function () {
  $.ajax({
    type: "get",
    url: "../cgi-bin/senconf/UpdateBasicInfo.py",
    async: true,
    success: function (data) {
      data = JSON.parse(data);
      ScriptVersion = data.scriptver;
      Iccid = data.iccid;
      IMEI = data.imei;
    },
  });
  loginUI();
  getAnylinkInfo();
  getUserinfo();
  getYear();
  getDeviceInfo();
  getStatueInfo();

  // add begin by fyj, 如果当前不是管理员，则只显示部分功能
  var LoginName = sessionStorage.AnylinkName;
  if (LoginName != "admin") {
    // 如果不是管理员用户则显示部分功能
    var href = window.location.href;
    if (href.indexOf("index.html") != -1) {
      $("#aB").parent().hide();
      $("#aS").parent().hide();
      changeSeniorhp();
      $("#menu ul li").hide();
      $("#li01").show();
      $("#li06").show();
      $("#li08").show();
    }
  }
  // add end
  coo = getCookie("AnyLinkLan");
  // document.getElementById("lan").value = coo;
});

function getAnylinkInfo() {
  $.ajax({
    type: "get",
    url: "../conf/AnyLink.xml",
    async: false,
    success: function (data) {
      $(data)
        .find("BasicInfo")
        .each(function () {
          var $BasicInfo = $(this);
          AnyLinkType = $BasicInfo.find("AnyLinkType").text();
          if (AnyLinkType == "BG") {
            $("#Add_DeviceID").empty();
            var str =
              '<option value="/dev/ttyO3" >COM1</option>' +
              '<option value="/dev/ttyO4" >COM2</option>' +
              '<option value="/dev/ttyO5" selected>COM3</option>' +
              '<option value="/dev/ttyO2">COM4</option>';
            $("#Add_DeviceID").append(str);
          }
          HardwareName = $BasicInfo.find("HardwareName").text();
          var SoftVersion = $BasicInfo.find("SoftVersion").text();
          //$("#AgentVersion").html(AnyLinkType + "-" + SoftVersion);
          $("#AgentVersion").html(SoftVersion);

          //DriverConfigUI  add by kali

          try{
            g_DriverConfigUI = $BasicInfo.find("DriverConfigUI").text();
            if(g_DriverConfigUI === "0" ){
              g_DriverConfigUI = 0;
            }else if(g_DriverConfigUI === "1"){
              g_DriverConfigUI = 1;
            }else if(g_DriverConfigUI === ""){
		    g_DriverConfigUI = 1;
	    }
          }catch(e01){
            g_DriverConfigUI = 1;
          }
          if(g_DriverConfigUI == 0){
            changeSeniorhp();
            disable_DeviceConfigUI();
            //disable
          }
          //DriverConfigUI
        });
      $(data)
        .find("NetworkInfo")
        .each(function () {
          var $NetworkInfo = $(this);
          var type = $NetworkInfo.attr("muti");
          if (type == "YES") {
            $("#06").attr(
              "href",
              "IPConfigDouble.html?t=" + new Date().getTime()
            );
          } else {
            $("#06").attr("href", "IPConfig.html?t=" + new Date().getTime());
          }
        });
      $(data)
        .find("VPN")
        .each(function () {
          var $VPN = $(this);
          var type = $VPN.attr("display");
          if (type == "YES") {
          } else {
            $("#li19").remove();
          }
        });
    },
  });
}

function get_net_level() {
  $.ajax({
    type: "get",
    url: "../cgi-bin/wifi/get_level.py",
    success: function (data) {
      var json_data = JSON.parse(data);
      if (json_data.mode === "4G") {
        $("#cellular-state").css("display", "inline");
        var i18n_data = {
          English: {
            good: "Good",
            fair: "Fair",
            weak: "Weak",
            excellent: "Excellent",
            disconnected: "Disconnected",
          },
          Chinese: {
            good: "良好",
            fair: "一般",
            weak: "差",
            excellent: "优秀",
            disconnected: "无网络",
          },
        };
        if (json_data.level >= 0 && json_data.level <= 19) {
          $("#cellular-state")[0].lastElementChild.innerText =
            i18n_data[coo].weak;
          $("#cellular-path-1")[0].setAttribute("fill", "#FFFFFF");
          $("#cellular-path-2")[0].setAttribute(
            "fill",
            "rgba(255,255,255,0.3)"
          );
          $("#cellular-path-3")[0].setAttribute(
            "fill",
            "rgba(255,255,255,0.3)"
          );
          $("#cellular-path-4")[0].setAttribute(
            "fill",
            "rgba(255,255,255,0.3)"
          );
        } else if (json_data.level >= 20 && json_data.level <= 23) {
          $("#cellular-state")[0].lastElementChild.innerText =
            i18n_data[coo].fair;
          $("#cellular-path-1")[0].setAttribute("fill", "#FFFFFF");
          $("#cellular-path-2")[0].setAttribute("fill", "#FFFFFF");
          $("#cellular-path-3")[0].setAttribute(
            "fill",
            "rgba(255,255,255,0.3)"
          );
          $("#cellular-path-4")[0].setAttribute(
            "fill",
            "rgba(255,255,255,0.3)"
          );
        } else if (json_data.level >= 24 && json_data.level <= 27) {
          $("#cellular-state")[0].lastElementChild.innerText =
            i18n_data[coo].good;
          $("#cellular-path-1")[0].setAttribute("fill", "#FFFFFF");
          $("#cellular-path-2")[0].setAttribute("fill", "#FFFFFF");
          $("#cellular-path-3")[0].setAttribute("fill", "#FFFFFF");
          $("#cellular-path-4")[0].setAttribute(
            "fill",
            "rgba(255,255,255,0.3)"
          );
        } else if (json_data.level >= 28 && json_data.level <= 31) {
          $("#cellular-state")[0].lastElementChild.innerText =
            i18n_data[coo].excellent;
          $("#cellular-path-1")[0].setAttribute("fill", "#FFFFFF");
          $("#cellular-path-2")[0].setAttribute("fill", "#FFFFFF");
          $("#cellular-path-3")[0].setAttribute("fill", "#FFFFFF");
          $("#cellular-path-4")[0].setAttribute("fill", "#FFFFFF");
        } else {
          state = "Disconnected ";
          $("#cellular-state")[0].lastElementChild.innerText =
            i18n_data[coo].disconnected;
          $("#cellular-path-1")[0].setAttribute(
            "fill",
            "rgba(255,255,255,0.3)"
          );
          $("#cellular-path-2")[0].setAttribute(
            "fill",
            "rgba(255,255,255,0.3)"
          );
          $("#cellular-path-3")[0].setAttribute(
            "fill",
            "rgba(255,255,255,0.3)"
          );
          $("#cellular-path-4")[0].setAttribute(
            "fill",
            "rgba(255,255,255,0.3)"
          );
        }
      } else if (json_data.mode === "wifi") {
        $("#wifi-state").css("display", "inline");
        var i18n_data = {
          English: {
            good: "Good",
            medium: "Medium",
            weak: "Weak",
            unknown: "Unknown",
          },
          Chinese: {
            good: "强",
            medium: "中",
            weak: "弱",
            unknown: "未知",
          },
        };

        if (
          (json_data.level < 0 && json_data.level >= -60) ||
          json_data.level >= 50
        ) {
          $("#wifi-state")[0].lastElementChild.innerText = i18n_data[coo].good;
          $("#wifi-path-1")[0].setAttribute("fill", "#FFFFFF");
          $("#wifi-path-2")[0].setAttribute("fill", "#FFFFFF");
          $("#wifi-path-3")[0].setAttribute("fill", "#FFFFFF");
        } else if (
          (json_data.level > -80 && json_data.level < -60) ||
          (json_data.level >= 40 && json_data.level < 50)
        ) {
          $("#wifi-state")[0].lastElementChild.innerText =
            i18n_data[coo].medium;
          $("#wifi-path-1")[0].setAttribute("fill", "#FFFFFF");
          $("#wifi-path-2")[0].setAttribute("fill", "#FFFFFF");
          $("#wifi-path-3")[0].setAttribute("fill", "rgba(255,255,255,0.3)");
        } else {
          $("#wifi-state")[0].lastElementChild.innerText = i18n_data[coo].weak;
          $("#wifi-path-1")[0].setAttribute("fill", "#FFFFFF");
          $("#wifi-path-2")[0].setAttribute("fill", "rgba(255,255,255,0.3)");
          $("#wifi-path-3")[0].setAttribute("fill", "rgba(255,255,255,0.3)");
        }

        if (json_data.level == 0) {
          $("#wifi-state")[0].lastElementChild.innerText =
            i18n_data[coo].unknown;
          $("#wifi-path-1")[0].setAttribute("fill", "rgba(255,255,255,0.3)");
          $("#wifi-path-2")[0].setAttribute("fill", "rgba(255,255,255,0.3)");
          $("#wifi-path-3")[0].setAttribute("fill", "rgba(255,255,255,0.3)");
        }
      } else {
        $("#wifi-state").css("display", "none");
        $("#cellular-state").css("display", "none");
      }
    },
  });
}

function getStatueInfo() {
  setTimeout(function () {
    getStatue();
  }, 1000);
  setInterval(function () {
    getStatue();
  }, 20000);
  setTimeout(function () {
    get_net_level();
  }, 5000);
  setInterval(function () {
    get_net_level();
  }, 15000);
}

function getStatue() {
  $.ajax({
    type: "get",
    url: "../cgi-bin/wifi/networkstatue.py",
    async: true,
    success: function (data) {
      data = data.replace(/^\s+|\s+$/g, "");
      if (coo == "English") {
        if (data == "1") {
          document.getElementById("netStatue").innerHTML = "Connected";
          document.getElementById("statueLight").src =
            "assets/img/Small-Up.gif";
        } else {
          document.getElementById("netStatue").innerHTML = "Disconnected";
          document.getElementById("statueLight").src =
            "assets/img/Small-Down.png";
        }
      } else {
        if (data == "1") {
          document.getElementById("netStatue").innerHTML = "连通";
          document.getElementById("statueLight").src =
            "assets/img/Small-Up.gif";
        } else {
          document.getElementById("netStatue").innerHTML = "中断";
          document.getElementById("statueLight").src =
            "assets/img/Small-Down.png";
        }
      }
    },
  });
}

//读取通道&根据通道ID传值打开连接
function loginUI() {
  getIDinfo();
  initAddChannelCOM();
  $("#tongdao").empty();
  $.get("../conf/config.xml", function (d1) {
    $(d1)
      .find("model")
      .each(function () {
        var $model = $(this);
        var id = $model.attr("id");
        var n = $model.attr("n");
        var d = $model.attr("d");
        var config = $model.attr("config");
        var d1 = "";
        var GotoDevice =
          "Device_PLC_Change.html?id=" + id + "&t=" + new Date().getTime();
        $("#Hide_Checked_ChannelID").val(id);
        /*修改者:jinxin.zhou 内容：对ra模块不显示通道*/
        //add 对CMD模块不显示通道,为了减少用户设置这个model名的概率,将其设置较为复杂
        if (n == "ra-model" || n == "CMDsfFRFv") {
          return true;
        }
        MagicID++;
        ChannelNum++;
        var list =
          "<div  id='' class='Channel' style='overflow:hidden;background:#08284e;margin-top:10px;' title='" +
          n +
          "'>" +
          "<a style='width:auto;margin-left:75px;background:#08284e' id='" +
          MagicID +
          "'  href='" +
          GotoDevice +
          "' target='detail' onClick='MagicChange(id)' > " +
          "<font style='font-size:15px;'>" +
          n +
          "</font></a>" +
          "<img src='assets/img/bianji.png' id='img1' class='editChannel' style='margin-left:30px;cursor:pointer;' title='编辑' onclick='Alter_Open_ChannelLayer(" +
          id +
          ")'>" +
          "<img src='assets/img/delete.png' id='img2' class='deleteChannel' style='margin-left:20px;cursor:pointer;' title='删除' onclick='Delete_Channel(" +
          id +
          ")'>" +
          "</div>";
        $("#tongdao").append(list);
        if (coo == "English") {
          $(".editChannel").attr("title", "Edit");
          $(".deleteChannel").attr("title", "Delete");
        } else {
          $(".editChannel").attr("title", "编辑");
          $(".deleteChannel").attr("title", "删除");
        }
      });
    MaxMagicID = MagicID;
  });
}

//读取用户信息
function getUserinfo() {
  // modified by fyj
  var LoginName = sessionStorage.AnylinkName;
  $("#user").html(LoginName);
}

//自动获取当前年份
function getYear() {
  var NowYear = new Date().getFullYear();
  $("#nowyear").html(NowYear);
}

//获取驱动类型
function getDeviceInfo() {
  $("#Add_DeviceType").empty();
  if (coo == "English") {
    $.get("../conf/AllDeviceDriverEn.xml", function (d1) {
      $(d1)
        .find("Fac")
        .each(function () {
          var $Fac = $(this);
          if (AnyLinkType == "RF") {
            var Text = $Fac.attr("text");
            var Val = $Fac.attr("value");
          } else {
            if ($Fac.attr("value") != "HKG-SERIAL") {
              var Text = $Fac.attr("text");
              var Val = $Fac.attr("value");
            }
          }
          var test = $("<option>").val(Val);
          if (test != "") {
            var option = test.text(Text);
            $("#Add_DeviceType").append(option);
          }
        });
    });
  } else {
    $.get("../conf/AllDeviceDriver.xml", function (d1) {
      $(d1)
        .find("Fac")
        .each(function () {
          var $Fac = $(this);
          if (AnyLinkType == "RF") {
            var Text = $Fac.attr("text");
            var Val = $Fac.attr("value");
          } else {
            if ($Fac.attr("value") != "HKG-SERIAL") {
              var Text = $Fac.attr("text");
              var Val = $Fac.attr("value");
            }
          }
          var test = $("<option>").val(Val);
          if (test != "") {
            var option = test.text(Text);
            $("#Add_DeviceType").append(option);
          }
        });
    });
  }
}
//读ID最大值

function getIDinfo() {
  $.get("../conf/IDinfo.xml", function (d1) {
    $(d1)
      .find("IDALL")
      .each(function () {
        var $IDALL = $(this);
        var ChannelID = $IDALL.find("ChannelID").text();
        $("#Add_ChannelMaxID_YuToXHZhang").val(ChannelID);
      });
  });
}

function disable_DeviceConfigUI(){
  if(g_DriverConfigUI == 0){
    document.getElementById("aB").className = "disable";
    document.getElementById("aS").className = "active";
  }

}
//切换到基本配置
function changeBasichp() {
  if(g_DriverConfigUI == 0){
    disable_DeviceConfigUI();
    return;
  }
  document.getElementById("detail").src =
    "MainState.html?t=" + new Date().getTime();
  document.getElementById("aB").className = "active";
  document.getElementById("aS").className = "";
  $("#menu ul li").hide();
  $("#menu div").show();
  $("#menu div img").show();

  for (var i = 10000000001; i <= MaxMagicID; i++) {
    if (document.getElementById(i) != undefined) {
      document.getElementById(i).className = "";
    }
  }
  // window.location.reload();
  loginUI();
}
//切换到高级配置

function changeSeniorhp() {
  document.getElementById("aB").className = "";
  document.getElementById("aS").className = "active";
  document.getElementById("detail").src =
    "GatewayInfo.html?t=" + new Date().getTime();
  $("#menu div").hide();
  $("#menu div img").hide();
  $("#menu ul li").show();
  $("#menu ul li div").show();
  $("#menu ul li a").removeClass();
  $("#menu ul li:first-child a").addClass("active");
  disable_DeviceConfigUI();
  // window.location.reload();
}
//高级配置菜单栏变化
$("#menu ul li a").click(function () {
  $("#menu ul li a").removeClass();
  $(this).addClass("active");
});
$("#Add_DeviceDriver").change(function () {
  var type = $(this).val();
  if (type == "AB-Ethernet/IP" || type == "AB-MicroLogix") {
    $(".Add_ChannelLayer").css("height", "300px");
  }
});
//设备类型切换效果
$("#Add_DeviceType").change(function () {
  var type = $(this).val();
  getDriverInfo(type);
  //根据不同的type显示不同的可选参数，目前只有一个BacNet为特殊
  //BacNet的特殊，IP中只有端口号，其余的都没有（默认第一个显示的是BacNet-IP）
  //ModBus特殊，有延时和缓冲区
  //三菱FX编程口,FX串口特殊，RF 下有响应超时时间
  if (type == "BacNet" || type == "BacNet任务") {
    $("#Add_SelParame tr").hide();
    $("#Add_Line_Port").show();
    $("#Add_Line_delayed").show();
    $("#Add_delayed").val("1000");
    /*author:jinxin.zhou 内容：加上modbus特有的发送延迟*/
    $("#Add_Line_SendDelay").hide();
    /*end*/
    $("#Add_Line_ResponseOverTime").hide();
    $(".Add_ChannelLayer").css("height", "400px");
    if (type == "BacNet任务") {
      $("#Add_Port").val("47808");
    } else {
      $("#Add_Port").val("");
    }
  } else if (
    type == "Modbus" ||
    type == "Schneider" ||
    type == "Detal" ||
    type == "XinjieXD3" ||
    type == "XinjieXC3" ||
    type == "Modbus任务"
  ) {
    $("#Add_SelParame tr").hide();
    $("#Add_Line_DeviceID").show();
    $("#Add_Line_Baudrate").show();
    $("#Add_Line_Parity").show();
    $("#Add_Line_Databits").show();
    $("#Add_Line_Stopbit").show();
    $("#Add_Line_delayed").show();
    $("#Add_delayed").val("200");
    $("#Add_Line_Buffer").show();
    $("#Add_Buffer").val("100");
    /*author:jinxin.zhou 内容：加上modbus特有的发送延迟*/
    $("#Add_Line_SendDelay").show();
    /*end*/
    $("#Add_Line_ResponseOverTime").hide();
    //变一下高度
    $(".Add_ChannelLayer").css("height", "514px");
  } else if (type == "SIEMENS") {
    $("#Add_SelParame tr").hide();
    $("#Add_Line_IPAddr").show();
    $("#Add_Line_S7").show();
    $("#Add_Line_JJ").show();
    $("#Add_Line_CC").show();
    $("#Add_Line_Type").show();
    $("#Add_IPAddress").val("127.0.0.1");
    $("#Add_JJ_1200").val("0");
    $("#Add_CC_1200").val("0");
    $("#Add_Type_200_OP").attr("checked", "checked");
    $("#Add_ChannelLayer").css("height", "400px");
  } else if (type == "OMRON") {
    $("#Add_SelParame tr").hide();

    $("#Add_Line_DeviceID").show();
    $("#Add_Line_Baudrate").show();
    $("#Add_Line_Parity").show();
    $("#Add_Line_Databits").show();
    $("#Add_Line_Stopbit").show();
    $("#Add_Line_HostLink_ResponseOvertime").show();
    $("#Add_HostLink_ResponseOvertime").val("500");
    $(".Add_ChannelLayer").css("height", "430px");
  }
  //ABPLC有额外三个特殊的
  else if (type == "AB") {
    $("#Add_SelParame tr").hide();
    $("#Add_Line_DeviceID").show();
    $("#Add_Line_Baudrate").show();
    $("#Add_Line_Parity").show();
    $("#Add_Line_Databits").show();
    $("#Add_Line_Stopbit").show();
    $("#Add_Line_LocStack").show();
    $("#Add_Line_PLCStack").show();
    $("#Add_Line_ABCheck").show();
    /*author:jinxin.zhou 内容：加上modbus特有的发送延迟*/
    $("#Add_Line_SendDelay").hide();
    /*end*/
    $("#Add_Line_ResponseOverTime").hide();
    $(".Add_ChannelLayer").css("height", "510px");
  }
  // add by fyj, 新增OCR驱动
  // add begin
  else if (type == "OCR") {
    $("#Add_SelParame tbody tr").hide();

    $("#Add_Line_IPAddr").show();
    $("#Add_Line_Port").show();
    $("#Add_Line_ResponseOverTime").show();

    $(".Add_ChannelLayer").css("height", "350px");
  }
  // add end
  // add by fyj, 新增KUKA驱动
  // add begin
  else if (type == "KUKA") {
    $("#Add_SelParame tbody tr").hide();

    $("#Add_Line_ReadInterval").show();
    $("#Add_Line_ReadWait").show();
    $("#Add_Line_WriteInterval").show();

    $("#Add_ReadInterval").val(500);
    $("#Add_ReadWait").val(2000);
    $("#Add_WriteInterval").val(3000);

    $(".Add_ChannelLayer").css("height", "350px");
  }
  // add end
  // add by fyj,新增DRACAL驱动
  else if (type == "DRACAL") {
    $("#Add_SelParame tr").hide();
    $("#Add_Line_DeviceID").hide();
    $("#Add_Line_Baudrate").hide();
    $("#Add_Line_Parity").hide();
    $("#Add_Line_Databits").hide();
    $("#Add_Line_Stopbit").hide();
    $("#Add_Line_ResponseOverTime").hide();
    $(".Add_ChannelLayer").css("height", "240px");
  }
  // add end
  //RF下，三菱增加响应超时时间
  else if (type == "MITSUBISHI") {
    if (AnyLinkType == "RF") {
      $("#Add_SelParame tr").hide();
      $("#Add_Line_DeviceID").show();
      $("#Add_Line_Baudrate").show();
      $("#Add_Line_Parity").show();
      $("#Add_Line_Databits").show();
      $("#Add_Line_Stopbit").show();
      /*author:jinxin.zhou 内容：加上modbus特有的发送延迟*/
      $("#Add_Line_SendDelay").hide();
      /*end*/
      $("#Add_Line_ResponseOverTime").show();
      $(".Add_ChannelLayer").css("height", "430px");
    } else {
      $("#Add_SelParame tr").hide();
      $("#Add_Line_DeviceID").show();
      $("#Add_Line_Baudrate").show();
      $("#Add_Line_Parity").show();
      $("#Add_Line_Databits").show();
      $("#Add_Line_Stopbit").show();
      /*author:jinxin.zhou 内容：加上modbus特有的发送延迟*/
      $("#Add_Line_SendDelay").hide();
      /*end*/
      $("#Add_Line_ResponseOverTime").hide();
      $(".Add_ChannelLayer").css("height", "400px");
    }
  } else if (type == "HMI") {
    $("#Add_SelParame tr").hide();
    $("#Add_Line_DeviceID").show();
    $("#Add_Line_Baudrate").show();
    $("#Add_Line_Parity").show();
    $("#Add_Line_Databits").show();
    $("#Add_Line_Stopbit").show();
    /*author:jinxin.zhou 内容：加上modbus特有的发送延迟*/
    $("#Add_Line_SendDelay").hide();
    /*end*/
    $("#Add_Line_ResponseOverTime").hide();
    $(".Add_ChannelLayer").css("height", "400px");
  }
  //YinHe显示ip,端口
  else if (type == "YinHe") {
    $("#Add_SelParame tr").hide();
    $("#Add_Line_IPAddr").show();
    $("#Add_Line_Port").show();
    $(".Add_ChannelLayer").css("height", "300px");
  }
  //增达显示ip,端口,超时
  else if (type == "Zundar") {
    $("#Add_SelParame tr").hide();
    $("#Add_Line_IPAddr").show();
    $("#Add_Line_Port").show();
    $("#Add_Line_delayed").show();
    $("#Add_delayed").val("3000");
    $(".Add_ChannelLayer").css("height", "400px");
  } else if (type == "Custom-TCP") {
    $("#Add_SelParame tr").hide();
    $("#Add_Line_IPAddr").show();
    $("#Add_Line_Port").show();
    if (coo == "English") {
      $("#Add_Line_delayed_t").html("Timeout (ms)");
    } else {
      $("#Add_Line_delayed_t").html("超时时间(毫秒)：");
    }
    $("#Add_Line_delayed").show();
    $(".Add_ChannelLayer").css("height", "350px");
  }
  //add begin by x
  //新增Beckhoff驱动
  else if (type == "Beckhoff") {
    $("#Add_SelParame tr").hide();
    $("#Add_Line_IPAddr").hide();
    $("#Add_Line_Port").hide();
    $("#Add_Line_delayed").show();
    $("#Add_delayed").val("200");
    $(".Add_ChannelLayer").css("height", "350px");
  }
  //end add
  //add begin by x
  //gps 驱动,通讯串口固定为"/dev/ttyO2"
  else if (type == "GPS") {
    $("#Add_SelParame tr").hide();
    $("#Add_Line_DeviceID").hide();
    $("#Add_Line_Baudrate").hide();
    $("#Add_Line_Parity").hide();
    $("#Add_Line_Databits").hide();
    $("#Add_Line_Stopbit").hide();
    $("#Add_Line_ResponseOverTime").hide();
    $(".Add_ChannelLayer").css("height", "240px");
  }
  //end add
  // add begin by fyj
  else if (type == "CloudWeb") {
    $("#Add_SelParame tbody tr").hide();

    $("#Add_Line_CloudAddress").show();
    $("#Add_Line_Username").show();
    $("#Add_Line_Password").show();

    $(".Add_ChannelLayer").css("height", "350px");
  }
  // end add
  // add begin by fyj
  else if (type == "DLT645") {
    $("#Add_SelParame tbody tr").hide();
    $("#Add_Line_DeviceID").show();
    $("#Add_Line_Baudrate").show();
    $("#Add_Line_Parity").show();
    $("#Add_Line_Databits").show();
    $("#Add_Line_Stopbit").show();
    $("#Add_Line_ResponseOverTime").show();
    $("#Add_ResponseOverTime").val(2000);
    $(".Add_ChannelLayer").css("height", "430px");
  }
  // add end
  //add begin by whc
  else if (type == "FATEK编程口") {
    $("#Add_SelParame tbody tr").hide();
    $("#Add_Line_DeviceID").show();
    $("#Add_Line_Baudrate").show();
    $("#Add_Line_Parity").show();
    $("#Add_Line_Databits").show();
    $("#Add_Line_Stopbit").show();
    $("#Add_Line_SendDelay").hide();
    $("#Add_Line_ResponseOverTime").hide();
    $(".Add_ChannelLayer").css("height", "400px");
  }
  //add end
  // add by whc
  else if (type == "OPC") {
    $("#Add_SelParame tbody tr").hide();

    $("#Add_Line_GatewayAddress").show();
    $("#Add_GatewayPort").val(15000); // OPC网关端口默认是15000
    $("#Add_Line_GatewayPort").show();
    $("#Add_Line_ServerAddress").show();
    $("#Add_Line_ServerName").show();
    $("#Add_Line_ReadMode").show();

    $(".Add_ChannelLayer").css("height", "400px");
  }
  // end add
  // add by lh, IEC104 驱动
  else if (type == "IEC104") {
    $("#Add_SelParame tr").hide();

    $("#Add_Line_IEC104IP").show();
    $("#Add_Line_IEC104Port").show();
    $("#Add_Line_IEC104Addr").show();
    $(".Add_ChannelLayer").css("height", "350px");
  }
  // add end
  // add by lh, IEC104 驱动
  else if (type == "common") {
    $("#Add_SelParame tbody tr").hide();

    $("#Add_Line_commonName").show();
    $("#Add_Line_commonConf").show();

    $(".Add_ChannelLayer").css("height", "300px");
  }
  // add end
  else if (type == "BacNet Task" || type == "BacNet任务") {
    $("#Add_SelParame tr").hide();
    $("#Add_Line_Port").show();
    $("#Add_Line_delayed").show();
    $("#Add_delayed").val("1000");
    $(".Add_ChannelLayer").css("height", "345px");
  } else if (type == "MITSUBISHI-TXZ") {
    $("#Add_SelParame tr").hide();
    $("#Add_Line_DeviceID").show();
    $("#Add_Line_Baudrate").show();
    $("#Add_Line_Parity").show();
    $("#Add_Line_Databits").show();
    $("#Add_Line_Stopbit").show();
    $("#Add_Line_ResponseOverTime").show();
    $(".Add_ChannelLayer").css("height", "445px");
  } else if (type == "MITSUBISHI-TX") {
    $("#Add_SelParame tr").hide();
    $("#Add_Line_DeviceID").show();
    $("#Add_Line_Baudrate").show();
    $("#Add_Line_Parity").show();
    $("#Add_Line_Databits").show();
    $("#Add_Line_Stopbit").show();
    $("#Add_Line_ResponseOverTime").show();
    $("#Add_Line_OutdoorAddress").show();
    $(".Add_ChannelLayer").css("height", "470px");
  } else if (type == "Samsung") {
    $("#Add_SelParame tr").hide();
    $("#Add_Line_DeviceID").show();
    $("#Add_Line_Baudrate").show();
    $("#Add_Line_Parity").show();
    $("#Add_Line_Databits").show();
    $("#Add_Line_Stopbit").show();
    $("#Add_Line_delayed").show();
    $("#Add_Line_SendDelay").hide();
    
    $("#Add_delayed").val("5000");
    /*end*/
    $("#Add_Line_ResponseOverTime").hide();
    $(".Add_ChannelLayer").css("height", "430px");
  } else {
    $("#Add_SelParame tr").hide();
    $("#Add_Line_DeviceID").show();
    $("#Add_Line_Baudrate").show();
    $("#Add_Line_Parity").show();
    $("#Add_Line_Databits").show();
    $("#Add_Line_Stopbit").show();
    /*author:jinxin.zhou 内容：加上modbus特有的发送延迟*/
    $("#Add_Line_SendDelay").hide();
    /*end*/
    $("#Add_Line_ResponseOverTime").hide();
    $(".Add_ChannelLayer").css("height", "400px");
  }
});
if (coo == "English") {
  $("#Add_S7_200_Yes").click(function () {
    $("#Add_Line_JJ_input").html("Local TSAP:");
    $("#Add_Line_CC_input").html("Remote TSAP:");
  });
  $("#Add_S7_200_No").click(function () {
    $("#Add_Line_JJ_input").html("Rack number:");
    $("#Add_Line_CC_input").html("Slot number:");
  });
  $("#Alter_S7_200_Yes").click(function () {
    $("#Alter_Line_JJ_input").html("Local TSAP:");
    $("#Alter_Line_CC_input").html("Remote TSAP:");
  });
  $("#Alter_S7_200_No").click(function () {
    $("#Alter_Line_JJ_input").html("Rack number:");
    $("#Alter_Line_CC_input").html("lot number:");
  });
} else {
  $("#Add_S7_200_Yes").click(function () {
    $("#Add_Line_JJ_input").html("本地TSAP：");
    $("#Add_Line_CC_input").html("远程TSAP：");
  });
  $("#Add_S7_200_No").click(function () {
    $("#Add_Line_JJ_input").html("机架号：");
    $("#Add_Line_CC_input").html("插槽号：");
  });
  $("#Alter_S7_200_Yes").click(function () {
    $("#Alter_Line_JJ_input").html("本地TSAP：");
    $("#Alter_Line_CC_input").html("远程TSAP：");
  });
  $("#Alter_S7_200_No").click(function () {
    $("#Alter_Line_JJ_input").html("机架号：");
    $("#Alter_Line_CC_input").html("插槽号：");
  });
}
$("#Add_DeviceDriver").change(function () {
  var type = $("#Add_DeviceType").val();
  var driver = $("#Add_DeviceDriver").val();
  //西门子MPI有串口、波特率、网络传输率
  if (driver == "SIEMENS-MPI") {
    $("#Add_SelParame tr").hide();
    $("#Add_Line_DeviceID").show();
    $("#Add_Line_Baudrate").show();
    $("#Add_Line_MPI").show();
  }
  // add by whc,SIEMENS-S7-PPI-Task有响应延时
  else if (driver == "SIEMENS-S7-PPI-Task") {
    $("#Add_SelParame tbody tr").hide();
    $("#Add_Line_PPI_DeviceID").show();
    $("#Add_Line_PPI_Baudrate").show();
    $("#Add_Line_Parity").show();
    $("#Add_Line_Databits").show();
    $("#Add_Line_PPI_Stopbit").show();
    $("#Add_Line_ResponseOverTime").show();
    $("#Add_ResponseOverTime").val(200);
    $(".Add_ChannelLayer").css("height", "430px");
  }
  // add end
  //西门子1200有IP地址，机架号和插槽号
  else if (driver == "SIEMENS-Ethernet") {
    $("#Add_SelParame tr").hide();
    $("#Add_Line_IPAddr").show();
    $("#Add_Line_S7").show();
    $("#Add_Line_JJ").show();
    $("#Add_Line_CC").show();
    $("#Add_Line_Type").show();
  }
  //TCP类型协议有IP地址、端口号
  else if (
    driver == "Modbus-TCP" ||
    driver == "Schneider-TCP" ||
    driver == "Detal-TCP" ||
    driver == "Modbus-TCP-task"
  ) {
    $("#Add_SelParame tr").hide();
    $("#Add_Line_IPAddr").show();
    $("#Add_Line_Port").show();
    $("#Add_Line_delayed").show();
    $("#Add_delayed").val("200");
    $("#Add_Line_Buffer").show();
    $("#Add_Buffer").val("100");
    $("#Add_Line_SendDelay").show();
    $(".Add_ChannelLayer").css("height", "420px");
  } else if (driver == "OMRON-TCP" || driver == "M-Bus-TCP") {
    $("#Add_SelParame tr").hide();
    $("#Add_Line_IPAddr").show();
    $("#Add_Line_Port").show();
    $(".Add_ChannelLayer").css("height", "300px");
  }
  //BacNet-IP只有端口地址
  else if (driver == "BacNet-IP" || driver == "BacNet-IP-task") {
    $("#Add_SelParame tr").hide();
    $("#Add_Line_Port").show();
    $("#Add_Line_delayed").show();
    $("#Add_delayed").val("1000");
    if (driver == "BacNet-IP-task") {
      $("#Add_Port").val("47808");
    } else {
      $("#Add_Port").val("");
    }
  }
  //BacNet-MS/TP有串口、波特率和MAC地址
  else if (driver == "BacNet-MS/TP" || driver == "BacNet-MS/TP-task") {
    $("#Add_SelParame tr").hide();
    $("#Add_Line_DeviceID").show();
    $("#Add_Line_Baudrate").show();
    $("#Add_Line_MACAddr").show();
  }
  //Modbus-RTU和ASCII有延时和缓冲区大小
  else if (
    driver == "Modbus-RTU" ||
    driver == "Modbus-ASCII" ||
    driver == "Detal-RTU" ||
    driver == "Detal-ASCII" ||
    driver == "Schneider-RTU" ||
    driver == "Schneider-ASCII" ||
    driver == "XinjieXD3-RTU" ||
    driver == "XinjieXD3-ASCII" ||
    driver == "XinjieXC3-RTU" ||
    driver == "XinjieXC3-ASCII" ||
    driver == "Modbus-RTU-task" ||
    driver == "Modbus-ASCII-task"
  ) {
    $("#Add_SelParame tr").hide();
    $("#Add_Line_DeviceID").show();
    $("#Add_Line_Baudrate").show();
    $("#Add_Line_Parity").show();
    $("#Add_Line_Databits").show();
    $("#Add_Line_Stopbit").show();
    $("#Add_Line_delayed").show();
    $("#Add_delayed").val("200");
    $("#Add_Line_Buffer").show();
    $("#Add_Buffer").val("100");
    $("#Add_Line_SendDelay").show();
    $(".Add_ChannelLayer").css("height", "520px");
  } else if (driver == "OMRON_NJNX") {
    $("#Add_SelParame tr").hide();
    $("#Add_Line_ResponseOverTime").show();
    $(".Add_ChannelLayer").css("height", "300px");
  } else if (driver == "DLT645-1997" || driver == "DLT645-2007") {
    $("#Add_SelParame tbody tr").hide();
    $("#Add_Line_DeviceID").show();
    $("#Add_Line_Baudrate").show();
    $("#Add_Line_Parity").show();
    $("#Add_Line_Databits").show();
    $("#Add_Line_Stopbit").show();
    $("#Add_Line_ResponseOverTime").show();
    $("#Add_ResponseOverTime").val(2000);
    $(".Add_ChannelLayer").css("height", "430px");
  }
  //三菱Q系列要plcip，plc端口号，本地端口号
  else if (driver == "MITSUBISHI-Q") {
    $("#Add_SelParame tr").hide();
    $("#Add_Line_IPAddr").show();
    $("#Add_Line_QLocalPort").show();
    $("#Add_Line_QPLCPort").show();
    $("#Add_Line_ResponseOverTime").hide();
  } else if (driver == "MITSUBISHI-QN") {
    $("#Add_SelParame tr").hide();
    $("#Add_Line_IPAddr").show();
    $("#Add_Line_QLocalPort").show();
    $("#Add_Line_QPLCPort").show();
    $("#Add_Line_Code").show();
    $("#Add_Line_ResponseOverTime").hide();
  }
  //RF下三菱FX编程口和FX串口增加响应超时时间
  else if (driver == "MITSUBISHI-FXP" && AnyLinkType == "RF") {
    $("#Add_SelParame tr").hide();
    $("#Add_Line_DeviceID").show();
    $("#Add_Line_Baudrate").show();
    $("#Add_Line_Parity").show();
    $("#Add_Line_Databits").show();
    $("#Add_Line_Stopbit").show();
    $("#Add_Line_ResponseOverTime").show();
  } else if (driver == "MITSUBISHI-FXS" && AnyLinkType == "RF") {
    $("#Add_SelParame tr").hide();
    $("#Add_Line_DeviceID").show();
    $("#Add_Line_Baudrate").show();
    $("#Add_Line_Parity").show();
    $("#Add_Line_Databits").show();
    $("#Add_Line_Stopbit").show();
    $("#Add_Line_ResponseOverTime").show();
  }
  //AB-Ethernet/IP有延时毫秒
  else if (
    driver == "AB-Ethernet/IP" ||
    driver == "AB-MicroLogix" ||
    driver == "TwinCAT"
  ) {
    $("#Add_SelParame tr").hide();
    $("#Add_Line_delayed").show();
    $("#Add_delayed").val("200");
  } else if (driver == "AB-DF1") {
    $("#Add_SelParame tr").hide();
    $("#Add_Line_DeviceID").show();
    $("#Add_Line_Baudrate").show();
    $("#Add_Line_Parity").show();
    $("#Add_Line_Databits").show();
    $("#Add_Line_Stopbit").show();
    $("#Add_Line_LocStack").show();
    $("#Add_Line_PLCStack").show();
    $("#Add_Line_ABCheck").show();
    /*author:jinxin.zhou 内容：加上modbus特有的发送延迟*/
    $("#Add_Line_SendDelay").hide();
    /*end*/
    $("#Add_Line_ResponseOverTime").hide();
    $(".Add_ChannelLayer").css("height", "510px");
  }
  //add begin by x
  //GPS 通讯串口 默认是 "/dev/ttyO2",其他的可以修改
  else if (driver == "GPS") {
    $("#Add_SelParame tr").hide();
    $("#Add_Line_DeviceID").hide();
    $("#Add_Line_Baudrate").hide();
    $("#Add_Line_Parity").hide();
    $("#Add_Line_Databits").hide();
    $("#Add_Line_Stopbit").hide();
    $("#Add_Line_ResponseOverTime").hide();
    $(".Add_ChannelLayer").css("height", "240px");
  }
  //end add
  // add by whc
  else if (driver == "DRACAL") {
    $("#Add_SelParame tr").hide();
    $("#Add_Line_DeviceID").hide();
    $("#Add_Line_Baudrate").hide();
    $("#Add_Line_Parity").hide();
    $("#Add_Line_Databits").hide();
    $("#Add_Line_Stopbit").hide();
    $("#Add_Line_ResponseOverTime").hide();
    $(".Add_ChannelLayer").css("height", "240px");
  }
  // add end
  //add begin by x
  //JB3102 默认参数232/19200/无校验/8/1
  //JB3208 默认参数232/19200/无校验/8/1
  else if (driver == "JB3102") {
    $("#Add_SelParame tr").hide();
    $("#Add_Line_DeviceID").show();
    $("#Add_Line_Baudrate").show();
    $("#Add_Line_Parity").show();
    $("#Add_Line_Databits").show();
    $("#Add_Line_Stopbit").show();
    $("#Add_Line_ResponseOverTime").hide();
    $(".Add_ChannelLayer").css("height", "420px");
  } else if (driver == "JB3208") {
    $("#Add_SelParame tr").hide();
    $("#Add_Line_DeviceID").show();
    $("#Add_Line_Baudrate").show();
    $("#Add_Line_Parity").show();
    $("#Add_Line_Databits").show();
    $("#Add_Line_Stopbit").show();
    $("#Add_Line_ResponseOverTime").hide();
    $(".Add_ChannelLayer").css("height", "420px");
  }
  //end add
  // add by fyj, OMRON-HostLink 任务驱动
  else if (driver == "OMRON-HostLink-Task" || driver == "OMRON-FINS-Task") {
    $("#Add_SelParame tr").hide();

    $("#Add_Line_DeviceID").show();
    $("#Add_Line_Baudrate").show();
    $("#Add_Line_Parity").show();
    $("#Add_Line_Databits").show();
    $("#Add_Line_Stopbit").show();
    $("#Add_Line_HostLink_ResponseOvertime").show();

    $(".Add_ChannelLayer").css("height", "430px");
  }
  // add end
  else if (driver == "OPC") {
    $("#Add_SelParame tbody tr").hide();

    $("#Add_Line_GatewayAddress").show();
    $("#Add_GatewayPort").val(15000); // OPC网关端口默认是15000
    $("#Add_Line_GatewayPort").show();
    $("#Add_Line_ServerAddress").show();
    $("#Add_Line_ServerName").show();
    $("#Add_Line_ReadMode").show();

    $(".Add_ChannelLayer").css("height", "400px");
  } else if (driver == "OPC-UA") {
    $("#Add_SelParame tbody tr").hide();

    $("#Add_Line_IPAddr").show();
    $("#Add_Line_Port").show();
    $("#Add_Line_Encoding").show();
    $("#Add_Line_Security").show();
    $("#Add_Line_Sync").show();
    $(".Add_ChannelLayer").css("height", "400px");
  } else if (driver == "device") {
    $("#Add_SelParame tbody tr").hide();

    $("#Add_Line_commonName").show();
    $("#Add_Line_commonConf").show();

    $(".Add_ChannelLayer").css("height", "300px");
  } else if (driver == "IEC104") {
    $("#Add_SelParame tr").hide();
    $("#Add_Line_IEC104IP").show();
    $("#Add_Line_IEC104Port").show();
    $("#Add_Line_IEC104Addr").show();
  } else if (driver == "MITSUBISHI-TXZ-MomMach" || driver == "MITSUBISHI-TXZ-SubMach1" || driver == "MITSUBISHI-TXZ-SubMach2") {
    $("#Add_SelParame tr").hide();
    $("#Add_Line_DeviceID").show();
    $("#Add_Line_Baudrate").show();
    $("#Add_Line_Parity").show();
    $("#Add_Line_Databits").show();
    $("#Add_Line_Stopbit").show();
    $("#Add_Line_ResponseOverTime").show();
    $(".Add_ChannelLayer").css("height", "445px");
  } else if (
    driver == "MITSUBISHI-TX-5HP" ||
    driver == "MITSUBISHI-TX-15P" ||
    driver == "MITSUBISHI-TX-Multi-link"
  ) {
    $("#Add_SelParame tr").hide();
    $("#Add_Line_DeviceID").show();
    $("#Add_Line_Baudrate").show();
    $("#Add_Line_Parity").show();
    $("#Add_Line_Databits").show();
    $("#Add_Line_Stopbit").show();
    $("#Add_Line_ResponseOverTime").show();
    $("#Add_Line_OutdoorAddress").show();
    $(".Add_ChannelLayer").css("height", "470px");
  }
  //其他的与默认的一致
  else {
    $("#Add_SelParame tr").hide();
    $("#Add_Line_DeviceID").show();
    $("#Add_Line_Baudrate").show();
    $("#Add_Line_Parity").show();
    $("#Add_Line_Databits").show();
    $("#Add_Line_Stopbit").show();
    $("#Add_Line_ResponseOverTime").hide();
    $(".Add_ChannelLayer").css("height", "420px");
  }
  //获取缺省值
  getConfig(type, driver);
});

function getDriverInfo(txt) {
  $("#Add_DeviceDriver").empty();
  if (coo == "English") {
    $.get("../conf/AllDeviceDriverEn.xml", function (d1) {
      $(d1)
        .find("Fac[value='" + txt + "']")
        .each(function () {
          //通用设备在AllDeviceDriver.xml中只有value，无config和lib字段
          if (txt == "common") {
            var $Fac = $(this);
            $Fac.find("Agr").each(function () {
              var $Agr = $(this);
              var Text = $Agr.text();
              var Val = $Agr.attr("value");
              var option = $("<option>").val(Val).text(Text);
              $("#Add_DeviceDriver").append(option);
            });
          } else {
            var $Fac = $(this);
            var firstconfig = $Fac.children(":first").attr("config");
            var firstlib = $Fac.children(":first").attr("lib");
            var configArr = new Array();
            configArr = firstconfig.split(";");
            $("#Add_DeviceID").val(configArr[0]);
            $("#Add_DeviceBaudrate").val(configArr[1]);
            $("#Add_DeviceParity").val(configArr[2]);
            $("#Add_DeviceDatabits").val(configArr[3]);
            if (configArr[4] == "1") {
              $("#Add_DeviceStopbit1").attr("checked", "checked");
            } else {
              $("#Add_DeviceStopbit2").attr("checked", "checked");
            }
            //AB有额外参数
            if (txt == "AB") {
              $("#Add_LocStack").val(configArr[5]);
              $("#Add_PLCStack").val(configArr[6]);
            }
            $("#Hide_Add_Lib").val(firstlib);
            $Fac.find("Agr").each(function () {
              var $Agr = $(this);
              var Text = $Agr.text();
              var Val = $Agr.attr("value");
              var option = $("<option>").val(Val).text(Text);
              $("#Add_DeviceDriver").append(option);
            });
          }
        });
    });
  } else {
    $.get("../conf/AllDeviceDriver.xml", function (d1) {
      $(d1)
        .find("Fac[value='" + txt + "']")
        .each(function () {
          //通用设备在AllDeviceDriver.xml中只有value，无config和lib字段
          if (txt == "common") {
            var $Fac = $(this);
            $Fac.find("Agr").each(function () {
              var $Agr = $(this);
              var Text = $Agr.text();
              var Val = $Agr.attr("value");
              var option = $("<option>").val(Val).text(Text);
              $("#Add_DeviceDriver").append(option);
            });
          } else {
            var $Fac = $(this);
            var firstconfig = $Fac.children(":first").attr("config");
            var firstlib = $Fac.children(":first").attr("lib");
            var configArr = new Array();
            configArr = firstconfig.split(";");
            $("#Add_DeviceID").val(configArr[0]);
            $("#Add_DeviceBaudrate").val(configArr[1]);
            $("#Add_DeviceParity").val(configArr[2]);
            $("#Add_DeviceDatabits").val(configArr[3]);
            if (configArr[4] == "1") {
              $("#Add_DeviceStopbit1").attr("checked", "checked");
            } else {
              $("#Add_DeviceStopbit2").attr("checked", "checked");
            }
            //AB有额外参数
            if (txt == "AB") {
              $("#Add_LocStack").val(configArr[5]);
              $("#Add_PLCStack").val(configArr[6]);
            }
            $("#Hide_Add_Lib").val(firstlib);
            $Fac.find("Agr").each(function () {
              var $Agr = $(this);
              var Text = $Agr.text();
              var Val = $Agr.attr("value");
              var option = $("<option>").val(Val).text(Text);
              $("#Add_DeviceDriver").append(option);
            });
          }
        });
    });
  }
}

function getConfig(a, b) {
  if (coo == "English") {
    $.get("../conf/AllDeviceDriverEn.xml", function (d1) {
      $(d1)
        .find("Fac[value='" + a + "']")
        .each(function () {
          var $Fac = $(this);
          $Fac.find("Agr[value='" + b + "']").each(function () {
            var $Agr = $(this);
            var config = $Agr.attr("config");
            var lib = $Agr.attr("lib");
            var configArr = new Array();
            configArr = config.split(";");
            //MPI协议有单独的
            if (b == "SIEMENS-MPI") {
              $("#Add_DeviceID").val(configArr[0]);
              $("#Add_DeviceBaudrate").val(configArr[1]);
              $("#Add_DeviceMPI").val(configArr[2]);
            }
            // add by fyj, OMRON-HostLink 任务
            if (b == "OMRON-HostLink-Task") {
              $("#Add_HostLink_ResponseOvertime").val(configArr[5]);
            }
            // add end
            // add by whc
            if (b == "SIEMENS-S7-PPI-Task") {
              $("#Add_Line_PPI_DeviceID").val(configArr[0]);
              $("#Add_Line_PPI_Baudrate").val(configArr[1]);
              $("#Add_Line_Parity").val(configArr[2]);
              $("#Add_Line_Databits").val(configArr[3]);
              $("#Add_Line_PPI_Stopbit").val(configArr[4]);
              $("#Add_Line_ResponseOverTime").val(configArr[5]);
            }
            // add end
            if (b == "SIEMENS-Ethernet") {
              var statue = configArr[0];
              if (statue == "S7-200") {
                $("#Add_S7_200_Yes").attr("checked", "checked");
                $("#Add_IPAddress").val(configArr[1]);
                $("#Add_JJ_1200").val(configArr[2]);
                $("#Add_CC_1200").val(configArr[3]);
                var type = configArr[4];
                if (type == "OP") {
                  $("#Add_Type_200_OP").attr("checked", "checked");
                } else {
                  $("#Add_Type_200_PG").attr("checked", "checked");
                }
              } else {
                $("#Add_S7_200_No").attr("checked", "checked");
                $("#Add_IPAddress").val(configArr[0]);
                $("#Add_JJ_1200").val(configArr[1]);
                $("#Add_CC_1200").val(configArr[2]);
                var type = configArr[3];
                if (type == "OP") {
                  $("#Add_Type_200_OP").attr("checked", "checked");
                } else {
                  $("#Add_Type_200_PG").attr("checked", "checked");
                }
              }
            }
            //其他情况下的协议
            $("#Add_DeviceID").val(configArr[0]);
            $("#Add_DeviceBaudrate").val(configArr[1]);
            $("#Add_DeviceParity").val(configArr[2]);
            $("#Add_DeviceDatabits").val(configArr[3]);
            if (configArr[4] == "1") {
              $("#Add_DeviceStopbit1").attr("checked", "checked");
            } else {
              $("#Add_DeviceStopbit2").attr("checked", "checked");
            }
            $("#Hide_Add_Lib").val(lib);
          });
        });
    });
  } else {
    $.get("../conf/AllDeviceDriver.xml", function (d1) {
      $(d1)
        .find("Fac[value='" + a + "']")
        .each(function () {
          var $Fac = $(this);
          $Fac.find("Agr[value='" + b + "']").each(function () {
            var $Agr = $(this);
            var config = $Agr.attr("config");
            var lib = $Agr.attr("lib");
            var configArr = new Array();
            configArr = config.split(";");
            //MPI协议有单独的
            if (b == "SIEMENS-MPI") {
              $("#Add_DeviceID").val(configArr[0]);
              $("#Add_DeviceBaudrate").val(configArr[1]);
              $("#Add_DeviceMPI").val(configArr[2]);
            }
            // add by fyj, OMRON-HostLink 任务
            if (b == "OMRON-HostLink-Task") {
              $("#Add_HostLink_ResponseOvertime").val(configArr[5]);
            }
            // add end
            // add by whc
            if (b == "SIEMENS-S7-PPI-Task") {
              $("#Add_Line_PPI_DeviceID").val(configArr[0]);
              $("#Add_Line_PPI_Baudrate").val(configArr[1]);
              $("#Add_Line_Parity").val(configArr[2]);
              $("#Add_Line_Databits").val(configArr[3]);
              $("#Add_Line_PPI_Stopbit").val(configArr[4]);
              $("#Add_Line_ResponseOverTime").val(configArr[5]);
            }
            // add end
            if (b == "SIEMENS-Ethernet") {
              var statue = configArr[0];
              if (statue == "S7-200") {
                $("#Add_S7_200_Yes").attr("checked", "checked");
                $("#Add_IPAddress").val(configArr[1]);
                $("#Add_JJ_1200").val(configArr[2]);
                $("#Add_CC_1200").val(configArr[3]);
                var type = configArr[4];
                if (type == "OP") {
                  $("#Add_Type_200_OP").attr("checked", "checked");
                } else {
                  $("#Add_Type_200_PG").attr("checked", "checked");
                }
              } else {
                $("#Add_S7_200_No").attr("checked", "checked");
                $("#Add_IPAddress").val(configArr[0]);
                $("#Add_JJ_1200").val(configArr[1]);
                $("#Add_CC_1200").val(configArr[2]);
                var type = configArr[3];
                if (type == "OP") {
                  $("#Add_Type_200_OP").attr("checked", "checked");
                } else {
                  $("#Add_Type_200_PG").attr("checked", "checked");
                }
              }
            }
            //其他情况下的协议
            $("#Add_DeviceID").val(configArr[0]);
            $("#Add_DeviceBaudrate").val(configArr[1]);
            $("#Add_DeviceParity").val(configArr[2]);
            $("#Add_DeviceDatabits").val(configArr[3]);
            if (configArr[4] == "1") {
              $("#Add_DeviceStopbit1").attr("checked", "checked");
            } else {
              $("#Add_DeviceStopbit2").attr("checked", "checked");
            }
            $("#Hide_Add_Lib").val(lib);
          });
        });
    });
  }
}
//安全退出

function safeExit() {
  if (coo == "English") {
    if (confirm("Please confirm to exit.")) {
      sessionStorage.name = "yushi";
      sessionStorage.pass = "yushi";
    } else return false;
  } else {
    if (confirm("确定退出吗？")) {
      sessionStorage.name = "yushi";
      sessionStorage.pass = "yushi";
    } else return false;
  }
  //点击变色效果
}

function MagicChange(txt) {
  if (MaxMagicID - 10000000001 == 0) {
    document.getElementById(txt).className = "active";
  } else {
    if (txt == 10000000001) {
      document.getElementById(txt).className = "active";
      for (var i = 10000000002; i <= MaxMagicID; i++) {
        if (
          document.getElementById(i) != undefined &&
          document.getElementById(i) != ""
        ) {
          document.getElementById(i).className = "";
        }
      }
    } else if (txt == MaxMagicID) {
      document.getElementById(txt).className = "active";
      for (var i = 10000000001; i < MaxMagicID; i++) {
        if (
          document.getElementById(i) != undefined &&
          document.getElementById(i) != ""
        ) {
          document.getElementById(i).className = "";
        }
      }
    } else {
      document.getElementById(txt).className = "active";
      for (var i = 10000000001; i < txt; i++) {
        if (
          document.getElementById(i) != undefined &&
          document.getElementById(i) != ""
        ) {
          document.getElementById(i).className;
        }
      }
      for (var j = txt; j <= MaxMagicID; j++) {
        j++;
        if (
          document.getElementById(j) != undefined &&
          document.getElementById(i) != ""
        ) {
          document.getElementById(j).className = "";
        }
        document.getElementById(MaxMagicID).className = "";
      }
    }
  }
}
//大加号特效
$("#add").hover(
  function () {
    $(this).attr("src", "assets/img/add1_hover.png");
  },
  function () {
    $(this).attr("src", "assets/img/add1.png");
  }
);
//增加通道层

function Add_Open_ChannelLayer() {
  getDeviceInfo();
  //变为缺省
  // $("#Add_SelParame tr").hide();
  // $("#Add_Line_DeviceID").show();
  // $("#Add_Line_Baudrate").show();
  // $("#Add_Line_Parity").show();
  // $("#Add_Line_Databits").show();
  // $("#Add_Line_Stopbit").show();
  // add by whc
  $("#Add_SelParame tr").hide();
  $("#Add_Line_DeviceID").show();
  $("#Add_Line_Baudrate").show();
  $("#Add_Line_Parity").show();
  $("#Add_Line_Databits").show();
  $("#Add_Line_Stopbit").show();
  $("#Add_Line_delayed").show();
  $("#Add_delayed").val("200");
  $("#Add_Line_Buffer").show();
  $("#Add_Buffer").val("100");
  $("#Add_Line_SendDelay").show();
  $(".Add_ChannelLayer").css("height", "520px");
  $("#Add_ChannelName").val("");
  if (AnyLinkType == "RF") {
    $("#Add_Line_ResponseOverTime").show();
  } else {
    $("#Add_Line_ResponseOverTime").hide();
  }
  $("#Hide_Add_Lib").val("T.IDrv.Task:libTModbus");
  $("#Add_DeviceType option:eq(0)").attr("selected", "selected");
  var type = $("#Add_DeviceType").val();
  $("#Add_DeviceDriver").empty();
  var list =
    '<option value="Modbus-RTU-task" selected="selected">RTU</option><option value="Modbus-ASCII-task">ASCII</option>';
  list += '<option value="Modbus-TCP-task">TCP</option>';
  $("#Add_DeviceDriver").append(list);
  var driver = $("#Add_DeviceDriver").val();
  getConfig(type, driver);
  document.getElementById("popWindow").style.display = "";
  document.getElementById("Add_ChannelLayer").style.display = "";
  // $(".Add_ChannelLayer").css("height", "420px");
}
//    点击添加按钮赋值以及执行py

function ClickAddChannelButton() {
  var isHidden = $("#Add_Line_DeviceID").attr("style").indexOf("display: none");
  if ($("#Add_DeviceID").val() == "-1" && isHidden == -1) {
    if (coo == "English") {
      alert(
        "No serial port is available currently. Please select a different driver."
      );
    } else {
      alert("当前无可用串口，请选择其他驱动");
    }
    return;
  }
  var val = $("#Add_DeviceDriver").val();
  var config = "";
  //通道名
  $("#Add_ChannelName_YuToXHZhang").val($("#Add_ChannelName").val());
  //通道类型
  $("#Add_ChannelDriver_YuToXHZhang").val(val);
  /*author: tao.zhou form里加一个字段用来判断是否是任务驱动*/
  $("#Add_IsTask_YuToXHZhang").val("NO");
  //Config
  //所有的rtu协议拼出的config
  if (val == "Schneider-RTU") {
    config =
      "rtu;" +
      $("#Add_DeviceID").val() +
      ";" +
      $("#Add_DeviceBaudrate").val() +
      ";" +
      $("#Add_DeviceParity").val() +
      ";" +
      $("#Add_DeviceDatabits").val() +
      ";" +
      $("input[name='Add_DeviceStopbit']:checked").val() +
      ";SCHNEIDER" +
      ";" +
      $("#Add_delayed").val() +
      ";" +
      $("#Add_Buffer").val() +
      ";" +
      $("#Add_SendDelay").val();
  } else if (val == "Modbus-RTU") {
    config =
      "rtu;" +
      $("#Add_DeviceID").val() +
      ";" +
      $("#Add_DeviceBaudrate").val() +
      ";" +
      $("#Add_DeviceParity").val() +
      ";" +
      $("#Add_DeviceDatabits").val() +
      ";" +
      $("input[name='Add_DeviceStopbit']:checked").val() +
      ";STANDARD" +
      ";" +
      $("#Add_delayed").val() +
      ";" +
      $("#Add_Buffer").val() +
      ";" +
      $("#Add_SendDelay").val();
  } else if (val == "Modbus-RTU-task") {
    config =
      "rtu;" +
      $("#Add_DeviceID").val() +
      ";" +
      $("#Add_DeviceBaudrate").val() +
      ";" +
      $("#Add_DeviceParity").val() +
      ";" +
      $("#Add_DeviceDatabits").val() +
      ";" +
      $("input[name='Add_DeviceStopbit']:checked").val() +
      ";STANDARD" +
      ";" +
      $("#Add_delayed").val() +
      ";" +
      $("#Add_Buffer").val() +
      ";" +
      $("#Add_SendDelay").val();
    $("#Add_IsTask_YuToXHZhang").val("YES");
  } else if (val == "Detal-RTU") {
    config =
      "rtu;" +
      $("#Add_DeviceID").val() +
      ";" +
      $("#Add_DeviceBaudrate").val() +
      ";" +
      $("#Add_DeviceParity").val() +
      ";" +
      $("#Add_DeviceDatabits").val() +
      ";" +
      $("input[name='Add_DeviceStopbit']:checked").val() +
      ";DETAL" +
      ";" +
      $("#Add_delayed").val() +
      ";" +
      $("#Add_Buffer").val() +
      ";" +
      $("#Add_SendDelay").val();
  } else if (val == "XinjieXD3-RTU") {
    config =
      "rtu;" +
      $("#Add_DeviceID").val() +
      ";" +
      $("#Add_DeviceBaudrate").val() +
      ";" +
      $("#Add_DeviceParity").val() +
      ";" +
      $("#Add_DeviceDatabits").val() +
      ";" +
      $("input[name='Add_DeviceStopbit']:checked").val() +
      ";XINJIE_XD3" +
      ";" +
      $("#Add_delayed").val() +
      ";" +
      $("#Add_Buffer").val() +
      ";" +
      $("#Add_SendDelay").val();
  } else if (val == "XinjieXC3-RTU") {
    config =
      "rtu;" +
      $("#Add_DeviceID").val() +
      ";" +
      $("#Add_DeviceBaudrate").val() +
      ";" +
      $("#Add_DeviceParity").val() +
      ";" +
      $("#Add_DeviceDatabits").val() +
      ";" +
      $("input[name='Add_DeviceStopbit']:checked").val() +
      ";XINJIE_XC3" +
      ";" +
      $("#Add_delayed").val() +
      ";" +
      $("#Add_Buffer").val() +
      ";" +
      $("#Add_SendDelay").val();
  }
  //所有ascii协议拼出的config
  else if (val == "Schneider-ASCII") {
    config =
      "ascii;" +
      $("#Add_DeviceID").val() +
      ";" +
      $("#Add_DeviceBaudrate").val() +
      ";" +
      $("#Add_DeviceParity").val() +
      ";" +
      $("#Add_DeviceDatabits").val() +
      ";" +
      $("input[name='Add_DeviceStopbit']:checked").val() +
      ";SCHNEIDER" +
      ";" +
      $("#Add_delayed").val() +
      ";" +
      $("#Add_Buffer").val() +
      ";" +
      $("#Add_SendDelay").val();
  } else if (val == "Modbus-ASCII") {
    config =
      "ascii;" +
      $("#Add_DeviceID").val() +
      ";" +
      $("#Add_DeviceBaudrate").val() +
      ";" +
      $("#Add_DeviceParity").val() +
      ";" +
      $("#Add_DeviceDatabits").val() +
      ";" +
      $("input[name='Add_DeviceStopbit']:checked").val() +
      ";STANDARD" +
      ";" +
      $("#Add_delayed").val() +
      ";" +
      $("#Add_Buffer").val() +
      ";" +
      $("#Add_SendDelay").val();
  } else if (val == "Modbus-ASCII-task") {
    config =
      "ascii;" +
      $("#Add_DeviceID").val() +
      ";" +
      $("#Add_DeviceBaudrate").val() +
      ";" +
      $("#Add_DeviceParity").val() +
      ";" +
      $("#Add_DeviceDatabits").val() +
      ";" +
      $("input[name='Add_DeviceStopbit']:checked").val() +
      ";STANDARD" +
      ";" +
      $("#Add_delayed").val() +
      ";" +
      $("#Add_Buffer").val() +
      ";" +
      $("#Add_SendDelay").val();
    $("#Add_IsTask_YuToXHZhang").val("YES");
  } else if (val == "Detal-ASCII") {
    config =
      "ascii;" +
      $("#Add_DeviceID").val() +
      ";" +
      $("#Add_DeviceBaudrate").val() +
      ";" +
      $("#Add_DeviceParity").val() +
      ";" +
      $("#Add_DeviceDatabits").val() +
      ";" +
      $("input[name='Add_DeviceStopbit']:checked").val() +
      ";DETAL" +
      ";" +
      $("#Add_delayed").val() +
      ";" +
      $("#Add_Buffer").val() +
      ";" +
      $("#Add_SendDelay").val();
  } else if (val == "XinjieXD3-ASCII") {
    config =
      "ascii;" +
      $("#Add_DeviceID").val() +
      ";" +
      $("#Add_DeviceBaudrate").val() +
      ";" +
      $("#Add_DeviceParity").val() +
      ";" +
      $("#Add_DeviceDatabits").val() +
      ";" +
      $("input[name='Add_DeviceStopbit']:checked").val() +
      ";XINJIE_XD3" +
      ";" +
      $("#Add_delayed").val() +
      ";" +
      $("#Add_Buffer").val() +
      ";" +
      $("#Add_SendDelay").val();
  } else if (val == "XinjieXC3-ASCII") {
    config =
      "ascii;" +
      $("#Add_DeviceID").val() +
      ";" +
      $("#Add_DeviceBaudrate").val() +
      ";" +
      $("#Add_DeviceParity").val() +
      ";" +
      $("#Add_DeviceDatabits").val() +
      ";" +
      $("input[name='Add_DeviceStopbit']:checked").val() +
      ";XINJIE_XC3" +
      ";" +
      $("#Add_delayed").val() +
      ";" +
      $("#Add_Buffer").val() +
      ";" +
      $("#Add_SendDelay").val();
  }
  //欧姆龙TCP协议拼出的config
  else if (val == "OMRON-TCP") {
    config = $("#Add_IPAddress").val() + ";" + $("#Add_Port").val();
  }
  //ModbusTCP协议拼出的config
  else if (val == "Modbus-TCP") {
    config =
      "tcp;" +
      $("#Add_IPAddress").val() +
      ";" +
      $("#Add_Port").val() +
      ";" +
      $("#Add_delayed").val() +
      ";" +
      $("#Add_Buffer").val() +
      ";" +
      $("#Add_SendDelay").val();
  } else if (val == "Modbus-TCP-task") {
    config =
      "tcp;" +
      $("#Add_IPAddress").val() +
      ";" +
      $("#Add_Port").val() +
      ";" +
      $("#Add_delayed").val() +
      ";" +
      $("#Add_Buffer").val() +
      ";" +
      $("#Add_SendDelay").val();
    $("#Add_IsTask_YuToXHZhang").val("YES");
  } else if (val == "OMRON_NJNX") {
    config = $("#Add_ResponseOverTime").val();
  }
  //台达TCP协议拼出的config
  else if (val == "Detal-TCP") {
    config =
      "tcp;" +
      $("#Add_IPAddress").val() +
      ";" +
      $("#Add_Port").val() +
      ";DETAL;" +
      $("#Add_delayed").val() +
      ";" +
      $("#Add_Buffer").val() +
      ";" +
      $("#Add_SendDelay").val();
  }
  //施耐德TCP协议拼出的config
  else if (val == "Schneider-TCP") {
    config =
      "tcp;" +
      $("#Add_IPAddress").val() +
      ";" +
      $("#Add_Port").val() +
      ";SCHNEIDER" +
      ";" +
      $("#Add_delayed").val() +
      ";" +
      $("#Add_Buffer").val() +
      ";" +
      $("#Add_SendDelay").val();
  }
  //MPI协议拼出的config
  else if (val == "SIEMENS-MPI") {
    config =
      $("#Add_DeviceID").val() +
      ";" +
      $("#Add_DeviceBaudrate").val() +
      ";" +
      $("#Add_DeviceMPI").val();
  }
  //SIEMENS-S7-PPI-Task
  else if (val == "SIEMENS-S7-PPI-Task") {
    config =
      $("#Add_PPI_DeviceID").val() +
      ";" +
      $("#Add_PPI_DeviceBaudrate").val() +
      ";" +
      $("#Add_DeviceParity").val() +
      ";" +
      $("#Add_DeviceDatabits").val() +
      ";" +
      $("input[name='Add_PPI_DeviceStopbit']:checked").val() +
      ";" +
      $("#Add_ResponseOverTime").val();
    $("#Add_IsTask_YuToXHZhang").val("YES");
  }
  //1200协议拼出的config
  else if (val == "SIEMENS-Ethernet") {
    var S7_200 = $("input[name='Add_S7_200']:checked").val();
    if (S7_200 == "yes") {
      config =
        "S7-200;" +
        $("#Add_IPAddress").val() +
        ";" +
        $("#Add_JJ_1200").val() +
        ";" +
        $("#Add_CC_1200").val() +
        ";" +
        $("input[name='Add_Type_200']:checked").val();
    } else {
      config =
        $("#Add_IPAddress").val() +
        ";" +
        $("#Add_JJ_1200").val() +
        ";" +
        $("#Add_CC_1200").val() +
        ";" +
        $("input[name='Add_Type_200']:checked").val();
    }
  }
  //BacNet-IP协议拼出的config
  else if (val == "BacNet-IP") {
    config = $("#Add_Port").val() + ";" + $("#Add_delayed").val();
  }
  //BacNet-IP-task协议拼出的config
  else if (val == "BacNet-IP-task") {
    config = $("#Add_Port").val() + ";" + $("#Add_delayed").val();
    $("#Add_IsTask_YuToXHZhang").val("YES");
  }
  //BacNet-MS/TP协议拼出的config
  else if (val == "BacNet-MS/TP") {
    config =
      $("#Add_DeviceID").val() +
      ";" +
      $("#Add_DeviceBaudrate").val() +
      ";" +
      $("#Add_Mac").val();
  }
  //BacNet-MS/TP-task协议拼出的config
  else if (val == "BacNet-MS/TP-task") {
    config =
      $("#Add_DeviceID").val() +
      ";" +
      $("#Add_DeviceBaudrate").val() +
      ";" +
      $("#Add_Mac").val();
    $("#Add_IsTask_YuToXHZhang").val("YES");
  }
  //AB-DF1拼出的config
  else if (val == "AB-DF1") {
    config =
      $("#Add_DeviceID").val() +
      ";" +
      $("#Add_DeviceBaudrate").val() +
      ";" +
      $("#Add_DeviceParity").val() +
      ";" +
      $("#Add_DeviceDatabits").val() +
      ";" +
      $("input[name='Add_DeviceStopbit']:checked").val() +
      ";" +
      $("#Add_LocStack").val() +
      ";" +
      $("#Add_PLCStack").val() +
      ";" +
      $("#Add_ABCheck").val();
  }
  //AB-Ethernet/IP拼出的config
  else if (
    val == "AB-Ethernet/IP" ||
    val == "AB-MicroLogix" ||
    val == "TwinCAT"
  ) {
    config = $("#Add_delayed").val();
  }
  //QN拼出的config
  else if (val == "MITSUBISHI-Q") {
    config =
      $("#Add_IPAddress").val() +
      ";" +
      $("#Add_QPLCPort").val() +
      ";" +
      $("#Add_QLocalPort").val();
  } else if (val == "MITSUBISHI-QN") {
    config =
      $("#Add_Code").val() +
      ";" +
      $("#Add_IPAddress").val() +
      ";" +
      $("#Add_QPLCPort").val() +
      ";" +
      $("#Add_QLocalPort").val();
  }
  //RF下三菱FX编程口和FX串口增加响应超时时间
  //其余的协议拼出的config
  else if (val == "MITSUBISHI-FXP" || val == "MITSUBISHI-FXS" || val == "HMI") {
    if (AnyLinkType == "RF") {
      config =
        $("#Add_DeviceID").val() +
        ";" +
        $("#Add_DeviceBaudrate").val() +
        ";" +
        $("#Add_DeviceParity").val() +
        ";" +
        $("#Add_DeviceDatabits").val() +
        ";" +
        $("input[name='Add_DeviceStopbit']:checked").val() +
        ";" +
        $("#Add_ResponseOverTime").val();
    } else {
      config =
        $("#Add_DeviceID").val() +
        ";" +
        $("#Add_DeviceBaudrate").val() +
        ";" +
        $("#Add_DeviceParity").val() +
        ";" +
        $("#Add_DeviceDatabits").val() +
        ";" +
        $("input[name='Add_DeviceStopbit']:checked").val();
    }
  }
  //MBus-Serial拼出的config
  else if (val == "M-Bus-serial") {
    config =
      "serial;" +
      $("#Add_DeviceID").val() +
      ";" +
      $("#Add_DeviceBaudrate").val() +
      ";" +
      $("#Add_DeviceParity").val() +
      ";" +
      $("#Add_DeviceDatabits").val() +
      ";" +
      $("input[name='Add_DeviceStopbit']:checked").val();
    /*author: tao.zhou form里加一个字段用来判断是否是任务驱动*/
    $("#Add_IsTask_YuToXHZhang").val("YES");
  }
  //MBus-TCP拼出的config
  else if (val == "M-Bus-TCP") {
    config = "tcp;" + $("#Add_IPAddress").val() + ";" + $("#Add_Port").val();
    /*author: tao.zhou form里加一个字段用来判断是否是任务驱动*/
    $("#Add_IsTask_YuToXHZhang").val("YES");
  } else if (val == "YinHe") {
    config = $("#Add_IPAddress").val() + ";" + $("#Add_Port").val();
  } else if (val == "Zundar") {
    config =
      $("#Add_IPAddress").val() +
      ";" +
      $("#Add_Port").val() +
      ";" +
      $("#Add_delayed").val();
  }
  //RF下HKG-SERIAL驱动拼出config
  else if (AnyLinkType == "RF" && val == "HKG-SERIAL") {
    config =
      "serial;" +
      $("#Add_DeviceID").val() +
      ";" +
      $("#Add_DeviceBaudrate").val() +
      ";" +
      $("#Add_DeviceParity").val() +
      ";" +
      $("#Add_DeviceDatabits").val() +
      ";" +
      $("input[name='Add_DeviceStopbit']:checked").val();
    $("#Add_IsTask_YuToXHZhang").val("YES");
  }
  //自定义TCP协议
  else if (val == "Custom-TCP") {
    config =
      $("#Add_IPAddress").val() +
      ";" +
      $("#Add_Port").val() +
      ";" +
      $("#Add_delayed").val();
  }
  //GPS 拼出的config，gps 默认的是/dev/tty02
  else if (val == "GPS") {
    config = "/dev/ttyHSL2;9600;N;8;1";
    $("#Add_IsTask_YuToXHZhang").val("YES");
  }
  // add by fyj, 新增OCR驱动
  // add by fyj
  else if (val == "DRACAL") {
    config = "usbtenki";
    $("#Add_IsTask_YuToXHZhang").val("YES");
  }
  // add end
  // add begin
  else if (val == "OCR") {
    config =
      $("#Add_IPAddress").val() +
      ";" +
      $("#Add_Port").val() +
      ";" +
      $("#Add_ResponseOverTime").val();
  }
  // add end
  // add by fyj, 新增KUKA驱动
  // add begin
  else if (val == "KUKA") {
    config =
      $("#Add_ReadInterval").val() +
      ";" +
      $("#Add_ReadWait").val() +
      ";" +
      $("#Add_WriteInterval").val();
    $("#Add_IsTask_YuToXHZhang").val("YES");
  }
  // add end
  // add by fyj, 新增cloudweb驱动
  else if (val == "CloudWeb") {
    config =
      $("#Add_CloudAddress").val() +
      ";" +
      $("#Add_Username").val() +
      ";" +
      $("#Add_Password").val();
    $("#Add_IsTask_YuToXHZhang").val("YES");
  }
  // add end
  // add by fyj, 新增DLT645-2007驱动
  else if (val == "DLT645-2007" || val == "DLT645-1997") {
    config =
      $("#Add_DeviceID").val() +
      ";" +
      $("#Add_DeviceBaudrate").val() +
      ";" +
      $("#Add_DeviceParity").val() +
      ";" +
      $("#Add_DeviceDatabits").val() +
      ";" +
      $("input[name='Add_DeviceStopbit']:checked").val() +
      ";" +
      $("#Add_ResponseOverTime").val();
    $("#Add_IsTask_YuToXHZhang").val("YES");
  }
  // add end
  // add by fyj,  新增OMRON-HostLink-Task驱动
  else if (val == "OMRON-HostLink-Task" || val == "OMRON-FINS-Task") {
    config =
      $("#Add_DeviceID").val() +
      ";" +
      $("#Add_DeviceBaudrate").val() +
      ";" +
      $("#Add_DeviceParity").val() +
      ";" +
      $("#Add_DeviceDatabits").val() +
      ";" +
      $("input[name='Add_DeviceStopbit']:checked").val() +
      ";" +
      $("#Add_HostLink_ResponseOvertime").val();
    $("#Add_IsTask_YuToXHZhang").val("YES");
  }
  // add end
  // add by whc, 新增FATEK编程口驱动
  else if (val == "FATEK编程口") {
    config =
      $("#Add_DeviceID").val() +
      ";" +
      $("#Add_DeviceBaudrate").val() +
      ";" +
      $("#Add_DeviceParity").val() +
      ";" +
      $("#Add_DeviceDatabits").val() +
      ";" +
      $("input[name='Add_DeviceStopbit']:checked").val();
    //$("#Add_IsTask_YuToXHZhang").val("YES");
  }
  // add end
  // add by lh,  新增IEC104驱动
  else if (val == "IEC104") {
    config =
      $("#Add_IECIP").val() +
      ";" +
      $("#Add_IECport").val() +
      ";" +
      $("#Add_IECaddr").val();
  }
  // add end
  // add by whc,新增OPC驱动
  else if (val == "OPC") {
    config =
      $("#Add_GatewayAddress").val() +
      ";" +
      $("#Add_GatewayPort").val() +
      ";" +
      $("#Add_ServerAddress").val() +
      ";" +
      $("#Add_ServerName").val() +
      ";" +
      $("#Add_ReadMode").val();
  }
  // add end
  // add by lh,新增OPC-UA驱动
  else if (val == "OPC-UA") {
    config =
      $("#Add_IPAddress").val() +
      ";" +
      $("#Add_Port").val() +
      ";" +
      $("#Add_Encoding").val() +
      ";" +
      $("#Add_Security").val() +
      ";" +
      $("#Add_Sync").val();
  }
  // add end
  else if (val == "device") {
    config = $("#Add_commonConf").val();
  } else if (val == "MITSUBISHI-TXZ-MomMach" || val == "MITSUBISHI-TXZ-SubMach1" || val == "MITSUBISHI-TXZ-SubMach2" ) {
    config =
      $("#Add_DeviceID").val() +
      ";" +
      $("#Add_DeviceBaudrate").val() +
      ";" +
      $("#Add_DeviceParity").val() +
      ";" +
      $("#Add_DeviceDatabits").val() +
      ";" +
      $("input[name='Add_DeviceStopbit']:checked").val() +
      ";" +
      $("#Add_ResponseOverTime").val();
  } else if (
    val == "MITSUBISHI-TX-5HP" ||
    val == "MITSUBISHI-TX-15P" ||
    val == "MITSUBISHI-TX-Multi-link"
  ) {
    config =
      $("#Add_DeviceID").val() +
      ";" +
      $("#Add_DeviceBaudrate").val() +
      ";" +
      $("#Add_DeviceParity").val() +
      ";" +
      $("#Add_DeviceDatabits").val() +
      ";" +
      $("input[name='Add_DeviceStopbit']:checked").val() +
      ";" +
      $("#Add_ResponseOverTime").val() +
      ";" +
      $("#Add_OutdoorAddress").val();
  } else if (val == "R1R2") {
    config =
      $("#Add_DeviceID").val() +
      ";" +
      $("#Add_DeviceBaudrate").val() +
      ";" +
      $("#Add_DeviceParity").val() +
      ";" +
      $("#Add_DeviceDatabits").val() +
      ";" +
      $("input[name='Add_DeviceStopbit']:checked").val() +
      ";" +
      $("#Add_delayed").val();
      $("#Add_IsTask_YuToXHZhang").val("YES");
  }
  //其余的协议拼出的config
  else {
    config =
      $("#Add_DeviceID").val() +
      ";" +
      $("#Add_DeviceBaudrate").val() +
      ";" +
      $("#Add_DeviceParity").val() +
      ";" +
      $("#Add_DeviceDatabits").val() +
      ";" +
      $("input[name='Add_DeviceStopbit']:checked").val();
  }

  $("#Add_ChannelConfig_YuToXHZhang").val(config);

  //驱动类型
  if (val == "device") {
    $("#Add_ChannelModelType_YuToXHZhang").val($("#Add_commonName").val());
  } else {
    $("#Add_ChannelModelType_YuToXHZhang").val($("#Hide_Add_Lib").val());
  }

  if (CheckAddChannel()) {
  } else {
    Add_ChannelMethod();
  }
}

//校验
function CheckAddChannel() {
  var reg = new RegExp(
    "^(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9])\\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[0-9])$"
  );
  var address = $("#Add_IPAddress").val();
  var reg2 = new RegExp("^[0-9]*$");
  var port = $("#Add_Port").val();
  var type = $("#Add_DeviceDriver").val();
  if ($("#Add_ChannelName").val() == "") {
    if (coo == "English") {
      alert("Please enter the channel name");
    } else {
      alert("请输入通道名称");
    }
    return true;
  }
  // else if (ChannelNum != 0) {
  //     alert("只允许存在一个通道");
  //     return true;
  // }
  else {
    //TCP的协议需要校验IP地址和端口号
    if (
      type == "OMRON-TCP" ||
      type == "M-Bus-TCP" ||
      type == "YinHe" ||
      type == "Zundar" ||
      type == "Custom-TCP"
    ) {
      if (address == "") {
        if (coo == "English") {
          alert("Please enter IP address");
        } else {
          alert("请输入IP地址");
        }
        return true;
      } else if (!reg.test(address)) {
        if (coo == "English") {
          alert("IP address input error");
        } else {
          alert("IP地址输入错误");
        }
        return true;
      } else if (port == "") {
        if (coo == "English") {
          alert("Please enter the port number");
        } else {
          alert("请输入端口号");
        }
        return true;
      } else if (!reg2.test(port)) {
        if (coo == "English") {
          alert("Incorrect port number input");
        } else {
          alert("端口号输入错误");
        }
        return true;
      }
      if (type == "Custom-TCP") {
        if ($("#Add_delayed").val() == "") {
          if (coo == "English") {
            alert("Please enter timeout");
          } else {
            alert("请输入超时时间");
          }
          return true;
        } else if (
          !reg2.test($("#Add_delayed").val()) ||
          $("#Add_delayed").val() < 100 ||
          $("#Add_delayed").val() > 20000
        ) {
          if (coo == "English") {
            alert(
              "The timeout must be a positive integer between 100ms-20000ms"
            );
          } else {
            alert("超时时间输入错误，延时必须为100ms-20000ms之间的正整数");
          }
          return true;
        }
      }
      return false;
    } else if (type == "MITSUBISHI-QN" || type == "MITSUBISHI-Q") {
      var port1 = $("#Add_QPLCPort").val();
      var port2 = $("#Add_QLocalPort").val();
      if (address == "") {
        if (coo == "English") {
          alert("Please enter IP address");
        } else {
          alert("请输入IP地址");
        }
        return true;
      } else if (!reg.test(address)) {
        if (coo == "English") {
          alert("IP address input error");
        } else {
          alert("IP地址输入错误");
        }
        return true;
      } else if (port1 == "" || port2 == "") {
        if (coo == "English") {
          alert("Please enter the port number");
        } else {
          alert("请输入端口号");
        }
        return true;
      } else if (!reg2.test(port1) || !reg2.test(port2)) {
        if (coo == "English") {
          alert("Incorrect port number input");
        } else {
          alert("端口号输入错误");
        }
        return true;
      }
    } else if (
      type == "Modbus-TCP" ||
      type == "Schneider-TCP" ||
      type == "Detal-TCP" ||
      type == "Modbus-TCP-task"
    ) {
      if (address == "") {
        if (coo == "English") {
          alert("Please enter IP address");
        } else {
          alert("请输入IP地址");
        }
        return true;
      } else if (!reg.test(address)) {
        if (coo == "English") {
          alert("IP address input error");
        } else {
          alert("IP地址输入错误");
        }
        return true;
      } else if (port == "") {
        if (coo == "English") {
          alert("Please enter the port number");
        } else {
          alert("请输入端口号");
        }
        return true;
      } else if (!reg2.test(port)) {
        if (coo == "English") {
          alert("Incorrect port number input");
        } else {
          alert("端口号输入错误");
        }
        return true;
      } else if ($("#Add_delayed").val() == "") {
        if (coo == "English") {
          alert("Please input response latency");
        } else {
          alert("请输入响应延时");
        }
        return true;
      }
      //else if(!reg2.test($("#Add_delayed").val()) || $("#Add_delayed").val() < 5000){
      //alert("延时输入错误，延时必须为大于5000ms的整数")
      //return true;
      //}
      else if ($("#Add_Buffer").val() == "") {
        if (coo == "English") {
          alert("Please input buffer");
        } else {
          alert("请输入缓冲区");
        }
        return true;
      }
      //else if(!reg2.test($("#Add_Buffer").val()) || $("#Add_Buffer").val() > 120){
      //alert("缓冲区输入错误，缓冲区必须为小于120的正整数")
      //return true;
      //}
      else if ($("#Add_SendDelay").val() == "") {
        if (coo == "English") {
          alert("Please enter send delay");
        } else {
          alert("请输入发送延时");
        }
        return true;
      } else {
        return false;
      }
    }
    //西门子1200需要校验IP地址、插槽号和机架号
    else if (type == "SIEMENS-Ethernet") {
      if (address == "") {
        if (coo == "English") {
          alert("Please enter IP address");
        } else {
          alert("请输入IP地址");
        }
        return true;
      } else if (!reg.test(address)) {
        if (coo == "English") {
          alert("IP address input error");
        } else {
          alert("IP地址输入错误");
        }
        return true;
      } else if ($("#Add_JJ_1200").val() == "") {
        if ($("input[name='Add_S7_200']:checked").val() == "yes") {
          if (coo == "English") {
            alert("Please enter local TSAP");
          } else {
            alert("请输入本地TSAP");
          }
        } else {
          if (coo == "English") {
            alert("Please enter the rack number");
          } else {
            alert("请输入机架号");
          }
        }
        return true;
      } else if (!reg2.test($("#Add_JJ_1200").val())) {
        if ($("input[name='Add_S7_200']:checked").val() == "yes") {
          if (coo == "English") {
            alert("Local TSAP input error");
          } else {
            alert("本地TSAP输入错误");
          }
        } else {
          if (coo == "English") {
            alert("Input error of rack number");
          } else {
            alert("机架号输入错误");
          }
        }
        return true;
      } else if ($("#Add_CC_1200").val() == "") {
        if ($("input[name='Add_S7_200']:checked").val() == "yes") {
          if (coo == "English") {
            alert("Please enter remote TSAP");
          } else {
            alert("请输入远程TSAP");
          }
        } else {
          if (coo == "English") {
            alert("Please enter the slot number");
          } else {
            alert("请输入插槽号");
          }
        }
        return true;
      } else if (!reg2.test($("#Add_CC_1200").val())) {
        if ($("input[name='Add_S7_200']:checked").val() == "yes") {
          if (coo == "English") {
            alert("Remote TSAP input error");
          } else {
            alert("远程TSAP输入错误");
          }
        } else {
          if (coo == "English") {
            alert("Slot number input error");
          } else {
            alert("插槽号输入错误");
          }
        }
        return true;
      } else {
        return false;
      }
    }
    //BacNet-IP需要校验端口号和延时
    else if (type == "BacNet-IP" || type == "BacNet-IP-task") {
      if (port == "") {
        if (coo == "English") {
          alert("Please enter the port number");
        } else {
          alert("请输入端口号");
        }
        return true;
      } else if (!reg2.test(port)) {
        if (coo == "English") {
          alert("Incorrect port number input");
        } else {
          alert("端口号输入错误");
        }
        return true;
      } else if ($("#Add_delayed").val() == "") {
        if (coo == "English") {
          alert("Please input delay");
        } else {
          alert("请输入延时");
        }
        return true;
      } else if (
        !reg2.test($("#Add_delayed").val()) ||
        $("#Add_delayed").val() < 500 ||
        $("#Add_delayed").val() > 10000 ||
        $("#Add_delayed").val() % 500 != 0
      ) {
        if (coo == "English") {
          alert(
            "The delay input error must be a positive integer between 500ms-10000ms, and must be a multiple of 500"
          );
        } else {
          alert(
            "延时输入错误，延时必须为500ms-10000ms之间的正整数，且必须为500的倍数"
          );
        }
        return true;
      } else {
        return false;
      }
    } else if (type == "Zundar") {
      if ($("#Add_delayed").val() == "") {
        if (coo == "English") {
          alert("Please input delay");
        } else {
          alert("请输入延时");
        }
        return true;
      } else if (
        !reg2.test($("#Add_delayed").val()) ||
        $("#Add_delayed").val() < 500 ||
        $("#Add_delayed").val() > 10000 ||
        $("#Add_delayed").val() % 500 != 0
      ) {
        if (coo == "English") {
          alert(
            "The delay input error must be a positive integer between 500ms-10000ms, and must be a multiple of 500"
          );
        } else {
          alert(
            "延时输入错误，延时必须为500ms-10000ms之间的正整数，且必须为500的倍数"
          );
        }
        return true;
      }
    }
    //BacNet-MS/TP需要校验MAC地址
    else if (type == "BacNet-MS/TP" || type == "BacNet-MS/TP-task") {
      if ($("#Add_Mac").val() == "") {
        if (coo == "English") {
          alert("Please enter MAC address");
        } else {
          alert("请输入MAC地址");
        }
        return true;
      } else if (!reg2.test($("#Add_Mac").val())) {
        if (coo == "English") {
          alert("MAC address input error");
        } else {
          alert("MAC地址输入错误");
        }
        return true;
      } else {
        return false;
      }
    }
    //ModBus-RTU和ASCII的缓冲区和延时需要校验
    else if (
      type == "Modbus-RTU" ||
      type == "Modbus-ASCII" ||
      type == "Detal-ASCII" ||
      type == "Detal-RTU" ||
      type == "XinjieXD3-RTU" ||
      type == "XinjieXD3-ASCII" ||
      type == "XinjieXC3-RTU" ||
      type == "XinjieXC3-ASCII" ||
      type == "Schneider-RTU" ||
      type == "Schneider-ASCII" ||
      type == "Modbus-RTU-task" ||
      type == "Modbus-ASCII-task"
    ) {
      if ($("#Add_delayed").val() == "") {
        if (coo == "English") {
          alert("Please input response latency");
        } else {
          alert("请输入响应延时");
        }
        return true;
      }
      //else if(!reg2.test($("#Add_delayed").val()) || $("#Add_delayed").val() < 5000){
      //alert("延时输入错误，延时必须为大于5000ms的整数")
      //return true;
      //}
      else if ($("#Add_Buffer").val() == "") {
        if (coo == "English") {
          alert("Please input buffer");
        } else {
          alert("请输入缓冲区");
        }
        return true;
      }
      //else if(!reg2.test($("#Add_Buffer").val()) || $("#Add_Buffer").val() > 120){
      //alert("缓冲区输入错误，缓冲区必须为小于120的正整数")
      //return true;
      //}
      else if ($("#Add_SendDelay").val() == "") {
        if (coo == "English") {
          alert("Please enter send delay");
        } else {
          alert("请输入发送延时");
        }
        return true;
      } else {
        return false;
      }
    } else if (type == "AB-DF1") {
      if ($("#Add_LocStack").val() == "") {
        if (coo == "English") {
          alert("Please enter the local stack number");
        } else {
          alert("请输入本地栈号");
        }
        return true;
      } else if (!reg2.test($("#Add_LocStack").val())) {
        if (coo == "English") {
          alert(
            "local stack number input error, local stack number can only be positive integer"
          );
        } else {
          alert("本地栈号输入错误，本地栈号只能为正整数");
        }
        return true;
      } else if ($("#Add_PLCStack").val() == "") {
        if (coo == "English") {
          alert("Please enter the PLC stack number");
        } else {
          alert("请输入PLC栈号");
        }
        return true;
      } else if (!reg2.test($("#Add_PLCStack").val())) {
        if (coo == "English") {
          alert(
            "PLC stack number input error, the PLC stack number can only be positive integer"
          );
        } else {
          alert("PLC栈号输入错误，PLC栈号只能为正整数");
        }
        return true;
      } else {
        return false;
      }
    } else if (type == "AB-Ethernet/IP" || type == "AB-MicroLogix") {
      if ($("#Add_delayed").val() == "") {
        if (coo == "English") {
          alert("Please input response latency");
        } else {
          alert("请输入响应延时");
        }
        return true;
      }
    }
    //RF下FX编程口和FX串口要校验响应超时时间
    else if (
      type == "MITSUBISHI-FXP" ||
      type == "MITSUBISHI-FXS" ||
      type == "OMRON_NJNX"
    ) {
      if (AnyLinkType == "RF" || type == "OMRON_NJNX") {
        if ($("#Add_ResponseOverTime").val() == "") {
          if (coo == "English") {
            alert("Please enter a response timeout");
          } else {
            alert("请输入响应超时时间");
          }
          return true;
        } else if (!reg2.test($("#Add_ResponseOverTime").val())) {
          if (coo == "English") {
            alert("The response timeout can only be positive integers");
          } else {
            alert("响应超时时间只能为正整数");
          }
          return true;
        } else {
          return false;
        }
      }
    }
    // add by fyj , 校验OCR驱动
    // add begin
    else if (type == "OCR") {
      if (address == "") {
        if (coo == "English") {
          alert("Please enter IP address");
        } else {
          alert("请输入IP地址");
        }
        return true;
      } else if (!reg.test(address)) {
        if (coo == "English") {
          alert("IP address input error");
        } else {
          alert("IP地址输入错误");
        }
        return true;
      } else if (port == "") {
        if (coo == "English") {
          alert("Please enter the port number");
        } else {
          alert("请输入端口号");
        }
        return true;
      } else if (!reg2.test(port)) {
        if (coo == "English") {
          alert("Incorrect port number input");
        } else {
          alert("端口号输入错误");
        }
        return true;
      } else if ($("#Add_ResponseOverTime").val() == "") {
        if (coo == "English") {
          alert("Please enter a response timeout");
        } else {
          alert("请输入响应超时时间");
        }
        return true;
      } else if (!reg2.test($("#Add_ResponseOverTime").val())) {
        if (coo == "English") {
          alert("The response timeout can only be positive integers");
        } else {
          alert("响应超时时间只能为正整数");
        }
        return true;
      }
    }
    // add end
    // add by fyj, 校验KUKA驱动
    // add begin
    else if (type == "KUKA") {
      var readInterval = $("#Add_ReadInterval").val();
      var readWait = $("#Add_ReadWait").val();
      var writeInterval = $("#Add_WriteInterval").val();
      if (readInterval == "") {
        if (coo == "English") {
          alert("Please enter the read interval");
        } else {
          alert("请输入读取间隔");
        }
        return true;
      } else if (!reg2.test(readInterval)) {
        if (coo == "English") {
          alert("Error reading interval input");
        } else {
          alert("读取间隔输入错误");
        }
        return true;
      } else if (readWait == "") {
        if (coo == "English") {
          alert("Please enter read wait");
        } else {
          alert("请输入读取等待");
        }
        return true;
      } else if (!reg2.test(readWait)) {
        if (coo == "English") {
          alert("Read wait for input error");
        } else {
          alert("读取等待输入错误");
        }
        return true;
      }
      if (writeInterval == "") {
        if (coo == "English") {
          alert("Please enter the write interval");
        } else {
          alert("请输入写间隔");
        }
        return true;
      } else if (!reg2.test(writeInterval)) {
        if (coo == "English") {
          alert("Write interval input error");
        } else {
          alert("写间隔输入错误");
        }
        return true;
      }
    }
    // add end
    // add by fyj, cloudweb驱动
    else if (type == "CloudWeb") {
      var cloudAddr = $("#Add_CloudAddress").val();
      var username = $("#Add_Username").val();
      var password = $("#Add_Password").val();
      if (cloudAddr == "") {
        if (coo == "English") {
          alert("Please enter the cloud platform address");
        } else {
          alert("请输入云平台地址");
        }
        return true;
      } else if (cloudAddr.indexOf("http://") != 0) {
        if (coo == "English") {
          alert("The cloud platform address must start with http://.");
        } else {
          alert("云平台地址必须以http://开头");
        }
        return true;
      } else if (username == "") {
        if (coo == "English") {
          alert("Please enter the user name");
        } else {
          alert("请输入用户名");
        }
        return true;
      } else if (password == "") {
        if (coo == "English") {
          alert("Please enter password");
        } else {
          alert("请输入密码");
        }
        return true;
      } else {
        return false;
      }
    }
    // add end
    // add by fyj, DLT645-2007驱动
    else if (
      type == "DLT645-2007" ||
      type == "DLT645-1997" ||
      type == "MITSUBISHI-TXZ-MomMach" ||
      type == "MITSUBISHI-TXZ-SubMach1" ||
      type == "MITSUBISHI-TXZ-SubMach2" 
    ) {
      var overtime = $("#Add_ResponseOverTime").val();
      if (overtime == "") {
        if (coo == "English") {
          alert("Please enter a response timeout");
        } else {
          alert("请输入响应超时");
        }
        return true;
      } else if (!reg2.test(overtime)) {
        if (coo == "English") {
          alert("Response timeout input error");
        } else {
          alert("响应超时输入错误");
        }
        return true;
      } else {
        return false;
      }
    }
    // add end
    else if (
      type == "MITSUBISHI-TX-5HP" ||
      type == "MITSUBISHI-TX-15P" ||
      type == "MITSUBISHI-TX-Multi-link"
    ) {
      var overtime = $("#Add_ResponseOverTime").val();
      var outdoorAddress = $("#Add_OutdoorAddress").val();
      if (overtime == "") {
        if (coo == "English") {
          alert("Please enter a response timeout");
        } else {
          alert("请输入响应超时");
        }
        return true;
      } else if (!reg2.test(overtime)) {
        if (coo == "English") {
          alert("Response timeout input error");
        } else {
          alert("响应超时输入错误");
        }
        return true;
      } else if (outdoorAddress == "") {
        if (coo == "English") {
          alert("Please enter outdoor address");
        } else {
          alert("请输入室外机地址");
        }
        return true;
      } else if (!reg2.test(outdoorAddress)) {
        if (coo == "English") {
          alert("Outdoor address timeout input error");
        } else {
          alert("室外机地址输入错误");
        }
        return true;
      } else {
        return false;
      }
    }
    // add by fyj, OMRON-HostLink-Task
    else if (type == "OMRON-HostLink-Task" || type == "OMRON-FINS-Task") {
      var overtime = $("#Add_HostLink_ResponseOvertime").val();
      if (overtime == "") {
        if (coo == "English") {
          alert("Please enter a response timeout");
        } else {
          alert("请输入响应超时");
        }
        return true;
      } else if (!reg2.test(overtime)) {
        if (coo == "English") {
          alert("Response timeout input error");
        } else {
          alert("响应超时输入错误");
        }
        return true;
      } else {
        return false;
      }
    }
    // add end
    // add by whc,SIEMENS-S7-PPI-Task
    else if (type == "SIEMENS-S7-PPI-Task") {
      var overtime = $("#Add_ResponseOverTime").val();
      if (overtime == "") {
        if (coo == "English") {
          alert("Please enter a response timeout");
        } else {
          alert("请输入响应超时");
        }
        return true;
      } else if (!reg2.test(overtime)) {
        if (coo == "English") {
          alert("Response timeout input error");
        } else {
          alert("响应超时输入错误");
        }
        return true;
      } else {
        return false;
      }
    }
    // add end
    // add by lh,IEC104
    else if (type == "IEC104") {
      var iecip = $("#Add_IECIP").val();
      var iecport = $("#Add_IECport").val();
      var iecaddr = $("#Add_IECaddr").val();

      if (iecip == "") {
        if (coo == "English") {
          alert("Please enter device IP address");
        } else {
          alert("请输入设备 IP");
        }
        return true;
      } else if (!reg.test(iecip)) {
        if (coo == "English") {
          alert("Device IP address input error");
        } else {
          alert("设备IP输入错误");
        }
        return true;
      } else if (iecport == "") {
        if (coo == "English") {
          alert("Please enter the device port");
        } else {
          alert("请输入设备端口");
        }
        return true;
      } else if (!reg2.test(iecport)) {
        if (coo == "English") {
          alert("Incorrect device port number input");
        } else {
          alert("设备端口输入错误");
        }
        return true;
      } else if (iecaddr == "") {
        if (coo == "English") {
          alert("Please enter the common address");
        } else {
          alert("请输入公共地址");
        }
        return true;
      } else {
        return false;
      }
    }
    // add end
    // add by whc,OPC驱动
    else if (type == "OPC") {
      var gatewayAddress = $("#Add_GatewayAddress").val();
      var gatewayPort = $("#Add_GatewayPort").val();
      var serverAddress = $("#Add_ServerAddress").val();
      var serverName = $("#Add_ServerName").val();
      var readMode = $("#Add_ReadMode").val();
      var posIntReg = /^(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9])\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[0-9])$/;
      if (gatewayAddress == "") {
        if (coo == "English") {
          alert("Please enter the plugin IP");
        } else {
          alert("请输入插件IP");
        }
        return true;
      } else if (gatewayPort == "") {
        if (coo == "English") {
          alert("Please enter the gateway port");
        } else {
          alert("请输入网关端口");
        }
        return true;
      } else if (!reg2.test(gatewayPort)) {
        if (coo == "English") {
          alert("Incorrect gateway port number input");
        } else {
          alert("网关端口错误");
        }
        return true;
      } else if (serverAddress == "") {
        if (coo == "English") {
          alert("Please enter the server address");
        } else {
          alert("请输入服务器地址");
        }
        return true;
      } else if (serverName == "") {
        if (coo == "English") {
          alert("Please enter the server name");
        } else {
          alert("请输入服务器名称");
        }
        return true;
      } else if (readMode == "") {
        if (coo == "English") {
          alert("Please enter the data access mode");
        } else {
          alert("请输入数据读取方式");
        }
        return true;
      } else if (!posIntReg.test(gatewayAddress)) {
        if (coo == "English") {
          alert("Plugin IP address input error");
        } else {
          alert("请输入正确格式的插件IP");
        }
        return true;
      } else {
        return false;
      }
    }
    // add end
    // add by lh,OPC-UA驱动
    else if (type == "OPC-UA") {
      var UAIP = $("#Add_IPAddress").val();
      var UAPort = $("#Add_Port").val();
      if (UAIP == "") {
        if (coo == "English") {
          alert("Please enter the server address");
        } else {
          alert("请输入服务器地址");
        }
        return true;
      } else if (UAPort == "") {
        if (coo == "English") {
          alert("Please enter the server port");
        } else {
          alert("请输入服务器端口");
        }
        return true;
      } else if (!reg.test(UAIP)) {
        if (coo == "English") {
          alert("Server IP address input error");
        } else {
          alert("请输入正确格式的IP");
        }
        return true;
      } else if (!reg2.test(UAPort)) {
        if (coo == "English") {
          alert("Server port input error");
        } else {
          alert("请输入正确格式的端口");
        }
        return true;
      } else {
        return false;
      }
    }
    // add end
    else {
      return false;
    }
  }
}
//执行py方法，添加通道名称和驱动类型

function Add_ChannelMethod() {
  $("#Add_Channel_Button_Confirm").attr("disabled", "disabled");
  $("#Add_Channel_Button_Cancel").attr("disabled", "disabled");
  var params = $("#Add_Channel_YuToXHZhang").serialize();
  $.ajax({
    type: "post",
    url: "cgi-bin/device/AddChannel.py",
    data: params,
    async: true,
    success: function (data) {
      $("#Add_ChannelLayer").hide();
      $("#popWindow").hide();
      $("#Add_Channel_Button_Confirm").attr("disabled", "");
      $("#Add_Channel_Button_Cancel").attr("disabled", "");
      loginUI();
    },
  });
}

//打开通道信息层

function Alter_Open_ChannelLayer(txt) {
  ReadChannelInfo(txt);
  $("#popWindow").show();
  $("#Alter_ChannelLayer").show();
}
//读取信息方法

function ReadChannelInfo(txt) {
  driverID = "";
  taskID = "";
  driverName = "";
  $.get("../conf/config.xml", function (d1) {
    $(d1)
      .find("model[id='" + txt + "']")
      .each(function () {
        var $model = $(this);
        var id = $model.attr("id");
        var n = $model.attr("n");
        var d = $model.attr("d");
        var config = $model.attr("config");
        var remoteadd = $model.attr("readd");
        var driver = $model.attr("devicedriver");
        var configArr = new Array();
        configArr = config.split(";");
        if (configArr[0].indexOf("/dev/tty") > -1) {
          initAlterChannelCOM(configArr[0]);
        } else {
          initAlterChannelCOM(configArr[1]);
        }
        //西门子MPI有串口、波特率、网络传输率
        if (driver == "SIEMENS-MPI") {
          $("#Alter_SelParame tr").hide();
          $("#Alter_Line_DeviceID").show();
          $("#Alter_Line_Baudrate").show();
          $("#Alter_Line_MPI").show();
          /*author:jinxin.zhou 内容：加上modbus特有的发送延迟*/
          $("#Alter_Line_SendDelay").hide();
          /*end*/
          $(".Add_ChannelLayer").css("height", "400px");
        } else if (driver == "OMRON_NJNX") {
          $("#Alter_SelParame tr").hide();
          $("#Alter_Line_ResponseOverTime").show();
          //$("#Alter_Line_SendDelay").hide();
          $(".Add_ChannelLayer").css("height", "300px");
        }
        //西门子1200有IP地址，机架号和插槽号
        else if (driver == "SIEMENS-Ethernet") {
          $("#Alter_SelParame tr").hide();
          $("#Alter_Line_IPAddr").show();
          $("#Alter_Line_S7").show();
          $("#Alter_Line_JJ").show();
          $("#Alter_Line_CC").show();
          $("#Alter_Line_Type").show();
          /*author:jinxin.zhou 内容：加上modbus特有的发送延迟*/
          $("#Alter_Line_SendDelay").hide();
          /*end*/
          $(".Add_ChannelLayer").css("height", "400px");
        }
        // add by whc,SIEMENS-S7-PPI-Task有响应延时
        else if (driver == "SIEMENS-S7-PPI-Task") {
          $("#Alter_SelParame tbody tr").hide();
          $("#Alter_Line_PPI_DeviceID").show();
          $("#Alter_Line_PPI_Baudrate").show();
          $("#Alter_Line_Parity").show();
          $("#Alter_Line_Databits").show();
          $("#Alter_Line_PPI_Stopbit").show();
          $("#Alter_Line_ResponseOverTime").show();
          $("#Alter_ResponseOverTime").val(200);
          $("#Alter_ChannelLayer").css("height", "430px");

          $("#Alter_PPI_DeviceID").val(configArr[0]);
          $("#Alter_PPI_DeviceBaudrate").val(configArr[1]);
          $("#Alter_DeviceParity").val(configArr[2]);
          $("#Alter_DeviceDatabits").val(configArr[3]);
          if (configArr[4] == "1") {
            $("#Alter_PPI_DeviceStopbit1").attr("checked", "checked");
          } else if (configArr[4] == "1.5") {
            $("#Alter_PPI_DeviceStopbit1.5").attr("checked", "checked");
          } else if (configArr[4] == "2") {
            $("#Alter_PPI_DeviceStopbit2").attr("checked", "checked");
          }
          $("#Alter_ResponseOverTime").val(configArr[5]);
        }
        // add end
        //TCP类型协议有IP地址、端口号
        else if (driver == "OMRON-TCP" || driver == "M-Bus-TCP") {
          $("#Alter_SelParame tr").hide();
          $("#Alter_Line_IPAddr").show();
          $("#Alter_Line_Port").show();
          /*author:jinxin.zhou 内容：加上modbus特有的发送延迟*/
          $("#Alter_Line_SendDelay").hide();
          /*end*/
          $(".Add_ChannelLayer").css("height", "320px");
        }
        //BacNet-IP只有端口地址和延时
        else if (driver == "BacNet-IP" || driver == "BacNet-IP-task") {
          $("#Alter_SelParame tr").hide();
          $("#Alter_Line_Port").show();
          $("#Alter_Line_delayed").show();
          /*author:jinxin.zhou 内容：加上modbus特有的发送延迟*/
          $("#Alter_Line_SendDelay").hide();
          /*end*/
          $(".Add_ChannelLayer").css("height", "400px");
        }
        //BacNet-MS/TP有串口、波特率和MAC地址
        else if (driver == "BacNet-MS/TP" || driver == "BacNet-MS/TP-task") {
          $("#Alter_SelParame tr").hide();
          $("#Alter_Line_DeviceID").show();
          $("#Alter_Line_Baudrate").show();
          $("#Alter_Line_MACAddr").show();
          /*author:jinxin.zhou 内容：加上modbus特有的发送延迟*/
          $("#Alter_Line_SendDelay").hide();
          /*end*/
          $(".Add_ChannelLayer").css("height", "400px");
        }
        //ModBus有延时和缓冲区
        else if (
          driver == "Modbus-RTU" ||
          driver == "Modbus-ASCII" ||
          driver == "Schneider-RTU" ||
          driver == "Schneider-ASCII" ||
          driver == "Detal-RTU" ||
          driver == "Detal-ASCII" ||
          driver == "XinjieXD3-RTU" ||
          driver == "XinjieXD3-ASCII" ||
          driver == "XinjieXC3-RTU" ||
          driver == "XinjieXC3-ASCII" ||
          driver == "Modbus-RTU-task" ||
          driver == "Modbus-ASCII-task"
        ) {
          $("#Alter_SelParame tr").hide();
          $("#Alter_Line_DeviceID").show();
          $("#Alter_Line_Baudrate").show();
          $("#Alter_Line_Parity").show();
          $("#Alter_Line_Databits").show();
          $("#Alter_Line_Stopbit").show();
          $("#Alter_Line_delayed").show();
          $("#Alter_Line_Buffer").show();
          /*author:jinxin.zhou 内容：加上modbus特有的发送延迟*/
          $("#Alter_Line_SendDelay").show();
          /*end*/
          $(".Add_ChannelLayer").css("height", "514px");
        } else if (
          driver == "Detal-TCP" ||
          driver == "Modbus-TCP" ||
          driver == "Schneider-TCP" ||
          driver == "Modbus-TCP-task"
        ) {
          $("#Alter_SelParame tr").hide();
          $("#Alter_Line_IPAddr").show();
          $("#Alter_Line_Port").show();
          $("#Alter_Line_SendDelay").hide();
          $("#Alter_Line_delayed").show();
          $("#Alter_Line_Buffer").show();
          $("#Alter_Line_SendDelay").show();
          $(".Add_ChannelLayer").css("height", "400px");
        }
        //AB有本地栈号、PLC栈号和校验方式
        else if (driver == "AB-DF1") {
          $("#Alter_SelParame tr").hide();
          $("#Alter_Line_DeviceID").show();
          $("#Alter_Line_Baudrate").show();
          $("#Alter_Line_Parity").show();
          $("#Alter_Line_Databits").show();
          $("#Alter_Line_Stopbit").show();
          $("#Alter_Line_LocStack").show();
          $("#Alter_Line_PLCStack").show();
          $("#Alter_Line_ABCheck").show();
          /*author:jinxin.zhou 内容：加上modbus特有的发送延迟*/
          $("#Alter_Line_SendDelay").hide();
          /*end*/
          $(".Add_ChannelLayer").css("height", "510px");
        }
        //三菱Q系列要plcip，plc端口号，本地端口号
        else if (driver == "MITSUBISHI-QN") {
          $("#Alter_SelParame tr").hide();
          $("#Alter_Line_IPAddr").show();
          $("#Alter_Line_QLocalPort").show();
          $("#Alter_Line_QPLCPort").show();
          $("#Alter_Line_Code").show();
          /*author:jinxin.zhou 内容：加上modbus特有的发送延迟*/
          $("#Alter_Line_SendDelay").hide();
          /*end*/
        } else if (driver == "MITSUBISHI-Q") {
          $("#Alter_SelParame tr").hide();
          $("#Alter_Line_IPAddr").show();
          $("#Alter_Line_QLocalPort").show();
          $("#Alter_Line_QPLCPort").show();
          /*author:jinxin.zhou 内容：加上modbus特有的发送延迟*/
          $("#Alter_Line_SendDelay").hide();
          /*end*/
        }
        //RF下三菱FX编程口和FX串口有响应超时时间
        else if (
          driver == "MITSUBISHI-FXP" ||
          driver == "MITSUBISHI-FXS" ||
          driver == "HMI"
        ) {
          if (AnyLinkType == "RF") {
            $("#Alter_SelParame tr").hide();
            $("#Alter_Line_DeviceID").show();
            $("#Alter_Line_Baudrate").show();
            $("#Alter_Line_Parity").show();
            $("#Alter_Line_Databits").show();
            $("#Alter_Line_Stopbit").show();
            /*author:jinxin.zhou 内容：加上modbus特有的发送延迟*/
            $("#Alter_Line_SendDelay").hide();
            /*end*/
            $("#Alter_Line_ResponseOverTime").show();
            $(".Add_ChannelLayer").css("height", "430px");
          } else {
            $("#Alter_SelParame tr").hide();
            $("#Alter_Line_DeviceID").show();
            $("#Alter_Line_Baudrate").show();
            $("#Alter_Line_Parity").show();
            $("#Alter_Line_Databits").show();
            $("#Alter_Line_Stopbit").show();
            /*author:jinxin.zhou 内容：加上modbus特有的发送延迟*/
            $("#Alter_Line_SendDelay").hide();
            /*end*/
            $("#Alter_Line_ResponseOverTime").hide();
            $(".Add_ChannelLayer").css("height", "400px");
          }
        }
        //AB-Ethernet/IP有延时毫秒
        else if (driver == "AB-Ethernet/IP" || driver == "AB-MicroLogix") {
          $("#Alter_SelParame tr").hide();
          $("#Alter_Line_delayed").show();
          $(".Add_ChannelLayer").css("height", "300px");
        }
        //YinHe显示ip,端口
        else if (driver == "YinHe") {
          $("#Alter_SelParame tr").hide();
          $("#Alter_Line_IPAddr").show();
          $("#Alter_Line_Port").show();
          $(".Add_ChannelLayer").css("height", "300px");
        }
        //增达显示ip,端口,延时
        else if (driver == "Zundar") {
          $("#Alter_SelParame tr").hide();
          $("#Alter_Line_IPAddr").show();
          $("#Alter_Line_Port").show();
          $("#Alter_Line_delayed").show();
          $(".Add_ChannelLayer").css("height", "400px");
        }
        //自定义TCP显示IP端口号和超时时间
        else if (driver == "Custom-TCP") {
          $("#Alter_SelParame tr").hide();
          $("#Alter_Line_IPAddr").show();
          $("#Alter_Line_Port").show();
          if (coo == "English") {
            $("#Alter_Line_delayed_t").html("Timeout (ms):");
          } else {
            $("#Alter_Line_delayed_t").html("超时时间(毫秒)：");
          }
          $("#Alter_Line_delayed").show();
          $(".Add_ChannelLayer").css("height", "350px");
        }
        //add begin by x
        //beckhoff 驱动
        else if (driver == "TwinCAT") {
          $("#Alter_SelParame tr").hide();
          $("#Alter_Line_delayed").show();
        }
        //end add
        //add begin by x
        else if (driver == "GPS") {
          $("#Alter_SelParame tr").hide();
          $("#Alter_Line_DeviceID").hide();
          $("#Alter_Line_Baudrate").hide();
          $("#Alter_Line_Parity").hide();
          $("#Alter_Line_Databits").hide();
          $("#Alter_Line_Stopbit").hide();
          /*author:jinxin.zhou 内容：加上modbus特有的发送延迟*/
          $("#Alter_Line_SendDelay").hide();
          /*end*/
          $("#Alter_Line_ResponseOverTime").hide();
          $(".Add_ChannelLayer").css("height", "240px");
        }
        // end add
        // add by fyj
        else if (driver == "DRACAL") {
          $("#Alter_SelParame tr").hide();
          $("#Alter_Line_DeviceID").hide();
          $("#Alter_Line_Baudrate").hide();
          $("#Alter_Line_Parity").hide();
          $("#Alter_Line_Databits").hide();
          $("#Alter_Line_Stopbit").hide();
          $("#Alter_Line_SendDelay").hide();
          $("#Alter_Line_ResponseOverTime").hide();
          $(".Add_ChannelLayer").css("height", "240px");
        }
        // add end
        // add by fyj, 增加OCR驱动
        // add begin
        else if (driver == "OCR") {
          $("#Alter_SelParame tr").hide();
          $("#Alter_Line_IPAddr").show();
          $("#Alter_Line_Port").show();
          $("#Alter_Line_ResponseOverTime").show();
          $("#Alter_IPAddress").val(configArr[0]);
          $("#Alter_Port").val(configArr[1]);
          $("#Alter_ResponseOverTime").val(configArr[2]);
        }
        // add end
        // add by fyj, 增加KUKA驱动
        // add begin
        else if (driver == "KUKA") {
          $("#Alter_SelParame tr").hide();

          $("#Alter_Line_ReadInterval").show();
          $("#Alter_Line_ReadWait").show();
          $("#Alter_Line_WriteInterval").show();

          $(d1)
            .find("TaskDriver driver[id='" + txt + "']")
            .each(function () {
              var $task = $(this);
              var kukaConfig = $task.attr("config");
              var kukaConfArr = kukaConfig.split(";");
              $("#Alter_ReadInterval").val(kukaConfArr[0]);
              $("#Alter_ReadWait").val(kukaConfArr[1]);
              $("#Alter_WriteInterval").val(kukaConfArr[2]);
            });
        }
        // add end
        // add by fyj, cloudweb驱动
        else if (driver == "CloudWeb") {
          $("#Alter_SelParame tr").hide();

          $("#Alter_Line_CloudAddress").show();
          $("#Alter_Line_Username").show();
          $("#Alter_Line_Password").show();

          $("#Alter_CloudAddress").val(configArr[0]);
          $("#Alter_Username").val(configArr[1]);
          $("#Alter_Password").val(configArr[2]);
          $(".Add_ChannelLayer").css("height", "350px");
        }
        // add end
        // add by fyj, DLT645-2007驱动
        else if (
          driver == "DLT645-2007" ||
          driver == "DLT645-1997" ||
          driver == "MITSUBISHI-TXZ-MomMach" ||
          driver == "MITSUBISHI-TXZ-SubMach1" ||
          driver == "MITSUBISHI-TXZ-SubMach2" 
        ) {
          $("#Alter_SelParame tr").hide();

          $("#Alter_Line_DeviceID").show();
          $("#Alter_Line_Baudrate").show();
          $("#Alter_Line_Parity").show();
          $("#Alter_Line_Databits").show();
          $("#Alter_Line_Stopbit").show();
          $("#Alter_Line_ResponseOverTime").show();

          $(".Add_ChannelLayer").css("height", "445px");
        }
        // add end
        else if (
          driver == "MITSUBISHI-TX-5HP" ||
          driver == "MITSUBISHI-TX-15P" ||
          driver == "MITSUBISHI-TX-Multi-link"
        ) {
          $("#Alter_SelParame tr").hide();

          $("#Alter_Line_DeviceID").show();
          $("#Alter_Line_Baudrate").show();
          $("#Alter_Line_Parity").show();
          $("#Alter_Line_Databits").show();
          $("#Alter_Line_Stopbit").show();
          $("#Alter_Line_ResponseOverTime").show();
          $("#Alter_Line_OutdoorAddress").show();
          $(".Add_ChannelLayer").css("height", "470px");
        }
        // add by fyj, OMRON-HostLink-Task
        else if (
          driver == "OMRON-HostLink-Task" ||
          driver == "OMRON-FINS-Task"
        ) {
          $("#Alter_SelParame tr").hide();

          $("#Alter_Line_DeviceID").show();
          $("#Alter_Line_Baudrate").show();
          $("#Alter_Line_Parity").show();
          $("#Alter_Line_Databits").show();
          $("#Alter_Line_Stopbit").show();
          $("#Alter_Line_HostLink_ResponseOvertime").show();

          $(".Add_ChannelLayer").css("height", "430px");
        }
        // add end
        // add by whc, FATEK编程口驱动
        else if (driver == "FATEK编程口") {
          $("#Alter_SelParame tr").hide();
          $("#Alter_Line_DeviceID").show();
          $("#Alter_Line_Baudrate").show();
          $("#Alter_Line_Parity").show();
          $("#Alter_Line_Databits").show();
          $("#Alter_Line_Stopbit").show();
          $("#Alter_Line_SendDelay").hide();
          $("#Alter_Line_ResponseOverTime").hide();
          $(".Add_ChannelLayer").css("height", "400px");
        }
        // add end
        // add by whc,OPC驱动
        else if (driver == "OPC") {
          $("#Alter_SelParame tr").hide();

          $("#Alter_Line_GatewayAddress").show();
          $("#Alter_Line_GatewayPort").show();
          $("#Alter_Line_ServerAddress").show();
          $("#Alter_Line_ServerName").show();
          $("#Alter_Line_ReadMode").show();

          $("#Alter_GatewayAddress").val(configArr[0]);
          $("#Alter_GatewayPort").val(configArr[1]);
          $("#Alter_ServerAddress").val(configArr[2]);
          $("#Alter_ServerName").val(configArr[3]);
          $("#Alter_ReadMode").val(configArr[4]);
          $(".Add_ChannelLayer").css("height", "400px");
        }
        // add by lh,OPC-UA驱动
        else if (driver == "OPC-UA") {
          $("#Alter_SelParame tr").hide();

          $("#Alter_Line_IPAddr").show();
          $("#Alter_Line_Port").show();
          $("#Alter_Line_Encoding").show();
          $("#Alter_Line_Security").show();
          $("#Alter_Line_Sync").show();

          $("#Alter_IPAddress").val(configArr[0]);
          $("#Alter_Port").val(configArr[1]);
          $(".Add_ChannelLayer").css("height", "400px");
        }
        // add by lh
        else if (driver == "device") {
          $("#Alter_SelParame tbody tr").hide();

          $("#Alter_Line_commonName").show();
          $("#Alter_Line_commonConf").show();

          $(".Add_ChannelLayer").css("height", "300px");

          $("#Alter_commonName").val(d);
          $("#Alter_commonConf").val(config);
        }
        // end add
        // add by lh,IEC104
        else if (driver == "IEC104") {
          $("#Alter_SelParame tbody tr").hide();
          $("#Alter_Line_IECIP").show();
          $("#Alter_Line_IECPort").show();
          $("#Alter_Line_IECAddr").show();

          $("#Alter_Line_IECIP").val(configArr[0]);
          $("#Alter_Line_IECPort").val(configArr[1]);
          $("#Alter_Line_IECAddr").val(configArr[2]);
          $(".Add_ChannelLayer").css("height", "350px");
        }
        // add end
        else if (driver == "R1R2") {
          $("#Alter_SelParame tr").hide();
          $("#Alter_Line_DeviceID").show();
          $("#Alter_Line_Baudrate").show();
          $("#Alter_Line_Parity").show();
          $("#Alter_Line_Databits").show();
          $("#Alter_Line_Stopbit").show();
          $("#Alter_Line_delayed").show();
          /*author:jinxin.zhou 内容：加上modbus特有的发送延迟*/
          $("#Alter_Line_SendDelay").hide();
          /*end*/
          $("#Alter_Line_ResponseOverTime").hide();
          $(".Add_ChannelLayer").css("height", "430px");
        }
        //其他的与默认的一致
        else {
          $("#Alter_SelParame tr").hide();
          $("#Alter_Line_DeviceID").show();
          $("#Alter_Line_Baudrate").show();
          $("#Alter_Line_Parity").show();
          $("#Alter_Line_Databits").show();
          $("#Alter_Line_Stopbit").show();
          /*author:jinxin.zhou 内容：加上modbus特有的发送延迟*/
          $("#Alter_Line_SendDelay").hide();
          /*end*/
          $("#Alter_Line_ResponseOverTime").hide();
          $(".Add_ChannelLayer").css("height", "400px");
        }

        $("#Alter_ChannelName").val(n);
        $("#Hide_Checked_ChannelID").val(id);
        $("#Hide_Alter_Lib").val(d);
        ReadCheckedDeviceDriver(driver);
        //Modbus-TCP协议解析展示的值
        if (driver == "M-Bus-TCP") {
          $("#Alter_IPAddress").val(configArr[1]);
          $("#Alter_Port").val(configArr[2]);
        }
        //OMRON-TCP协议解析展示的值
        else if (driver == "OMRON-TCP") {
          $("#Alter_IPAddress").val(configArr[0]);
          $("#Alter_Port").val(configArr[1]);
        }
        //Schneider-TCP协议和Detal-TCP解析展示的值
        else if (driver == "Schneider-TCP") {
          $("#Alter_IPAddress").val(configArr[1]);
          $("#Alter_Port").val(configArr[2]);
          $("#Alter_delayed").val(configArr[4]);
          $("#Alter_Buffer").val(configArr[5]);
          $("#Alter_SendDelay").val(configArr[6]);
        } else if (driver == "OMRON_NJNX") {
          $("#Alter_ResponseOverTime").val(configArr[0]);
        }
        // ModBus-RTU和ASCII解析
        else if (
          driver == "Modbus-RTU" ||
          driver == "Modbus-ASCII" ||
          driver == "Schneider-RTU" ||
          driver == "Detal-RTU" ||
          driver == "Schneider-ASCII" ||
          driver == "Detal-ASCII" ||
          driver == "XinjieXC3-RTU" ||
          driver == "XinjieXC3-ASCII" ||
          driver == "XinjieXD3-RTU" ||
          driver == "XinjieXD3-ASCII" ||
          driver == "Modbus-RTU-task" ||
          driver == "Modbus-ASCII-task"
        ) {
          $("#Alter_DeviceID").val(configArr[1]);
          $("#Alter_DeviceBaudrate").val(configArr[2]);
          $("#Alter_DeviceParity").val(configArr[3]);
          $("#Alter_DeviceDatabits").val(configArr[4]);
          if (configArr[5] == 1) {
            $("#Alter_DeviceStopbit1").attr("checked", "checked");
          }
          if (configArr[5] == 2) {
            $("#Alter_DeviceStopbit2").attr("checked", "checked");
          }
          $("#Alter_delayed").val(configArr[7]);
          $("#Alter_Buffer").val(configArr[8]);
          /*author:jinxin.zhou 内容：加上modbus特有的发送延迟*/
          $("#Alter_SendDelay").val(configArr[9]);
          /*end*/
        } else if (driver == "Detal-TCP" || driver == "Schneider-TCP") {
          $("#Alter_IPAddress").val(configArr[1]);
          $("#Alter_Port").val(configArr[2]);
          $("#Alter_delayed").val(configArr[4]);
          $("#Alter_Buffer").val(configArr[5]);
          $("#Alter_SendDelay").val(configArr[6]);
        } else if (driver == "Modbus-TCP" || driver == "Modbus-TCP-task") {
          $("#Alter_IPAddress").val(configArr[1]);
          $("#Alter_Port").val(configArr[2]);
          $("#Alter_delayed").val(configArr[3]);
          $("#Alter_Buffer").val(configArr[4]);
          $("#Alter_SendDelay").val(configArr[5]);
        }
        //MPI协议解析展示的值
        else if (driver == "SIEMENS-MPI") {
          $("#Alter_DeviceID").val(configArr[0]);
          $("#Alter_DeviceBaudrate").val(configArr[1]);
          $("#Alter_DeviceMPI").val(configArr[2]);
        } else if (driver == "SIEMENS-Ethernet") {
          var statue = configArr[0];
          if (statue == "S7-200") {
            $("#Alter_S7_200_Yes").attr("checked", "checked");
            $("#Alter_IPAddress").val(configArr[1]);
            if (coo == "English") {
              $("#Alter_Line_JJ_input").html("Local TSAP:");
              $("#Alter_Line_CC_input").html("Remote TSAP:");
            } else {
              $("#Alter_Line_JJ_input").html("本地TSAP：");
              $("#Alter_Line_CC_input").html("远程TSAP：");
            }
            $("#Alter_JJ_1200").val(configArr[2]);
            $("#Alter_CC_1200").val(configArr[3]);
            var type = configArr[4];
            if (type == "OP") {
              $("#Alter_Type_200_OP").attr("checked", "checked");
            } else {
              $("#Alter_Type_200_PG").attr("checked", "checked");
            }
          } else {
            $("#Alter_S7_200_No").attr("checked", "checked");
            if (coo == "English") {
              $("#Alter_Line_JJ_input").html("Rack number:");
              $("#Alter_Line_CC_input").html("Slot number:");
            } else {
              $("#Alter_Line_JJ_input").html("机架号：");
              $("#Alter_Line_CC_input").html("插槽号：");
            }
            $("#Alter_IPAddress").val(configArr[0]);
            $("#Alter_JJ_1200").val(configArr[1]);
            $("#Alter_CC_1200").val(configArr[2]);
            var type = configArr[3];
            if (type == "OP") {
              $("#Alter_Type_200_OP").attr("checked", "checked");
            } else {
              $("#Alter_Type_200_PG").attr("checked", "checked");
            }
          }
        }
        //BacNet-IP展示端口号
        else if (driver == "BacNet-IP" || driver == "BacNet-IP-task") {
          $("#Alter_Port").val(configArr[0]);
          $("#Alter_delayed").val(configArr[1]);
        }
        //BacNet-MS/TP展示串口号、波特率、MAC
        else if (driver == "BacNet-MS/TP" || driver == "BacNet-MS/TP-task") {
          $("#Alter_DeviceID").val(configArr[0]);
          $("#Alter_DeviceBaudrate").val(configArr[1]);
          $("#Alter_Mac").val(configArr[2]);
        }
        //AB协议有额外的三个参数
        else if (driver == "AB-DF1") {
          $("#Alter_DeviceID").val(configArr[0]);
          $("#Alter_DeviceBaudrate").val(configArr[1]);
          $("#Alter_DeviceParity").val(configArr[2]);
          $("#Alter_DeviceDatabits").val(configArr[3]);
          if (configArr[4] == 1) {
            $("#Alter_DeviceStopbit1").attr("checked", "checked");
          }
          if (configArr[4] == 2) {
            $("#Alter_DeviceStopbit2").attr("checked", "checked");
          }
          $("#Alter_LocStack").val(configArr[5]);
          $("#Alter_PLCStack").val(configArr[6]);
          $("#Alter_ABCheck").val(configArr[7]);
        } else if (driver == "MITSUBISHI-QN") {
          $("#Alter_Code").val(configArr[0]);
          $("#Alter_IPAddress").val(configArr[1]);
          $("#Alter_QPLCPort").val(configArr[2]);
          $("#Alter_QLocalPort").val(configArr[3]);
        } else if (driver == "MITSUBISHI-Q") {
          $("#Alter_IPAddress").val(configArr[0]);
          $("#Alter_QPLCPort").val(configArr[1]);
          $("#Alter_QLocalPort").val(configArr[2]);
        }
        //RF下三菱FX编程口和三菱FX串口显示响应超时时间
        else if (
          driver == "MITSUBISHI-FXP" ||
          driver == "MITSUBISHI-FXS" ||
          driver == "HMI"
        ) {
          if (AnyLinkType == "RF") {
            $("#Alter_DeviceID").val(configArr[0]);
            $("#Alter_DeviceBaudrate").val(configArr[1]);
            $("#Alter_DeviceParity").val(configArr[2]);
            $("#Alter_DeviceDatabits").val(configArr[3]);
            if (configArr[4] == 1) {
              $("#Alter_DeviceStopbit1").attr("checked", "checked");
            }
            if (configArr[4] == 2) {
              $("#Alter_DeviceStopbit2").attr("checked", "checked");
            }
            $("#Alter_ResponseOverTime").val(configArr[5]);
          } else {
            $("#Alter_DeviceID").val(configArr[0]);
            $("#Alter_DeviceBaudrate").val(configArr[1]);
            $("#Alter_DeviceParity").val(configArr[2]);
            $("#Alter_DeviceDatabits").val(configArr[3]);
            if (configArr[4] == 1) {
              $("#Alter_DeviceStopbit1").attr("checked", "checked");
            }
            if (configArr[4] == 2) {
              $("#Alter_DeviceStopbit2").attr("checked", "checked");
            }
          }
        }
        //M-Bus-serial协议展示
        else if (driver == "M-Bus-serial") {
          $("#Alter_DeviceID").val(configArr[1]);
          $("#Alter_DeviceBaudrate").val(configArr[2]);
          $("#Alter_DeviceParity").val(configArr[3]);
          $("#Alter_DeviceDatabits").val(configArr[4]);
          if (configArr[5] == 1) {
            $("#Alter_DeviceStopbit1").attr("checked", "checked");
          }
          if (configArr[5] == 2) {
            $("#Alter_DeviceStopbit2").attr("checked", "checked");
          }
        }
        //AB-Ethernet/IP协议展示
        else if (driver == "AB-Ethernet/IP" || driver == "AB-MicroLogix") {
          $("#Alter_delayed").val(configArr[0]);
        } else if (driver == "YinHe") {
          $("#Alter_IPAddress").val(configArr[0]);
          $("#Alter_Port").val(configArr[1]);
        } else if (driver == "Zundar") {
          $("#Alter_IPAddress").val(configArr[0]);
          $("#Alter_Port").val(configArr[1]);
          $("#Alter_delayed").val(configArr[2]);
        }
        //HKG-SERIAL驱动
        else if (AnyLinkType == "RF" && driver == "HKG-SERIAL") {
          $("#Alter_DeviceID").val(configArr[1]);
          $("#Alter_DeviceBaudrate").val(configArr[2]);
          $("#Alter_DeviceParity").val(configArr[3]);
          $("#Alter_DeviceDatabits").val(configArr[4]);
          if (configArr[5] == 1) {
            $("#Alter_DeviceStopbit1").attr("checked", "checked");
          }
          if (configArr[5] == 2) {
            $("#Alter_DeviceStopbit2").attr("checked", "checked");
          }
        }
        //自定义TCP
        else if (driver == "Custom-TCP") {
          $("#Alter_IPAddress").val(configArr[0]);
          $("#Alter_Port").val(configArr[1]);
          $("#Alter_delayed").val(configArr[2]);
        }
        //add begin by x
        else if (driver == "TwinCAT") {
          $("#Alter_delayed").val(configArr[0]);
        }
        //end add
        // add by fyj, 新增OCR驱动
        // add begin
        else if (driver == "OCR") {
          $("#Alter_Line_IPAddr").val(configArr[0]);
          $("#Alter_Line_Port").show(configArr[1]);
          $("#Alter_Line_ResponseOverTime").val(configArr[2]);
        }
        // add end
        // add by fyj
        else if (
          driver == "DLT645-2007" ||
          driver == "DLT645-1997" ||
          driver == "MITSUBISHI-TXZ-MomMach" ||
          driver == "MITSUBISHI-TXZ-SubMach1" ||
          driver == "MITSUBISHI-TXZ-SubMach2" 
        ) {
          $("#Alter_DeviceID").val(configArr[0]);
          $("#Alter_DeviceBaudrate").val(configArr[1]);
          $("#Alter_DeviceParity").val(configArr[2]);
          $("#Alter_DeviceDatabits").val(configArr[3]);
          if (configArr[4] == 1) {
            $("#Alter_DeviceStopbit1").attr("checked", "checked");
          }
          if (configArr[4] == 2) {
            $("#Alter_DeviceStopbit2").attr("checked", "checked");
          }
          $("#Alter_ResponseOverTime").val(configArr[5]);
        }
        // add end
        else if (
          driver == "MITSUBISHI-TX-5HP" ||
          driver == "MITSUBISHI-TX-15P" ||
          driver == "MITSUBISHI-TX-Multi-link"
        ) {
          $("#Alter_DeviceID").val(configArr[0]);
          $("#Alter_DeviceBaudrate").val(configArr[1]);
          $("#Alter_DeviceParity").val(configArr[2]);
          $("#Alter_DeviceDatabits").val(configArr[3]);
          if (configArr[4] == 1) {
            $("#Alter_DeviceStopbit1").attr("checked", "checked");
          }
          if (configArr[4] == 2) {
            $("#Alter_DeviceStopbit2").attr("checked", "checked");
          }
          $("#Alter_ResponseOverTime").val(configArr[5]);
          $("#Alter_OutdoorAddress").val(configArr[6]);
        }
        // add by fyj, OMRON-HostLink-Task
        else if (
          driver == "OMRON-HostLink-Task" ||
          driver == "OMRON-FINS-Task"
        ) {
          $("#Alter_DeviceID").val(configArr[0]);
          $("#Alter_DeviceBaudrate").val(configArr[1]);
          $("#Alter_DeviceParity").val(configArr[2]);
          $("#Alter_DeviceDatabits").val(configArr[3]);
          if (configArr[4] == 1) {
            $("#Alter_DeviceStopbit1").attr("checked", "checked");
          }
          if (configArr[4] == 2) {
            $("#Alter_DeviceStopbit2").attr("checked", "checked");
          }
          $("#Alter_HostLink_ResponseOvertime").val(configArr[5]);
        }
        // add end
        // add by whc
        else if (driver == "FATEK编程口") {
          $("#Alter_DeviceID").val(configArr[0]);
          $("#Alter_DeviceBaudrate").val(configArr[1]);
          $("#Alter_DeviceParity").val(configArr[2]);
          $("#Alter_DeviceDatabits").val(configArr[3]);
          if (configArr[4] == 1) {
            $("#Alter_DeviceStopbit1").attr("checked", "checked");
          }
          if (configArr[4] == 2) {
            $("#Alter_DeviceStopbit2").attr("checked", "checked");
          }
        }
        //add end
        else if (driver == "R1R2") {
          $("#Alter_DeviceID").val(configArr[0]);
          $("#Alter_DeviceBaudrate").val(configArr[1]);
          $("#Alter_DeviceParity").val(configArr[2]);
          $("#Alter_DeviceDatabits").val(configArr[3]);
          if (configArr[4] == 1) {
            $("#Alter_DeviceStopbit1").attr("checked", "checked");
          }
          if (configArr[4] == 2) {
            $("#Alter_DeviceStopbit2").attr("checked", "checked");
          }
          $("#Alter_delayed").val(configArr[5]);
        }
        else {
          $("#Alter_DeviceID").val(configArr[0]);
          $("#Alter_DeviceBaudrate").val(configArr[1]);
          $("#Alter_DeviceParity").val(configArr[2]);
          $("#Alter_DeviceDatabits").val(configArr[3]);
          if (configArr[4] == 1) {
            $("#Alter_DeviceStopbit1").attr("checked", "checked");
          }
          if (configArr[4] == 2) {
            $("#Alter_DeviceStopbit2").attr("checked", "checked");
          }
        }

        $model.find("device").each(function () {
          var $device = $(this);
          // $device.find("driver[n='" + d + "']").each(function () {
          //     var $driver = $(this);
          //     driverID = $driver.attr("id");
          // });  modify by fyj
          $device.find("driver").each(function () {
            var $driver = $(this);
            driverID = $driver.attr("id");
            driverName = $driver.attr("n");
          });
        });
      });
  });

  $.get("../conf/config.xml", function (data) {
    $(data)
      .find("task")
      .each(function () {
        var $task = $(this);
        $task.find("TaskDriver").each(function () {
          var $TaskDriver = $(this);
          $TaskDriver.find("driver").each(function () {
            var $driver = $(this);
            var id = $driver.attr("id");
            if (id == undefined) {
            } else {
              taskID = id;
            }
          });
        });
      });
  });
}
//根据value读取text值

function ReadCheckedDeviceDriver(txt) {
  $("#Alter_DeviceType").empty();
  $("#Alter_DeviceDriver").empty();
  if (coo == "English") {
    $.get("../conf/AllDeviceDriverEn.xml", function (d1) {
      $(d1)
        .find("Fac")
        .each(function () {
          $Fac = $(this);
          $Fac.find("Agr[value='" + txt + "']").each(function () {
            $Agr = $(this);
            var val_Type = $Agr.parent().attr("value");
            var text_Type = $Agr.parent().attr("text");
            var option1 = $("<option>").val(val_Type).text(text_Type);
            $("#Alter_DeviceType").append(option1);

            var val_Driver = txt;
            var text_Driver = $Agr.text();
            var option2 = $("<option>").val(val_Driver).text(text_Driver);
            $("#Alter_DeviceDriver").append(option2);
          });
        });
    });
  } else {
    $.get("../conf/AllDeviceDriver.xml", function (d1) {
      $(d1)
        .find("Fac")
        .each(function () {
          $Fac = $(this);
          $Fac.find("Agr[value='" + txt + "']").each(function () {
            $Agr = $(this);
            var val_Type = $Agr.parent().attr("value");
            var text_Type = $Agr.parent().attr("text");
            var option1 = $("<option>").val(val_Type).text(text_Type);
            $("#Alter_DeviceType").append(option1);

            var val_Driver = txt;
            var text_Driver = $Agr.text();
            var option2 = $("<option>").val(val_Driver).text(text_Driver);
            $("#Alter_DeviceDriver").append(option2);
          });
        });
    });
  }
}
//点击修改按钮赋值并执行py

function ClickAlterChannelButton() {
  var val = $("#Alter_DeviceDriver").val();
  var config = "";
  //driverID
  if (driverID == "") {
    $("#Alter_ChannelDriverID_YuToXHZhang").val("NULL");
  } else {
    if (val == "OMRON_NJNX" || val == "HKG-SERIAL") {
      $("#Alter_ChannelDriverID_YuToXHZhang").val("NULL");
    } else {
      $("#Alter_ChannelDriverID_YuToXHZhang").val(driverID);
    }
  }
  //通道名
  $("#Alter_ChannelName_YuToXHZhang").val($("#Alter_ChannelName").val());
  //通道类型
  $("#Alter_ChannelDriver_YuToXHZhang").val(val);
  //选中的ID
  $("#Alter_ChannelID_YuToXHZhang").val($("#Hide_Checked_ChannelID").val());
  //驱动类型
  $("#Alter_ChannelModelType_YuToXHZhang").val($("#Hide_Alter_Lib").val());
  //Config
  //所有的rtu协议拼出的config
  if (val == "Schneider-RTU") {
    config =
      "rtu;" +
      $("#Alter_DeviceID").val() +
      ";" +
      $("#Alter_DeviceBaudrate").val() +
      ";" +
      $("#Alter_DeviceParity").val() +
      ";" +
      $("#Alter_DeviceDatabits").val() +
      ";" +
      $("input[name='Alter_DeviceStopbit']:checked").val() +
      ";SCHNEIDER" +
      ";" +
      $("#Alter_delayed").val() +
      ";" +
      $("#Alter_Buffer").val() +
      ";" +
      $("#Alter_SendDelay").val();
  } else if (val == "Modbus-RTU") {
    config =
      "rtu;" +
      $("#Alter_DeviceID").val() +
      ";" +
      $("#Alter_DeviceBaudrate").val() +
      ";" +
      $("#Alter_DeviceParity").val() +
      ";" +
      $("#Alter_DeviceDatabits").val() +
      ";" +
      $("input[name='Alter_DeviceStopbit']:checked").val() +
      ";STANDARD" +
      ";" +
      $("#Alter_delayed").val() +
      ";" +
      $("#Alter_Buffer").val() +
      ";" +
      $("#Alter_SendDelay").val();
  } else if (val == "Modbus-RTU-task") {
    config =
      "rtu;" +
      $("#Alter_DeviceID").val() +
      ";" +
      $("#Alter_DeviceBaudrate").val() +
      ";" +
      $("#Alter_DeviceParity").val() +
      ";" +
      $("#Alter_DeviceDatabits").val() +
      ";" +
      $("input[name='Alter_DeviceStopbit']:checked").val() +
      ";STANDARD" +
      ";" +
      $("#Alter_delayed").val() +
      ";" +
      $("#Alter_Buffer").val() +
      ";" +
      $("#Alter_SendDelay").val();
  } else if (val == "Detal-RTU") {
    config =
      "rtu;" +
      $("#Alter_DeviceID").val() +
      ";" +
      $("#Alter_DeviceBaudrate").val() +
      ";" +
      $("#Alter_DeviceParity").val() +
      ";" +
      $("#Alter_DeviceDatabits").val() +
      ";" +
      $("input[name='Alter_DeviceStopbit']:checked").val() +
      ";DETAL" +
      ";" +
      $("#Alter_delayed").val() +
      ";" +
      $("#Alter_Buffer").val() +
      ";" +
      $("#Alter_SendDelay").val();
  } else if (val == "XinjieXD3-RTU") {
    config =
      "rtu;" +
      $("#Alter_DeviceID").val() +
      ";" +
      $("#Alter_DeviceBaudrate").val() +
      ";" +
      $("#Alter_DeviceParity").val() +
      ";" +
      $("#Alter_DeviceDatabits").val() +
      ";" +
      $("input[name='Alter_DeviceStopbit']:checked").val() +
      ";XINJIE_XD3" +
      ";" +
      $("#Alter_delayed").val() +
      ";" +
      $("#Alter_Buffer").val() +
      ";" +
      $("#Alter_SendDelay").val();
  } else if (val == "XinjieXC3-RTU") {
    config =
      "rtu;" +
      $("#Alter_DeviceID").val() +
      ";" +
      $("#Alter_DeviceBaudrate").val() +
      ";" +
      $("#Alter_DeviceParity").val() +
      ";" +
      $("#Alter_DeviceDatabits").val() +
      ";" +
      $("input[name='Alter_DeviceStopbit']:checked").val() +
      ";XINJIE_XC3" +
      ";" +
      $("#Alter_delayed").val() +
      ";" +
      $("#Alter_Buffer").val() +
      ";" +
      $("#Alter_SendDelay").val();
  }
  //所有ascii协议拼出的config
  else if (val == "Schneider-ASCII") {
    config =
      "ascii;" +
      $("#Alter_DeviceID").val() +
      ";" +
      $("#Alter_DeviceBaudrate").val() +
      ";" +
      $("#Alter_DeviceParity").val() +
      ";" +
      $("#Alter_DeviceDatabits").val() +
      ";" +
      $("input[name='Alter_DeviceStopbit']:checked").val() +
      ";SCHNEIDER" +
      ";" +
      $("#Alter_delayed").val() +
      ";" +
      $("#Alter_Buffer").val() +
      ";" +
      $("#Alter_SendDelay").val();
  } else if (val == "Modbus-ASCII") {
    config =
      "ascii;" +
      $("#Alter_DeviceID").val() +
      ";" +
      $("#Alter_DeviceBaudrate").val() +
      ";" +
      $("#Alter_DeviceParity").val() +
      ";" +
      $("#Alter_DeviceDatabits").val() +
      ";" +
      $("input[name='Alter_DeviceStopbit']:checked").val() +
      ";STANDARD" +
      ";" +
      $("#Alter_delayed").val() +
      ";" +
      $("#Alter_Buffer").val() +
      ";" +
      $("#Alter_SendDelay").val();
  } else if (val == "Modbus-ASCII-task") {
    config =
      "ascii;" +
      $("#Alter_DeviceID").val() +
      ";" +
      $("#Alter_DeviceBaudrate").val() +
      ";" +
      $("#Alter_DeviceParity").val() +
      ";" +
      $("#Alter_DeviceDatabits").val() +
      ";" +
      $("input[name='Alter_DeviceStopbit']:checked").val() +
      ";STANDARD" +
      ";" +
      $("#Alter_delayed").val() +
      ";" +
      $("#Alter_Buffer").val() +
      ";" +
      $("#Alter_SendDelay").val();
  } else if (val == "Detal-ASCII") {
    config =
      "ascii;" +
      $("#Alter_DeviceID").val() +
      ";" +
      $("#Alter_DeviceBaudrate").val() +
      ";" +
      $("#Alter_DeviceParity").val() +
      ";" +
      $("#Alter_DeviceDatabits").val() +
      ";" +
      $("input[name='Alter_DeviceStopbit']:checked").val() +
      ";DETAL" +
      ";" +
      $("#Alter_delayed").val() +
      ";" +
      $("#Alter_Buffer").val() +
      ";" +
      $("#Alter_SendDelay").val();
  } else if (val == "XinjieXD3-ASCII") {
    config =
      "ascii;" +
      $("#Alter_DeviceID").val() +
      ";" +
      $("#Alter_DeviceBaudrate").val() +
      ";" +
      $("#Alter_DeviceParity").val() +
      ";" +
      $("#Alter_DeviceDatabits").val() +
      ";" +
      $("input[name='Alter_DeviceStopbit']:checked").val() +
      ";XINJIE_XD3" +
      ";" +
      $("#Alter_delayed").val() +
      ";" +
      $("#Alter_Buffer").val() +
      ";" +
      $("#Alter_SendDelay").val();
  } else if (val == "XinjieXC3-ASCII") {
    config =
      "ascii;" +
      $("#Alter_DeviceID").val() +
      ";" +
      $("#Alter_DeviceBaudrate").val() +
      ";" +
      $("#Alter_DeviceParity").val() +
      ";" +
      $("#Alter_DeviceDatabits").val() +
      ";" +
      $("input[name='Alter_DeviceStopbit']:checked").val() +
      ";XINJIE_XC3" +
      ";" +
      $("#Alter_delayed").val() +
      ";" +
      $("#Alter_Buffer").val() +
      ";" +
      $("#Alter_SendDelay").val();
  }

  //欧姆龙TCP协议拼出的config
  else if (val == "OMRON-TCP") {
    config = $("#Alter_IPAddress").val() + ";" + $("#Alter_Port").val();
  }
  //ModbusTCP协议拼出的config
  else if (val == "M-Bus-TCP") {
    config =
      "tcp;" + $("#Alter_IPAddress").val() + ";" + $("#Alter_Port").val();
  } else if (val == "Modbus-TCP") {
    config =
      "tcp;" +
      $("#Alter_IPAddress").val() +
      ";" +
      $("#Alter_Port").val() +
      ";" +
      $("#Alter_delayed").val() +
      ";" +
      $("#Alter_Buffer").val() +
      ";" +
      $("#Alter_SendDelay").val();
  } else if (val == "Modbus-TCP-task") {
    config =
      "tcp;" +
      $("#Alter_IPAddress").val() +
      ";" +
      $("#Alter_Port").val() +
      ";" +
      $("#Alter_delayed").val() +
      ";" +
      $("#Alter_Buffer").val() +
      ";" +
      $("#Alter_SendDelay").val();
  } else if (val == "OMRON_NJNX") {
    config = $("#Alter_ResponseOverTime").val();
  }
  //Schneider-TCP协议拼出的config
  else if (val == "Schneider-TCP") {
    config =
      "tcp;" +
      $("#Alter_IPAddress").val() +
      ";" +
      $("#Alter_Port").val() +
      ";SCHNEIDER" +
      ";" +
      $("#Alter_delayed").val() +
      ";" +
      $("#Alter_Buffer").val() +
      ";" +
      $("#Alter_SendDelay").val();
  }
  //Detal-TCP协议拼出的config
  else if (val == "Detal-TCP") {
    config =
      "tcp;" +
      $("#Alter_IPAddress").val() +
      ";" +
      $("#Alter_Port").val() +
      ";DETAL" +
      ";" +
      $("#Alter_delayed").val() +
      ";" +
      $("#Alter_Buffer").val() +
      ";" +
      $("#Alter_SendDelay").val();
  }
  //MPI协议拼出的config
  else if (val == "SIEMENS-MPI") {
    config =
      $("#Alter_DeviceID").val() +
      ";" +
      $("#Alter_DeviceBaudrate").val() +
      ";" +
      $("#Alter_DeviceMPI").val();
  }
  //SIEMENS-S7-PPI-Task
  else if (val == "SIEMENS-S7-PPI-Task") {
    config =
      $("#Alter_PPI_DeviceID").val() +
      ";" +
      $("#Alter_PPI_DeviceBaudrate").val() +
      ";" +
      $("#Alter_DeviceParity").val() +
      ";" +
      $("#Alter_DeviceDatabits").val() +
      ";" +
      $("input[name='Alter_PPI_DeviceStopbit']:checked").val() +
      ";" +
      $("#Alter_ResponseOverTime").val();
  }
  //1200拼出的config
  else if (val == "SIEMENS-Ethernet") {
    var S7_200 = $("input[name='Alter_S7_200']:checked").val();
    if (S7_200 == "yes") {
      config =
        "S7-200;" +
        $("#Alter_IPAddress").val() +
        ";" +
        $("#Alter_JJ_1200").val() +
        ";" +
        $("#Alter_CC_1200").val() +
        ";" +
        $("input[name='Alter_Type_200']:checked").val();
    } else {
      config =
        $("#Alter_IPAddress").val() +
        ";" +
        $("#Alter_JJ_1200").val() +
        ";" +
        $("#Alter_CC_1200").val() +
        ";" +
        $("input[name='Alter_Type_200']:checked").val();
    }
  }
  //自定义TCP协议
  else if (val == "Custom-TCP") {
    config =
      $("#Alter_IPAddress").val() +
      ";" +
      $("#Alter_Port").val() +
      ";" +
      $("#Alter_delayed").val();
  }
  //BacNet-IP协议拼出的config
  else if (val == "BacNet-IP") {
    config = $("#Alter_Port").val() + ";" + $("#Alter_delayed").val();
  }
  //BacNet-IP-task
  else if (val == "BacNet-IP-task") {
    config = $("#Alter_Port").val() + ";" + $("#Alter_delayed").val();
  }
  //BacNet-MS/TP协议拼出的config
  else if (val == "BacNet-MS/TP") {
    config =
      $("#Alter_DeviceID").val() +
      ";" +
      $("#Alter_DeviceBaudrate").val() +
      ";" +
      $("#Alter_Mac").val();
  }
  //BacNet-MS/TP-task协议拼出的config
  else if (val == "BacNet-MS/TP-task") {
    config =
      $("#Alter_DeviceID").val() +
      ";" +
      $("#Alter_DeviceBaudrate").val() +
      ";" +
      $("#Alter_Mac").val();
  } else if (val == "AB-DF1") {
    config =
      $("#Alter_DeviceID").val() +
      ";" +
      $("#Alter_DeviceBaudrate").val() +
      ";" +
      $("#Alter_DeviceParity").val() +
      ";" +
      $("#Alter_DeviceDatabits").val() +
      ";" +
      $("input[name='Alter_DeviceStopbit']:checked").val() +
      ";" +
      $("#Alter_LocStack").val() +
      ";" +
      $("#Alter_PLCStack").val() +
      ";" +
      $("#Alter_ABCheck").val();
  }
  //QN系列拼出的config
  else if (val == "MITSUBISHI-Q") {
    config =
      $("#Alter_IPAddress").val() +
      ";" +
      $("#Alter_QPLCPort").val() +
      ";" +
      $("#Alter_QLocalPort").val();
  } else if (val == "MITSUBISHI-QN") {
    config =
      $("#Alter_Code").val() +
      ";" +
      $("#Alter_IPAddress").val() +
      ";" +
      $("#Alter_QPLCPort").val() +
      ";" +
      $("#Alter_QLocalPort").val();
  }
  //RF下三菱FX编程口和FX串口拼出的config
  else if (val == "MITSUBISHI-FXP" || val == "MITSUBISHI-FXS" || val == "HMI") {
    if (AnyLinkType == "RF") {
      config =
        $("#Alter_DeviceID").val() +
        ";" +
        $("#Alter_DeviceBaudrate").val() +
        ";" +
        $("#Alter_DeviceParity").val() +
        ";" +
        $("#Alter_DeviceDatabits").val() +
        ";" +
        $("input[name='Alter_DeviceStopbit']:checked").val() +
        ";" +
        $("#Alter_ResponseOverTime").val();
    } else {
      config =
        $("#Alter_DeviceID").val() +
        ";" +
        $("#Alter_DeviceBaudrate").val() +
        ";" +
        $("#Alter_DeviceParity").val() +
        ";" +
        $("#Alter_DeviceDatabits").val() +
        ";" +
        $("input[name='Alter_DeviceStopbit']:checked").val();
    }
  }
  //M-Bus-serial协议拼出的config
  else if (val == "M-Bus-serial") {
    config =
      "serial;" +
      $("#Alter_DeviceID").val() +
      ";" +
      $("#Alter_DeviceBaudrate").val() +
      ";" +
      $("#Alter_DeviceParity").val() +
      ";" +
      $("#Alter_DeviceDatabits").val() +
      ";" +
      $("input[name='Alter_DeviceStopbit']:checked").val();
  }
  //AB-Ethernet/IP拼出的config
  else if (
    val == "AB-Ethernet/IP" ||
    val == "AB-MicroLogix" ||
    val == "TwinCAT"
  ) {
    config = $("#Alter_delayed").val();
  } else if (val == "YinHe") {
    config = $("#Alter_IPAddress").val() + ";" + $("#Alter_Port").val();
  } else if (val == "Zundar") {
    config =
      $("#Alter_IPAddress").val() +
      ";" +
      $("#Alter_Port").val() +
      ";" +
      $("#Alter_delayed").val();
  }
  //HKG-SERIAL拼出config
  else if (AnyLinkType == "RF" && val == "HKG-SERIAL") {
    config =
      "serial;" +
      $("#Alter_DeviceID").val() +
      ";" +
      $("#Alter_DeviceBaudrate").val() +
      ";" +
      $("#Alter_DeviceParity").val() +
      ";" +
      $("#Alter_DeviceDatabits").val() +
      ";" +
      $("input[name='Alter_DeviceStopbit']:checked").val();
  }
  //gps 拼出的config
  else if (val == "GPS") {
    config = "/dev/ttyHSL2;9600;N;8;1";
  }
  // add by whc
  else if (val == "DRACAL") {
    config = "usbtenki";
  }
  // add end
  // add by fyj , 新增OCR驱动
  // add begin
  else if (val == "OCR") {
    config =
      $("#Alter_IPAddress").val() +
      ";" +
      $("#Alter_Port").val() +
      ";" +
      $("#Alter_ResponseOverTime").val();
  }
  // add end
  // add by fyj, 新增KUKA驱动
  // add begin
  else if (val == "KUKA") {
    config =
      $("#Alter_ReadInterval").val() +
      ";" +
      $("#Alter_ReadWait").val() +
      ";" +
      $("#Alter_WriteInterval").val();
  }
  // add end
  // add by fyj, cloudweb驱动
  else if (val == "CloudWeb") {
    config =
      $("#Alter_CloudAddress").val() +
      ";" +
      $("#Alter_Username").val() +
      ";" +
      $("#Alter_Password").val();
  }
  // end add
  // add by fyj, DLT645-2007驱动
  else if (
    val == "DLT645-2007" ||
    val == "DLT645-1997" ||
    val == "MITSUBISHI-TXZ-MomMach" ||
    val == "MITSUBISHI-TXZ-SubMach1" ||
    val == "MITSUBISHI-TXZ-SubMach2" 
  ) {
    config =
      $("#Alter_DeviceID").val() +
      ";" +
      $("#Alter_DeviceBaudrate").val() +
      ";" +
      $("#Alter_DeviceParity").val() +
      ";" +
      $("#Alter_DeviceDatabits").val() +
      ";" +
      $("input[name='Alter_DeviceStopbit']:checked").val() +
      ";" +
      $("#Alter_ResponseOverTime").val();
  }
  // add end
  else if (
    val == "MITSUBISHI-TX-5HP" ||
    val == "MITSUBISHI-TX-15P" ||
    val == "MITSUBISHI-TX-Multi-link"
  ) {
    config =
      $("#Alter_DeviceID").val() +
      ";" +
      $("#Alter_DeviceBaudrate").val() +
      ";" +
      $("#Alter_DeviceParity").val() +
      ";" +
      $("#Alter_DeviceDatabits").val() +
      ";" +
      $("input[name='Alter_DeviceStopbit']:checked").val() +
      ";" +
      $("#Alter_ResponseOverTime").val() +
      ";" +
      $("#Alter_OutdoorAddress").val();
  }
  // add by fyj, OMRON-HostLink-Task
  else if (val == "OMRON-HostLink-Task" || val == "OMRON-FINS-Task") {
    config =
      $("#Alter_DeviceID").val() +
      ";" +
      $("#Alter_DeviceBaudrate").val() +
      ";" +
      $("#Alter_DeviceParity").val() +
      ";" +
      $("#Alter_DeviceDatabits").val() +
      ";" +
      $("input[name='Alter_DeviceStopbit']:checked").val() +
      ";" +
      $("#Alter_HostLink_ResponseOvertime").val();
  }
  // add end
  // add by whc, FATEK编程口驱动
  else if (val == "FATEK编程口") {
    config =
      $("#Alter_DeviceID").val() +
      ";" +
      $("#Alter_DeviceBaudrate").val() +
      ";" +
      $("#Alter_DeviceParity").val() +
      ";" +
      $("#Alter_DeviceDatabits").val() +
      ";" +
      $("input[name='Alter_DeviceStopbit']:checked").val();
  }
  //add end
  // add by whc,OPC驱动
  else if (val == "OPC") {
    config =
      $("#Alter_GatewayAddress").val() +
      ";" +
      $("#Alter_GatewayPort").val() +
      ";" +
      $("#Alter_ServerAddress").val() +
      ";" +
      $("#Alter_ServerName").val() +
      ";" +
      $("#Alter_ReadMode").val();
  }
  // add end
  // add by lh,OPC-UA驱动
  else if (val == "OPC-UA") {
    config =
      $("#Alter_IPAddress").val() +
      ";" +
      $("#Alter_Port").val() +
      ";" +
      $("#Alter_Encoding").val() +
      ";" +
      $("#Alter_Security").val() +
      ";" +
      $("#Alter_Sync").val();
  }
  // add end
  // add by lh,  新增IEC104驱动
  else if (val == "IEC104") {
    config =
      $("#Alter_IECIP").val() +
      ";" +
      $("#Alter_IECPort").val() +
      ";" +
      $("#Alter_IECAddr").val();
  }
  // add end
  else if (val == "device") {
    config = $("#Alter_commonConf").val();
  }
  else if (val == "R1R2") {
    config =
      $("#Alter_DeviceID").val() +
      ";" +
      $("#Alter_DeviceBaudrate").val() +
      ";" +
      $("#Alter_DeviceParity").val() +
      ";" +
      $("#Alter_DeviceDatabits").val() +
      ";" +
      $("input[name='Alter_DeviceStopbit']:checked").val() +
      ";" +
      $("#Alter_delayed").val() ;
  }
  //其余的协议拼出的config
  else {
    config =
      $("#Alter_DeviceID").val() +
      ";" +
      $("#Alter_DeviceBaudrate").val() +
      ";" +
      $("#Alter_DeviceParity").val() +
      ";" +
      $("#Alter_DeviceDatabits").val() +
      ";" +
      $("input[name='Alter_DeviceStopbit']:checked").val();
  }
  $("#Alter_ChannelConfig_YuToXHZhang").val(config);
  //alert(document.getElementById("Alter_ChannelConfig_YuToXHZhang").value)
  if (val == "device") {
    var libName = $("#Alter_commonName").val();
    $("#Alter_ChannelModelType_YuToXHZhang").val(libName);
  }
  if (CheckAlertChannel()) {
  } else {
    Alter_ChannelMethod();
  }
}
//校验

function CheckAlertChannel() {
  var reg = new RegExp(
    "^(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]).(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0).(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0).(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[0-9])$"
  );
  var address = $("#Alter_IPAddress").val();
  var reg2 = new RegExp("^[0-9]*$");
  var port = $("#Alter_Port").val();
  var gatewayPort = $("#Alter_GatewayPort").val();
  var type = $("#Alter_DeviceDriver").val();
  if ($("#Alter_ChannelName").val() == "") {
    if (coo == "English") {
      alert("Please enter the channel name");
    } else {
      alert("请输入通道名称");
    }
    return true;
  } else {
    //TCP的协议需要校验IP地址和端口号
    if (
      type == "OMRON-TCP" ||
      type == "M-Bus-TCP" ||
      type == "YinHe" ||
      type == "Zundar"
    ) {
      if (address == "") {
        if (coo == "English") {
          alert("Please enter IP address");
        } else {
          alert("请输入IP地址");
        }
        return true;
      } else if (!reg.test(address)) {
        if (coo == "English") {
          alert("IP address input error");
        } else {
          alert("IP地址输入错误");
        }
        return true;
      } else if (port == "") {
        if (coo == "English") {
          alert("Please enter the port number");
        } else {
          alert("请输入端口号");
        }
        return true;
      } else if (!reg2.test(port)) {
        if (coo == "English") {
          alert("Incorrect port number input");
        } else {
          alert("端口号输入错误");
        }
        return true;
      } else {
        return false;
      }
    } else if (type == "MITSUBISHI-QN" || type == "MITSUBISHI-Q") {
      var port1 = $("#Alter_QPLCPort").val();
      var port2 = $("#Alter_QLocalPort").val();
      if (address == "") {
        if (coo == "English") {
          alert("Please enter IP address");
        } else {
          alert("请输入IP地址");
        }
        return true;
      } else if (!reg.test(address)) {
        if (coo == "English") {
          alert("IP address input error");
        } else {
          alert("IP地址输入错误");
        }
        return true;
      } else if (port1 == "" || port2 == "") {
        if (coo == "English") {
          alert("Please enter the port number");
        } else {
          alert("请输入端口号");
        }
        return true;
      } else if (!reg2.test(port1) || !reg2.test(port2)) {
        if (coo == "English") {
          alert("Incorrect port number input");
        } else {
          alert("端口号输入错误");
        }
        return true;
      }
    } else if (
      type == "Modbus-TCP" ||
      type == "Schneider-TCP" ||
      type == "Detal-TCP" ||
      type == "Modbus-TCP-task"
    ) {
      if (address == "") {
        if (coo == "English") {
          alert("Please enter IP address");
        } else {
          alert("请输入IP地址");
        }
        return true;
      } else if (!reg.test(address)) {
        if (coo == "English") {
          alert("IP address input error");
        } else {
          alert("IP地址输入错误");
        }
        return true;
      } else if (port == "") {
        if (coo == "English") {
          alert("Please enter the port number");
        } else {
          alert("请输入端口号");
        }
        return true;
      } else if (!reg2.test(port)) {
        if (coo == "English") {
          alert("Incorrect port number input");
        } else {
          alert("端口号输入错误");
        }
        return true;
      } else if ($("#Alter_delayed").val() == "") {
        if (coo == "English") {
          alert("Please input response latency");
        } else {
          alert("请输入响应延时");
        }
        return true;
      } else if ($("#Alter_Buffer").val() == "") {
        if (coo == "English") {
          alert("Please input buffer");
        } else {
          alert("请输入缓冲区");
        }
        return true;
      } else if ($("#Alter_SendDelay").val() == "") {
        if (coo == "English") {
          alert("Please enter send delay");
        } else {
          alert("请输入发送延时");
        }
        return true;
      } else {
        return false;
      }
    }
    //西门子1200需要校验IP地址、插槽号和机架号
    else if (type == "SIEMENS-Ethernet") {
      if (address == "") {
        if (coo == "English") {
          alert("Please enter IP address");
        } else {
          alert("请输入IP地址");
        }
        return true;
      } else if (!reg.test(address)) {
        if (coo == "English") {
          alert("IP address input error");
        } else {
          alert("IP地址输入错误");
        }
        return true;
      } else if ($("#Alter_JJ_1200").val() == "") {
        if ($("input[name='Alter_S7_200']:checked").val() == "yes") {
          if (coo == "English") {
            alert("Please enter local TSAP");
          } else {
            alert("请输入本地TSAP");
          }
        } else {
          if (coo == "English") {
            alert("Please enter the rack number");
          } else {
            alert("请输入机架号");
          }
        }
        return true;
      } else if (!reg2.test($("#Alter_JJ_1200").val())) {
        if ($("input[name='Alter_S7_200']:checked").val() == "yes") {
          if (coo == "English") {
            alert("Local TSAP input error");
          } else {
            alert("本地TSAP输入错误");
          }
        } else {
          if (coo == "English") {
            alert("Input error of rack number");
          } else {
            alert("机架号输入错误");
          }
        }
        return true;
      } else if ($("#Alter_CC_1200").val() == "") {
        if ($("input[name='Add_S7_200']:checked").val() == "yes") {
          if (coo == "English") {
            alert("Please enter remote TSAP");
          } else {
            alert("请输入远程TSAP");
          }
        } else {
          if (coo == "English") {
            alert("Please enter the slot number");
          } else {
            alert("请输入插槽号");
          }
        }
        return true;
      } else if (!reg2.test($("#Alter_CC_1200").val())) {
        if ($("input[name='Alter_S7_200']:checked").val() == "yes") {
          if (coo == "English") {
            alert("Remote TSAP input error");
          } else {
            alert("远程TSAP输入错误");
          }
        } else {
          if (coo == "English") {
            alert("Slot number input error");
          } else {
            alert("插槽号输入错误");
          }
        }
        return true;
      } else {
        return false;
      }
    }
    //BacNet-IP需要校验端口号
    else if (type == "BacNet-IP" || type == "BacNet-IP-task") {
      if (port == "") {
        if (coo == "English") {
          alert("Please enter the port number");
        } else {
          alert("请输入端口号");
        }
        return true;
      } else if (!reg2.test(port)) {
        if (coo == "English") {
          alert("Incorrect port number input");
        } else {
          alert("端口号输入错误");
        }
        return true;
      } else if ($("#Alter_delayed").val() == "") {
        if (coo == "English") {
          alert("Please input delay");
        } else {
          alert("请输入延时");
        }
        return true;
      } else if (
        !reg2.test($("#Alter_delayed").val()) ||
        $("#Alter_delayed").val() < 500 ||
        $("#Alter_delayed").val() > 10000 ||
        $("#Alter_delayed").val() % 500 != 0
      ) {
        if (coo == "English") {
          alert(
            "The delay input error must be a positive integer between 500ms-10000ms, and must be a multiple of 500"
          );
        } else {
          alert(
            "延时输入错误，延时必须为500ms-10000ms之间的正整数，且必须为500的倍数"
          );
        }
        return true;
      } else {
        return false;
      }
    }
    //增达校验延时
    else if (type == "Zundar") {
      if ($("#Alter_delayed").val() == "") {
        if (coo == "English") {
          alert("Please input delay");
        } else {
          alert("请输入延时");
        }
        return true;
      } else if (
        !reg2.test($("#Alter_delayed").val()) ||
        $("#Alter_delayed").val() < 500 ||
        $("#Alter_delayed").val() > 10000 ||
        $("#Alter_delayed").val() % 500 != 0
      ) {
        if (coo == "English") {
          alert(
            "The delay input error must be a positive integer between 500ms-10000ms, and must be a multiple of 500"
          );
        } else {
          alert(
            "延时输入错误，延时必须为500ms-10000ms之间的正整数，且必须为500的倍数"
          );
        }
        return true;
      }
    }
    //BacNet-MS/TP需要校验MAC地址
    else if (type == "BacNet-MS/TP" || type == "BacNet-MS/TP-task") {
      if ($("#Alter_Mac").val() == "") {
        if (coo == "English") {
          alert("Please enter MAC address");
        } else {
          alert("请输入MAC地址");
        }
        return true;
      } else if (!reg2.test($("#Alter_Mac").val())) {
        if (coo == "English") {
          alert("MAC address input error");
        } else {
          alert("MAC地址输入错误");
        }
        return true;
      } else {
        return false;
      }
    }
    //ModBus-RTU和ASCII的缓冲区和延时需要校验
    else if (
      type == "Modbus-RTU" ||
      type == "Modbus-ASCII" ||
      type == "Schneider-RTU" ||
      type == "Schneider-ASCII" ||
      type == "Detal-RTU" ||
      type == "Detal-ASCII" ||
      type == "XinjieXD3-RTU" ||
      type == "XinjieXD3-ASCII" ||
      type == "XinjieXC3-RTU" ||
      type == "XinjieXC3-ASCII"
    ) {
      if ($("#Alter_delayed").val() == "") {
        if (coo == "English") {
          alert("Please input response latency");
        } else {
          alert("请输入响应延时");
        }
        return true;
      }
      //else if(!reg2.test($("#Alter_delayed").val()) || $("#Alter_delayed").val() < 5000){
      //alert("延时输入错误，延时必须为大于5000ms的整数")
      //return true;
      //}
      else if ($("#Alter_Buffer").val() == "") {
        if (coo == "English") {
          alert("Please input buffer");
        } else {
          alert("请输入缓冲区");
        }
        return true;
      } else if ($("#Alter_SendDelay").val() == "") {
        if (coo == "English") {
          alert("Please enter send delay");
        } else {
          alert("请输入发送延时");
        }
        return true;
      }
      //else if(!reg2.test($("#Alter_Buffer").val()) || $("#Alter_Buffer").val() > 120){
      //alert("缓冲区输入错误，缓冲区必须为小于120的正整数")
      //return true;
      //}
      else {
        return false;
      }
    } else if (type == "AB-DF1") {
      if ($("#Alter_LocStack").val() == "") {
        if (coo == "English") {
          alert("Please enter the local stack number");
        } else {
          alert("请输入本地栈号");
        }
        return true;
      } else if (!reg2.test($("#Alter_LocStack").val())) {
        if (coo == "English") {
          alert(
            "local stack number input error, local stack number can only be positive integer"
          );
        } else {
          alert("本地栈号输入错误，本地栈号只能为正整数");
        }
        return true;
      } else if ($("#Alter_PLCStack").val() == "") {
        if (coo == "English") {
          alert("Please enter the PLC stack number");
        } else {
          alert("请输入PLC栈号");
        }
        return true;
      } else if (!reg2.test($("#Alter_PLCStack").val())) {
        if (coo == "English") {
          alert(
            "PLC stack number input error, the PLC stack number can only be positive integer"
          );
        } else {
          alert("PLC栈号输入错误，PLC栈号只能为正整数");
        }
        return true;
      } else {
        return false;
      }
    }
    //RF下FX编程口和FX串口要校验响应超时时间
    else if (
      type == "MITSUBISHI-FXP" ||
      type == "MITSUBISHI-FXS" ||
      type == "OMRON_NJNX"
    ) {
      if (AnyLinkType == "RF" || type == "OMRON_NJNX") {
        if ($("#Alter_ResponseOverTime").val() == "") {
          if (coo == "English") {
            alert("Please enter a response timeout");
          } else {
            alert("请输入响应超时时间");
          }
          return true;
        } else if (!reg2.test($("#Alter_ResponseOverTime").val())) {
          if (coo == "English") {
            alert("The response timeout can only be positive integers");
          } else {
            alert("响应超时时间只能为正整数");
          }
          return true;
        } else {
          return false;
        }
      }
    } else if (type == "AB-Ethernet/IP" || type == "AB-MicroLogix") {
      if ($("#Alter_delayed").val() == "") {
        if (coo == "English") {
          alert("Please input response latency");
        } else {
          alert("请输入响应延时");
        }
        return true;
      }
    }
    // add by fyj , 校验OCR驱动
    // add begin
    else if (type == "OCR") {
      if (address == "") {
        if (coo == "English") {
          alert("Please enter IP address");
        } else {
          alert("请输入IP地址");
        }
        return true;
      } else if (!reg.test(address)) {
        if (coo == "English") {
          alert("IP address input error");
        } else {
          alert("IP地址输入错误");
        }
        return true;
      } else if (port == "") {
        if (coo == "English") {
          alert("Please enter the port number");
        } else {
          alert("请输入端口号");
        }
        return true;
      } else if (!reg2.test(port)) {
        if (coo == "English") {
          alert("Incorrect port number input");
        } else {
          alert("端口号输入错误");
        }
        return true;
      } else if ($("#Add_ResponseOverTime").val() == "") {
        if (coo == "English") {
          alert("Please enter a response timeout");
        } else {
          alert("请输入响应超时时间");
        }
        return true;
      } else if (!reg2.test($("#Add_ResponseOverTime").val())) {
        if (coo == "English") {
          alert("The response timeout can only be positive integers");
        } else {
          alert("响应超时时间只能为正整数");
        }
        return true;
      }
    }
    // add end
    // add by fyj, 校验KUKA驱动
    // add begin
    else if (type == "KUKA") {
      var readInterval = $("#Alter_ReadInterval").val();
      var readWait = $("#Alter_ReadWait").val();
      var writeInterval = $("#Alter_WriteInterval").val();
      if (readInterval == "") {
        if (coo == "English") {
          alert("Please enter the read interval");
        } else {
          alert("请输入读取间隔");
        }
        return true;
      } else if (!reg2.test(readInterval)) {
        if (coo == "English") {
          alert("Error reading interval input");
        } else {
          alert("读取间隔输入错误");
        }
        return true;
      } else if (readWait == "") {
        if (coo == "English") {
          alert("Please enter read wait");
        } else {
          alert("请输入读取等待");
        }
        return true;
      } else if (!reg2.test(readWait)) {
        if (coo == "English") {
          alert("Read wait for input error");
        } else {
          alert("读取等待输入错误");
        }
        return true;
      }
      if (writeInterval == "") {
        if (coo == "English") {
          alert("Please enter the write interval");
        } else {
          alert("请输入写间隔");
        }
        return true;
      } else if (!reg2.test(writeInterval)) {
        if (coo == "English") {
          alert("Write interval input error");
        } else {
          alert("写间隔输入错误");
        }
        return true;
      }
    }
    // add end
    // add by fyj, cloudweb
    else if (type == "CloudWeb") {
      var cloudAddr = $("#Alter_CloudAddress").val();
      var username = $("#Alter_Username").val();
      var password = $("#Alter_Password").val();
      if (cloudAddr == "") {
        if (coo == "English") {
          alert("Please enter the cloud platform address");
        } else {
          alert("请输入云平台地址");
        }
        return true;
      } else if (username == "") {
        if (coo == "English") {
          alert("Please enter the user name");
        } else {
          alert("请输入用户名");
        }
        return true;
      } else if (password == "") {
        if (coo == "English") {
          alert("Please enter password");
        } else {
          alert("请输入密码");
        }
        return true;
      } else {
        return false;
      }
    }
    // add end
    // add by fyj, DLT645-2007驱动
    else if (
      type == "DLT645-2007" ||
      type == "DLT645-1997" ||
      type == "MITSUBISHI-TXZ-MomMach" ||
      type == "MITSUBISHI-TXZ-SubMach1" ||
      type == "MITSUBISHI-TXZ-SubMach2" 
    ) {
      var overtime = $("#Alter_ResponseOverTime").val();
      if (overtime == "") {
        if (coo == "English") {
          alert("Please enter a response timeout");
        } else {
          alert("请输入响应超时");
        }
        return true;
      } else if (!reg2.test(overtime)) {
        if (coo == "English") {
          alert("Response timeout input error");
        } else {
          alert("响应超时输入错误");
        }
        return true;
      } else {
        return false;
      }
    }
    // add end
    else if (
      type == "MITSUBISHI-TX-5HP" ||
      type == "MITSUBISHI-TX-15P" ||
      type == "MITSUBISHI-TX-Multi-link"
    ) {
      var overtime = $("#Alter_ResponseOverTime").val();
      var outdoorAddress = $("#Alter_OutdoorAddress").val();
      if (overtime == "") {
        if (coo == "English") {
          alert("Please enter a response timeout");
        } else {
          alert("请输入响应超时");
        }
        return true;
      } else if (!reg2.test(overtime)) {
        if (coo == "English") {
          alert("Response timeout input error");
        } else {
          alert("响应超时输入错误");
        }
        return true;
      } else if (outdoorAddress == "") {
        if (coo == "English") {
          alert("Please enter outdoor address");
        } else {
          alert("请输入室外机地址");
        }
        return true;
      } else if (!reg2.test(outdoorAddress)) {
        if (coo == "English") {
          alert("Outdoor address timeout input error");
        } else {
          alert("室外机地址输入错误");
        }
        return true;
      } else {
        return false;
      }
    }
    // add by fyj, OMRON-HostLink-Task
    else if (type == "OMRON-HostLink-Task" || type == "OMRON-FINS-Task") {
      var overtime = $("#Alter_HostLink_ResponseOvertime").val();
      if (overtime == "") {
        if (coo == "English") {
          alert("Please enter a response timeout");
        } else {
          alert("请输入响应超时");
        }
        return true;
      } else if (!reg2.test(overtime)) {
        if (coo == "English") {
          alert("Response timeout input error");
        } else {
          alert("响应超时输入错误");
        }
        return true;
      } else {
        return false;
      }
    }
    // add end
    // add by whc,SIEMENS-S7-PPI-Task
    else if (type == "SIEMENS-S7-PPI-Task") {
      var overtime = $("#Alter_ResponseOverTime").val();
      if (overtime == "") {
        if (coo == "English") {
          alert("Please enter a response timeout");
        } else {
          alert("请输入响应超时");
        }
        return true;
      } else if (!reg2.test(overtime)) {
        if (coo == "English") {
          alert("Response timeout input error");
        } else {
          alert("响应超时输入错误");
        }
        return true;
      } else {
        return false;
      }
    }
    // add by lh,IEC104
    else if (type == "IEC104") {
      var iecip = $("#Alter_IECIP").val();
      var iecport = $("#Alter_IECPort").val();
      var iecaddr = $("#Alter_IECAddr").val();

      if (iecip == "") {
        if (coo == "English") {
          alert("Please enter device IP address");
        } else {
          alert("请输入设备 IP");
        }
        return true;
      } else if (!reg.test(iecip)) {
        if (coo == "English") {
          alert("Device IP address input error");
        } else {
          alert("设备IP输入错误");
        }
        return true;
      } else if (iecport == "") {
        if (coo == "English") {
          alert("Please enter the device port");
        } else {
          alert("请输入设备端口");
        }
        return true;
      } else if (!reg2.test(iecport)) {
        if (coo == "English") {
          alert("Incorrect device port number input");
        } else {
          alert("设备端口输入错误");
        }
        return true;
      } else if (iecaddr == "") {
        if (coo == "English") {
          alert("Please enter the device port");
        } else {
          alert("请输入公共地址");
        }
        return true;
      } else {
        return false;
      }
    }
    // add end
    // add by whc,OPC驱动
    else if (type == "OPC") {
      var gatewayAddress = $("#Alter_GatewayAddress").val();
      var gatewayPort = $("#Alter_GatewayPort").val();
      var serverAddress = $("#Alter_ServerAddress").val();
      var serverName = $("#Alter_ServerName").val();
      var readMode = $("#Alter_ReadMode").val();
      var posIntReg = /^(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9])\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[0-9])$/;
      if (gatewayAddress == "") {
        if (coo == "English") {
          alert("Please enter the plugin IP");
        } else {
          alert("请输入插件IP");
        }
        return true;
      } else if (gatewayPort == "") {
        if (coo == "English") {
          alert("Please enter the gateway port");
        } else {
          alert("请输入网关端口");
        }
        return true;
      } else if (!reg2.test(gatewayPort)) {
        if (coo == "English") {
          alert("Incorrect gateway port number input");
        } else {
          alert("网关端口错误");
        }
        return true;
      } else if (serverAddress == "") {
        if (coo == "English") {
          alert("Please enter the server address");
        } else {
          alert("请输入服务器地址");
        }
        return true;
      } else if (serverName == "") {
        if (coo == "English") {
          alert("Please enter the server name");
        } else {
          alert("请输入服务器名称");
        }
        return true;
      } else if (readMode == "") {
        if (coo == "English") {
          alert("Please enter the data access mode");
        } else {
          alert("请输入数据读取方式");
        }
        return true;
      } else if (!posIntReg.test(gatewayAddress)) {
        if (coo == "English") {
          alert("Plugin IP address input error");
        } else {
          alert("请输入正确格式的插件IP");
        }
        return true;
      } else {
        return false;
      }
    }
    // add end
    // add by lh,OPC-UA驱动
    else if (type == "OPC-UA") {
      var UAIP = $("#Alter_IPAddress").val();
      var UAPort = $("#Alter_Port").val();
      if (UAIP == "") {
        if (coo == "English") {
          alert("Please enter the server address");
        } else {
          alert("请输入服务器地址");
        }
        return true;
      } else if (UAPort == "") {
        if (coo == "English") {
          alert("Please enter the server port");
        } else {
          alert("请输入服务器端口");
        }
        return true;
      } else if (!reg.test(UAIP)) {
        if (coo == "English") {
          alert("Server IP address input error");
        } else {
          alert("请输入正确格式的IP");
        }
        return true;
      } else if (!reg2.test(UAPort)) {
        if (coo == "English") {
          alert("Server port input error");
        } else {
          alert("请输入正确格式的端口");
        }
        return true;
      } else {
        return false;
      }
    }
    // add end
    else {
      return false;
    }
  }
}
//修改通道方法

function Alter_ChannelMethod() {
  $("#Alter_Channel_Button_Confirm").attr("disabled", "disabled");
  $("#Alter_Channel_Button_Cancel").attr("disabled", "disabled");
  $("#Delete_Channel_Button").attr("disabled", "disabled");
  var params = $("#Alter_Channel_YuToXHZhang").serialize();
  $.ajax({
    type: "post",
    url: "cgi-bin/device/AlterChannel.py",
    data: params,
    async: true,
    success: function (data) {
      $("#Alter_ChannelLayer").hide();
      $("#popWindow").hide();
      $("#Alter_Channel_Button_Confirm").attr("disabled", "");
      $("#Alter_Channel_Button_Cancel").attr("disabled", "");
      $("#Delete_Channel_Button").attr("disabled", "");
      loginUI();
      //iframe中刷新页面
      $("#detail").attr("src", $("#detail").attr("src"));
    },
  });
}
//删除通道

function Delete_Channel(id) {
  //taskID
  if (coo == "English") {
    if (confirm("Are you sure you want to delete this channel?")) {
      if (taskID == "") {
        $("#Alter_TaskID_YuToXHZhang").val("NULL");
      } else {
        $("#Alter_TaskID_YuToXHZhang").val(taskID);
      }
      document.getElementById("Alter_ChannelID_YuToXHZhang").value = id;
      $("#Alter_Channel_Button_Confirm").attr("disabled", "disabled");
      $("#Alter_Channel_Button_Cancel").attr("disabled", "disabled");
      $("#Delete_Channel_Button").attr("disabled", "disabled");
      var params = $("#Alter_Channel_YuToXHZhang").serialize();
      $.ajax({
        type: "post",
        url: "cgi-bin/device/DeleteChannel.py",
        data: params,
        async: true,
        success: function (data) {
          $("#Alter_ChannelLayer").hide();
          $("#popWindow").hide();
          $("#Alter_Channel_Button_Confirm").attr("disabled", "");
          $("#Alter_Channel_Button_Cancel").attr("disabled", "");
          $("#Delete_Channel_Button").attr("disabled", "");
          ChannelNum = 0;
          loginUI();
          //iframe中刷新页面
          $("#detail").attr("src", $("#detail").attr("src"));
        },
      });
    }
  } else {
    if (confirm("确定删除通道？")) {
      if (taskID == "") {
        $("#Alter_TaskID_YuToXHZhang").val("NULL");
      } else {
        $("#Alter_TaskID_YuToXHZhang").val(taskID);
      }
      document.getElementById("Alter_ChannelID_YuToXHZhang").value = id;
      $("#Alter_Channel_Button_Confirm").attr("disabled", "disabled");
      $("#Alter_Channel_Button_Cancel").attr("disabled", "disabled");
      $("#Delete_Channel_Button").attr("disabled", "disabled");
      var params = $("#Alter_Channel_YuToXHZhang").serialize();
      $.ajax({
        type: "post",
        url: "cgi-bin/device/DeleteChannel.py",
        data: params,
        async: true,
        success: function (data) {
          $("#Alter_ChannelLayer").hide();
          $("#popWindow").hide();
          $("#Alter_Channel_Button_Confirm").attr("disabled", "");
          $("#Alter_Channel_Button_Cancel").attr("disabled", "");
          $("#Delete_Channel_Button").attr("disabled", "");
          ChannelNum = 0;
          loginUI();
          //iframe中刷新页面
          $("#detail").attr("src", $("#detail").attr("src"));
        },
      });
    }
  }
}

//初始化新增通道时，将已被占用的com口去掉
function initAddChannelCOM() {
  $("#Add_DeviceID").empty();
  $("#Add_DeviceID").append(
    '<option value="/dev/ttyHS0">Port1(1A 1B)</option><option value="/dev/ttyHS1">Port2(2A 2B)</option>'
  );
  $("#Add_PPI_DeviceID").empty();
  $("#Add_PPI_DeviceID").append(
    '<option value="/dev/ttyHS0">Port1(1A 1B)</option><option value="/dev/ttyHS1">Port2(2A 2B)</option>'
  );
  $.get("../conf/config.xml", function (d1) {
    $(d1)
      .find("model")
      .each(function () {
        var $model = $(this);
        var n = $model.attr("n");
        if (n == "ra-model") {
          return true;
        }
        var config = $model.attr("config");
        $("#Add_DeviceID")
          .find("option")
          .each(function () {
            if (config && config.indexOf($(this).val()) > -1) {
              $(this).remove();
            }
          });
        $("#Add_PPI_DeviceID")
          .find("option")
          .each(function () {
            if (config && config.indexOf($(this).val()) > -1) {
              $(this).remove();
            }
          });
      });
    if ($("#Add_DeviceID").find("option").length == 0) {
      if (coo == "English") {
        $("#Add_DeviceID").append(
          '<option value="-1">No communication is available</option>'
        );
      } else {
        $("#Add_DeviceID").append('<option value="-1">无可用通讯串口</option>');
      }
    }
  });
}

//初始化修改通道时，将已被占用的com口去掉
function initAlterChannelCOM(com) {
  //清空com口下拉框，重新赋予1234口
  $("#Alter_DeviceID").empty();
  $("#Alter_DeviceID").append(
    '<option value="/dev/ttyHS0">Port1(1A 1B)</option><option value="/dev/ttyHS1">Port2(2A 2B)</option>'
  );
  $("#Alter_PPI_DeviceID").empty();
  $("#Alter_PPI_DeviceID").append(
    '<option value="/dev/ttyHS0">Port1(1A 1B)</option><option value="/dev/ttyHS1">Port2(2A 2B)</option>'
  );

  $.get("../conf/config.xml", function (d1) {
    $(d1)
      .find("model")
      .each(function () {
        var $model = $(this);
        var n = $model.attr("n");
        if (n == "ra-model") {
          return true;
        }
        var config = $model.attr("config");
        $("#Alter_DeviceID")
          .find("option")
          .each(function () {
            if ($(this).val() == com) {
              return true;
            }
            if (config && config.indexOf($(this).val()) > -1) {
              $(this).remove();
            }
          });
        $("#Alter_PPI_DeviceID")
          .find("option")
          .each(function () {
            if ($(this).val() == com) {
              return true;
            }
            if (config && config.indexOf($(this).val()) > -1) {
              $(this).remove();
            }
          });
      });
  });
}
// add by whc
//下发数据项
function Open_IssuedLayer2() {
  document.getElementById("popWindow").style.display = "";
  document.getElementById("IssuedLayer2").style.display = "";
  document.getElementById("ConUp1").style.display = "";
  $("#up_success2").hide();
  //      document.getElementById("Hide_IssuedIframe").style.display = 'none'
  document.getElementById("Issued_Button_Confim2").style.display = "";
  document.getElementById("Issued_Button_Cancel2").style.display = "";
  document.getElementById("Issued_Success_Button_Confim2").style.display =
    "none";
  //动态图隐藏
  document.getElementById("Loading2").style.display = "none";
}

function UpConfigCon2() {
  times = 0;
  document.getElementById("IssuedLayer2").style.display = "none";
  window.parent.document.getElementById("IssuedLayer2").style.display = "";
  document.getElementById("ConUp1").style.display = "none";
  document.getElementById("Loading2").style.display = "";
  //document.getElementById("Hide_IssuedIframe").style.display = "none"
  $("#Issued_Button_Confim2").attr("disabled", "disabled");
  $("#Issued_Button_Cancel2").attr("disabled", "disabled");
  $.ajax({
    type: "post",
    url: "cgi-bin/agent/GiveToAgent.py",
    data: "up=1",
    async: false,
    success: function (data) {
      $("#up_success2").html(data);
      document.getElementById("popWindow").style.backgroundColor = "#ddd";
      window.parent.document.getElementById("popWindow").style.display = "";
      window.parent.document.getElementById("IssuedLayer2").style.display = "";
      getagent = setInterval("getAgentStatue()", 5000);
    },
  });
}
//全局一个发送次数
var times = 0;
var getagent = "";

function getAgentStatue() {
  var value = getID();
  $("#Test_Value_YuToXHZhang").val(value);
  var params = $("#Test_DataItemForm_YuToXHZhang").serialize();
  times++;
  //两分钟超时
  if (times < 18) {
    $.ajax({
      type: "post",
      url: "cgi-bin/RealTimeData/GetAgentStatue.py",
      data: params,
      async: true,
      success: function (data) {
        //如果测试返回结果正确，即返回为1，则可以关闭下发窗口
        if (data == 1) {
          $("#up_success2").show();
          $("#Loading2").hide();
          $("#Issued_Button_Confim2").attr("disabled", "");
          $("#Issued_Button_Cancel2").attr("disabled", "");
          $("#Issued_Button_Confim2").hide();
          $("#Issued_Button_Cancel2").hide();
          $("#Issued_Success_Button_Confim2").show();
          $("#ConUp1").hide();
          window.parent.document.getElementById("popWindow").style.display =
            "none";
          document.getElementById("popWindow").style.backgroundColor =
            "#9D9D9D";
          window.parent.document.getElementById("IssuedLayer2").style.display =
            "none";
          document.getElementById("IssuedLayer2").style.display = "";
          clearInterval(getagent);
        } else {
        }
      },
    });
  } else {
    $("#Issued_Button_Confim2").attr("disabled", "");
    $("#Issued_Button_Cancel2").attr("disabled", "");
    document.getElementById("IssuedLayer2").style.display = "";
    window.parent.document.getElementById("popWindow").style.display = "none";
    document.getElementById("popWindow").style.backgroundColor = "#9D9D9D";
    // window.parent.document.getElementById("IssuedLayer2").style.display = 'none';
    document.getElementById("Loading2").style.display = "none";
    if (coo == "English") {
      document.getElementById("up_success2").innerHTML =
        "Agent startup timeout, please try again later";
    } else {
      document.getElementById("up_success2").innerHTML =
        "agent启动超时，请稍后再试";
    }
    document.getElementById("up_success2").style.display = "";
    document.getElementById("ConUp1").style.display = "none";
    document.getElementById("Issued_Button_Confim2").style.display = "none";
    document.getElementById("Issued_Success_Button_Confim2").style.display = "";
    clearInterval(getagent);
  }
}

function getID() {
  var id = "";
  $.ajax({
    type: "get",
    url: "../conf/config.xml",
    async: false,
    success: function (data) {
      $(data)
        .find("model")
        .each(function () {
          var $model = $(this);
          ChannelName = $model.attr("n");
          if (ChannelName == "ra-model") {
            return true;
          } else {
            ChannelID = $model.attr("id");
            ChannelDriver = $model.attr("d");
            $model.find("device").each(function () {
              var $device = $(this);
              DeviceID = $device.attr("id");
              $device.find("driver").each(function () {
                var $driver = $(this);
                driverID = $driver.attr("id");
                $device.find("commDataItems").each(function () {
                  var $commDataItems = $(this);
                  $commDataItems.find("dataItem:first-child").each(function () {
                    var $dataItem = $(this);
                    dataItemID = $dataItem.attr("id");
                    id = dataItemID;
                  });
                });
              });
            });
          }
        });
    },
  });
  //拼出测试字符串

  var value = "";
  var ChannelDriverArr = new Array();
  ChannelDriverArr = ChannelDriver.split(":");
  var ChannelDriverShort = ChannelDriverArr[1];
  if (ChannelID != "") {
    if (DeviceID != "") {
      if (id == "") {
        //没有数据的时候
        value =
          '{"id":' +
          DeviceID +
          ',"dn":"","vid":' +
          driverID +
          ',"vn":"' +
          ChannelDriverShort +
          '", "cmds":{"read":1}}';
      } else {
        //有数据的时候
        value =
          '{"id":' +
          DeviceID +
          ',"dn":"","vid":' +
          driverID +
          ',"vn":"' +
          ChannelDriverShort +
          '", "cmds":{"read":0,"ids":[' +
          id +
          "]}}";
      }
      return value;
    } else {
      if (coo == "English") {
        $("#up_success2").show().html("Push success!");
      } else {
        $("#up_success2").show().html("下发成功！");
      }
      $("#Loading2").hide();
      $("#Issued_Button_Confim2").attr("disabled", "");
      $("#Issued_Button_Cancel2").attr("disabled", "");
      $("#Issued_Button_Confim2").hide();
      $("#Issued_Button_Cancel2").hide();
      $("#Issued_Success_Button_Confim2").show();
      $("#ConUp1").hide();
      window.parent.document.getElementById("popWindow").style.display = "none";
      document.getElementById("popWindow").style.backgroundColor = "#9D9D9D";
      window.parent.document.getElementById("IssuedLayer2").style.display =
        "none";
      document.getElementById("IssuedLayer2").style.display = "";
      clearInterval(getagent);
      return true;
    }
  } else {
    if (coo == "English") {
      $("#up_success2").show().html("Push success!");
    } else {
      $("#up_success2").show().html("下发成功！");
    }
    $("#Loading2").hide();
    $("#Issued_Button_Confim2").attr("disabled", "");
    $("#Issued_Button_Cancel2").attr("disabled", "");
    $("#Issued_Button_Confim2").hide();
    $("#Issued_Button_Cancel2").hide();
    $("#Issued_Success_Button_Confim2").show();
    $("#ConUp1").hide();
    window.parent.document.getElementById("popWindow").style.display = "none";
    document.getElementById("popWindow").style.backgroundColor = "#9D9D9D";
    window.parent.document.getElementById("IssuedLayer2").style.display =
      "none";
    document.getElementById("IssuedLayer2").style.display = "";
    clearInterval(getagent);
    return true;
  }
}
