// 设备页面跳转、警告切回数据项的跳转方法
// 其中txt为传递的驱动value值，返回值1代表最基础的PLC协议，返回值2代表Modbus协议，返回值3代表MPI协议

function locationhref(txt) {
  switch (txt) {
    case "SIEMENS-PPI":
      return 1;
    case "OMRON-HostLink":
      return 1;
    case "MITSUBISHI-FXP":
      return 1;
    case "MITSUBISHI-FXS":
      return 1;
    case "MITSUBISHI-QS":
      return 3;
    case "MITSUBISHI-QN":
      return 3;
    case "MITSUBISHI-Q":
      return 3;
    case "OMRON-FINS":
      return 1;
    case "OMRON-TCP":
      return 1;
    case "test":
      return 1;
    case "Panasonic":
      return 1;
    case "Modbus-RTU":
      return 2;
    case "Modbus-RTU-task":
      return 2;
    case "Modbus-ASCII":
      return 2;
    case "Modbus-ASCII-task":
      return 2;
    case "Modbus-TCP":
      return 2;
    case "Modbus-TCP-task":
      return 2;
    case "Schneider-RTU":
      return 2;
    case "Schneider-ASCII":
      return 2;
    case "Schneider-TCP":
      return 2;
    case "Detal-ASCII":
      return 2;
    case "Detal-RTU":
      return 2;
    case "Detal-TCP":
      return 2;
    case "XinjieXC3-RTU":
      return 2;
    case "XinjieXC3-ASCII":
      return 2;
    case "XinjieXD3-RTU":
      return 2;
    case "XinjieXD3-ASCII":
      return 2;
    case "SIEMENS-MPI":
      return 3;
    case "SIEMENS-Ethernet":
      return 3;
    case "BacNet-IP":
      return 4;
    case "BacNet-MS/TP":
      return 4;
    case "AB-DF1":
      return 3;
    case "AB-Ethernet/IP":
      return 3;
    case "AB-MicroLogix":
      return 3;
    case "M-Bus-serial":
      return 5;
    case "M-Bus-TCP":
      return 5;
    case "YinHe":
      return 1;
    case "Zundar":
      return 1;
    case "OMRON_NJNX":
      return 1;
    case "HKG-SERIAL":
      return 1;
    case "Custom-TCP":
      return 1;
    case "TwinCAT":
      return 3;
    case "GPS":
      return 1;
    // add begin by x
    case "JB3102":
      return 1;
    case "JB3208":
      return 1;
    // end add
    // add begin by x
    case "BacNet-IP-task":
      return 4;
    case "BacNet-MS/TP-task":
      return 4;
    // end add
    // add by whc,增加FATEK编程口驱动
    case "FATEK编程口":
      return 1;
    // add end
    // add by whc
    case "DRACAL":
      return 1;
    // add end
    // add by fyj, 增加OCR驱动
    // add begin
    case "OCR":
      return 6;
    // end add
    // add by fyj
    // add begin
    case "KUKA":
      return 1;
    // add by fyj
    case "CloudWeb":
      return 7;
    // add end
    // add by fyj, 增加DLT645-2007
    case "DLT645-2007":
      return 1;
    // add end
    case "DLT645-1997":
      return 1;
    // add end
    case "OPC":
      return 1;
    // add by whc
    case "SIEMENS-S7-PPI-Task":
      return 1;
    // add by fyj
    case "OMRON-HostLink-Task":
      return 1;
    case "OMRON-FINS-Task":
      return 1;
    case "OPC-UA":
      return 1;
    // add end
    // add by lh
    case "IEC104":
      return 1;
    case "device":
      return 1;
    case "HMI":
      return 1;
    case "MITSUBISHI-TXZ-MomMach":
      return 1;
    case "MITSUBISHI-TXZ-SubMach1":
      return 1;
    case "MITSUBISHI-TXZ-SubMach2":
      return 1;
    case "MITSUBISHI-TX-5HP":
      return 1;
    case "MITSUBISHI-TX-15P":
      return 1;
    case "MITSUBISHI-TX-Multi-link":
      return 1;
    case "R1R2":
      return 1;
    // add end
    // author: jinxin.zhou Da_RA传过来devicedriver是空的
    // default:
    //     alert('Sorry');
  }
}
