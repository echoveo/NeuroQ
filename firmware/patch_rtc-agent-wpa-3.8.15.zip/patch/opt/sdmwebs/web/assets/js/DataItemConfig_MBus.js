document.writeln("<script src=\"assets/js/effect_Com.js?t=" + (new Date()).getTime() + "\" type=\"text/javascript\" charset=\"utf-8\"></script>");
document.writeln("<" + "script language='javascript' src='assets/js/language.js?t=" + (new Date()).getTime() + "'></" + "script>");

CheckLogin();
$.ajaxSetup({
    cache: false
});
//全局变量
var diffCol = 1000000000000;
var EditChange = 100000000000000;
//通道ID
var ChannelID = "";
//设备ID
var DeviceID = "";
//驱动ID
var DriverID = "";
//校验所需要的
var category = "";
//数据项总数    
var DataItemNum = "";
//设备驱动类型
var ChannelDriver = "";
//设备的驱动类型
var ChannelDeviceType = "";
var coo = '';
//根据传值获取通道ID和设备ID
function initUI() {
    //传值
    var string = decodeURIComponent(document.location.search).substr(1);
    var logArr = new Array();
    logArr = string.split("=");
    ChannelID = string.split("&")[0].split("=")[1];
    DeviceID = string.split("&")[1].split("=")[1];
}
//点击切告警和数据项
$("#dataTab").click(function () {
    window.location.href = "../DataItemConfig_MBus.html?channelid=" + ChannelID + "&deviceid=" + DeviceID + "&t=" + (new Date()).getTime();
});
$("#rulesTab").click(function () {
    window.location.href = "../Alarm.html?channelid=" + ChannelID + "&deviceid=" + DeviceID + "&t=" + (new Date()).getTime();
});
$("#computeTab").click(function () {
    window.location.href = "../ConditionalUpload.html?channelid=" + ChannelID + "&deviceid=" + DeviceID + "&t=" + (new Date()).getTime();
});

//帧类型切换
$("#Add_DataItemFrameType").change(function () {
    if ($(this).val() == "snd_ud") {
        $("tr[name='moreControl']").show();
        $("tr[name='req2_id']").hide();
        $("tr[name='beilv']").hide();
    } else if ($(this).val() == "req2") {
        $("tr[name='moreControl']").hide();
        $("tr[name='req2_id']").show();
        $("tr[name='beilv']").show();
    } else {
        $("tr[name='moreControl']").hide();
        $("tr[name='req2_id']").hide();
        $("tr[name='beilv']").hide();
    }
});
$("#Alter_DataItemFrameType").change(function () {
    if ($(this).val() == "snd_ud") {
        $("tr[name='AltermoreControl']").show();
        $("tr[name='AlterReq2_id']").hide();
        $("tr[name='beilv']").hide();
    } else if ($(this).val() == "req2") {
        $("tr[name='AltermoreControl']").hide();
        $("tr[name='AlterReq2_id']").show();
        $("tr[name='beilv']").show();
    } else {
        $("tr[name='AltermoreControl']").hide();
        $("tr[name='AlterReq2_id']").hide();
        $("tr[name='beilv']").hide();
    }
});
//根据通道ID、设备ID读数据项
$(document).ready(function () {
    initUI();
    getID();
    getData();
    coo = getCookie("AnyLinkLan");
    if (coo == "English") {
        $(".AutoRefresh").css("left", "289px");
        $("#computeTab").css("width", "100px");
    } else {
        $(".AutoRefresh").css("left", "77px");
        $("#computeTab").css("width", "60px");
    }
});
//根据通道ID、设备ID读数据项
function getData() {
    getID();
    $("#allItemName").empty();
    DataItemNum = 0;
    $("#DataItemNum").empty();
    $("#info").empty();
    $("#itemTable tr").empty("");
    $("#itemTable  tr").css("display", "none");
    $.get('../conf/config.xml', function (d1) {
        $(d1).find("model[id='" + ChannelID + "']").each(function () {
            var $model = $(this);
            var modelid = $model.attr('id');
            var modeln = $model.attr('n');
            var modeld = $model.attr('d');
            ChannelDriver = $model.attr("d");
            $("#ChannelName").html(modeln);
            $("#ChannelName").attr("title", modeln);
            $model.find("device[id='" + DeviceID + "']").each(function () {
                var $device = $(this);
                var deviceid = $device.attr('id');
                var deviceip = $device.attr('ip');
                var devicen = $device.attr('n');
                var driverId = '';
                $device.find('driver').each(function () {
                    var $driver = $(this);
                    var config = $driver.attr('config');
                    driverId = $driver.attr('id');
                    var configArr = new Array();
                    configArr = config.split(";");
                    category = configArr[0];
                    ItemConfigHelp(category);
                });
                $("#DeviceName").html(devicen);
                $("#DeviceName").attr("title", devicen);
                $device.find("commDataItems").each(function () {
                    var $commDataItems = $(this);
                    $commDataItems.find("dataItem").each(function () {
                        var $dataItem = $(this);
                        var dataItemN = $dataItem.attr('n');
                        var dataItemA = $dataItem.attr('alias');
                        var dataItemID = $dataItem.attr('id');
                        var dataItemFreq = $dataItem.attr('freq');
                        var dataItemReport1 = $dataItem.attr('report');
                        var dataItemType1 = $dataItem.attr("type");
                        var dataItemReport = "";
                        if (coo == "English") {
                            if (dataItemReport1 == "0") {
                                dataItemReport = "Not report"
                            } else if ( dataItemReport1 == "2") {
                                dataItemReport = "change report"
                            } else {
                                dataItemReport = "Report"
                            }
                        } else {
                            if (dataItemReport1 == "0") {
                                dataItemReport = "不上传"
                            }  else if ( dataItemReport1 == "2") {
                                dataItemReport = "变化上传"
                            } else {
                                dataItemReport = "全部上传"
                            }
                        }
                        var dataItemWR1 = $dataItem.attr('rw');
                        var dataItemWR = "";
                        if (coo == "English") {
                            if (dataItemWR1 == "0")
                                dataItemWR = "Read"
                            if (dataItemWR1 == "1")
                                dataItemWR = "Read&Write"
                        } else {
                            if (dataItemWR1 == "0")
                                dataItemWR = "只读"
                            if (dataItemWR1 == "1")
                                dataItemWR = "可写"
                        }

                        var dataItemConfig = $dataItem.attr('config');
                        var ConfigArr = new Array();
                        ConfigArr = dataItemConfig.split(";");
                        var frameType = ConfigArr[0];
                        var tableAddress = "";
                        if (ConfigArr.length > 3) {
                            tableAddress = ConfigArr[2];
                        } else {
                            tableAddress = ConfigArr[1];
                        }
                        tableAddress = tableAddress.split(":")[1];

                        diffCol++;
                        EditChange++;
                        DataItemNum++;
                        var list = "<tr id=" + diffCol + " class='diffC' onMouseOver='Highlight(id)' onMouseOut='HideHighlight(id)' onDblClick='Open_Alter_DataItem_Layer(" + dataItemID + ")'>" +
                            "<td>" + "<input name='tryadd' type='checkbox' value='" + dataItemID + "'>" + "</td>" +
                            "<td>" + dataItemID + "</td>" +
                            "<td class='nameAliasWidth'>" + dataItemN + "</td>" +
                            "<td class='nameAliasWidth'>" + dataItemA + "</td>" +
                            "<td class='nameAliasWidth'>" + frameType + "</td>" +
                            "<td class='nameAliasWidth'>" + tableAddress + "</td>"
                        if (coo == "English") {
                            list += "<td>" + dataItemFreq / 1000 + "s</td>"
                        } else {
                            list += "<td>" + dataItemFreq / 1000 + "秒</td>"
                        }
                        list = list + "<td>" + dataItemReport + "</td>" +
                            "<td>" +
                            "<img src='assets/img/bianji_ico.png' onClick='Open_Alter_DataItem_Layer(" + dataItemID + ")' class='edit' title='编辑'>" +
                            "&nbsp;<img src='assets/img/xieru_ico.png'  onClick='open_write_layer(" + JSON.stringify({
                                'id': +deviceid,
                                'dn': '',
                                'vn': modeld.split(":")[1],
                                'vid': +driverId,
                                'cmds': [{
                                    'dt': dataItemType1,
                                    'cfg': dataItemConfig,
                                    'itemid': dataItemID,
                                    'rw': dataItemWR1
                                }]
                            }).replace(/"/g, '&quot;') + ")' class='write i18n-input' selectname='WriteOperation' selectattr='title' >" + "</td>" +
                            "</tr>"
                        $("#itemTable").append(list);
                        if (coo == "English") {
                            $(".edit").attr("title", "Edit");
                            $(".write").attr("title", "Write");
                        } else {
                            $(".edit").attr("title", "编辑");
                            $(".write").attr("title", "写入");
                        }
                        if (diffCol % 2 == "0")
                            document.getElementById(diffCol).className = "diffC1";
                        if (coo == "English") {
                            document.getElementById("DataItemNum").innerHTML = "Total number of dataItems: " + "<strong>" + DataItemNum + "</strong>" + " &nbsp; ";
                        } else {
                            document.getElementById("DataItemNum").innerHTML = "数据项总数： " + "<strong>" + DataItemNum + "</strong>" + " &nbsp; ";
                        }
                        var allName = dataItemN + ";"
                        $("#allItemName").append(allName);
                    });
                    $(".edit").mouseover(function () {
                        $(this).attr("src", "assets/img/bianji_hover_ico.png");
                        this.myTitle = this.title;
                        this.title = "";
                        var tooltip = "<div id='tooltip'>" + this.myTitle + "</div>";
                        $("body").append(tooltip);
                        var width = parseInt($("#tooltip").css("width")) + 10;
                        $("#tooltip").css("top", y + "px")
                        $("#tooltip").css("left", x + "px")
                        $("#tooltip").css("width", width + "px")
                    });
                    $(".edit").mouseout(function () {
                        $(this).attr("src", "assets/img/bianji_ico.png");
                        this.title = this.myTitle;
                        $("#tooltip").remove();
                    });
                });
            });
        });
    });
}
//点击返回效果
function ReturnToDevice() {
    window.location.href = "../Device_PLC_Change.html?id=" + ChannelID + "&t=" + (new Date()).getTime();
}
//移动高亮显示

function Highlight(txt) {
    document.getElementById(txt).className = "diffC2";
}

function HideHighlight(txt) {
    if (txt % 2 == "0")
        document.getElementById(txt).className = "diffC1";
    else
        document.getElementById(txt).className = "diffC";
}
//全局变量当前编辑的名称
var NowItemName = "";
//根据设备ID和数据项ID查找数据项信息并显示
function Open_Alter_DataItem_Layer(txt) {
    //清空错误信息
    document.getElementById('idTipInfo').innerHTML = "";
    document.getElementById('nameTipInfo').innerHTML = "";
    document.getElementById('AliasTipInfo').innerHTML = "";
    document.getElementById('freqTipInfo').innerHTML = "";
    document.getElementById('tableAddressTipInfo').innerHTML = "";
    document.getElementById('controlBitTipInfo').innerHTML = "";
    document.getElementById('controlInfoTipInfo').innerHTML = "";
    document.getElementById('tableSAAddressTipInfo').innerHTML = "";
    document.getElementById('dataDomainTipInfo').innerHTML = "";
    document.getElementById('req2IdTipInfo').innerHTML = "";

    //add datahandler
    $("#line_Alter_DataItemDHEnable").show();
    $("#DHMode1_alter").attr('checked', 'checked');
    $('#RWmode2Info').attr('disabled', false);
    $('#Alter_DataItemDHSelect').val('1');
    $('#Alter_DataItemDHParam').val('');
    $("#Alter_DHFunctionParam1").val("");
    $("#Alter_DHFunctionParam2").val("");
    $("#line_Alter_DataItemDHOpt").hide();
    $("#line_Alter_DataItemDHParamTip").hide();

    //将ID赋值给表单
    document.getElementById("Alter_DataItemID_YuToXHZhang").value = txt;

    document.getElementById("popWindow").style.display = '';
    document.getElementById("Alter_DataItem_Layer").style.display = '';


    $(document).ready(function () {
        $.get('../conf/config.xml', function (d1) {
            $(d1).find("model").each(function () {
                var $model = $(this);
                $model.find("device[id='" + DeviceID + "']").each(function () {
                    var $device = $(this);
                    $device.find("commDataItems").each(function () {
                        var $commDataItems = $(this);
                        $commDataItems.find("dataItem[id='" + txt + "']").each(function () {
                            var $dataItem = $(this);
                            var dataItemN = $dataItem.attr('n');
                            NowItemName = dataItemN;
                            var dataItemA = $dataItem.attr('alias');
                            var dataItemID = $dataItem.attr('id');
                            var dataItemFreq = $dataItem.attr('freq');
                            var dataItemReport = $dataItem.attr('report');
                            var dataItemType = $dataItem.attr('type');
                            $("#Alter_DataItemType").val(dataItemType);
                            /*author: jinxin.zhou*/
                            var dataItemWR = $dataItem.attr('rw');
                            if (dataItemReport == "3") {
                                $("input[name='Alter_ReportType']").each(function(){
                                    if($(this).val()=='1'){
                                        $(this).attr("checked",true);
                                    }
                                })
                            } else {
                                $("input[name='Alter_ReportType']").each(function(){
                                    if($(this).val()==dataItemReport){
                                        $(this).attr("checked",true);
                                    }
                                })
                            }
                            if (dataItemWR == "0")
                                document.getElementById("RWmode1Info").checked = "checked";
                            if (dataItemWR == "1")
                                document.getElementById("RWmode2Info").checked = "checked";
                            $("#Alter_DataItemID").val(txt);
                            document.getElementById("Alter_DataItemName").value = dataItemN;
                            document.getElementById("Alter_DataItemAlias").value = dataItemA;
                            var Freq = "";
                            if (dataItemFreq % 60000 == 0) {
                                Freq = dataItemFreq / 60000;
                                $("#Alter_DataItemUnit").val("minute");
                            } else {
                                Freq = dataItemFreq / 1000;
                                $("#Alter_DataItemUnit").val("second");
                            }
                            document.getElementById("Alter_DataItemFreq").value = Freq;
                            // document.getElementById("Alter_DataItemReport").value = dataItemReport;

                            var configAry = $dataItem.attr("config").split(";");
                            var frameType = configAry[0];
                            if (frameType == "snd_ud") {
                                $("#Alter_DataItemFrameType").val(frameType);
                                $("input[name='Alter_DataItemTableAddress']").val(configAry[2].split(":")[1]);
                                $("input[name='Alter_DataItemControlBit']").val(configAry[1].split(":")[1]);
                                $("input[name='Alter_DataItemControlInfo']").val(configAry[3].split(":")[1]);
                                $("input[name='Alter_DataItemTableSAAddress']").val(configAry[4].split(":")[1]);
                                $("input[name='Alter_DataItemDataDomain']").val(configAry[5].split(":")[1]);
                                $("tr[name='AltermoreControl']").show();
                                $("tr[name='AlterReq2_id']").hide();
                                $("tr[name='beilv']").hide();
                            } else if (frameType == "req2") {
                                $("#Alter_DataItemFrameType").val(frameType);
                                $("input[name='Alter_DataItemTableAddress']").val(configAry[1].split(":")[1]);
                                $("input[name='Alter_DataItemReq2Id']").val(configAry[2].split(":")[1]);
                                $("input[name='Alter_DataItemBeilv']").val(configAry[3].split(":")[1]);
                                $("tr[name='AltermoreControl']").hide();
                                $("tr[name='AlterReq2_id']").show();
                                $("tr[name='beilv']").show();
                            } else {
                                $("#Alter_DataItemFrameType").val(frameType);
                                $("input[name='Alter_DataItemTableAddress']").val(configAry[1].split(":")[1]);
                                $("tr[name='AltermoreControl']").hide();
                                $("tr[name='AlterReq2_id']").hide();
                                $("tr[name='beilv']").hide();
                            }

                        });
                    });
                });
            });
            //add datahandler
            $(d1).find('task dataHandler item[id="' + txt + '"]').each(function () {
                $('#line_Alter_DataItemDHEnable').show();
                $('#line_Alter_DataItemDHOpt').show();
                $('#line_Alter_DataItemDHParamTip').show();
                var dhItem = $(this);
                $("#DHMode2_alter").attr("checked", "checked");
                var dhOptType = dhItem.attr('op');
                var dhOptParam = dhItem.attr('coe');
                if (dhOptType == '+') {
                    dhOptType = '1';
                } else if (dhOptType == '-') {
                    dhOptType = '2';
                } else if (dhOptType == '*') {
                    dhOptType = '3';
                } else if (dhOptType == '/') {
                    dhOptType = '4';
                } else if (dhOptType == 'b') {
                    dhOptType = '5';
                    // $('#RWmode2Info').attr('disabled', true);
                }
                $('#Alter_DataItemDHSelect').val(dhOptType);
                if(dhOptType=="#" ){
                    $("#Alter_DataItemDHParam").hide();
                    $("#Alter_DHFunctionParam1").show();
                    $("#Alter_DHFunctionParam2").show();
                    var reBrackets = /\([^\)]+\)/g;
                    var coeList = dhOptParam.match(reBrackets);
                    $("#Alter_DHFunctionParam1").val(coeList[0].substring(1,coeList[0].length-1) );
                    $("#Alter_DHFunctionParam2").val(coeList[1].substring(1,coeList[1].length-1) );
                  }else{
                    $("#Alter_DataItemDHParam").show();
                    $("#Alter_DHFunctionParam1").hide();
                    $("#Alter_DHFunctionParam2").hide();
                    $("#Alter_DataItemDHParam").val(dhOptParam);
                  }
            });
        });
    });
}
//弹出PLC数据项添加层


// add by fyj, OMRON-HostLink增加datahandler驱动
function DHEnableClicked(radioVal) {
    if (radioVal == '0') {
        $('#line_Add_DataItemDHOpt').hide();
        $('#line_Add_DataItemDHParamTip').hide();
    } else {
        $('#line_Add_DataItemDHOpt').show();
        $('#line_Add_DataItemDHParamTip').show();
    }
}

function DHEnableClicked_alter(radioVal) {
    if (radioVal == '0') {
        $('#line_Alter_DataItemDHOpt').hide();
        $('#line_Alter_DataItemDHParamTip').hide();
    } else {
        $('#line_Alter_DataItemDHOpt').show();
        $('#line_Alter_DataItemDHParamTip').show();
    }
}

function ChangeDHSelect(dhSelect) {
    var optType = $(dhSelect).val();
    if (optType == "#") {
      $("#Add_DataItemDHParam").hide();
      $("#Add_DHFunctionParam1").show();
      $("#Add_DHFunctionParam2").show();
    } else {
      $("#Add_DataItemDHParam").show();
      $("#Add_DHFunctionParam1").hide();
      $("#Add_DHFunctionParam2").hide();
    }
}

function ChangeDHSelect_alter(dhSelect) {
    var optType = $(dhSelect).val();
    if (optType == "#") {
      $("#Alter_DataItemDHParam").hide();
      $("#Alter_DHFunctionParam1").show();
      $("#Alter_DHFunctionParam2").show();
    } else {
      $("#Alter_DataItemDHParam").show();
      $("#Alter_DHFunctionParam1").hide();
      $("#Alter_DHFunctionParam2").hide();
    }
}

function openPLCadd() {
    getID();
    document.getElementById("Add_DataItemName").value = "";
    document.getElementById("Add_DataItemAlias").value = "";
    $("input[name='Add_DataItemTableAddress']").val("");
    $("input[name='Add_DataItemControlBit']").val("");
    $("input[name='Add_DataItemControlInfo']").val("");
    $("input[name='Add_DataItemTableSAAddress']").val("");
    $("input[name='Add_DataItemDataDomain']").val("");

    document.getElementsByName("Add_DataItemRWmode").value = "0";
    // document.getElementById("Add_DataItemReport").value = "1"
    $("input[name='Add_ReportType']").each(function(){
        if($(this).val()=="1"){
            $(this).attr("checked",true);
        }
    })
    //清空错误信息
    document.getElementById('idTip').innerHTML = "";
    document.getElementById('nameTip').innerHTML = "";
    document.getElementById('AliasTip').innerHTML = "";
    document.getElementById('freqTip').innerHTML = "";
    document.getElementById('tableAddressTip').innerHTML = "";
    document.getElementById('controlBitTip').innerHTML = "";
    document.getElementById('controlInfoTip').innerHTML = "";
    document.getElementById('tableSAAddressTip').innerHTML = "";
    document.getElementById('dataDomainTip').innerHTML = "";
    $("#Add_DataItemFrameType").val("snd_ud");
    $("tr[name='moreControl']").show();

    document.getElementById("popWindow").style.display = '';
    document.getElementById("Add_DataItem_Layer").style.display = '';

    $('#line_Add_DataItemDHEnable').show();
    $('#DHMode1').attr('checked', 'checked');
    $('#RWmode2').attr('disabled', false);
    $("#Add_DataItemDHParam").show();
    $("#Add_DHFunctionParam1").hide();
    $("#Add_DHFunctionParam2").hide();
    $('#line_Add_DataItemDHOpt').hide();
    $('#line_Add_DataItemDHParamTip').hide();
    $('#Add_DataItemDHParam').val('');
    $('#Add_DataItemDHSelect').val('1');
    $("#Add_DHFunctionParam1").val("");
    $("#Add_DHFunctionParam2").val("");
}
//弹出删除层

function openDeleteLayer() {
    CheckedLength();
    document.getElementById("popWindow").style.display = "";
    document.getElementById("DeleteDataItemLayer").style.display = "";
    if (document.getElementById("AllDataitemID").value == "") {
        document.getElementById("NoDataItemChecked").style.display = "";
        document.getElementById("DeleteChecked").style.display = "none";
        document.getElementById("DeleteDataItem_Button_Confim").style.display = "none";
        document.getElementById("DeleteDataItem_Button_Cancel").style.display = "none";
        document.getElementById("DeleteDataItem_Success_Button_Confim").style.display = "";
    } else {
        document.getElementById("NoDataItemChecked").style.display = "none";
        document.getElementById("DeleteChecked").style.display = "";
        if (coo == "English") {
            document.getElementById("DeleteChecked").innerHTML = "Make sure to delete the selected<strong> &nbsp;" + checkLength + "&nbsp; </strong>dataItems?";
        } else {
            document.getElementById("DeleteChecked").innerHTML = "确定要删除选中的<strong> &nbsp;" + checkLength + "&nbsp; </strong>个数据项吗？";
        }
        document.getElementById("DeleteDataItem_Button_Confim").style.display = "";
        document.getElementById("DeleteDataItem_Button_Cancel").style.display = "";
        document.getElementById("DeleteDataItem_Success_Button_Confim").style.display = "none";
    }
}
//弹出帮助层

function Open_DataItemHelpLayer() {
    if (document.getElementById("Help_DataItemLayer").style.display == "none")
        document.getElementById("Help_DataItemLayer").style.display = ''
    else
        document.getElementById("Help_DataItemLayer").style.display = 'none'
}
//缺省 单选按钮
function changeReport() {
    if (document.getElementById("DataItemReport1").checked)
        document.getElementById("Add_DataItemReport").value = "1";
    else
        document.getElementById("Add_DataItemReport").value = "0";
}

function changeReportInfo() {
    if (document.getElementById("Alter_DataItemReport1").checked)
        document.getElementById("Alter_DataItemReport").value = "1";
    else
        document.getElementById("Alter_DataItemReport").value = "0";
}
//检查重名
function CheckReName(txt) {
    var string = document.getElementById("allItemName").innerHTML;
    var NameArr = new Array();
    NameArr = string.split(";");
    for (var i = 0; i < NameArr.length - 1; i++) {
        //alert(NameArr[i])
        if (txt != NameArr[i]) {} else {
            return false;
        }
    }
    return true;
}
//检查数据项名称输入格式
function Check_Chinese_Character(txt) {
    var str = txt;
    var re = /^[A-Za-z]\w*$/;
    if (re.test(str)) {
        return true;
    } else {
        return false;
    }
}
//添加数据项的校验
function Check_Add_DataItem() {
    var CheckID = $("#Add_DataItemID").val();
    var CheckName = $("#Add_DataItemName").val();
    var Alies = $("#Add_DataItemAlias").val();
    var Freq = $("#Add_DataItemFreq").val();
    var reg = new RegExp("^[0-9]+$");
    var regID = new RegExp("^[1-9]+[0-9]*$");
    //校验数据项ID输入格式
    if (CheckID == "" || !regID.test(CheckID)) {
        if (coo == "English") {
            $("#idTip").html("The dataItem ID must be a non-negative integer");
        } else {
            $("#idTip").html("数据项ID必须为非负整数");
        }
    } else {
        $.ajax({
            type: "get",
            url: "../conf/config.xml",
            async: false,
            success: function (data) {
                var flag = true;
                $(data).find("model").each(function () {
                    var $model = $(this);
                    $model.find("device").each(function () {
                        var $device = $(this);
                        $device.find("commDataItems").each(function () {
                            var $commDataItems = $(this);
                            $commDataItems.find("dataItem").each(function () {
                                var $dataItem = $(this);
                                var dataItemID = $dataItem.attr('id');
                                if (dataItemID == CheckID) {
                                    if (coo == "English") {
                                        $("#idTip").html("The dataItem ID is repeated, please change");
                                    } else {
                                        $("#idTip").html("数据项ID已重复，请更改");
                                    }
                                    flag = false;
                                }
                            });
                        });
                    });
                });
                if (flag) {
                    $("#idTip").html("");
                }
            }
        });
    }

    //校验数据项名称输入格式
    if (!Check_Chinese_Character(CheckName)) {
        if (coo == "English") {
            $("#nameTip").html("*The dataItem name format error, only the alphanumeric underscore and must start with the letter");
        } else {
            $("#nameTip").html("*数据项名称格式错误，仅允许字母数字下划线且必须以字母开头");
        }
    } else {
        //校验数据项名称是否重名
        if (!CheckReName(CheckName)) {
            if (coo == "English") {
                $("#nameTip").html("The dataItem name is repeated");
            } else {
                $("#nameTip").html("数据项名称重复");
            }
        } else {
            $("#nameTip").html("");
        }
    }
    //校验数据项别名不为空
    if (Alies == "") {
        if (coo == "English") {
            $("#AliasTip").html("*Please fill in the alias");
        } else {
            $("#AliasTip").html("*请填写别名");
        }
    } else {
        $("#AliasTip").html("");
    }
    //校验频率不为空
    if (Freq == "") {
        if (coo == "English") {
            $("#freqTip").html("*Please fill in the sample frequency")
        } else {
            $("#freqTip").html("*请填写采集频率")
        }
    } else {
        if (!reg.test(Freq) || Freq == 0) {
            if (coo == "English") {
                $("#freqTip").html("*The frequencies must be positive integers");
            } else {
                $("#freqTip").html("*频率必须为正整数");
            }
        } else {
            $.ajax({
              type: "get",
              url: "../conf/Common.xml",
              async: false,
              success: function (data) {
                var minFrequency = $(data).find("MinFrequency").text();
                var currentFreq = 0;
                if ($("#Add_DataItemUnit").val() == "second") {
                  currentFreq = parseInt(Freq) * 1000;
                } else {
                  currentFreq = parseInt(Freq) * 1000 * 60;
                }

                if (currentFreq < parseInt(minFrequency)) {
                  if (coo == "English") {
                    $("#freqTip").html(
                      "*The lowest frequency currently supported is" +
                        minFrequency / 1000 +
                        "seconds"
                    );
                  } else {
                    $("#freqTip").html(
                      "*当前支持的最低频率为" + minFrequency / 1000 + "秒"
                    );
                  }
                } else {
                  $("#freqTip").html("");
                }
              },
            });
        }
    }
    //校验表地址
    var tableAddress = $('input[name="Add_DataItemTableAddress"]').val();
    regex = /^[0-9ABCDEF]*$/;
    if (tableAddress == "") {
        if (coo == "English") {
            $('#tableAddressTip').html('*Please fill in the table address');
        } else {
            $('#tableAddressTip').html('*请填写表地址');
        }
    } else {
        if (!regex.test(tableAddress)) {
            if (coo == "English") {
                $('#tableAddressTip').html('*The table address must be a hexadecimal number');
            } else {
                $('#tableAddressTip').html('*表地址必须是16进制数');
            }
        } else {
            $('#tableAddressTip').html('');
        }
    }

    //根据帧类型验证C,CI,SA,D
    if ($("#Add_DataItemFrameType").val() == "snd_ud") {
        var c = $("input[name='Add_DataItemControlBit']").val();
        var ci = $("input[name='Add_DataItemControlInfo']").val();
        var sa = $("input[name='Add_DataItemTableSAAddress']").val();
        var d = $("input[name='Add_DataItemDataDomain']").val();
        $('#req2IdTip').html('');
        if (c == "") {
            if (coo == "English") {
                $("#controlBitTip").html("Please fill in the control bit");
            } else {
                $("#controlBitTip").html("请填写控制位");
            }
        } else {
            if (!regex.test(c)) {
                if (coo == "English") {
                    $('#controlBitTip').html('The control bit must be a hexadecimal number');
                } else {
                    $('#controlBitTip').html('控制位必须是16进制数');
                }
            } else {
                $('#controlBitTip').html('');
            }
        }
        if (ci == "") {
            if (coo == "English") {
                $("#controlInfoTip").html("Please fill in the control information");
            } else {
                $("#controlInfoTip").html("请填写控制信息");
            }
        } else {
            if (!regex.test(ci)) {
                if (coo == "English") {
                    $('#controlInfoTip').html('The control information must be a hexadecimal number');
                } else {
                    $('#controlInfoTip').html('控制信息必须是16进制数');
                }
            } else {
                $('#controlInfoTip').html('');
            }
        }
        if (sa == "") {
            if (coo == "English") {
                $("#tableSAAddressTip").html("Please fill in the table address sa");
            } else {
                $("#tableSAAddressTip").html("请填写表地址sa");
            }
        } else {
            //其他验证
            if (!regex.test(sa)) {
                if (coo == "English") {
                    $("#tableSAAddressTip").html('*The table address must be a hexadecimal number');
                } else {
                    $("#tableSAAddressTip").html('*表地址必须是16进制数');
                }
            } else {
                $("#tableSAAddressTip").html('');
            }
        }
        if (d == "") {
            if (coo == "English") {
                $("#dataDomainTip").html("Please fill in the data field");
            } else {
                $("#dataDomainTip").html("请填写数据域");
            }
        } else {
            //其他验证
            if (!regex.test(d)) {
                if (coo == "English") {
                    $("#dataDomainTip").html('The data field must be a hexadecimal number');
                } else {
                    $("#dataDomainTip").html('数据域必须是16进制数');
                }
            } else {
                $("#dataDomainTip").html('');
            }
        }

    } else if ($("#Add_DataItemFrameType").val() == "req2") {
        //验证ID
        $("#controlBitTip").html("");
        $("#controlInfoTip").html("");
        $("#tableSAAddressTip").html("");
        $("#dataDomainTip").html("");
        var id = $("input[name='Add_DataItemReq2Id']").val();
        var R = $("input[name='Add_DataItemBeilv']").val();
        if (id == "") {
            if (coo == "English") {
                $("#req2IdTip").html("Please fill in ID");
            } else {
                $("#req2IdTip").html("请填写ID");
            }
        } else {
            if (!reg.test(id)) {
                if (coo == "English") {
                    $('#req2IdTip').html('The ID must be a positive integer');
                } else {
                    $('#req2IdTip').html('ID必须是正整数');
                }
            } else {
                $('#req2IdTip').html('');
            }
        }
        if (R == "") {
            if (coo == "English") {
                $("#AddbeilvInfo").html("Please fill in the ratio");
            } else {
                $("#AddbeilvInfo").html("请填写倍率");
            }
        } else {
            var bei = new RegExp("^-?[0-9]+.?[0-9]*$");
            if (!bei.test(R)) {
                if (coo == "English") {
                    $('#AddbeilvInfo').html('Ratio must be a number');
                } else {
                    $('#AddbeilvInfo').html('倍率必须是数字');
                }
            } else {
                $('#AddbeilvInfo').html('');
            }
        }
    } else {
        //只有表地址A，其他清空错误信息
        $("#controlBitTip").html("");
        $("#controlInfoTip").html("");
        $("#tableSAAddressTip").html("");
        $("#dataDomainTip").html("");
        $('#req2IdTip').html('');
    }

    $("#Add_DataItemDHParamTip").html('');
    var isChecked = $("input[name='Add_DataItemDHEnable']:checked").val();
    if (isChecked == '1') {
        var paramVal = $('#Add_DataItemDHParam').val();
        if ($("#Add_DataItemDHSelect").val() == "#") {
            var linearParam1 = $("#Add_DHFunctionParam1").val();
            var linearParam2 = $("#Add_DHFunctionParam2").val();
            if (linearParam1 == "" || linearParam2 == "") {
              if (coo == "English") {
                $("#Add_DataItemDHParamTip").html(
                  "Please fill in the value operation parameters"
                );
              } else {
                $("#Add_DataItemDHParamTip").html("请填写值运算参数");
              }
            } else {
              var dhReg = /^-?[0-9]+.?[0-9]*$/;
              if (!dhReg.test(linearParam1) || !dhReg.test(linearParam2)) {
                if (coo == "English") {
                  $("#Add_DataItemDHParamTip").html(
                    "The value operation parameter must be a number"
                  );
                } else {
                  $("#Add_DataItemDHParamTip").html("值运算参数必须是数字");
                }
              }
            }
          } else if (paramVal == "") {
            if (coo == "English") {
                $("#Add_DataItemDHParamTip").html('Please fill in the value operation parameters');
            } else {
                $("#Add_DataItemDHParamTip").html('请填写值运算参数');
            }
        } else {
            // 校验输入的操作数是否是数字
            var dhReg = /^-?[0-9]+.?[0-9]*$/;
            if (!dhReg.test(paramVal)) {
                if (coo == "English") {
                    $("#Add_DataItemDHParamTip").html('The value operation parameter must be a number');
                } else {
                    $("#Add_DataItemDHParamTip").html('值运算参数必须是数字');
                }
            } else if ($("#Add_DataItemDHSelect").val() == '5') {
                var dhReg = /^[0-9]+$/;
                if (!dhReg.test(paramVal)) {
                    if (coo == "English") {
                        $("#Add_DataItemDHParamTip").html('The parameter of the fetch operation must be an integer');
                    } else {
                        $("#Add_DataItemDHParamTip").html('取位运算的参数必须是整数');
                    }
                } else {
                    var paramVal = Number(paramVal);
                    if (paramVal < 0 || paramVal > 31) {
                        if (coo == "English") {
                            $("#Add_DataItemDHParamTip").html('The range of parameters for the fetch operation must be 0 to 31');
                        } else {
                            $("#Add_DataItemDHParamTip").html('取位运算的参数的范围必须是0到31');
                        }
                    }
                }
            }
        }
    }

    //判断是否通过
    if ($("#idTip").html() == "" && $("#nameTip").html() == "" && $("#AliasTip").html() == "" && $("#freqTip").html() == "" &&
        $('#tableAddressTip').html() == "" && $('#controlBitTip').html() == "" &&
        $('#controlInfoTip').html() == "" && $('#tableSAAddressTip').html() == "" && $('#dataDomainTip').html() == "" &&
        $('#req2IdTip').html() == "" && $('#AddbeilvInfo').html() == "" && ($("#Add_DataItemDHParamTip").html() == '' || $("#Add_DataItemDHParamTip").html() == null) && ($("#Add_DataItemDltEnergyTip").html() == '' || $("#Add_DataItemDltEnergyTip").html() == null)) {
        //        全部通过
        Add_DataItemMethod();
    } else {}
}
//添加数据点方法

function Add_DataItemMethod() {
    //赋值
    // var reg = /[a-zA-Z]/g;
    // var str = document.getElementById("Add_DataItemAddress").value;
    // var length = str.match(reg).length
    var Freq = document.getElementById("Add_DataItemFreq").value;
    var Unit = document.getElementById("Add_DataItemUnit").value;
    if (Unit == "minute") {
        Freq = Freq * 60000;
    } else {
        Freq = Freq * 1000;
    }
    //数据项类型 
    document.getElementById("Add_DataItemType_YuToXHZhang").value = document.getElementById("Add_DataItemType").value;
    //数据项ID
    document.getElementById("Add_DataItemID_YuToXHZhang").value = document.getElementById("Add_DataItemID").value;
    //数据项名称
    document.getElementById("Add_DataItemName_YuToXHZhang").value = document.getElementById("Add_DataItemName").value;
    //别名
    document.getElementById("Add_DataItemAlias_YuToXHZhang").value = document.getElementById("Add_DataItemAlias").value;
    //频率
    document.getElementById("Add_DataItemFreq_YuToXHZhang").value = Freq;
    //读写模式
    document.getElementById("Add_DataItemRWmode_YuToXHZhang").value = $("input[name='Add_DataItemRWmode']:checked").val();
    //是否上报
    $("#Add_DataItemReport_YuToXHZhang").val( $("input[name='Add_ReportType']:checked").val()  );

    var isChecked = $("input[name='Add_DataItemDHEnable']:checked").val();
    $('#Add_DataItemDHEnable_YuToXHZhang').val(isChecked);
    if (isChecked == '1') {
        $('#Add_DataItemDHOptType_YuToXHZhang').val($('#Add_DataItemDHSelect').val());
        if ($("#Add_DataItemDHSelect").val() === "#") {
            $("#Add_DataItemDHOptParam_YuToXHZhang").val(
              $("#Add_DHFunctionParam1").val() +
                "|" +
                $("#Add_DHFunctionParam2").val()
            );
          } else {
            $("#Add_DataItemDHOptParam_YuToXHZhang").val(
              $("#Add_DataItemDHParam").val()
            );
          }
    }

    var config = "";
    config += $("#Add_DataItemFrameType").val() + ";";
    if ($("#Add_DataItemFrameType").val() == "snd_ud") {
        config += "C:" + $("input[name='Add_DataItemControlBit']").val() + ";";
        config += "A:" + $("input[name='Add_DataItemTableAddress']").val() + ";";
        config += "CI:" + $("input[name='Add_DataItemControlInfo']").val() + ";";
        config += "SA:" + $("input[name='Add_DataItemTableSAAddress']").val() + ";";
        config += "D:" + $("input[name='Add_DataItemDataDomain']").val();
    } else if ($("#Add_DataItemFrameType").val() == "req2") {
        config += "A:" + $("input[name='Add_DataItemTableAddress']").val() + ";";

        config += "ID:" + $("input[name='Add_DataItemReq2Id']").val() + ";";

        config += "R:" + $("input[name='Add_DataItemBeilv']").val();
    } else {
        config += "A:" + $("input[name='Add_DataItemTableAddress']").val();
    }

    $("#Add_DataItemConfig_YuToXHZhang").val(config);

    //设备ID
    document.getElementById("Add_DeviceID_YuToXHZhang").value = DeviceID;
    $("#return3").attr("disabled", "disabled");
    $("#return4").attr("disabled", "disabled");
    var params = $("#Add_DataItemForm_YuToXHZhang").serialize();
    $.ajax({
        type: "post",
        url: "cgi-bin/device/AddDataitem.py",
        data: params,
        async: true,
        success: function (data) {
            $("#popWindow").hide();
            $("#Add_DataItem_Layer").hide();
            $("#return3").attr("disabled", "");
            $("#return4").attr("disabled", "");
            getData();
        }
    });
}

//修改数据项校验

function Check_Alter_DataItem() {
    var CheckID = $("#Alter_DataItemID").val();
    var CheckName = $("#Alter_DataItemName").val();
    var Alies = $("#Alter_DataItemAlias").val();
    var Freq = $("#Alter_DataItemFreq").val();
    var reg = new RegExp("^[0-9]+$");
    var regID = new RegExp("^[1-9]+[0-9]*$");
    //校验数据项ID输入格式
    if (CheckID == "" || !regID.test(CheckID)) {
        if (coo == "English") {
            $("#idTipInfo").html("The dataItem ID must be a non-negative integer");
        } else {
            $("#idTipInfo").html("数据项ID必须为非负整数");
        }
    } else {
        $.ajax({
            type: "get",
            url: "../conf/config.xml",
            async: false,
            success: function (data) {
                var flag = 0;
                $(data).find("model").each(function () {
                    var $model = $(this);
                    $model.find("device").each(function () {
                        var $device = $(this);
                        $device.find("commDataItems").each(function () {
                            var $commDataItems = $(this);
                            $commDataItems.find("dataItem").each(function () {
                                var $dataItem = $(this);
                                var dataItemID = $dataItem.attr('id');
                                if (dataItemID == CheckID) {
                                    var dataItemName = $dataItem.attr('n');
                                    if (dataItemName == NowItemName) {
                                        //跳过
                                    } else {
                                        flag = flag + 1;
                                    }
                                }
                            });
                        });
                    });
                });
                if (flag < 1) {
                    $("#idTipInfo").html("");
                } else {
                    if (coo == "English") {
                        $("#idTipInfo").html("The dataItem ID is repeated, please change");
                    } else {
                        $("#idTipInfo").html("数据项ID已重复，请更改");
                    }
                }
            }
        });
    }

    //校验数据项名称输入格式
    if (!Check_Chinese_Character(CheckName)) {
        if (coo == "English") {
            $("#nameTipInfo").html("*The dataItem name format error, only the alphanumeric underscore and must start with the letter");
        } else {
            $("#nameTipInfo").html("*数据项名称格式错误，仅允许字母数字下划线且必须以字母开头");
        }
    } else {
        //名字未修改时，不校验重名
        if (CheckName == NowItemName) {
            $("#nameTipInfo").html("");
        } else {
            //校验数据项名称是否重名
            if (!CheckReName(CheckName)) {
                if (coo == "English") {
                    $("#nameTipInfo").html("The dataItem name is repeated")
                } else {
                    $("#nameTipInfo").html("数据项名称重复")
                }
            } else {
                $("#nameTipInfo").html("");
            }
        }
    }
    //校验数据项别名不为空
    if (Alies == "") {
        if (coo == "English") {
            $("#AliasTipInfo").html("*Please fill in the alias")
        } else {
            $("#AliasTipInfo").html("*请填写别名")
        }
    } else {
        $("#AliasTipInfo").html("");
    }


    //校验频率不为空
    if (Freq == "") {
        if (coo == "English") {
            $("#freqTipInfo").html("*Please fill in the sample frequency")
        } else {
            $("#freqTipInfo").html("*请填写采集频率")
        }
    } else {
        if (!reg.test(Freq) || Freq == 0) {
            if (coo == "English") {
                $("#freqTipInfo").html("*The frequencies must be positive integers");
            } else {
                $("#freqTipInfo").html("*频率必须为正整数");
            }
        } else {
            $.ajax({
              type: "get",
              url: "../conf/Common.xml",
              async: false,
              success: function (data) {
                var minFrequency = $(data).find("MinFrequency").text();
                var currentFreq = 0;
                if ($("#Alter_DataItemUnit").val() == "second") {
                  currentFreq = parseInt(Freq) * 1000;
                } else {
                  currentFreq = parseInt(Freq) * 1000 * 60;
                }

                if (currentFreq < parseInt(minFrequency)) {
                  if (coo == "English") {
                    $("#freqTipInfo").html(
                      "*The lowest frequency currently supported is" +
                        minFrequency / 1000 +
                        "seconds"
                    );
                  } else {
                    $("#freqTipInfo").html(
                      "*当前支持的最低频率为" + minFrequency / 1000 + "秒"
                    );
                  }
                } else {
                  $("#freqTipInfo").html("");
                }
              },
            });
        }
    }

    //校验表地址
    var tableAddress = $('input[name="Alter_DataItemTableAddress"]').val();
    regex = /^[0-9ABCDEF]*$/;
    if (tableAddress == "") {
        if (coo == "English") {
            $('#tableAddressTipInfo').html('*Please fill in the table address');
        } else {
            $('#tableAddressTipInfo').html('*请填写表地址');
        }
    } else {
        if (!regex.test(tableAddress)) {
            if (coo == "English") {
                $('#tableAddressTipInfo').html('*The table address must be a hexadecimal number');
            } else {
                $('#tableAddressTipInfo').html('*表地址必须是16进制数');
            }
        } else {
            $('#tableAddressTipInfo').html('');
        }
    }

    //根据帧类型验证C,CI,SA,D
    if ($("#Alter_DataItemFrameType").val() == "snd_ud") {
        $('#req2IdTipInfo').html('');
        var c = $("input[name='Alter_DataItemControlBit']").val();
        var ci = $("input[name='Alter_DataItemControlInfo']").val();
        var sa = $("input[name='Alter_DataItemTableSAAddress']").val();
        var d = $("input[name='Alter_DataItemDataDomain']").val();
        if (c == "") {
            if (coo == "English") {
                $("#controlBitTipInfo").html("Please fill in the control bit");
            } else {
                $("#controlBitTipInfo").html("请填写控制位");
            }
        } else {
            if (!regex.test(c)) {
                if (coo == "English") {
                    $('#controlBitTipInfo').html('*The control bit must be a hexadecimal number');
                } else {
                    $('#controlBitTipInfo').html('*控制位必须是16进制数');
                }
            } else {
                $('#controlBitTipInfo').html('');
            }
        }
        if (ci == "") {
            if (coo == "English") {
                $("#controlInfoTipInfo").html("Please fill in the control information");
            } else {
                $("#controlInfoTipInfo").html("请填写控制信息");
            }
        } else {
            if (!regex.test(ci)) {
                if (coo == "English") {
                    $('#controlInfoTipInfo').html('*The control information must be a hexadecimal number');
                } else {
                    $('#controlInfoTipInfo').html('*控制信息必须是16进制数');
                }
            } else {
                $('#controlInfoTipInfo').html('');
            }


        }
        if (sa == "") {
            if (coo == "English") {
                $("#tableSAAddressTipInfo").html("Please fill in the table address sa");
            } else {
                $("#tableSAAddressTipInfo").html("请填写表地址sa");
            }
        } else {
            //其他验证
            if (!regex.test(sa)) {
                if (coo == "English") {
                    $("#tableSAAddressTipInfo").html('*The table address must be a hexadecimal number');
                } else {
                    $("#tableSAAddressTipInfo").html('*表地址必须是16进制数');
                }
            } else {
                $("#tableSAAddressTipInfo").html('');
            }
        }
        if (d == "") {
            if (coo == "English") {
                $("#dataDomainTipInfo").html("Please fill in the data field");
            } else {
                $("#dataDomainTipInfo").html("请填写数据域");
            }
        } else {
            //其他验证
            if (!regex.test(d)) {
                if (coo == "English") {
                    $("#dataDomainTipInfo").html('The data field must be a hexadecimal number');
                } else {
                    $("#dataDomainTipInfo").html('数据域必须16进制数');
                }
            } else {
                $("#dataDomainTipInfo").html('');
            }
        }
    } else if ($("#Alter_DataItemFrameType").val() == "req2") {
        //验证ID
        $("#controlBitTipInfo").html("");
        $("#controlInfoTipInfo").html("");
        $("#tableSAAddressTipInfo").html("");
        $("#dataDomainTipInfo").html("");
        var id = $("input[name='Alter_DataItemReq2Id']").val();
        var R = $("input[name='Alter_DataItemBeilv']").val();
        if (id == "") {
            if (coo == "English") {
                $("#req2IdTipInfo").html("Please fill out the ID");
            } else {
                $("#req2IdTipInfo").html("请填写ID");
            }
        } else {
            if (!reg.test(id)) {
                if (coo == "English") {
                    $('#req2IdTipInfo').html('The ID must be a positive integer');
                } else {
                    $('#req2IdTipInfo').html('ID必须是正整数');
                }
            } else {
                $('#req2IdTipInfo').html('');
            }
        }
        if (R == "") {
            if (coo == "English") {
                $("#AlterbeilvInfo").html("Please fill in the ratio");
            } else {
                $("#AlterbeilvInfo").html("请填写倍率");
            }
        } else {
            var bei = new RegExp("^-?[0-9]+.?[0-9]*$");
            if (!bei.test(R)) {
                if (coo == "English") {
                    $('#AlterbeilvInfo').html('Ratio must be a number');
                } else {
                    $('#AlterbeilvInfo').html('倍率必须是数字');
                }
            } else {
                $('#AlterbeilvInfo').html('');
            }
        }
    } else {
        //只有表地址A，其他清空错误信息
        $("#controlBitTipInfo").html("");
        $("#controlInfoTipInfo").html("");
        $("#tableSAAddressTipInfo").html("");
        $("#dataDomainTipInfo").html("");
        $('#req2IdTipInfo').html('');
    }

    $("#Alter_DataItemDHParamTip").html('');
    var isChecked = $("input[name='Alter_DataItemDHEnable']:checked").val();
    if (isChecked == '1') {
        var paramVal = $('#Alter_DataItemDHParam').val();
        if ($("#Alter_DataItemDHSelect").val() == "#") {
            var linearParam1 = $("#Alter_DHFunctionParam1").val();
            var linearParam2 = $("#Alter_DHFunctionParam2").val();
            if (linearParam1 == "" || linearParam2 == "") {
              if (coo == "English") {
                $("#Alter_DataItemDHParamTip").html(
                  "Please fill in the value operation parameters"
                );
              } else {
                $("#Alter_DataItemDHParamTip").html("请填写值运算参数");
              }
            } else {
              var dhReg = /^-?[0-9]+.?[0-9]*$/;
              if (!dhReg.test(linearParam1) || !dhReg.test(linearParam2)) {
                if (coo == "English") {
                  $("#Alter_DataItemDHParamTip").html(
                    "The value operation parameter must be a number"
                  );
                } else {
                  $("#Alter_DataItemDHParamTip").html("值运算参数必须是数字");
                }
              }
            }
          }else if (paramVal == "") {
            if (coo == "English") {
                $("#Alter_DataItemDHParamTip").html('Please fill in the value operation parameters');
            } else {
                $("#Alter_DataItemDHParamTip").html('请填写值运算参数');
            }
        } else {
            // 校验输入的操作数是否是数字
            var dhReg = /^-?[0-9]+.?[0-9]*$/;
            if (!dhReg.test(paramVal)) {
                if (coo == "English") {
                    $("#Alter_DataItemDHParamTip").html('The value operation parameter must be a number');
                } else {
                    $("#Alter_DataItemDHParamTip").html('值运算参数必须是数字');
                }
            } else if ($("#Alter_DataItemDHSelect").val() == '5') {
                var dhReg = /^[0-9]+$/;
                if (!dhReg.test(paramVal)) {
                    if (coo == "English") {
                        $("#Alter_DataItemDHParamTip").html('The parameter of the fetch operation must be an integer');
                    } else {
                        $("#Alter_DataItemDHParamTip").html('取位运算的参数必须是整数');
                    }
                } else {
                    var paramVal = Number(paramVal);
                    if (paramVal < 0 || paramVal > 31) {
                        if (coo == "English") {
                            $("#Alter_DataItemDHParamTip").html('The range of parameters for the fetch operation must be 0 to 31');
                        } else {
                            $("#Alter_DataItemDHParamTip").html('取位运算的参数的范围必须是0到31');
                        }
                    }
                }
            }
        }
    }



    //判断是否通过
    if ($("#idTipInfo").html() == "" && $("#nameTipInfo").html() == "" && $("#AliasTipInfo").html() == "" && $("#freqTipInfo").html() == "" &&
        $('#tableAddressTipInfo').html() == "" && $('#controlBitTipInfo').html() == "" &&
        $('#controlInfoTipInfo').html() == "" && $('#tableSAAddressTipInfo').html() == "" && $('#dataDomainTipInfo').html() == "" && $('#req2IdTipInfo').html() == "" &&
        $('#AlterbeilvInfo').html() == "" && $('#Alter_DataItemDHParamTip').html() == '') {
        //        全部通过

        Alter_DataItemMethod();
    } else {}
}
//修改数据项方法

function Alter_DataItemMethod() {
    // var reg = /[a-zA-Z]/g;
    // var str = document.getElementById("Alter_DataItemAddress").value;
    // var length = str.match(reg).length;
    var Freq = document.getElementById("Alter_DataItemFreq").value;
    var Unit = document.getElementById("Alter_DataItemUnit").value;
    if (Unit == "minute") {
        Freq = Freq * 60000;
    } else {
        Freq = Freq * 1000;
    }
    document.getElementById("Alter_DataItemType_YuToXHZhang").value = document.getElementById("Alter_DataItemType").value;
    //设备ID
    document.getElementById("Alter_DeviceID_YuToXHZhang").value = DeviceID;
    //数据项ID
    document.getElementById("Alter_DataItemID_after").value = document.getElementById("Alter_DataItemID").value;
    //数据项名称
    document.getElementById("Alter_DataItemName_YuToXHZhang").value = document.getElementById("Alter_DataItemName").value;
    //数据项别名
    document.getElementById("Alter_DataItemAlias_YuToXHZhang").value = document.getElementById("Alter_DataItemAlias").value;
    //读写模式
    document.getElementById("Alter_DataItemRWmode_YuToXHZhang").value = $("input[name='Alter_DataItemRWmode']:checked").val();
    //频率
    document.getElementById("Alter_DataItemFreq_YuToXHZhang").value = Freq;
    //是否上报
    $("#Alter_DataItemReport_YuToXHZhang").val( $("input[name='Alter_ReportType']:checked").val() );

    var isChecked = $("input[name='Alter_DataItemDHEnable']:checked").val();
    $('#Alter_DataItemDHEnable_YuToXHZhang').val(isChecked);
    if (isChecked == '1') {
        $('#Alter_DataItemDHOptType_YuToXHZhang').val($('#Alter_DataItemDHSelect').val());
        if ($("#Alter_DataItemDHSelect").val() === "#") {
            $("#Alter_DataItemDHOptParam_YuToXHZhang").val(
              $("#Alter_DHFunctionParam1").val() +
                "|" +
                $("#Alter_DHFunctionParam2").val()
            );
          } else {
            $("#Alter_DataItemDHOptParam_YuToXHZhang").val(
              $("#Alter_DataItemDHParam").val()
            );
          }
    }

    var config = "";
    config += $("#Alter_DataItemFrameType").val() + ";";

    if ($("#Alter_DataItemFrameType").val() == "snd_ud") {
        config += "C:" + $("input[name='Alter_DataItemControlBit']").val() + ";";
        config += "A:" + $("input[name='Alter_DataItemTableAddress']").val() + ";";
        config += "CI:" + $("input[name='Alter_DataItemControlInfo']").val() + ";";
        config += "SA:" + $("input[name='Alter_DataItemTableSAAddress']").val() + ";";
        config += "D:" + $("input[name='Alter_DataItemDataDomain']").val();
    } else if ($("#Alter_DataItemFrameType").val() == "req2") {
        config += "A:" + $("input[name='Alter_DataItemTableAddress']").val() + ";";

        config += "ID:" + $("input[name='Alter_DataItemReq2Id']").val() + ";";

        config += "R:" + $("input[name='Alter_DataItemBeilv']").val();
    } else {
        config += "A:" + $("input[name='Alter_DataItemTableAddress']").val();
    }
    $("#Alter_DataItemConfig_YuToXHZhang").val(config);
    $("#return5").attr("disabled", "disabled");
    $("#return6").attr("disabled", "disabled");
    var params = $("#Alter_DataItemForm_YuToXHZhang").serialize();
    $.ajax({
        type: "post",
        url: "cgi-bin/device/AlterDataitem.py",
        data: params,
        async: true,
        success: function (data) {
            $("#popWindow").hide();
            $("#Alter_DataItem_Layer").hide();
            $("#return5").attr("disabled", "");
            $("#return6").attr("disabled", "");
            getData();
        }
    });
}

//全局一个需要删除的长度
var checkLength = "";

function CheckedLength() {
    checkLength = 0;
    document.getElementById("AllDataitemID").value = "";
    document.getElementById("Delete_DataItemAllID_YuToXHZhang").value = "";
    var inputs = document.getElementsByName("tryadd");
    var length = inputs.length;
    for (var i = 0; i < length; i++) {
        if (inputs[i].checked) {
            document.getElementById("AllDataitemID").value += inputs[i].value + ";";
            checkLength++;
        }
    }
    var str = document.getElementById("AllDataitemID").value;
    var strArr = new Array();
    strArr = str.split(";");
    var maxlength = strArr.length;
    for (var j = 0; j < maxlength - 2; j++) {
        document.getElementById("Delete_DataItemAllID_YuToXHZhang").value += strArr[j] + ",";
    }
    document.getElementById("Delete_DataItemAllID_YuToXHZhang").value += strArr[maxlength - 2];
}
//删除数据项
function DeleteConfig() {
    document.getElementById("Delete_DeviceID_YuToXHZhang").value = DeviceID;
    CheckedLength();
    $("#DeleteDataItem_Button_Confim").attr("disabled", "disabled");
    $("#DeleteDataItem_Button_Cancel").attr("disabled", "disabled");
    var params = $("#Delete_DataItemForm_YuToXHZhang").serialize();
    $.ajax({
        type: "post",
        url: "cgi-bin/device/DeleteDataitem.py",
        data: params,
        async: true,
        success: function (data) {
            $("#popWindow").hide();
            $("#DeleteDataItemLayer").hide();
            $("#DeleteDataItem_Button_Confim").attr("disabled", "");
            $("#DeleteDataItem_Button_Cancel").attr("disabled", "");
            getData();
            $("#selectAll").attr("checked", "");
        }
    });
}
//全选和反选

function addTry() {
    if (document.getElementById("selectAll").checked) {
        var inputs = document.getElementsByName("tryadd");
        for (var i = 0; i < inputs.length; i++) {
            inputs[i].checked = true;
        }
    } else {
        var inputs = document.getElementsByName("tryadd");
        for (var i = 0; i < inputs.length; i++) {
            inputs[i].checked = false;
        }
    }
}
//下发数据项
function Open_IssuedLayer() {
    document.getElementById("popWindow").style.display = ''
    document.getElementById("IssuedLayer").style.display = ''
    document.getElementById("ConUp1").style.display = ''
    $("#up_success").hide();
    //      document.getElementById("Hide_IssuedIframe").style.display = 'none'
    document.getElementById("Issued_Button_Confim").style.display = ''
    document.getElementById("Issued_Button_Cancel").style.display = ''
    document.getElementById("Issued_Success_Button_Confim").style.display = 'none'
    //动态图隐藏
    document.getElementById("Loading").style.display = "none";
}

function UpConfigCon() {
    times = 0;
    document.getElementById("IssuedLayer").style.display = 'none';
    window.parent.document.getElementById("IssuedLayer").style.display = '';
    document.getElementById("ConUp1").style.display = 'none';
    //      document.getElementById("Hide_IssuedIframe").style.display = "none"
    $("#Issued_Button_Confim").attr("disabled", "disabled");
    $("#Issued_Button_Cancel").attr("disabled", "disabled");
    $.ajax({
        type: "post",
        url: "cgi-bin/agent/GiveToAgent.py",
        data: "up=1",
        async: false,
        success: function (data) {
            $("#up_success").html(data);
            document.getElementById("popWindow").style.backgroundColor = "#ddd";
            window.parent.document.getElementById("popWindow").style.display = "";
            window.parent.document.getElementById("IssuedLayer").style.display = '';
            getagent = setInterval("getAgentStatue()", 5000);
        }
    });
}
//全局一个发送次数
var times = 0
var getagent = "";

function getAgentStatue() {
    //获取测试字符串
    var value = getFirstID();
    $("#Test_Value_YuToXHZhang").val(value);
    var params = $("#Test_DataItemForm_YuToXHZhang").serialize();
    times++;
    //45秒超时
    if (times < 18) {
        $.ajax({
            type: "post",
            url: "cgi-bin/RealTimeData/GetAgentStatue.py",
            data: params,
            async: true,
            success: function (data) {
                //如果测试返回结果正确，即返回为1，则可以关闭下发窗口
                if (data == 1) {
                    $("#up_success").show();
                    $("#Loading").hide();
                    $("#Issued_Button_Confim").attr("disabled", "");
                    $("#Issued_Button_Cancel").attr("disabled", "");
                    $("#Issued_Button_Confim").hide();
                    $("#Issued_Button_Cancel").hide();
                    $("#Issued_Success_Button_Confim").show();
                    $("#ConUp1").hide();
                    window.parent.document.getElementById("popWindow").style.display = "none";
                    document.getElementById("popWindow").style.backgroundColor = "#9D9D9D";
                    window.parent.document.getElementById("IssuedLayer").style.display = 'none';
                    document.getElementById("IssuedLayer").style.display = '';
                    clearInterval(getagent);
                } else {

                }
            },
        });
    } else {
        $("#Issued_Button_Confim").attr("disabled", "");
        $("#Issued_Button_Cancel").attr("disabled", "");
        document.getElementById("IssuedLayer").style.display = '';
        window.parent.document.getElementById("popWindow").style.display = "none";
        document.getElementById("popWindow").style.backgroundColor = "#9D9D9D";
        window.parent.document.getElementById("IssuedLayer").style.display = 'none';
        if (coo == "English") {
            document.getElementById("up_success").innerHTML = "Agent startup timeout, please try again later";
        } else {
            document.getElementById("up_success").innerHTML = "agent启动超时，请稍后再试";
        }
        document.getElementById("up_success").style.display = "";
        document.getElementById("ConUp1").style.display = "none";
        document.getElementById("Issued_Button_Confim").style.display = 'none';
        document.getElementById("Issued_Success_Button_Confim").style.display = '';
        clearInterval(getagent);
    }
}

function getFirstID() {
    var id = "";
    $.ajax({
        type: "get",
        url: "../conf/config.xml",
        async: false,
        success: function (data) {
            $(data).find("model[id='" + ChannelID + "']").each(function () {
                var $model = $(this);
                $model.find("device[id='" + DeviceID + "']").each(function () {
                    var $device = $(this);
                    $device.find("driver").each(function () {
                        var $driver = $(this);
                        DriverID = $driver.attr('id');
                        $driver.find("commDataItems").each(function () {
                            var $commDataItems = $(this);
                            $commDataItems.find("dataItem:first-child").each(function () {
                                var $dataItem = $(this);
                                var dataItemID = $dataItem.attr('id');
                                id = dataItemID;
                            });
                        });
                    })
                });
            });
        }
    });
    //拼出测试字符串

    var value = "";
    var ChannelDriverArr = new Array();
    ChannelDriverArr = ChannelDriver.split(":");
    var ChannelDriverShort = ChannelDriverArr[1];
    if (id == "") {
        //没有数据时候
        value = '{"id":' + DeviceID + ',"dn":"","vid":' + DriverID + ',"vn":"' + ChannelDriverShort + '", "cmds":{"read":1}}'
    } else {
        value = '{"id":' + DeviceID + ',"dn":"","vid":' + DriverID + ',"vn":"' + ChannelDriverShort + '", "cmds":{"read":0,"ids":[' + id + ']}}'
    }
    return value;
}
//读数据项ID最大值并赋值
function getID() {
    $.get('../conf/IDinfo.xml', function (d1) {
        $(d1).find("IDALL").each(function () {
            var $IDALL = $(this);
            var DataitemID = $IDALL.find('ItemID').text();
            document.getElementById("Add_DataItemID_YuToXHZhang").value = DataitemID;
            document.getElementById("Add_DataItemID").value = DataitemID;
        });
    });
}

function Import_DataItem() {
    if (document.getElementById("FileName").value == "") {
        if (coo == "English") {
            alert("Please select the files to upload!")
        } else {
            alert("请选择需要上传的文件！")
        }
    } else {
        document.getElementById('Import_Button_Confirm').disabled = true;
        document.getElementById('Import_Button_Cancel').disabled = true;
        document.getElementById("ImportForm_YuToXHZhang").action = '../cgi-bin/import/ImportMbus.py?deviceID=' + DeviceID;
        document.getElementById("ImportForm_YuToXHZhang").submit();
        var iframe01 = document.getElementById("Hide_ImportIframe");
        if (iframe01.attachEvent) {
            iframe01.attachEvent("onload", function () {
                document.getElementById("UpWord").style.display = 'none';
                document.getElementById("Import_Two_Button").style.display = 'none';
                document.getElementById("Success_Import").style.display = '';
                document.getElementById("Import_Success_Button").style.display = '';
                document.getElementById('Import_Button_Confirm').disabled = false;
                document.getElementById('Import_Button_Cancel').disabled = false;
            });
        } else {
            iframe01.onload = function () {
                document.getElementById("UpWord").style.display = 'none';
                document.getElementById("Import_Two_Button").style.display = 'none';
                document.getElementById("Success_Import").style.display = '';
                document.getElementById("Import_Success_Button").style.display = '';
                document.getElementById('Import_Button_Confirm').disabled = false;
                document.getElementById('Import_Button_Cancel').disabled = false;
            };
        }
    }
}


function Close_ExportLayer() {
    document.getElementById("popWindow").style.display = 'none'
    document.getElementById("ExprotLayer").style.display = 'none'
    document.getElementById('Exportout').disabled = false;
    document.getElementById('ExSucc').disabled = false;
}

function ExportInfo() {
    document.getElementById("ExportForm_YuToXHZhang").action = '../cgi-bin/export/ExportMbus.py?deviceID=' + DeviceID;
    document.getElementById("ExportForm_YuToXHZhang").submit();
    document.getElementById("ExportForm_YuToXHZhang").target = 'Hide_ExportIframe';
    document.getElementById('Exportout').disabled = true;
    document.getElementById('ExSucc').disabled = true;
    window.setTimeout(Close_ExportLayer, 3000);
}
//切换到测试

function Open_TestLayer() {
    //alert(ChannelDriver)
    var value = "";
    var idArr = "";
    var ChannelDriverArr = new Array();
    ChannelDriverArr = ChannelDriver.split(":");
    var ChannelDriverShort = ChannelDriverArr[1];
    CheckedLength();
    if (document.getElementById("AllDataitemID").value == "") {
        value = '{"id":' + DeviceID + ',"dn":"", "vn":"' + ChannelDriverShort + '", "cmds":{"read":1}}'
    } else {
        var str = document.getElementById("AllDataitemID").value;
        var strArr = new Array();
        strArr = str.split(";");
        var maxlength = strArr.length;
        for (var j = 0; j < maxlength - 2; j++) {
            idArr += strArr[j] + ",";
        }
        idArr += strArr[maxlength - 2];
        value = '{"id":' + DeviceID + ',"dn":"", "vn":"' + ChannelDriverShort + '", "cmds":{"read":0,"ids":[' + idArr + ']}}'
    }
    TestDateItem(value);


    if (window.testTimer) {
        clearInterval(window.testTimer);
        window.testTimer = null;
    }

    window.testTimer = setInterval(function () {
        var testWindowVisable = $('#TestLayer').is(":hidden");
        var popWindowVisable = $('#popWindow').is(":hidden");
        var autoTest = ($("#onoffswitch").is(':checked'));
        if (testWindowVisable || popWindowVisable) {
            clearInterval(window.testTimer);
            window.testTimer = null;
        } else if (autoTest) {
            console.log('刷新！');
            TestDateItem(value);
        }
    }, 10000);

}

function TestDateItem(txt) {
    $("#testInfomation").empty();
    document.getElementById("Test_Value_YuToXHZhang").value = txt;
    document.getElementById("popWindow").style.display = "";
    var params = $("#Test_DataItemForm_YuToXHZhang").serialize();
    $.ajax({
        type: "post",
        url: "cgi-bin/RealTimeData/GetRealTimeData.py",
        data: params,
        async: true,
        datatype: "xml",
        beforeSend: function () {
            $("#wait").show();
        },
        complete: function () {
            $("#wait").hide();
            //方法执行完毕，效果自己可以关闭，或者隐藏效果
        },
        success: function (data) {
            if (data.substr(1, 3) != "All") {
                $("#wait").hide();
                $("#popWindow").hide();
                alert(data);
            } else {
                $("#TestLayer").show();
                $(data).find("dataItem").each(function () {
                    var $dataitem = $(this);
                    var name = $dataitem.attr("n");
                    var config = $dataitem.attr("config");
                    var id = $dataitem.attr("id");
                    var typeshort = $dataitem.attr("type");
                    var freq = $dataitem.attr("freq");
                    var report = $dataitem.attr("report");
                    var value = $dataitem.attr("value");
                    var alias = $dataitem.attr("alias");
                    var quality1 = $dataitem.attr("quality");
                    var configArr = new Array();
                    configArr = config.split(";");
                    var add = configArr[0];
                    var type1 = configArr[1];
                    var type = "";
                    var quality = "";
                    if (quality1 == 1) {
                        quality = "good";
                    }
                    if (quality1 != 1) {
                        quality = "bad";
                    }
                    if (type1 == "BIT")
                        type = "Boolean";
                    if (type1 == "BYTE")
                        type = "Byte";
                    if (type1 == "WORD")
                        type = "Word";
                    if (type1 == "SHORT")
                        type = "Short";
                    if (type1 == "DWORD")
                        type = "DWord";
                    if (type1 == "LONG")
                        type = "Long";
                    if (type1 == "FLOAT")
                        type = "Float";
                    if (type1 == "STRING")
                        type = "String";
                    var list = "<div style='width:678px;height:25px;border: 1px solid #D7D7D7;border-top:none'>" +
                        "<div align='center' style='width:165px;float:left;height:25px;line-height:25px;overflow:hidden' title='" + alias + "'>" + name + "</div>" +
                        "<div align='center' style='width:170px;float:left;height:25px;line-height:25px;overflow:hidden' title='" + alias + "'>" + alias + "</div>" +
                        "<div align='center' style='width:90px;float:left;height:25px;line-height:25px'>" + add + "</div>" +
                        "<div align='center' style='width:159px;float:left;height:25px;line-height:25px'>" + value + "</div>" +
                        "<div align='center' style='width:85px;float:left;height:25px;line-height:25px'>" + quality + "</div>" +
                        "</div>"
                    $("#testInfomation").append(list);
                });
            }
        },
        error: function () {
            $("#popWindow").hide();
            if (coo == "English") {
                alert("Test fails, please contact your administrator");
            } else {
                alert("测试失败，请联系管理员");
            }
        }
    });
}
//切换到导入
function Open_ImportLayer() {
    $("#popWindow").show();
    $("#ImportLayer").show();
    $("#FileName").val("");
    $("#UpWord").show();
    $("#Import_Two_Button").show();
    $("#Success_Import").hide();
    $("#Import_Success_Button").hide();
    $("#Import_Button_Confirm").show();
    $("#Import_Button_Cancel").show();
}
//切换到导出

function Open_ExportLayer() {
    document.getElementById("popWindow").style.display = '';
    document.getElementById("ExprotLayer").style.display = '';
}

function Import_Success_ReloadNewPage() {
    getData();
    $("#popWindow").hide();
    $("#ImportLayer").hide();
}

function open_write_layer(data) {
    $('#write_layer').css('display', '');
    $("#popWindow").css('display', '');
    //
    $("#Write_Button_Confirm").unbind("click").click(function () {
        //构造参数
        data.cmds[0]["userid"] = "1493282026529"; //userid 可以随便填写
        data.cmds[0]["cmd"] = $("#write_input").val();
        //验证非空
        if (data.cmds[0]["cmd"] == "" || data.cmds[0]["cmd"] == null) {
            if (coo == "English") {
                alert("Write value cannot be empty");
            } else {
                alert("写入值不能为空");
            }
            return;
        }
        if (data.cmds[0]["rw"] == "0") {
            if (coo == "English") {
                alert("Please set the R/W type to be Read&Write first.");
            } else {
                alert("请先设置读写类型为可写");
            }
            return;
        }
        //验证bool 类型(dt == b)只能为0或1
        if (data.cmds[0]['dt'] == 'b' && ['0', '1'].indexOf(data.cmds[0]["cmd"]) == -1) {
            if (coo == "English") {
                alert("Boolean type can only fill 0 or 1");
            } else {
                alert("Boolean类型只能填写0或者1");
            }
            return;
        }
        //直接提交json cgi无法收到，这里把json字符串放到一个伪造的表单里,key是'Write_Value_command'
        var $form = $("<form></form>");
        var $input = $("<input tyle='text' name='Write_Value_command'>");
        $input.val(JSON.stringify(data))
        $form.append($input);
        var param = $form.serialize();
        $.ajax({
            type: 'post',
            url: 'cgi-bin/RealTimeData/WriteItemValue.py',
            data: param,
            // dataType: 'xml',
            beforeSend: function (request) {
                $("#Write_Button_Confirm").attr("disabled", "disabled");
                $("#write_Button_Cancel").attr("disabled", "disabled");
            },
            complete: function () {
                $("#Write_Button_Confirm").removeAttr("disabled");
                $("#write_Button_Cancel").removeAttr("disabled");
                $('#write_layer').css('display', 'none');
                $("#popWindow").css('display', 'none');
                $('#write_input').val("");
            },
            success: function (data) {
                alert(data);
            },
            error: function () {
                alert('error');
            }
        })
    })
};

function clocs_write_layer() {
    $('#write_layer').css('display', 'none');
    $("#popWindow").css('display', 'none');
    $('#write_input').val("");
};