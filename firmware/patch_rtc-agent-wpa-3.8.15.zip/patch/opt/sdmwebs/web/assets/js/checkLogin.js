document.writeln("<" + "script language='javascript' src='assets/js/Md5.js?t="+(new Date()).getTime()+"'></" + "script>");
document.writeln("<" + "script language='javascript' src='assets/js/cookie.min.js?t="+(new Date()).getTime()+"'></" + "script>");
document.writeln("<" + "script language='javascript' src='assets/js/locationhref.js?t="+(new Date()).getTime()+"'></" + "script>");
$.ajaxSetup({
    cache: false
});

//add by kali
function CheckLogin() {

    var isLogin = false;
    var LoginName = sessionStorage.AnylinkName;
    
    var token = cookie.get('token')
    if( !token ){
         // 验证失败
         window.open('login.html?t='+(new Date()).getTime(), '_parent');
         return
    }
    $.ajax({
        url: "cgi-bin/senconf/userlogin.py",
        type: "post",
        dataType: "json",
        contentType: "application/json",
        data: JSON.stringify({token}),
        async: true,
        timeout: 8000,
        success: function (data) {
            
            if(data.errcode){
                window.open('login.html?t='+(new Date()).getTime(), '_parent');
                //alert("error:"+(data.msg||"unkonw errors 001!"));
                return;
            }
            if( data.code == 200 ){
                isLogin = true;
            }
            if(isLogin == false) {
                // 验证失败
                window.open('login.html?t='+(new Date()).getTime(), '_parent');
            }else {
                // 验证成功            
            }
        },
        error: function (err) {
            
            alert("exception:"+JSON.stringify(err));
        }
    });

   
}

// modified begin by fyj
function CheckLogin_nouse() {
    var LoginName = sessionStorage.AnylinkName;
    var LoginPassNor = sessionStorage.AnylinkPass;
    var isLogin = false;
    $.get('../conf/Login.xml', function (d) {
        $(d).find('LoginInfo').each(function () {
            var $LoginInfo = $(this);
            var User = $LoginInfo.find('UserName').text();
            var pass = $LoginInfo.find('Password').text();
            // if (LoginName == User && hex_md5(LoginPassNor) == pass) {} else {
            //     window.open('login.html', '_parent');
            // }
            if(LoginName == User && LoginPassNor == pass){
                isLogin = true;
            }
        });
        if(isLogin == false) {
            // 验证失败
            window.open('login.html?t='+(new Date()).getTime(), '_parent');
        }else {
            // 验证成功            
        }
    });
}
// modified end

//所有页面的关闭按钮
//浮动效果
$(".infoTOPPic").hover(
    function () {
        $(this).attr("src", "assets/img/closed_ico_hover.png");
    },
    function () {
        $(this).attr("src", "assets/img/closed.png");
    }
);
$(".infoTOPPic").click(function () {
    var $parent = $(this).parent().parent();
    var id = "#" + $parent.attr("id")
    $(id).hide();
    $(".popWindow").hide();
});
//关闭层效果
$(".close_but").click(function () {
    var $parent = $(this).parent().parent();
    var id = "#" + $parent.attr("id")
    $(id).hide();
    $(".popWindow").hide();
});
//拖动功能
$(document).ready(function () {
    $(function () {
        // 鼠标按下时
        $('.infoTOP').mousedown(function (e) {
            // 获取当前元素的 偏移量
            id = "#" + $(this).parent().attr("id");
            var positionDiv = $(id).offset();
            // 获取是否在当前事件下在当前元素上
            var distenceX = e.pageX - positionDiv.left;
            var distenceY = e.pageY - positionDiv.top;
            // 移动时
            $(document).mousemove(function (e) {
                // 获取
                var x = e.pageX - distenceX;
                var y = e.pageY - distenceY;
                if (x < 0) {
                    x = 0;
                } else if (x > window.innerWidth - $(id).outerWidth(true)) { // 判断是否超出浏览器宽度
                    x = window.innerWidth - $(id).outerWidth(true);
                }
                if (y < 0) {
                    y = 0;
                } else if (y > $(document).height() - $(id).outerHeight(true)) { // 判断是否超出浏览器高度
                    y = $(document).height() - $(id).outerHeight(true);
                }
                // 设置left值和top值
                $(id).css({
                    'left': x + 'px',
                    'top': y + 'px'
                });
            });
            // 解绑事件
            $(document).mouseup(function () {
                $(document).unbind('mousemove');
            });
        });
    });
});