document.writeln("<script src=\"assets/js/effect_Com.js?t=" + (new Date()).getTime() + "\" type=\"text/javascript\" charset=\"utf-8\"></script>");
document.writeln("<" + "script language='javascript' src='assets/js/language.js?" + (new Date()).getTime() + "'></" + "script>");

CheckLogin();
$.ajaxSetup({
    cache: false
});
//全局变量
var diffCol = 1000000000000;
var EditChange = 100000000000000;
//通道ID
var ChannelID = "";
//设备ID
var DeviceID = "";
//驱动ID
var DriverID = '';
//校验所需要的
var category = "";
//数据项总数    
var DataItemNum = "";
//设备驱动类型
var ChannelDriver = "";
//设备的驱动类型
var ChannelDeviceType = "";
var coo = '';
//根据传值获取通道ID和设备ID
function initUI() {
    //传值
    var string = decodeURIComponent(document.location.search).substr(1);
    var logArr = new Array();
    logArr = string.split("=");
    ChannelID = string.split("&")[0].split("=")[1];
    DeviceID = string.split("&")[1].split("=")[1];
}
//点击切告警和数据项
$("#dataTab").click(function () {
    window.location.href = "../DataItemConfig_MPI.html?channelid=" + ChannelID + "&deviceid=" + DeviceID + "&t=" + (new Date()).getTime();
});
$("#rulesTab").click(function () {
    window.location.href = "../Alarm.html?channelid=" + ChannelID + "&deviceid=" + DeviceID + "&t=" + (new Date()).getTime();
});
$("#computeTab").click(function () {
    window.location.href = "../ConditionalUpload.html?channelid=" + ChannelID + "&deviceid=" + DeviceID + "&t=" + (new Date()).getTime();
});

//根据通道ID、设备ID读数据项
$(document).ready(function () {
    initUI();
    getID();
    getData();
    coo = getCookie("AnyLinkLan");
    if (coo == "English") {
        $(".AutoRefresh").css("left", "289px");
        $("#computeTab").css("width", "100px");
    } else {
        $(".AutoRefresh").css("left", "77px");
        $("#computeTab").css("width", "60px");
    }
});
//根据通道ID、设备ID读数据项
function getData() {
    getID();
    $("#allItemName").empty();
    DataItemNum = 0;
    $("#DataItemNum").empty();
    $("#info").empty();
    $("#itemTable tr").empty("");
    $("#itemTable  tr").css("display", "none");
    $.get('../conf/config.xml', function (d1) {
        $(d1).find("model[id='" + ChannelID + "']").each(function () {
            var $model = $(this);
            var modelid = $model.attr('id');
            var modeln = $model.attr('n');
            var modeld = $model.attr('d');
            ChannelDriver = $model.attr("d");
            ChannelDeviceType = $model.attr("devicedriver");
            //add begin by x
            //特殊处理如果是ADS驱动类型,数据项是以下的内容
            var options = '<option value = "BIT">BIT</option>' +
                '<option value = "INT8_T">INT8_T</option>' +
                '<option value = "UINT8_T">UINT8_T</option>' +
                '<option value = "INT16_T">INT16_T</option>' +
                '<option value = "UINT16_T">UINT16_T</option>' +
                '<option value = "INT32_T">INT32_T</option>' +
                '<option value = "UINT32_T">UINT32_T</option>' +
                '<option value = "FLOAT">FLOAT</option>' +
                '<option value = "DOUBLE">DOUBLE</option>';
            if (ChannelDeviceType == 'TwinCAT') {
                $("#Add_DataItemType").html(options);
                $("#Alter_DataItemType").html(options);
            }
            //end add

            //add begin by x
            //特殊处理西门子 以太网 增加BCD数据类型
            if (ChannelDeviceType === 'SIEMENS-Ethernet') {
                $("#Add_DataItemType").find('option[value="BCD"]').remove();
                $("#Add_DataItemType").append('<option id="BCD" value="BCD">BCD</option>');
                $("#Alter_DataItemType").find('option[value="BCD"]').remove();
                $("#Alter_DataItemType").append('<option id="BCD" value="BCD">BCD</option>');
            }
            //end add

            $("#ChannelName").html(modeln);
            $("#ChannelName").attr("title", modeln);
            $model.find("device[id='" + DeviceID + "']").each(function () {
                var $device = $(this);
                var deviceid = $device.attr('id');
                var deviceip = $device.attr('ip');
                var devicen = $device.attr('n');
                var type = $device.attr('type');
                ItemConfigHelp(type);
                var driverId = '';
                $device.find('driver').each(function () {
                    var $driver = $(this);
                    driverId = $driver.attr('id');
                    var config = $driver.attr('config');
                    var configArr = new Array();
                    configArr = config.split(";");
                    category = configArr[0];
                });
                $("#DeviceName").html(devicen);
                $("#DeviceName").attr("title", devicen);
                $device.find("commDataItems").each(function () {
                    var $commDataItems = $(this);
                    $commDataItems.find("dataItem").each(function () {
                        var $dataItem = $(this);
                        var dataItemN = $dataItem.attr('n');
                        var dataItemA = $dataItem.attr('alias');
                        var dataItemID = $dataItem.attr('id');
                        var dataItemFreq = $dataItem.attr('freq');
                        var dataItemReport1 = $dataItem.attr('report');
                        var dataItemWR1 = $dataItem.attr('rw');
                        var dataItemType_w = $dataItem.attr('type');
                        var dataItemConfig = $dataItem.attr('config');
                        var ConfigArr = new Array();
                        ConfigArr = dataItemConfig.split(";");
                        var dataItemAdd = ConfigArr[0];
                        var dataItemReport = "";
                        var dataItemType = "";
                        if (coo == "English") {
                            if (dataItemReport1 == "0") {
                                dataItemReport = "Not report"
                            } else if ( dataItemReport1 == "2") {
                                dataItemReport = "change report"
                            } else {
                                dataItemReport = "Report"
                            }
                        } else {
                            if (dataItemReport1 == "0") {
                                dataItemReport = "不上传"
                            }  else if ( dataItemReport1 == "2") {
                                dataItemReport = "变化上传"
                            } else {
                                dataItemReport = "全部上传"
                            }
                        }
                        if (ChannelDeviceType == "AB-Ethernet/IP" || ChannelDeviceType == "AB-MicroLogix") {
                            if (coo == "English") {
                                if (dataItemType_w == "b")
                                    dataItemType = "Switch quantity";
                                if (dataItemType_w == "a")
                                    dataItemType = "Numerical value";
                                if (dataItemType_w.indexOf("s") != -1)
                                    dataItemType = "String";
                            } else {
                                if (dataItemType_w == "b")
                                    dataItemType = "开关量";
                                if (dataItemType_w == "a")
                                    dataItemType = "数值";
                                if (dataItemType_w.indexOf("s") != -1)
                                    dataItemType = "字符串";
                            }
                        } else {
                            var dataItemType1 = ConfigArr[1];
                            if (dataItemType1 == "BIT")
                                dataItemType = "Boolean";
                            if (dataItemType1 == "BYTE")
                                dataItemType = "Byte";
                            if (dataItemType1 == "WORD")
                                dataItemType = "Word";
                            if (dataItemType1 == "SHORT")
                                dataItemType = "Short";
                            if (dataItemType1 == "DWORD")
                                dataItemType = "DWord";
                            if (dataItemType1 == "LONG")
                                dataItemType = "Long";
                            if (dataItemType1 == "FLOAT")
                                dataItemType = "Float";
                            if (dataItemType1 == "BCD")
                                dataItemType = "BCD";
                            if (dataItemType1.indexOf("STRING") != -1)
                                dataItemType = "String";
                            if (dataItemType1 == "INT8") {
                                dataItemType = "Int 8";
                            }
                            if (dataItemType1 == "INT16") {
                                dataItemType = "Int 16";
                            }
                            if (dataItemType1 == "INT32") {
                                dataItemType = "Int 32";
                            }
                        }
                        //add begin by x
                        //如果是beckhoff驱动就显示实际添加的数据类型
                        if (ChannelDeviceType == "TwinCAT") {
                            dataItemType = dataItemType1;
                        }
                        //and add
                        var dataItemWR = "";
                        if (coo == "English") {
                            if (dataItemWR1 == "0") {
                                dataItemWR = "Read";
                            }
                            if (dataItemWR1 == "1") {
                                dataItemWR = "Read&Write";
                            }
                        } else {
                            if (dataItemWR1 == "0") {
                                dataItemWR = "只读";
                            }
                            if (dataItemWR1 == "1") {
                                dataItemWR = "可写";
                            }
                        }
                        diffCol++;
                        EditChange++;
                        DataItemNum++;
                        var list = "<tr id=" + diffCol + " class='diffC' onMouseOver='Highlight(id)' onMouseOut='HideHighlight(id)' onDblClick='Open_Alter_DataItem_Layer(" + dataItemID + ")'>" +
                            "<td>" + "<input name='tryadd' type='checkbox' value='" + dataItemID + "'>" + "</td>" +
                            "<td>" + dataItemID + "</td>" +
                            "<td class='nameAliasWidth'>" + dataItemN + "</td>" +
                            "<td class='nameAliasWidth'>" + dataItemA + "</td>" +
                            "<td class='nameAliasWidth'>" + dataItemAdd + "</td>" +
                            "<td class='nameAliasWidth'>" + dataItemType + "</td>" +
                            "<td>" + dataItemWR + "</td>"
                        if (coo == "English") {
                            list += "<td>" + dataItemFreq / 1000 + "s</td>"
                        } else {
                            list += "<td>" + dataItemFreq / 1000 + "秒</td>"
                        }
                        list = list + "<td>" + dataItemReport + "</td>" +
                            "<td>" +
                            "<img src='assets/img/bianji_ico.png'  onClick='Open_Alter_DataItem_Layer(" + dataItemID + ")' class='edit' title='编辑'>" +
                            "&nbsp;<img src='assets/img/xieru_ico.png'  onClick='open_write_layer(" + JSON.stringify({
                                'id': +deviceid,
                                'dn': '',
                                'vn': modeld.split(":")[1],
                                'vid': +driverId,
                                'cmds': [{
                                    'dt': dataItemType_w,
                                    'cfg': dataItemConfig,
                                    'itemid': dataItemID,
                                    'rw': dataItemWR1
                                }]
                            }).replace(/"/g, '&quot;') + ")' class='write i18n-input' selectname='WriteOperation' selectattr='title' >" + "</td>" +
                            "</tr>"
                        $("#itemTable").append(list);
                        if (coo == "English") {
                            $(".edit").attr("title", "Edit");
                            $(".write").attr("title", "Write");
                        } else {
                            $(".edit").attr("title", "编辑");
                            $(".write").attr("title", "写入");
                        }
                        if (diffCol % 2 == "0")
                            document.getElementById(diffCol).className = "diffC1";
                        if (coo == "English") {
                            document.getElementById("DataItemNum").innerHTML = "Total number of dataItems: " + "<strong>" + DataItemNum + "</strong>" + " &nbsp; ";
                        } else {
                            document.getElementById("DataItemNum").innerHTML = "数据项总数： " + "<strong>" + DataItemNum + "</strong>" + " &nbsp; ";
                        }
                        var allName = dataItemN + ";"
                        $("#allItemName").append(allName);
                    });
                    $(".edit").mouseover(function () {
                        $(this).attr("src", "assets/img/bianji_hover_ico.png");
                        this.myTitle = this.title;
                        this.title = "";
                        var tooltip = "<div id='tooltip'>" + this.myTitle + "</div>";
                        $("body").append(tooltip);
                        var width = parseInt($("#tooltip").css("width")) + 10;
                        $("#tooltip").css("top", y + "px")
                        $("#tooltip").css("left", x + "px")
                        $("#tooltip").css("width", width + "px")
                    });
                    $(".edit").mouseout(function () {
                        $(this).attr("src", "assets/img/bianji_ico.png");
                        this.title = this.myTitle;
                        $("#tooltip").remove();
                    });
                });
            });
        });
    });
}
//点击返回效果
function ReturnToDevice() {
    window.location.href = "../Device_PLC_Change.html?id=" + ChannelID + "&t=" + (new Date()).getTime();
}
//移动高亮显示
function Highlight(txt) {
    document.getElementById(txt).className = "diffC2";
}

function HideHighlight(txt) {
    if (txt % 2 == "0")
        document.getElementById(txt).className = "diffC1";
    else
        document.getElementById(txt).className = "diffC";
}
//全局变量当前编辑的名称
var NowItemName = "";
//根据设备ID和数据项ID查找数据项信息并显示
function Open_Alter_DataItem_Layer(txt) {
    //将ID赋值给表单
    document.getElementById("Alter_DataItemID_YuToXHZhang").value = txt;
    document.getElementById('idTipInfo').innerHTML = "";
    document.getElementById('nameTipInfo').innerHTML = "";
    document.getElementById('AliasTipInfo').innerHTML = "";
    document.getElementById('addressTipInfo').innerHTML = "";
    document.getElementById('checkTwoInfo').innerHTML = "";
    document.getElementById('Alter_stringMsg').innerHTML = "";
    $("#freqTipInfo").html("");
    document.getElementById("popWindow").style.display = '';
    document.getElementById("Alter_DataItem_Layer").style.display = '';
    // add by fyj, 西门子以太网 add datahandler
    document.getElementById("Alter_DataItemDHParamTip").innerHTML = "";
    // add end
    if (ChannelDeviceType == "AB-Ethernet/IP" || ChannelDeviceType == "AB-MicroLogix") {
        document.getElementById("Alter_Byte").style.display = "none";
        document.getElementById("Alter_Word").style.display = "none";
        document.getElementById("Alter_DWord").style.display = "none";
        if (coo == "English") {
            document.getElementById("Alter_Boolean").innerHTML = "Switch quantity";
            document.getElementById("Alter_Float").innerHTML = "Numerical value";
            document.getElementById("Alter_String").innerHTML = "String";
        } else {
            document.getElementById("Alter_Boolean").innerHTML = "开关量";
            document.getElementById("Alter_Float").innerHTML = "数值";
            document.getElementById("Alter_String").innerHTML = "字符串";
        }
    }
    // add by fyj , 西门子以太网 add datahandler

    $("#line_Alter_DataItemDHEnable").show();
    $("#DHMode1_alter").attr('checked', 'checked');
    $('#RWmode2Info').attr('disabled', false);
    $('#Alter_DataItemDHSelect').val('1');
    $('#Alter_DataItemDHParam').val('');
    $("#Alter_DHFunctionParam1").val("");
    $("#Alter_DHFunctionParam2").val("");
    $("#line_Alter_DataItemDHOpt").hide();
    $("#line_Alter_DataItemDHParamTip").hide();

    // add end
    $(document).ready(function () {
        $.get('../conf/config.xml', function (d1) {
            $(d1).find("model").each(function () {
                var $model = $(this);
                $model.find("device[id='" + DeviceID + "']").each(function () {
                    var $device = $(this);
                    $device.find("commDataItems").each(function () {
                        var $commDataItems = $(this);
                        $commDataItems.find("dataItem[id='" + txt + "']").each(function () {
                            var $dataItem = $(this);
                            var dataItemN = $dataItem.attr('n');
                            NowItemName = dataItemN;
                            var dataItemA = $dataItem.attr('alias');
                            var dataItemID = $dataItem.attr('id');
                            var dataItemFreq = $dataItem.attr('freq');
                            var dataItemReport = $dataItem.attr('report');
                            var dataItemType_w = $dataItem.attr('type');
                            var dataItemWR1 = $dataItem.attr('rw');
                            var dataItemConfig = $dataItem.attr('config');
                            var ConfigArr = new Array();
                            ConfigArr = dataItemConfig.split(";");

                            var dataItemAdd = ConfigArr[0];
                            if (dataItemReport == "3") {
                                $("input[name='Alter_ReportType']").each(function(){
                                    if($(this).val()=='1'){
                                        $(this).attr("checked",true);
                                    }
                                })
                            } else {
                                $("input[name='Alter_ReportType']").each(function(){
                                    if($(this).val()==dataItemReport){
                                        $(this).attr("checked",true);
                                    }
                                })
                            }
                            if (ChannelDeviceType == "AB-Ethernet/IP" || ChannelDeviceType == "AB-MicroLogix") {
                                $("#Alter_tr_string").hide();
                                $("#Alter_tr_string_msg").hide();
                                if (dataItemWR1 == "0")
                                    document.getElementById("RWmode1Info").checked = "checked";
                                if (dataItemWR1 == "1")
                                    document.getElementById("RWmode2Info").checked = "checked";

                                $("#Alter_DataItemID").val(txt);
                                document.getElementById("Alter_DataItemName").value = dataItemN;
                                document.getElementById("Alter_DataItemAlias").value = dataItemA;
                                document.getElementById("Alter_DataItemAddress").value = dataItemAdd;
                                if (dataItemType_w == "s") {
                                    document.getElementById("Alter_DataItemType").value = "STRING";
                                }
                                if (dataItemType_w == "a") {
                                    document.getElementById("Alter_DataItemType").value = "FLOAT";
                                }
                                if (dataItemType_w == "b") {
                                    document.getElementById("Alter_DataItemType").value = "BIT";
                                }
                                var Freq = "";
                                if (dataItemFreq % 60000 == 0) {
                                    Freq = dataItemFreq / 60000;
                                    $("#Alter_DataItemUnit").val("minute");
                                } else {
                                    Freq = dataItemFreq / 1000;
                                    $("#Alter_DataItemUnit").val("second");
                                }
                                document.getElementById("Alter_DataItemFreq").value = Freq;
                                // document.getElementById("Alter_DataItemReport").value = dataItemReport;
                            } else {
                                var dataItemType = ConfigArr[1];
                                var dataItemWR = ConfigArr[2];
                                if (dataItemWR == "0")
                                    document.getElementById("RWmode1Info").checked = "checked";
                                if (dataItemWR == "1")
                                    document.getElementById("RWmode2Info").checked = "checked";
                                $("#Alter_DataItemID").val(txt)
                                document.getElementById("Alter_DataItemName").value = dataItemN;
                                document.getElementById("Alter_DataItemAlias").value = dataItemA;
                                document.getElementById("Alter_DataItemAddress").value = dataItemAdd;

                                if (dataItemType.indexOf("STRING") != -1) {
                                    document.getElementById("Alter_DataItemType").value = "STRING";
                                    $("#Alter_tr_string").show();
                                    $("#Alter_tr_string_msg").show();
                                    $("#Alter_stringLength").val(dataItemType.substr(6));
                                } else {
                                    $("#Alter_tr_string").hide();
                                    $("#Alter_tr_string_msg").hide();
                                    document.getElementById("Alter_DataItemType").value = dataItemType;
                                }

                                var Freq = "";
                                if (dataItemFreq % 60000 == 0) {
                                    Freq = dataItemFreq / 60000;
                                    $("#Alter_DataItemUnit").val("minute");
                                } else {
                                    Freq = dataItemFreq / 1000;
                                    $("#Alter_DataItemUnit").val("second");
                                }
                                document.getElementById("Alter_DataItemFreq").value = Freq;
                                // document.getElementById("Alter_DataItemReport").value = dataItemReport;
                                //$("#Alter_DataItemType").val(dataItemType);
                            }
                            //$("#Alter_DataItemType").val(dataItemType);
                        });
                    });
                });
            });
            // add by fyj, SIEMENS-Ethernet增加datahandler驱动
            $(d1).find('task dataHandler item[id="' + txt + '"]').each(function () {
                $('#line_Alter_DataItemDHEnable').show();
                $('#line_Alter_DataItemDHOpt').show();
                $('#line_Alter_DataItemDHParamTip').show();
                var dhItem = $(this);
                $("#DHMode2_alter").attr("checked", "checked");
                var dhOptType = dhItem.attr('op');
                var dhOptParam = dhItem.attr('coe');
                if (dhOptType == '+') {
                    dhOptType = '1';
                } else if (dhOptType == '-') {
                    dhOptType = '2';
                } else if (dhOptType == '*') {
                    dhOptType = '3';
                } else if (dhOptType == '/') {
                    dhOptType = '4';
                } else if (dhOptType == 'b') {
                    dhOptType = '5';
                    // $('#RWmode2Info').attr('disabled', true);
                }
                $('#Alter_DataItemDHSelect').val(dhOptType);
                if(dhOptType=="#" ){
                    $("#Alter_DataItemDHParam").hide();
                    $("#Alter_DHFunctionParam1").show();
                    $("#Alter_DHFunctionParam2").show();
                    var reBrackets = /\([^\)]+\)/g;
                    var coeList = dhOptParam.match(reBrackets);
                    $("#Alter_DHFunctionParam1").val(coeList[0].substring(1,coeList[0].length-1) );
                    $("#Alter_DHFunctionParam2").val(coeList[1].substring(1,coeList[1].length-1) );
                  }else{
                    $("#Alter_DataItemDHParam").show();
                    $("#Alter_DHFunctionParam1").hide();
                    $("#Alter_DHFunctionParam2").hide();
                    $("#Alter_DataItemDHParam").val(dhOptParam);
                  }
            });

            // add end
        });
    });
}
// add by fyj, 西门子以太网增加datahandler驱动
function DHEnableClicked(radioVal) {
    if (radioVal == '0') {
        $('#line_Add_DataItemDHOpt').hide();
        $('#line_Add_DataItemDHParamTip').hide();
    } else {
        $('#line_Add_DataItemDHOpt').show();
        $('#line_Add_DataItemDHParamTip').show();
    }
}

function DHEnableClicked_alter(radioVal) {
    if (radioVal == '0') {
        $('#line_Alter_DataItemDHOpt').hide();
        $('#line_Alter_DataItemDHParamTip').hide();
    } else {
        $('#line_Alter_DataItemDHOpt').show();
        $('#line_Alter_DataItemDHParamTip').show();
    }
}

function ChangeDHSelect(dhSelect) {
    var optType = $(dhSelect).val();
    if (optType == "#") {
      $("#Add_DataItemDHParam").hide();
      $("#Add_DHFunctionParam1").show();
      $("#Add_DHFunctionParam2").show();
    } else {
      $("#Add_DataItemDHParam").show();
      $("#Add_DHFunctionParam1").hide();
      $("#Add_DHFunctionParam2").hide();
    }
}

function ChangeDHSelect_alter(dhSelect) {
    var optType = $(dhSelect).val();
    if (optType == "#") {
      $("#Alter_DataItemDHParam").hide();
      $("#Alter_DHFunctionParam1").show();
      $("#Alter_DHFunctionParam2").show();
    } else {
      $("#Alter_DataItemDHParam").show();
      $("#Alter_DHFunctionParam1").hide();
      $("#Alter_DHFunctionParam2").hide();
    }
}
// add end

//弹出PLC数据项添加层
function openPLCadd() {
    getID();
    document.getElementById("Add_DataItemName").value = "";
    document.getElementById("Add_DataItemAddress").value = "";
    document.getElementById("idTip").innerHTML = "";
    document.getElementById("nameTip").innerHTML = "";
    document.getElementById("AliasTip").innerHTML = "";
    document.getElementById("addressTip").innerHTML = "";
    $("#freqTip").html("");
    // add by fyj, hostlink add datahandler
    document.getElementById("Add_DataItemDHParamTip").innerHTML = "";
    // add end
    document.getElementById("checkTwo").innerHTML = "";
    document.getElementById("stringMsg").innerHTML = "";
    document.getElementsByName("Add_DataItemRWmode").value = "0";
    // document.getElementById("Add_DataItemReport").value = "1"
    $("input[name='Add_ReportType']").each(function(){
        if($(this).val()=="1"){
            $(this).attr("checked",true);
        }
    })
    document.getElementById("popWindow").style.display = ''
    document.getElementById("Add_DataItem_Layer").style.display = ''
    if (ChannelDeviceType == "AB-Ethernet/IP" || ChannelDeviceType == "AB-MicroLogix") {
        document.getElementById("Byte").style.display = "none";
        document.getElementById("Word").style.display = "none";
        document.getElementById("DWord").style.display = "none";
        if (coo == "English") {
            document.getElementById("Boolean").innerHTML = "Switch quantity";
            document.getElementById("Float").innerHTML = "Numerical value";
            document.getElementById("String").innerHTML = "String";
        } else {
            document.getElementById("Boolean").innerHTML = "开关量";
            document.getElementById("Float").innerHTML = "数值";
            document.getElementById("String").innerHTML = "字符串";
        }
    }
    // add by fyj, 西门子以太网增加datahandler驱动
    $('#line_Add_DataItemDHEnable').show();
    $('#DHMode1').attr('checked', 'checked');
    $('#RWmode2').attr('disabled', false);
    $("#Add_DataItemDHParam").show();
    $("#Add_DHFunctionParam1").hide();
    $("#Add_DHFunctionParam2").hide();
    $('#line_Add_DataItemDHOpt').hide();
    $('#line_Add_DataItemDHParamTip').hide();
    $('#Add_DataItemDHParam').val('');
    $('#Add_DataItemDHSelect').val('1');
    $("#Add_DHFunctionParam1").val("");
    $("#Add_DHFunctionParam2").val("");
}
//弹出删除层
function openDeleteLayer() {
    CheckedLength();
    document.getElementById("popWindow").style.display = "";
    document.getElementById("DeleteDataItemLayer").style.display = "";
    if (document.getElementById("AllDataitemID").value == "") {
        document.getElementById("NoDataItemChecked").style.display = "";
        document.getElementById("DeleteChecked").style.display = "none";
        document.getElementById("DeleteDataItem_Button_Confim").style.display = "none";
        document.getElementById("DeleteDataItem_Button_Cancel").style.display = "none";
        document.getElementById("DeleteDataItem_Success_Button_Confim").style.display = "";
    } else {
        document.getElementById("NoDataItemChecked").style.display = "none";
        document.getElementById("DeleteChecked").style.display = "";
        if (coo == "English") {
            document.getElementById("DeleteChecked").innerHTML = "Make sure to delete the selected<strong> &nbsp;" + checkLength + "&nbsp; </strong>dataItems?";
        } else {
            document.getElementById("DeleteChecked").innerHTML = "确定要删除选中的<strong> &nbsp;" + checkLength + "&nbsp; </strong>个数据项吗？";
        }
        document.getElementById("DeleteDataItem_Button_Confim").style.display = "";
        document.getElementById("DeleteDataItem_Button_Cancel").style.display = "";
        document.getElementById("DeleteDataItem_Success_Button_Confim").style.display = "none";
    }
}
//弹出帮助层

function Open_DataItemHelpLayer() {
    if (document.getElementById("Help_DataItemLayer").style.display == "none")
        document.getElementById("Help_DataItemLayer").style.display = ''
    else
        document.getElementById("Help_DataItemLayer").style.display = 'none'
}
//缺省 单选按钮
function changeReport() {
    if (document.getElementById("DataItemReport1").checked)
        document.getElementById("Add_DataItemReport").value = "1";
    else
        document.getElementById("Add_DataItemReport").value = "0";
}

function changeReportInfo() {
    if (document.getElementById("Alter_DataItemReport1").checked)
        document.getElementById("Alter_DataItemReport").value = "1";
    else
        document.getElementById("Alter_DataItemReport").value = "0";
}
//检查重名
function CheckReName(txt) {
    var string = document.getElementById("allItemName").innerHTML;
    var NameArr = new Array();
    NameArr = string.split(";");
    for (var i = 0; i < NameArr.length - 1; i++) {
        //alert(NameArr[i])
        if (txt != NameArr[i]) {} else {
            return false;
        }
    }
    return true;
}
//检查数据项名称输入格式
function Check_Chinese_Character(txt) {
    var str = txt;
    var re = /^[A-Za-z]\w*$/;
    if (re.test(str)) {
        return true;
    } else {
        return false;
    }
}
//添加数据项的校验
function Check_Add_DataItem() {
    var CheckID = $("#Add_DataItemID").val();
    var CheckName = $("#Add_DataItemName").val();
    var Alies = $("#Add_DataItemAlias").val();
    var Address = $("#Add_DataItemAddress").val();
    var FirAdd = Address.substr(0, 1);
    var Freq = $("#Add_DataItemFreq").val();

    var DataItemType = $("#Add_DataItemType").val();
    var StringLength = $("#stringLength").val();

    var reg = new RegExp("^[0-9]+$");
    var regID = new RegExp("^[1-9]+[0-9]*$");
    //校验数据项ID输入格式
    if (CheckID == "" || !regID.test(CheckID)) {
        if (coo == "English") {
            $("#idTip").html("The dataItem ID must be a non-negative integer");
        } else {
            $("#idTip").html("数据项ID必须为非负整数");
        }
    } else {
        $.ajax({
            type: "get",
            url: "../conf/config.xml",
            async: false,
            success: function (data) {
                var flag = true;
                $(data).find("model").each(function () {
                    var $model = $(this);
                    $model.find("device").each(function () {
                        var $device = $(this);
                        $device.find("commDataItems").each(function () {
                            var $commDataItems = $(this);
                            $commDataItems.find("dataItem").each(function () {
                                var $dataItem = $(this);
                                var dataItemID = $dataItem.attr('id');
                                if (dataItemID == CheckID) {
                                    if (coo == "English") {
                                        $("#idTip").html("The dataItem ID is repeated, please change");
                                    } else {
                                        $("#idTip").html("数据项ID已重复，请更改");
                                    }
                                    flag = false;
                                }
                            });
                        });
                    });
                });
                if (flag) {
                    $("#idTip").html("");
                }
            }
        });
    }
    //校验数据项名称输入格式
    if (!Check_Chinese_Character(CheckName)) {
        if (coo == "English") {
            $("#nameTip").html("*The dataItem name format error, only the alphanumeric underscore and must start with the letter");
        } else {
            $("#nameTip").html("*数据项名称格式错误，仅允许字母数字下划线且必须以字母开头");
        }
    } else {
        //校验数据项名称是否重名
        if (!CheckReName(CheckName)) {
            if (coo == "English") {
                $("#nameTip").html("The dataItem name is repeated");
            } else {
                $("#nameTip").html("数据项名称重复");
            }
        } else {
            $("#nameTip").html("");
        }
    }
    //校验数据项别名不为空
    if (Alies == "") {
        if (coo == "English") {
            $("#AliasTip").html("*Please fill in the alias");
        } else {
            $("#AliasTip").html("*请填写别名");
        }
    } else {
        $("#AliasTip").html("");
    }
    //校验地址不为空
    if (Address == "") {
        if (coo == "English") {
            $("#addressTip").html("*Please fill in the dataItem address");
        } else {
            $("#addressTip").html("*请填写数据项地址");
        }
    } else {
        //MicroLogix校验地址 author hongyuwang
        if (ChannelDeviceType == "AB-MicroLogix") {
            var Addressa = Address.toUpperCase();
            var typeAddress = Addressa.substring(0, 1);
            if (typeAddress == "O" || typeAddress == "I") {
                var word = /^(I|O):([0-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])$/;
                var wordbit = /^(I|O):([0-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])\/([0-9]*)$/;
                var wordbitrc = /^(I|O):([0-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])\/([0-9]*)(\[[0-9]*\])(\[[0-9]*\])$/;
                var wordbitr = /^(I|O):([0-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])\/([0-9]*)(\[[0-9]*\])$/;
                var bit = /^(I|O)\/([0-9]*)$/;
                var birrc = /^(I|O)\/([0-9]*)(\[[0-9]*\])(\[[0-9]*\])$/;
                var birr = /^(I|O)\/([0-9]*)(\[[0-9]*\])$/;
                if (word.test(Addressa) || wordbit.test(Addressa) || wordbitrc.test(Addressa) || wordbitr.test(Addressa) || bit.test(Addressa) || birrc.test(Addressa) || birr.test(Addressa)) {
                    $("#Add_DataItemAddress").val(Addressa);
                    $("#addressTip").html("");
                } else {
                    if (coo == "English") {
                        $("#addressTip").html("DataItem address input error");
                    } else {
                        $("#addressTip").html("数据项地址输入错误");
                    }
                }
            } else if (typeAddress == "S") {
                var word = /^(S:|S([0-9]*):)([0-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])$/;
                var wordrc = /^(S:|S([0-9]*):)([0-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])(\[[0-9]*\])(\[[0-9]*\])$/;
                var wordr = /^(S:|S([0-9]*):)([0-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])(\[[0-9]*\])$/;
                var wordbit = /^(S:|S([0-9]*):)([0-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])\/([0-9]*)$/;
                var wordbitrc = /^(S:|S([0-9]*):)([0-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])\/([0-9]*)(\[[0-9]*\])(\[[0-9]*\])$/;
                var wordbitr = /^(S:|S([0-9]*):)([0-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])\/([0-9]*)(\[[0-9]*\])$/;
                var bit = /^(S|S([0-9]*))\/([0-9]*)$/;
                var birrc = /^(S|S([0-9]*))\/([0-9]*)(\[[0-9]*\])(\[[0-9]*\])$/;
                var birr = /^(S|S([0-9]*))\/([0-9]*)(\[[0-9]*\])$/;
                if (word.test(Addressa) || wordbit.test(Addressa) || wordbitrc.test(Addressa) || wordbitr.test(Addressa) || bit.test(Addressa) || birrc.test(Addressa) || birr.test(Addressa) || wordrc.test(Addressa) || wordr.test(Addressa)) {
                    $("#Add_DataItemAddress").val(Addressa);
                    $("#addressTip").html("");
                } else {
                    if (coo == "English") {
                        $("#addressTip").html("Please fill in the correct state type dataItem address");
                    } else {
                        $("#addressTip").html("请填写正确的状态类型数据项地址");
                    }
                }
            } else if (typeAddress == "B" || typeAddress == "N") {
                var fileword = /^(B|N)(.*):([0-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])$/;
                var filewordrc = /^(B|N)(.*):([0-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])(\[[0-9]*\])(\[[0-9]*\])$/;
                var filewordr = /^(B|N)(.*):([0-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])(\[[0-9]*\])$/;
                var filewordbit = /^(B|N)(.*):([0-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])\/([0-9]*)$/;
                var filewordbitrc = /^(B|N)(.*):([0-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])\/([0-9]*)(\[[0-9]*\])(\[[0-9]*\])$/;
                var filewordbitr = /^(B|N)(.*):([0-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])\/([0-9]*)(\[[0-9]*\])$/;
                var filebit = /^(B|N)(.*)\/([0-9]*)$/;
                var filebirrc = /^(B|N)(.*)\/([0-9]*)(\[[0-9]*\])(\[[0-9]*\])$/;
                var filebirr = /^(B|N)(.*)\/([0-9]*)(\[[0-9]*\])$/;
                if (fileword.test(Addressa) || filewordbit.test(Addressa) || filewordbitrc.test(Addressa) || filewordbitr.test(Addressa) || filebit.test(Addressa) || filebirrc.test(Addressa) || filebirr.test(Addressa) || filewordrc.test(Addressa) || filewordr.test(Addressa)) {
                    $("#Add_DataItemAddress").val(Addressa);
                    $("#addressTip").html("");
                } else {
                    if (coo == "English") {
                        $("#addressTip").html("DataItem address input error");
                    } else {
                        $("#addressTip").html("数据项地址输入错误");
                    }
                }
            } else if (typeAddress == "T") {
                var ttype = /^T(.*):([0-9]*)\.(ACC|PRE|DN|TT|EN)$/;
                if (ttype.test(Addressa)) {
                    $("#Add_DataItemAddress").val(Addressa);
                    $("#addressTip").html("");
                } else {
                    if (coo == "English") {
                        $("#addressTip").html("Please fill in the correct timer type dataItem address");
                    } else {
                        $("#addressTip").html("请填写正确的计时器类型数据项地址");
                    }
                }
            } else if (typeAddress == "C") {
                var ctype = /^C(.*):([0-9]*)\.(ACC|PRE|DN|UA|OV|UN|CD|CU)$/;
                if (ctype.test(Addressa)) {
                    $("#Add_DataItemAddress").val(Addressa);
                    $("#addressTip").html("");
                } else {
                    if (coo == "English") {
                        $("#addressTip").html("Please fill in the correct counter type dataItem address");
                    } else {
                        $("#addressTip").html("请填写正确的计数器类型数据项地址");
                    }
                }
            } else if (typeAddress == "R") {
                var rtype = /^R(.*):([0-9]*)\.(LEN|POS|DN|FD|IN|UN|UL|ER|EM|EU|EN)$/;
                if (rtype.test(Addressa)) {
                    $("#Add_DataItemAddress").val(Addressa);
                    $("#addressTip").html("");
                } else {
                    if (coo == "English") {
                        $("#addressTip").html("DataItem address input error");
                    } else {
                        $("#addressTip").html("数据项地址输入错误");
                    }
                }
            } else if (typeAddress == "F") {
                var filee = /^F(.*):([0-9]*)$/;
                var fileerc = /^(B|N)(.*):([0-9]*)(\[[0-9]*\])(\[[0-9]*\])$/;
                var fileer = /^(B|N)(.*):([0-9]*)(\[[0-9]*\])$/;
                if (filee.test(Addressa) || fileerc.test(Addressa) || fileer.test(Addressa)) {
                    $("#Add_DataItemAddress").val(Addressa);
                    $("#addressTip").html("");
                } else {
                    if (coo == "English") {
                        $("#addressTip").html("DataItem address input error");
                    } else {
                        $("#addressTip").html("数据项地址输入错误");
                    }
                }
            } else {
                if (coo == "English") {
                    $("#addressTip").html("DataItem address input error");
                } else {
                    $("#addressTip").html("数据项地址输入错误");
                }
            }
        } else {
            //校验地址第一位不为数字
            if (reg.test(FirAdd) == 1) {
                if (coo == "English") {
                    $("#addressTip").html("*The first dataItem address cannot be a positive integer");
                } else {
                    $("#addressTip").html("*数据项地址第一位不能为正整数");
                }
            } else {
                $("#addressTip").html("");
            }
        }
    }
    //校验频率不为空
    if (Freq == "") {
        if (coo == "English") {
            $("#freqTip").html("*Please fill in the sample frequency")
        } else {
            $("#freqTip").html("*请填写采集频率")
        }
    } else {
        if (!reg.test(Freq) || Freq == 0) {
            if (coo == "English") {
                $("#freqTip").html("*The frequencies must be positive integers");
            } else {
                $("#freqTip").html("*频率必须为正整数");
            }
        } else {
            $.ajax({
              type: "get",
              url: "../conf/Common.xml",
              async: false,
              success: function (data) {
                var minFrequency = $(data).find("MinFrequency").text();
                var currentFreq = 0;
                if ($("#Add_DataItemUnit").val() == "second") {
                  currentFreq = parseInt(Freq) * 1000;
                } else {
                  currentFreq = parseInt(Freq) * 1000 * 60;
                }

                if (currentFreq < parseInt(minFrequency)) {
                  if (coo == "English") {
                    $("#freqTip").html(
                      "*The lowest frequency currently supported is" +
                        minFrequency / 1000 +
                        "seconds"
                    );
                  } else {
                    $("#freqTip").html(
                      "*当前支持的最低频率为" + minFrequency / 1000 + "秒"
                    );
                  }
                } else {
                  $("#freqTip").html("");
                }
              },
            });
        }
    }

    //如果数据项类型为String，则校验长度是否为整数且为偶数
    if (ChannelDeviceType != "AB-Ethernet/IP" && ChannelDeviceType != "AB-MicroLogix" && DataItemType == "STRING") {
        if (StringLength == "") {
            if (coo == "English") {
                $("#stringMsg").html("*Please input length");
            } else {
                $("#stringMsg").html("*请输入长度");
            }
        } else {
            if (reg.test(StringLength) && parseInt(StringLength) % 2 == 0) {
                $("#stringMsg").html("");
            } else {
                if (coo == "English") {
                    $("#stringMsg").html("*The length must be numeric and even");
                } else {
                    $("#stringMsg").html("*长度必须为数字且为偶数");
                }
            }
        }
    } else {
        $("#stringMsg").html("");
    }

    // add by fyj, OMRON-HostLink增加datahandler驱动
    $("#Add_DataItemDHParamTip").html('');
    var isChecked = $("input[name='Add_DataItemDHEnable']:checked").val();
    if (isChecked == '1') {
        var paramVal = $('#Add_DataItemDHParam').val();
        if ($("#Add_DataItemDHSelect").val() == "#") {
            var linearParam1 = $("#Add_DHFunctionParam1").val();
            var linearParam2 = $("#Add_DHFunctionParam2").val();
            if (linearParam1 == "" || linearParam2 == "") {
              if (coo == "English") {
                $("#Add_DataItemDHParamTip").html(
                  "Please fill in the value operation parameters"
                );
              } else {
                $("#Add_DataItemDHParamTip").html("请填写值运算参数");
              }
            } else {
              var dhReg = /^-?[0-9]+.?[0-9]*$/;
              if (!dhReg.test(linearParam1) || !dhReg.test(linearParam2)) {
                if (coo == "English") {
                  $("#Add_DataItemDHParamTip").html(
                    "The value operation parameter must be a number"
                  );
                } else {
                  $("#Add_DataItemDHParamTip").html("值运算参数必须是数字");
                }
              }
            }
          } else if (paramVal == "") {
            if (coo == "English") {
                $("#Add_DataItemDHParamTip").html('Please fill in the value operation parameters');
            } else {
                $("#Add_DataItemDHParamTip").html('请填写值运算参数');
            }
        } else {
            // 校验输入的操作数是否是数字
            var dhReg = /^-?[0-9]+.?[0-9]*$/;
            if (!dhReg.test(paramVal)) {
                if (coo == "English") {
                    $("#Add_DataItemDHParamTip").html('The value operation parameter must be a number');
                } else {
                    $("#Add_DataItemDHParamTip").html('值运算参数必须是数字');
                }
            } else if ($("#Add_DataItemDHSelect").val() == '5') {
                var dhReg = /^[0-9]+$/;
                if (!dhReg.test(paramVal)) {
                    if (coo == "English") {
                        $("#Add_DataItemDHParamTip").html('The parameter of the fetch operation must be an integer');
                    } else {
                        $("#Add_DataItemDHParamTip").html('取位运算的参数必须是整数');
                    }
                } else {
                    var paramVal = Number(paramVal);
                    if (paramVal < 0 || paramVal > 31) {
                        if (coo == "English") {
                            $("#Add_DataItemDHParamTip").html('The range of parameters for the fetch operation must be 0 to 31');
                        } else {
                            $("#Add_DataItemDHParamTip").html('取位运算的参数的范围必须是0到31');
                        }
                    }
                }
            }
        }
    }

    // add end

    //判断是否通过
    if ($("#idTip").html() == "" && $("#nameTip").html() == "" && $("#AliasTip").html() == "" && $("#addressTip").html() == "" && $("#freqTip").html() == "" && $("#stringMsg").html() == "" && $("#Add_DataItemDHParamTip").html() == '') {
        //        全部通过
        Add_DataItemMethod();
    } else {}
}

//添加数据点方法
function Add_DataItemMethod() {
    //赋值
    document.getElementById('checkTwo').innerHTML = "";
    var reg = /[a-zA-Z]/g;
    var str = document.getElementById("Add_DataItemAddress").value;
    var length = str.match(reg).length;
    //增加String类型。如果是String，则config中写入STRING+长度
    var DataItemType = $("#Add_DataItemType").val();
    var StringLength = $("#stringLength").val();
    if (document.getElementById("Add_DataItemType").value == "BIT")
        document.getElementById("Add_DataItemType_YuToXHZhang").value = "b";
    else if (document.getElementById("Add_DataItemType").value == "STRING")
        document.getElementById("Add_DataItemType_YuToXHZhang").value = "s";
    else
        document.getElementById("Add_DataItemType_YuToXHZhang").value = "a";
    var Freq = document.getElementById("Add_DataItemFreq").value;
    var Unit = document.getElementById("Add_DataItemUnit").value;
    if (Unit == "minute") {
        Freq = Freq * 60000;
    } else {
        Freq = Freq * 1000;
    }
    //数据项ID
    document.getElementById("Add_DataItemID_YuToXHZhang").value = document.getElementById("Add_DataItemID").value;
    //数据项名称
    document.getElementById("Add_DataItemName_YuToXHZhang").value = document.getElementById("Add_DataItemName").value;
    //别名
    document.getElementById("Add_DataItemAlias_YuToXHZhang").value = document.getElementById("Add_DataItemAlias").value;
    //频率
    document.getElementById("Add_DataItemFreq_YuToXHZhang").value = Freq;
    //读写模式
    document.getElementById("Add_DataItemRWmode_YuToXHZhang").value = $("input[name='Add_DataItemRWmode']:checked").val();
    //是否上报
    $("#Add_DataItemReport_YuToXHZhang").val( $("input[name='Add_ReportType']:checked").val()  );
    //数据项信息

    var isChecked = $("input[name='Add_DataItemDHEnable']:checked").val();
    $('#Add_DataItemDHEnable_YuToXHZhang').val(isChecked);
    if (isChecked == '1') {
        $('#Add_DataItemDHOptType_YuToXHZhang').val($('#Add_DataItemDHSelect').val());
        if ($("#Add_DataItemDHSelect").val() === "#") {
            $("#Add_DataItemDHOptParam_YuToXHZhang").val(
              $("#Add_DHFunctionParam1").val() +
                "|" +
                $("#Add_DHFunctionParam2").val()
            );
          } else {
            $("#Add_DataItemDHOptParam_YuToXHZhang").val(
              $("#Add_DataItemDHParam").val()
            );
          }
    }

    if (ChannelDeviceType == "AB-DF1") {
        str = str.toUpperCase();
        document.getElementById("Add_DataItemConfig_YuToXHZhang").value = str + ";" + (DataItemType == "STRING" ? "STRING" + StringLength : DataItemType) + ";" + $("input[name='Add_DataItemRWmode']:checked").val();
    } else if (ChannelDeviceType == "AB-Ethernet/IP" || ChannelDeviceType == "AB-MicroLogix") {
        document.getElementById("Add_DataItemConfig_YuToXHZhang").value = str;
    }
    //add begin by x
    else if (ChannelDeviceType == "TwinCAT") {
        document.getElementById("Add_DataItemConfig_YuToXHZhang").value = str + ";" + (DataItemType == "STRING" ? "STRING" + StringLength : DataItemType);
    }
    //end add
    // add by fyj, SIEMENS-Ethernet增加datahandler驱动
    else if (ChannelDeviceType == 'SIEMENS-Ethernet') {
        document.getElementById("Add_DataItemConfig_YuToXHZhang").value = str + ";" + (DataItemType == "STRING" ? "STRING" + StringLength : DataItemType) + ";" + $("input[name='Add_DataItemRWmode']:checked").val();
    }
    // add end
    else {
        document.getElementById("Add_DataItemConfig_YuToXHZhang").value = str + ";" + (DataItemType == "STRING" ? "STRING" + StringLength : DataItemType) + ";" + $("input[name='Add_DataItemRWmode']:checked").val();
    }

    //设备ID
    document.getElementById("Add_DeviceID_YuToXHZhang").value = DeviceID;
    $("#return3").attr("disabled", "disabled");
    $("#return4").attr("disabled", "disabled");
    var params = $("#Add_DataItemForm_YuToXHZhang").serialize();
    $.ajax({
        type: "post",
        url: "cgi-bin/device/AddDataitem.py",
        data: params,
        async: true,
        success: function (data) {
            $("#popWindow").hide();
            $("#Add_DataItem_Layer").hide();
            $("#return3").attr("disabled", "");
            $("#return4").attr("disabled", "");
            getData();
        }
    });
}

//修改数据项校验
function Check_Alter_DataItem() {
    var CheckID = $("#Alter_DataItemID").val();
    var CheckName = $("#Alter_DataItemName").val();
    var Alies = $("#Alter_DataItemAlias").val();
    var Address = $("#Alter_DataItemAddress").val();
    var FirAdd = Address.substr(0, 1);
    var Freq = $("#Alter_DataItemFreq").val();
    var reg = new RegExp("^[0-9]+$");
    var regID = new RegExp("^[1-9]+[0-9]*$");
    var DataItemType = $("#Alter_DataItemType").val();
    var StringLength = $("#Alter_stringLength").val();
    //校验数据项ID输入格式
    if (!regID.test(CheckID)) {
        if (coo == "English") {
            $("#idTipInfo").html("The dataItem ID must be a non-negative integer");
        } else {
            $("#idTipInfo").html("数据项ID必须为非负整数");
        }
    } else {
        $.ajax({
            type: "get",
            url: "../conf/config.xml",
            async: false,
            success: function (data) {
                var flag = 0;
                $(data).find("model").each(function () {
                    var $model = $(this);
                    $model.find("device").each(function () {
                        var $device = $(this);
                        $device.find("commDataItems").each(function () {
                            var $commDataItems = $(this);
                            $commDataItems.find("dataItem").each(function () {
                                var $dataItem = $(this);
                                var dataItemID = $dataItem.attr('id');
                                if (dataItemID == CheckID) {
                                    var dataItemName = $dataItem.attr('n');
                                    if (dataItemName == NowItemName) {
                                        //跳过
                                    } else {
                                        flag = flag + 1;
                                    }
                                }
                            });
                        });
                    });
                });
                if (flag < 1) {
                    $("#idTipInfo").html("");
                } else {
                    if (coo == "English") {
                        $("#idTipInfo").html("The dataItem ID is repeated, please change");
                    } else {
                        $("#idTipInfo").html("数据项ID已重复，请更改");
                    }
                }
            }
        });
    }

    //校验数据项名称输入格式
    if (!Check_Chinese_Character(CheckName)) {
        if (coo == "English") {
            $("#nameTipInfo").html("*The dataItem name format error, only the alphanumeric underscore and must start with the letter");
        } else {
            $("#nameTipInfo").html("*数据项名称格式错误，仅允许字母数字下划线且必须以字母开头");
        }
    } else {
        //名字未修改时，不校验重名
        if (CheckName == NowItemName) {
            $("#nameTipInfo").html("");
        } else {
            //校验数据项名称是否重名
            if (!CheckReName(CheckName)) {
                if (coo == "English") {
                    $("#nameTipInfo").html("The data item name is repeated")
                } else {
                    $("#nameTipInfo").html("数据项名称重复")
                }
            } else {
                $("#nameTipInfo").html("");
            }
        }
    }
    //校验数据项别名不为空
    if (Alies == "") {
        if (coo == "English") {
            $("#AliasTipInfo").html("*Please fill in the alias")
        } else {
            $("#AliasTipInfo").html("*请填写别名")
        }
    } else {
        $("#AliasTipInfo").html("");
    }
    if (Address == "") {
        if (coo == "English") {
            $("#addressTipInfo").html("*Please fill in the data item address")
        } else {
            $("#addressTipInfo").html("*请填写数据项地址")
        }
    } else {
        if (ChannelDeviceType == "AB-MicroLogix") {
            var Addressa = Address.toUpperCase();
            var typeAddress = Addressa.substring(0, 1);
            if (typeAddress == "O" || typeAddress == "I") {
                var word = /^(I|O):([0-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])$/;
                var wordbit = /^(I|O):([0-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])\/([0-9]*)$/;
                var wordbitrc = /^(I|O):([0-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])\/([0-9]*)(\[[0-9]*\])(\[[0-9]*\])$/;
                var wordbitr = /^(I|O):([0-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])\/([0-9]*)(\[[0-9]*\])$/;
                var bit = /^(I|O)\/([0-9]*)$/;
                var birrc = /^(I|O)\/([0-9]*)(\[[0-9]*\])(\[[0-9]*\])$/;
                var birr = /^(I|O)\/([0-9]*)(\[[0-9]*\])$/;
                if (word.test(Addressa) || wordbit.test(Addressa) || wordbitrc.test(Addressa) || wordbitr.test(Addressa) || bit.test(Addressa) || birrc.test(Addressa) || birr.test(Addressa)) {
                    $("#Alter_DataItemAddress").val(Addressa);
                    $("#addressTipInfo").html("");
                } else {
                    if (coo == "English") {
                        $("#addressTipInfo").html("Data item address input error");
                    } else {
                        $("#addressTipInfo").html("数据项地址输入错误");
                    }
                }
            } else if (typeAddress == "S") {
                var word = /^(S:|S([0-9]*):)([0-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])$/;
                var wordrc = /^(S:|S([0-9]*):)([0-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])(\[[0-9]*\])(\[[0-9]*\])$/;
                var wordr = /^(S:|S([0-9]*):)([0-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])(\[[0-9]*\])$/;
                var wordbit = /^(S:|S([0-9]*):)([0-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])\/([0-9]*)$/;
                var wordbitrc = /^(S:|S([0-9]*):)([0-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])\/([0-9]*)(\[[0-9]*\])(\[[0-9]*\])$/;
                var wordbitr = /^(S:|S([0-9]*):)([0-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])\/([0-9]*)(\[[0-9]*\])$/;
                var bit = /^(S|S([0-9]*))\/([0-9]*)$/;
                var birrc = /^(S|S([0-9]*))\/([0-9]*)(\[[0-9]*\])(\[[0-9]*\])$/;
                var birr = /^(S|S([0-9]*))\/([0-9]*)(\[[0-9]*\])$/;
                if (word.test(Addressa) || wordbit.test(Addressa) || wordbitrc.test(Addressa) || wordbitr.test(Addressa) || bit.test(Addressa) || birrc.test(Addressa) || birr.test(Addressa) || wordrc.test(Addressa) || wordr.test(Addressa)) {
                    $("#Alter_DataItemAddress").val(Addressa);
                    $("#addressTipInfo").html("");
                } else {
                    if (coo == "English") {
                        $("#addressTipInfo").html("Please fill in the correct state type data item address");
                    } else {
                        $("#addressTipInfo").html("请填写正确的状态类型数据项地址");
                    }
                }
            } else if (typeAddress == "B" || typeAddress == "N") {
                var fileword = /^(B|N)(.*):([0-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])$/;
                var filewordrc = /^(B|N)(.*):([0-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])(\[[0-9]*\])(\[[0-9]*\])$/;
                var filewordr = /^(B|N)(.*):([0-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])(\[[0-9]*\])$/;
                var filewordbit = /^(B|N)(.*):([0-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])\/([0-9]*)$/;
                var filewordbitrc = /^(B|N)(.*):([0-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])\/([0-9]*)(\[[0-9]*\])(\[[0-9]*\])$/;
                var filewordbitr = /^(B|N)(.*):([0-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])\/([0-9]*)(\[[0-9]*\])$/;
                var filebit = /^(B|N)(.*)\/([0-9]*)$/;
                var filebirrc = /^(B|N)(.*)\/([0-9]*)(\[[0-9]*\])(\[[0-9]*\])$/;
                var filebirr = /^(B|N)(.*)\/([0-9]*)(\[[0-9]*\])$/;
                if (fileword.test(Addressa) || filewordbit.test(Addressa) || filewordbitrc.test(Addressa) || filewordbitr.test(Addressa) || filebit.test(Addressa) || filebirrc.test(Addressa) || filebirr.test(Addressa) || filewordrc.test(Addressa) || filewordr.test(Addressa)) {
                    $("#Alter_DataItemAddress").val(Addressa);
                    $("#addressTipInfo").html("");
                } else {
                    if (coo == "English") {
                        $("#addressTipInfo").html("Data item address input error");
                    } else {
                        $("#addressTipInfo").html("数据项地址输入错误");
                    }
                }
            } else if (typeAddress == "T") {
                var ttype = /^T(.*):([0-9]*)\.(ACC|PRE|DN|TT|EN)$/;
                if (ttype.test(Addressa)) {
                    $("#Alter_DataItemAddress").val(Addressa);
                    $("#addressTipInfo").html("");
                } else {
                    if (coo == "English") {
                        $("#addressTipInfo").html("Please fill in the correct timer type data item address");
                    } else {
                        $("#addressTipInfo").html("请填写正确的计时器类型数据项地址");
                    }
                }
            } else if (typeAddress == "C") {
                var ctype = /^C(.*):([0-9]*)\.(ACC|PRE|DN|UA|OV|UN|CD|CU)$/;
                if (ctype.test(Addressa)) {
                    $("#Alter_DataItemAddress").val(Addressa);
                    $("#addressTipInfo").html("");
                } else {
                    if (coo == "English") {
                        $("#addressTipInfo").html("Please fill in the correct counter type data item address");
                    } else {
                        $("#addressTipInfo").html("请填写正确的计数器类型数据项地址");
                    }
                }
            } else if (typeAddress == "R") {
                var rtype = /^R(.*):([0-9]*)\.(LEN|POS|DN|FD|IN|UN|UL|ER|EM|EU|EN)$/;
                if (rtype.test(Addressa)) {
                    $("#Alter_DataItemAddress").val(Addressa);
                    $("#addressTipInfo").html("");
                } else {
                    if (coo == "English") {
                        $("#addressTipInfo").html("Data item address input error");
                    } else {
                        $("#addressTipInfo").html("数据项地址输入错误");
                    }
                }
            } else if (typeAddress == "F") {
                var filee = /^F(.*):([0-9]*)$/;
                var fileerc = /^(B|N)(.*):([0-9]*)(\[[0-9]*\])(\[[0-9]*\])$/;
                var fileer = /^(B|N)(.*):([0-9]*)(\[[0-9]*\])$/;
                if (filee.test(Addressa) || fileerc.test(Addressa) || fileer.test(Addressa)) {
                    $("#Alter_DataItemAddress").val(Addressa);
                    $("#addressTipInfo").html("");
                } else {
                    if (coo == "English") {
                        $("#addressTipInfo").html("Data item address input error");
                    } else {
                        $("#addressTipInfo").html("数据项地址输入错误");
                    }
                }
            } else {
                if (coo == "English") {
                    $("#addressTipInfo").html("Data item address input error");
                } else {
                    $("#addressTipInfo").html("数据项地址输入错误");
                }
            }
        } else {
            //校验地址第一位不为数字
            if (reg.test(FirAdd) == 1) {
                if (coo == "English") {
                    $("#addressTipInfo").html("*The first data item address cannot be a positive integer");
                } else {
                    $("#addressTipInfo").html("*数据项地址第一位不能为正整数");
                }
            } else {
                $("#addressTipInfo").html("");
            }
        }
    }


    //校验频率不为空
    if (Freq == "") {
        if (coo == "English") {
            $("#freqTipInfo").html("*Please fill in the sample frequency")
        } else {
            $("#freqTipInfo").html("*请填写采集频率")
        }
    } else {
        if (!reg.test(Freq) || Freq == 0) {
            if (coo == "English") {
                $("#freqTipInfo").html("*The frequencies must be positive integers");
            } else {
                $("#freqTipInfo").html("*频率必须为正整数");
            }
        } else {
            $.ajax({
              type: "get",
              url: "../conf/Common.xml",
              async: false,
              success: function (data) {
                var minFrequency = $(data).find("MinFrequency").text();
                var currentFreq = 0;
                if ($("#Alter_DataItemUnit").val() == "second") {
                  currentFreq = parseInt(Freq) * 1000;
                } else {
                  currentFreq = parseInt(Freq) * 1000 * 60;
                }

                if (currentFreq < parseInt(minFrequency)) {
                  if (coo == "English") {
                    $("#freqTipInfo").html(
                      "*The lowest frequency currently supported is" +
                        minFrequency / 1000 +
                        "seconds"
                    );
                  } else {
                    $("#freqTipInfo").html(
                      "*当前支持的最低频率为" + minFrequency / 1000 + "秒"
                    );
                  }
                } else {
                  $("#freqTipInfo").html("");
                }
              },
            });
        }
    }

    //如果数据项类型为String，则校验长度是否为整数且为偶数
    if (ChannelDeviceType != "AB-Ethernet/IP" && DataItemType == "STRING" && ChannelDeviceType != "AB-MicroLogix") {
        if (StringLength == "") {
            if (coo == "English") {
                $("#Alter_stringMsg").html("*Please input length");
            } else {
                $("#Alter_stringMsg").html("*请输入长度");
            }
        } else {
            if (reg.test(StringLength) && parseInt(StringLength) % 2 == 0) {
                $("#Alter_stringMsg").html("");
            } else {
                if (coo == "English") {
                    $("#Alter_stringMsg").html("*The length must be numeric and even");
                } else {
                    $("#Alter_stringMsg").html("*长度必须为数字且为偶数");
                }
            }
        }
    } else {
        $("#Alter_stringMsg").html("");
    }
    // add by fyj, 西门子以太网增加datahandler驱动
    $("#Alter_DataItemDHParamTip").html('');
    var isChecked = $("input[name='Alter_DataItemDHEnable']:checked").val();
    if (isChecked == '1') {
        var paramVal = $('#Alter_DataItemDHParam').val();
        if ($("#Alter_DataItemDHSelect").val() == "#") {
            var linearParam1 = $("#Alter_DHFunctionParam1").val();
            var linearParam2 = $("#Alter_DHFunctionParam2").val();
            if (linearParam1 == "" || linearParam2 == "") {
              if (coo == "English") {
                $("#Alter_DataItemDHParamTip").html(
                  "Please fill in the value operation parameters"
                );
              } else {
                $("#Alter_DataItemDHParamTip").html("请填写值运算参数");
              }
            } else {
              var dhReg = /^-?[0-9]+.?[0-9]*$/;
              if (!dhReg.test(linearParam1) || !dhReg.test(linearParam2)) {
                if (coo == "English") {
                  $("#Alter_DataItemDHParamTip").html(
                    "The value operation parameter must be a number"
                  );
                } else {
                  $("#Alter_DataItemDHParamTip").html("值运算参数必须是数字");
                }
              }
            }
          }else if (paramVal == "") {
            if (coo == "English") {
                $("#Alter_DataItemDHParamTip").html('Please fill in the value operation parameters');
            } else {
                $("#Alter_DataItemDHParamTip").html('请填写值运算参数');
            }
        } else {
            // 校验输入的操作数是否是数字
            var dhReg = /^-?[0-9]+.?[0-9]*$/;
            if (!dhReg.test(paramVal)) {
                if (coo == "English") {
                    $("#Alter_DataItemDHParamTip").html('The value operation parameter must be a number');
                } else {
                    $("#Alter_DataItemDHParamTip").html('值运算参数必须是数字');
                }
            } else if ($("#Alter_DataItemDHSelect").val() == '5') {
                var dhReg = /^[0-9]+$/;
                if (!dhReg.test(paramVal)) {
                    if (coo == "English") {
                        $("#Alter_DataItemDHParamTip").html('The parameter of the fetch operation must be an integer');
                    } else {
                        $("#Alter_DataItemDHParamTip").html('取位运算的参数必须是整数');
                    }
                } else {
                    var paramVal = Number(paramVal);
                    if (paramVal < 0 || paramVal > 31) {
                        if (coo == "English") {
                            $("#Alter_DataItemDHParamTip").html('The range of parameters for the fetch operation must be 0 to 31');
                        } else {
                            $("#Alter_DataItemDHParamTip").html('取位运算的参数的范围必须是0到31');
                        }
                    }
                }
            }
        }
    }

    // add end
    //判断是否通过
    if ($("#idTipInfo").html() == "" && $("#nameTipInfo").html() == "" && $("#AliasTipInfo").html() == "" && $("#addressTipInfo").html() == "" && $("#freqTipInfo").html() == "" && $("#Alter_stringMsg").html() == "" && $("#Alter_DataItemDHParamTip").html() == '') {
        //        全部通过
        Alter_DataItemMethod();
    } else {}
}
//修改数据项方法

function Alter_DataItemMethod() {
    document.getElementById('checkTwoInfo').innerHTML = "";
    var reg = /[a-zA-Z]/g;
    var str = document.getElementById("Alter_DataItemAddress").value;
    var length = str.match(reg).length;

    var DataItemType = $("#Alter_DataItemType").val();
    var StringLength = $("#Alter_stringLength").val();
    var Freq = document.getElementById("Alter_DataItemFreq").value;
    var Unit = document.getElementById("Alter_DataItemUnit").value;
    if (Unit == "minute") {
        Freq = Freq * 60000;
    } else {
        Freq = Freq * 1000;
    }
    if (document.getElementById("Alter_DataItemType").value == "BIT")
        document.getElementById("Alter_DataItemType_YuToXHZhang").value = "b";
    else if (document.getElementById("Alter_DataItemType").value == "STRING")
        document.getElementById("Alter_DataItemType_YuToXHZhang").value = "s";
    else
        document.getElementById("Alter_DataItemType_YuToXHZhang").value = "a";
    //数据项类型
    //document.getElementById("Alter_DataItemType_YuToXHZhang").value = $("#Alter_DataItemType").val();
    //设备ID
    document.getElementById("Alter_DeviceID_YuToXHZhang").value = DeviceID;
    //数据项ID
    document.getElementById("Alter_DataItemID_after").value = document.getElementById("Alter_DataItemID").value;
    //数据项名称
    document.getElementById("Alter_DataItemName_YuToXHZhang").value = document.getElementById("Alter_DataItemName").value;
    //数据项别名
    document.getElementById("Alter_DataItemAlias_YuToXHZhang").value = document.getElementById("Alter_DataItemAlias").value;
    //读写模式
    document.getElementById("Alter_DataItemRWmode_YuToXHZhang").value = $("input[name='Alter_DataItemRWmode']:checked").val();
    //频率
    document.getElementById("Alter_DataItemFreq_YuToXHZhang").value = Freq;
    //是否上报
    $("#Alter_DataItemReport_YuToXHZhang").val( $("input[name='Alter_ReportType']:checked").val() );
    //add datahandler
    var isChecked = $("input[name='Alter_DataItemDHEnable']:checked").val();
    $('#Alter_DataItemDHEnable_YuToXHZhang').val(isChecked);
    if (isChecked == '1') {
        $('#Alter_DataItemDHOptType_YuToXHZhang').val($('#Alter_DataItemDHSelect').val());
        if ($("#Alter_DataItemDHSelect").val() === "#") {
            $("#Alter_DataItemDHOptParam_YuToXHZhang").val(
              $("#Alter_DHFunctionParam1").val() +
                "|" +
                $("#Alter_DHFunctionParam2").val()
            );
          } else {
            $("#Alter_DataItemDHOptParam_YuToXHZhang").val(
              $("#Alter_DataItemDHParam").val()
            );
          }
    }

    //数据项配置字符串
    if (ChannelDeviceType == "AB-DF1") {
        str = str.toUpperCase();
        document.getElementById("Alter_DataItemConfig_YuToXHZhang").value = str + ";" + (DataItemType == "STRING" ? "STRING" + StringLength : DataItemType) + ";" + $("input[name='Alter_DataItemRWmode']:checked").val();
    } else if (ChannelDeviceType == "AB-Ethernet/IP" || ChannelDeviceType == "AB-MicroLogix") {
        document.getElementById("Alter_DataItemConfig_YuToXHZhang").value = str;
    }
    // add by fyj, SIEMENS-Ethernet 
    else if (ChannelDeviceType == 'SIEMENS-Ethernet') {
        document.getElementById("Alter_DataItemConfig_YuToXHZhang").value = str + ";" + (DataItemType == "STRING" ? "STRING" + StringLength : DataItemType) + ";" + $("input[name='Alter_DataItemRWmode']:checked").val();
    }
    // add end
    else {
        document.getElementById("Alter_DataItemConfig_YuToXHZhang").value = str + ";" + (DataItemType == "STRING" ? "STRING" + StringLength : DataItemType) + ";" + $("input[name='Alter_DataItemRWmode']:checked").val();
    }

    $("#return5").attr("disabled", "disabled");
    $("#return6").attr("disabled", "disabled");
    var params = $("#Alter_DataItemForm_YuToXHZhang").serialize();
    $.ajax({
        type: "post",
        url: "cgi-bin/device/AlterDataitem.py",
        data: params,
        async: true,
        success: function (data) {
            $("#popWindow").hide();
            $("#Alter_DataItem_Layer").hide();
            $("#return5").attr("disabled", "");
            $("#return6").attr("disabled", "");
            getData();
        }
    });
}

//全局一个需要删除的长度
var checkLength = "";

function CheckedLength() {
    checkLength = 0;
    document.getElementById("AllDataitemID").value = "";
    document.getElementById("Delete_DataItemAllID_YuToXHZhang").value = "";
    var inputs = document.getElementsByName("tryadd");
    var length = inputs.length;
    for (var i = 0; i < length; i++) {
        if (inputs[i].checked) {
            document.getElementById("AllDataitemID").value += inputs[i].value + ";";
            checkLength++;
        }
    }
    var str = document.getElementById("AllDataitemID").value;
    var strArr = new Array();
    strArr = str.split(";");
    var maxlength = strArr.length;
    for (var j = 0; j < maxlength - 2; j++) {
        document.getElementById("Delete_DataItemAllID_YuToXHZhang").value += strArr[j] + ",";
    }
    document.getElementById("Delete_DataItemAllID_YuToXHZhang").value += strArr[maxlength - 2];
}
//删除数据项
function DeleteConfig() {
    document.getElementById("Delete_DeviceID_YuToXHZhang").value = DeviceID;
    CheckedLength();
    $("#DeleteDataItem_Button_Confim").attr("disabled", "disabled");
    $("#DeleteDataItem_Button_Cancel").attr("disabled", "disabled");
    var params = $("#Delete_DataItemForm_YuToXHZhang").serialize();
    $.ajax({
        type: "post",
        url: "cgi-bin/device/DeleteDataitem.py",
        data: params,
        async: true,
        success: function (data) {
            $("#popWindow").hide();
            $("#DeleteDataItemLayer").hide();
            $("#DeleteDataItem_Button_Confim").attr("disabled", "");
            $("#DeleteDataItem_Button_Cancel").attr("disabled", "");
            getData();
            $("#selectAll").attr("checked", "");
        }
    });
}
//全选和反选
function addTry() {
    if (document.getElementById("selectAll").checked) {
        var inputs = document.getElementsByName("tryadd");
        for (var i = 0; i < inputs.length; i++) {
            inputs[i].checked = true;
        }
    } else {
        var inputs = document.getElementsByName("tryadd");
        for (var i = 0; i < inputs.length; i++) {
            inputs[i].checked = false;
        }
    }
}
//下发数据项
function Open_IssuedLayer() {
    document.getElementById("popWindow").style.display = ''
    document.getElementById("IssuedLayer").style.display = ''
    document.getElementById("ConUp1").style.display = ''
    $("#up_success").hide();
    //      document.getElementById("Hide_IssuedIframe").style.display = 'none'
    document.getElementById("Issued_Button_Confim").style.display = ''
    document.getElementById("Issued_Button_Cancel").style.display = ''
    document.getElementById("Issued_Success_Button_Confim").style.display = 'none'
    //动态图隐藏
    document.getElementById("Loading").style.display = "none";
}

function UpConfigCon() {
    times = 0;
    document.getElementById("IssuedLayer").style.display = 'none';
    window.parent.document.getElementById("IssuedLayer").style.display = '';
    document.getElementById("ConUp1").style.display = 'none';
    //      document.getElementById("Hide_IssuedIframe").style.display = "none"
    $("#Issued_Button_Confim").attr("disabled", "disabled");
    $("#Issued_Button_Cancel").attr("disabled", "disabled");
    $.ajax({
        type: "post",
        url: "cgi-bin/agent/GiveToAgent.py",
        data: "up=1",
        async: false,
        success: function (data) {
            $("#up_success").html(data);
            document.getElementById("popWindow").style.backgroundColor = "#ddd";
            window.parent.document.getElementById("popWindow").style.display = "";
            window.parent.document.getElementById("IssuedLayer").style.display = '';
            getagent = setInterval("getAgentStatue()", 5000);
        }
    });
}
//全局一个发送次数
var times = 0
var getagent = "";

function getAgentStatue() {
    //获取测试字符串
    var value = getFirstID();
    $("#Test_Value_YuToXHZhang").val(value);
    var params = $("#Test_DataItemForm_YuToXHZhang").serialize();
    times++;
    //45秒超时
    if (times < 18) {
        $.ajax({
            type: "post",
            url: "cgi-bin/RealTimeData/GetAgentStatue.py",
            data: params,
            async: true,
            success: function (data) {
                //如果测试返回结果正确，即返回为1，则可以关闭下发窗口
                if (data == 1) {
                    $("#up_success").show();
                    $("#Loading").hide();
                    $("#Issued_Button_Confim").attr("disabled", "");
                    $("#Issued_Button_Cancel").attr("disabled", "");
                    $("#Issued_Button_Confim").hide();
                    $("#Issued_Button_Cancel").hide();
                    $("#Issued_Success_Button_Confim").show();
                    $("#ConUp1").hide();
                    window.parent.document.getElementById("popWindow").style.display = "none";
                    document.getElementById("popWindow").style.backgroundColor = "#9D9D9D";
                    window.parent.document.getElementById("IssuedLayer").style.display = 'none';
                    document.getElementById("IssuedLayer").style.display = '';
                    clearInterval(getagent);
                } else {

                }
            },
        });
    } else {
        $("#Issued_Button_Confim").attr("disabled", "");
        $("#Issued_Button_Cancel").attr("disabled", "");
        document.getElementById("IssuedLayer").style.display = '';
        window.parent.document.getElementById("popWindow").style.display = "none";
        document.getElementById("popWindow").style.backgroundColor = "#9D9D9D";
        window.parent.document.getElementById("IssuedLayer").style.display = 'none';
        if (coo == "English") {
            document.getElementById("up_success").innerHTML = "Agent startup timeout, please try again later";
        } else {
            document.getElementById("up_success").innerHTML = "agent启动超时，请稍后再试";
        }
        document.getElementById("up_success").style.display = "";
        document.getElementById("ConUp1").style.display = "none";
        document.getElementById("Issued_Button_Confim").style.display = 'none';
        document.getElementById("Issued_Success_Button_Confim").style.display = '';
        clearInterval(getagent);
    }
}

function getFirstID() {
    var id = "";
    $.ajax({
        type: "get",
        url: "../conf/config.xml",
        async: false,
        success: function (data) {
            $(data).find("model[id='" + ChannelID + "']").each(function () {
                var $model = $(this);
                $model.find("device[id='" + DeviceID + "']").each(function () {
                    var $device = $(this);
                    $device.find("driver").each(function () {
                        var $driver = $(this);
                        DriverID = $driver.attr('id');
                        $driver.find("commDataItems").each(function () {
                            var $commDataItems = $(this);
                            $commDataItems.find("dataItem:first-child").each(function () {
                                var $dataItem = $(this);
                                var dataItemID = $dataItem.attr('id');
                                id = dataItemID;
                            });
                        });
                    })
                });
            });
        }
    });
    //拼出测试字符串

    var value = "";
    var ChannelDriverArr = new Array();
    ChannelDriverArr = ChannelDriver.split(":");
    var ChannelDriverShort = ChannelDriverArr[1];
    if (id == "") {
        //没有数据时候
        value = '{"id":' + DeviceID + ',"dn":"","vid":' + DriverID + ',"vn":"' + ChannelDriverShort + '", "cmds":{"read":1}}'
    } else {
        value = '{"id":' + DeviceID + ',"dn":"","vid":' + DriverID + ',"vn":"' + ChannelDriverShort + '", "cmds":{"read":0,"ids":[' + id + ']}}'
    }
    return value;
}
//读数据项ID最大值并赋值
function getID() {
    $.get('../conf/IDinfo.xml', function (d1) {
        $(d1).find("IDALL").each(function () {
            var $IDALL = $(this);
            var DataitemID = $IDALL.find('ItemID').text();
            document.getElementById("Add_DataItemID_YuToXHZhang").value = DataitemID;
            document.getElementById("Add_DataItemID").value = DataitemID;
        });
    });
}

function Import_DataItem() {
    if (document.getElementById("FileName").value == "") {
        if (coo == "English") {
            alert("Please select the files to upload!")
        } else {
            alert("请选择需要上传的文件！")
        }
    } else {
        document.getElementById('Import_Button_Confirm').disabled = true;
        document.getElementById('Import_Button_Cancel').disabled = true;
        if (ChannelDeviceType == "AB-Ethernet/IP" || ChannelDeviceType == "AB-MicroLogix") {
            document.getElementById("ImportForm_YuToXHZhang").action = '../cgi-bin/import/ImportABEthernetIPDataitem.py?deviceID=' + DeviceID;
        } else {
            document.getElementById("ImportForm_YuToXHZhang").action = '../cgi-bin/import/ImportSiemensEthernet.py?deviceID=' + DeviceID;
        }
        document.getElementById("ImportForm_YuToXHZhang").submit();
        var iframe01 = document.getElementById("Hide_ImportIframe");
        if (iframe01.attachEvent) {
            iframe01.attachEvent("onload", function () {
                document.getElementById("UpWord").style.display = 'none';
                document.getElementById("Import_Two_Button").style.display = 'none';
                document.getElementById("Success_Import").style.display = '';
                document.getElementById("Import_Success_Button").style.display = '';
                document.getElementById('Import_Button_Confirm').disabled = false;
                document.getElementById('Import_Button_Cancel').disabled = false;
            });
        } else {
            iframe01.onload = function () {
                document.getElementById("UpWord").style.display = 'none';
                document.getElementById("Import_Two_Button").style.display = 'none';
                document.getElementById("Success_Import").style.display = '';
                document.getElementById("Import_Success_Button").style.display = '';
                document.getElementById('Import_Button_Confirm').disabled = false;
                document.getElementById('Import_Button_Cancel').disabled = false;
            };
        }
    }
}


function Close_ExportLayer() {
    document.getElementById("popWindow").style.display = 'none'
    document.getElementById("ExprotLayer").style.display = 'none'
    document.getElementById('Exportout').disabled = false;
    document.getElementById('ExSucc').disabled = false;
}

function ExportInfo() {
    if (ChannelDeviceType == "AB-Ethernet/IP" || ChannelDeviceType == "AB-MicroLogix") {
        document.getElementById("ExportForm_YuToXHZhang").action = '../cgi-bin/export/ExportAB_EthernetIPDataitem.py?deviceID=' + DeviceID;
    } else {
        document.getElementById("ExportForm_YuToXHZhang").action = '../cgi-bin/export/ExportSiemensEthernet.py?deviceID=' + DeviceID;
    }
    document.getElementById("ExportForm_YuToXHZhang").submit();
    document.getElementById("ExportForm_YuToXHZhang").target = 'Hide_ExportIframe';
    document.getElementById('Exportout').disabled = true;
    document.getElementById('ExSucc').disabled = true;
    window.setTimeout(Close_ExportLayer, 3000);
}
//切换到测试

function Open_TestLayer() {
    //alert(ChannelDriver)
    var value = "";
    var idArr = "";
    var ChannelDriverArr = new Array();
    ChannelDriverArr = ChannelDriver.split(":");
    var ChannelDriverShort = ChannelDriverArr[1];
    CheckedLength();
    if (document.getElementById("AllDataitemID").value == "") {
        value = '{"id":' + DeviceID + ',"dn":"", "vn":"' + ChannelDriverShort + '", "cmds":{"read":1}}'
    } else {
        var str = document.getElementById("AllDataitemID").value;
        var strArr = new Array();
        strArr = str.split(";");
        var maxlength = strArr.length;
        for (var j = 0; j < maxlength - 2; j++) {
            idArr += strArr[j] + ",";
        }
        idArr += strArr[maxlength - 2];
        value = '{"id":' + DeviceID + ',"dn":"", "vn":"' + ChannelDriverShort + '", "cmds":{"read":0,"ids":[' + idArr + ']}}'
    }
    TestDateItem(value);

    if (window.testTimer) {
        clearInterval(window.testTimer);
        window.testTimer = null;
    }

    window.testTimer = setInterval(function () {
        var testWindowVisable = $('#TestLayer').is(":hidden");
        var popWindowVisable = $('#popWindow').is(":hidden");
        var autoTest = ($("#onoffswitch").is(':checked'));
        if (testWindowVisable || popWindowVisable) {
            clearInterval(window.testTimer);
            window.testTimer = null;
        } else if (autoTest) {
            console.log('刷新！');
            TestDateItem(value);
        }
    }, 10000);

}

function TestDateItem(txt) {
    $("#testInfomation").empty();
    document.getElementById("Test_Value_YuToXHZhang").value = txt;
    document.getElementById("popWindow").style.display = "";
    var params = $("#Test_DataItemForm_YuToXHZhang").serialize();
    $.ajax({
        type: "post",
        url: "cgi-bin/RealTimeData/GetRealTimeData.py",
        data: params,
        async: true,
        datatype: "xml",
        beforeSend: function () {
            $("#wait").show();
        },
        complete: function () {
            $("#wait").hide();
            //方法执行完毕，效果自己可以关闭，或者隐藏效果
        },
        success: function (data) {
            if (data.substr(1, 3) != "All") {
                $("#wait").hide();
                $("#popWindow").hide();
                alert(data);
            } else {
                $("#TestLayer").show();
                $(data).find("dataItem").each(function () {
                    var $dataitem = $(this);
                    var name = $dataitem.attr("n");
                    var config = $dataitem.attr("config");
                    var id = $dataitem.attr("id");
                    var typeshort = $dataitem.attr("type");
                    var freq = $dataitem.attr("freq");
                    var report = $dataitem.attr("report");
                    var value = $dataitem.attr("value");
                    var alias = $dataitem.attr("alias");
                    var quality1 = $dataitem.attr("quality");
                    var configArr = new Array();
                    configArr = config.split(";");
                    var add = configArr[0];
                    var type1 = configArr[1];
                    var type = "";
                    var quality = "";
                    if (quality1 == 1) {
                        quality = "good";
                    }
                    if (quality1 != 1) {
                        quality = "bad";
                    }
                    if (type1 == "BIT")
                        type = "Boolean";
                    if (type1 == "BYTE")
                        type = "Byte";
                    if (type1 == "WORD")
                        type = "Word";
                    if (type1 == "SHORT")
                        type = "Short";
                    if (type1 == "DWORD")
                        type = "DWord";
                    if (type1 == "LONG")
                        type = "Long";
                    if (type1 == "FLOAT")
                        type = "Float";
                    if (type1 == "STRING")
                        type = "String";
                    var list = "<div style='width:678px;height:25px;border: 1px solid #D7D7D7;border-top:none'>" +
                        "<div align='center' style='width:165px;float:left;height:25px;line-height:25px;overflow:hidden' title='" + alias + "'>" + name + "</div>" +
                        "<div align='center' style='width:170px;float:left;height:25px;line-height:25px;overflow:hidden' title='" + alias + "'>" + alias + "</div>" +
                        "<div align='center' style='width:90px;float:left;height:25px;line-height:25px'>" + add + "</div>" +
                        "<div align='center' style='width:159px;float:left;height:25px;line-height:25px'>" + value + "</div>" +
                        "<div align='center' style='width:85px;float:left;height:25px;line-height:25px'>" + quality + "</div>" +
                        "</div>"
                    $("#testInfomation").append(list);
                });
            }
        },
        error: function () {
            $("#popWindow").hide();
            if (coo == "English") {
                alert("Test fails, please contact your administrator");
            } else {
                alert("测试失败，请联系管理员");
            }
        }
    });
}
//切换到导入
function Open_ImportLayer() {
    $("#popWindow").show();
    $("#ImportLayer").show();
    $("#FileName").val("");
    $("#UpWord").show();
    $("#Import_Two_Button").show();
    $("#Success_Import").hide();
    $("#Import_Success_Button").hide();
    $("#Import_Button_Confirm").show();
    $("#Import_Button_Cancel").show();
}
//切换到导出
function Open_ExportLayer() {
    document.getElementById("popWindow").style.display = '';
    document.getElementById("ExprotLayer").style.display = '';
}

function Import_Success_ReloadNewPage() {
    getData();
    $("#popWindow").hide();
    $("#ImportLayer").hide();
}

$("#Add_DataItemType").change(function () {
    if (ChannelDeviceType != "AB-Ethernet/IP" && ChannelDeviceType != "AB-MicroLogix" && $(this).val() == "STRING") {
        $("#tr_string").show();
        $("#tr_string_msg").show();
    } else {
        $("#tr_string").hide();
        $("#tr_string_msg").hide();
    }
});

$("#Alter_DataItemType").change(function () {
    if (ChannelDeviceType != "AB-Ethernet/IP" && ChannelDeviceType != "AB-MicroLogix" && $(this).val() == "STRING") {
        $("#Alter_tr_string").show();
        $("#Alter_tr_string_msg").show();
    } else {
        $("#Alter_tr_string").hide();
        $("#Alter_tr_string_msg").hide();
    }
});

function open_write_layer(data) {
    $('#write_layer').css('display', '');
    $("#popWindow").css('display', '');
    //
    $("#Write_Button_Confirm").unbind("click").click(function () {
        //构造参数
        data.cmds[0]["userid"] = "1493282026529"; //userid 可以随便填写
        data.cmds[0]["cmd"] = $("#write_input").val();
        //验证非空
        if (data.cmds[0]["cmd"] == "" || data.cmds[0]["cmd"] == null) {
            if (coo == "English") {
                alert("Write value cannot be empty");
            } else {
                alert("写入值不能为空");
            }
            return;
        }
        if (data.cmds[0]["rw"] == "0") {
            if (coo == "English") {
                alert("Please set the R/W type to be Read&Write first.");
            } else {
                alert("请先设置读写类型为可写");
            }
            return;
        }
        //验证bool 类型(dt == b)只能为0或1
        if (data.cmds[0]['dt'] == 'b' && ['0', '1'].indexOf(data.cmds[0]["cmd"]) == -1) {
            if (coo == "English") {
                alert("Boolean type can only fill 0 or 1");
            } else {
                alert("Boolean类型只能填写0或者1");
            }
            return;
        }
        //直接提交json cgi无法收到，这里把json字符串放到一个伪造的表单里,key是'Write_Value_command'
        var $form = $("<form></form>");
        var $input = $("<input tyle='text' name='Write_Value_command'>");
        $input.val(JSON.stringify(data))
        $form.append($input);
        var param = $form.serialize();
        $.ajax({
            type: 'post',
            url: 'cgi-bin/RealTimeData/WriteItemValue.py',
            data: param,
            // dataType: 'xml',
            beforeSend: function (request) {
                $("#Write_Button_Confirm").attr("disabled", "disabled");
                $("#write_Button_Cancel").attr("disabled", "disabled");
            },
            complete: function () {
                $("#Write_Button_Confirm").removeAttr("disabled");
                $("#write_Button_Cancel").removeAttr("disabled");
                $('#write_layer').css('display', 'none');
                $("#popWindow").css('display', 'none');
                $('#write_input').val("");
            },
            success: function (data) {
                alert(data);
            },
            error: function () {
                alert('error');
            }
        })
    })
};

function clocs_write_layer() {
    $('#write_layer').css('display', 'none');
    $("#popWindow").css('display', 'none');
    $('#write_input').val("");
};