//数据项页面的通用js，用于效果的变化，例如鼠标移动效果等
//三个小图标的效果
function hoverEdit(txt) {
    document.getElementById(txt).src = 'assets/img/bianji_hover_ico.png'
}

function Edit(txt) {
    document.getElementById(txt).src = 'assets/img/bianji_ico.png'
}

function addPLChover() {
    document.getElementById("PLCaddPIC").src = "assets/img/add_hover_ico.png"
}

function addPLCout() {
    document.getElementById("PLCaddPIC").src = "assets/img/add_ico.png"
}

function addSNMPhover() {
    document.getElementById("SNMPaddPIC").src = "assets/img/add_hover_ico.png"
}

function addSNMPout() {
    document.getElementById("SNMPaddPIC").src = "assets/img/add_ico.png"
}

function Deletehover() {
    document.getElementById("DeletePIC").src = "assets/img/delet_hover_ico.png"
}

function Deleteout() {
    document.getElementById("DeletePIC").src = "assets/img/delet_ico.png"
}

function Downhover() {
    document.getElementById("DownPIC").style.backgroundImage = "url(assets/img/menun_hover_bg.png)"
}

function Downout() {
    document.getElementById("DownPIC").style.backgroundImage = ""
}

function ImportPIChover() {
    document.getElementById("ImportPIC").style.backgroundImage = "url(assets/img/menun_hover_bg.png)"
}

function ImportPICout() {
    document.getElementById("ImportPIC").style.backgroundImage = ""
}

function ExportPIChover() {
    document.getElementById("ExportPIC").style.backgroundImage = "url(assets/img/menun_hover_bg.png)"
}

function ExportPICout() {
    document.getElementById("ExportPIC").style.backgroundImage = ""
}

function TestPIChover() {
    document.getElementById("TestPIC").style.backgroundImage = "url(assets/img/menun_hover_bg.png)"
}

function TestPICout() {
    document.getElementById("TestPIC").style.backgroundImage = ""
}
//测试导入导出

function Close_TestLayer_PIC_Over() {
    document.getElementById("Close_TestLayer_PIC").src = "assets/img/closed_ico_hover.png"
}

function Close_TestLayer_PIC_Out() {
    document.getElementById("Close_TestLayer_PIC").src = "assets/img/closed.png"
}

function Close_TestLayer() {
    document.getElementById("popWindow").style.display = 'none'
    document.getElementById("TestLayer").style.display = 'none'
}

function Close_ImportLayer() {
    document.getElementById("popWindow").style.display = 'none'
    document.getElementById("ImportLayer").style.display = 'none'
}

function Close_ImportLayer_PIC_Over() {
    document.getElementById("Close_ImportLayer_PIC").src = "assets/img/closed_ico_hover.png"
}

function Close_ImportLayer_PIC_Out() {
    document.getElementById("Close_ImportLayer_PIC").src = "assets/img/closed.png"
}

function Close_ExportLayer_PIC_Over() {
    document.getElementById("Close_ExportLayer_PIC").src = "assets/img/closed_ico_hover.png"
}

function Close_ExportLayer_PIC_Out() {
    document.getElementById("Close_ExportLayer_PIC").src = "assets/img/closed.png"
}
//小图标移动效果

function Open_DataItemHelpLayer_PIC_Over() {
    document.getElementById("Open_DataItemHelpLayer_PIC").src = "assets/img/help_hover_ico.png"
}

function Open_DataItemHelpLayer_PIC_Out() {
    document.getElementById("Open_DataItemHelpLayer_PIC").src = "assets/img/help_ico.png"
}

//显示帮助信息

function ItemConfigHelp(txt) {}
//帮助信息效果

function ChangeBgColor(txt) {
    document.getElementById(txt).className = "helpTableMain3";
}

function BackBgColor(txt) {
    if (txt.substr(4) % 2 == 0)
        document.getElementById(txt).className = "helpTableMain2";
    else
        document.getElementById(txt).className = "helpTableMain1";
}