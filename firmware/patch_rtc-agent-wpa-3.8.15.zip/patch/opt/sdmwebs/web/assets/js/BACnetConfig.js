﻿document.writeln("<" + "script language='javascript' src='assets/js/language.js?t="+(new Date()).getTime()+"'></" + "script>");

CheckLogin();
$(function () {
    $("#IP").hide();
    $("#MSTP").hide();
    init();
    coo = getCookie("AnyLinkLan");
});
var coo = '';
var DRIVER_ID = "";
var DRIVER_NAME = "";
var DEVICE_ID = "";

//初始化
function init() {

    DRIVER_ID = "";
    DRIVER_NAME = "";
    DEVICE_ID = "";


    $.get('conf/config.xml', function (d1) {
        $(d1).find('device').each(function () {
            if ($(this).attr('id') == '1023' || $(this).attr('id') == 1023) {
                return true;
            }
            DEVICE_ID = $(this).attr('id');
        });
        if (DEVICE_ID == "" || DEVICE_ID == null) {
            if (coo == "English") {
                $("#info").html("Before configuring the BACnet driver, please add the device");
            }
            else {
                $("#info").html("配置BACnet驱动前请先添加设备");
            }
            $("#maskLayer").show();
            $("#popWindow").show();
        }
    });

    $.get('conf/config.xml', function (d1) {

        var flag = false; //是否是修改

        $(d1).find('task').find('driver').each(function () {

            if ($(this).attr('n') == 'T.IDrv.Task:libkbacnet') {
                flag = true;
                //TP  
                var config = $(this).attr('config');
                var paramArr = config.split(';');
                if (paramArr.length == 4 || paramArr.length == 5) {
                    $("#TP_deviceId").val(paramArr[0]);
                    $("#TP_timeout").val(paramArr[1]);
                    $("#port").val(paramArr[2]);
                    if (paramArr.length == 5) {
                        $("#networkCard").val(paramArr[3]);
                    }
                    //常量设置
                    DRIVER_NAME = "T.IDrv.Task:libkbacnet";
                    DRIVER_ID = $(this).attr("id");
                    setCurrentDriver(DRIVER_NAME);
                } else {
                    setDefault(); //异常数据处理 
                }
                $(".classify").find("[name='mode']").eq(0).show();
                $(".classify").find("[name='mode']").eq(1).hide();
                $(".classify").find("[name='mode']").eq(0).click();
            } else if ($(this).attr('n') == 'T.IDrv.Task:libkbacnetmstp') {
                flag = true;
                //MSTP
                var config = $(this).attr('config');
                var paramArr = config.split(';');
                if (paramArr.length == 8) {
                    $("#MSTP_deviceId").val(paramArr[0]);
                    $("#MSTP_timeout").val(paramArr[1]);
                    $("#serialNum option").each(function () {
                        if ($(this).attr("value") == paramArr[2]) {
                            $(this).attr("selected", "selected");
                        }
                    });
                    $("#baudrate").val(paramArr[3]);
                    $("#mac").val(paramArr[4]);
                    $("#master").val(paramArr[5]);
                    $("#frame").val(paramArr[6]);
                    //常量设置
                    DRIVER_NAME = "T.IDrv.Task:libkbacnetmstp";
                    DRIVER_ID = $(this).attr("id");
                    setCurrentDriver(DRIVER_NAME);
                } else {
                    setDefault(); //异常数据处理 
                }
                $(".classify").find("[name='mode']").eq(0).hide();
                $(".classify").find("[name='mode']").eq(1).show();
                $(".classify").find("[name='mode']").eq(1).click();
            }
        });

        if (flag == false) {
            setDefault();
        }
    });
}

//设置缺省值 
function setDefault() {

    $(".classify").find("[name='mode']").eq(0).show();
    $(".classify").find("[name='mode']").eq(1).show();
    //TP
    $("#TP_deviceId").val("260001");
    $("#TP_timeout").val("3000");
    $("#port").val("47808");
    $("#networkCard").val("");
    //MSTP
    $("#MSTP_deviceId").val("260001");
    $("#MSTP_timeout").val("60000");
    // $("#serialNum").val("");
    $("#baudrate").val("38400");
    $("#mac").val("");
    $("#master").val("127");
    $("#frame").val("1");
    setCurrentDriver("");

    $.get('conf/IDinfo.xml', function (d1) {
        DRIVER_ID = $(d1).find('DriverID').text();
    });
}

//选择IP还是MS/TP
$(".classify").find("[name='mode']").click(function () {
    if ($(this).val() == 'IP') {
        $("#MSTP").hide();
        $("#IP").show();
        $("#IP").find("[name='mode']").val('IP');
    }
    if ($(this).val() == 'MSTP') {
        $("#IP").hide();
        $("#MSTP").show();
        $("#MSTP").find("[name='mode']").val('MSTP');
    }
});

/*正则验证方法集合*/
//验证设备ID
function verify_deviceId(str) {
    if (coo == "English") {
        var regex = /^[0-9]+$/;
        if (!regex.test(str)) {
            setMessage("The device ID must be a number");
            return false;
        }
        var num = parseInt(str);
        if (num < 0 || num > 4194303) {
            setMessage("The device ID must be within the interval [0,4194303]");
            return false;
        }
        return true;
    }
    else {
        var regex = /^[0-9]+$/;
        if (!regex.test(str)) {
            setMessage("设备ID必须是数字");
            return false;
        }
        var num = parseInt(str);
        if (num < 0 || num > 4194303) {
            setMessage("设备ID必须在区间[0,4194303]内");
            return false;
        }
        return true;
    }
}

//验证超时
function verify_timeout(str) {
    var regex = /^[0-9]+$/;
    if (!regex.test(str)) {
        if (coo == "English") {
            setMessage("The timeout must be a number");
        }
        else {
            setMessage("超时时间必须是数字");
        }
        return false;
    }
    return true;
}

//验证端口
function verify_port(str) {
    if (coo == "English") {
        var regex = /^[0-9]+$/;
        if (!regex.test(str)) {
            setMessage("The port must be a number");
            return false;
        }
        var num = parseInt(str);
        if (num <= 1024 || num > 65534) {
            setMessage("The port must be in the interval (1024,65534)");
            return false;
        }
        return true;
    }
    else {
        var regex = /^[0-9]+$/;
        if (!regex.test(str)) {
            setMessage("端口必须是数字");
            return false;
        }
        var num = parseInt(str);
        if (num <= 1024 || num > 65534) {
            setMessage("端口必须在区间(1024,65534]内");
            return false;
        }
        return true;
    }
}

//验证串口号
function verify_serialNum(str) {
    var regex = /^\/dev\/{1,}/;
    if (!regex.test(str)) {
        if (coo == "English") {
            setMessage("The serial number must be in the form of /dev/* (note: * represents multiple arbitrary characters)");
        }
        else {
            setMessage("串口号必须是 /dev/* 的形式(注: * 代表多个任意字符)");
        }
        return false;
    }
    return true;
}

//验证波特率
function verify_baudrate(str) {
    var regex = /^[0-9]+$/;
    if (!regex.test(str)) {
        if (coo == "English") {
            setMessage("The baud rate must be a number");
        }
        else {
            setMessage("波特率必须是数字");
        }
        return false;
    }
    var sample = [200, 300, 600, 1200, 1800, 2400, 4800, 9600, 19200, 38400, 57600, 76800, 115200];
    var num = parseInt(str);
    for (var i in sample) {
        if (sample[i] == num) {
            return true;
        }
    }
    if (coo == "English"){
        setMessage("Baud rate must be {200300600120 0180 0240 0480 0960 0192 00384 00576 00768 00115 200} in the collection");
    }
    else {
        setMessage("波特率必须在{200,300,600,1200,1800,2400,4800,9600,19200,38400,57600,76800,115200}集合内");
    }
    return false;
}

//验证mac地址
function verify_mac(str) {
    if (coo == "English") {
        var regex = /^[0-9]+$/;
        if (!regex.test(str)) {
            setMessage("MAC addresses must be Numbers");
            return false;
        }
        var num = parseInt(str);
        if (num < 0 || num > 127) {
            setMessage("The MAC address must be within the interval [0,127]");
            return false;
        }
        return true;
    }
    else {
        var regex = /^[0-9]+$/;
        if (!regex.test(str)) {
            setMessage("mac地址必须是数字");
            return false;
        }
        var num = parseInt(str);
        if (num < 0 || num > 127) {
            setMessage("mac地址必须在区间[0,127]内");
            return false;
        }
        return true;
    }
}

//验证最大主站地址
function verify_master(str) {
    if (coo == "English") {
        var regex = /^[0-9]+$/;
        if (!regex.test(str)) {
            setMessage("The maximum address must be the number");
            return false;
        }
        var num = parseInt(str);
        if (num < 0 || num > 127) {
            setMessage("The maximum main station address is within the interval [0,127]");
            return false;
        }
        return true;
    }
    else {
        var regex = /^[0-9]+$/;
        if (!regex.test(str)) {
            setMessage("最大主站地址必须是数字");
            return false;
        }
        var num = parseInt(str);
        if (num < 0 || num > 127) {
            setMessage("最大主站地址在区间[0,127]内");
            return false;
        }
        return true;
    }
}

//mac地址与主站地址，联合验证
//str1:mac
//str2:master
function verify_mac_master(str1, str2) {
    var num1 = parseInt(str1);
    var num2 = parseInt(str2);
    if (num1 >= num2) {
        if (coo == "English") {
            setMessage("The MAC address must be less than the maximum address");
        }
        else {
            setMessage("mac地址必须小于最大主站地址");
        }
        return false;
    }
    return true;
}

//验证最大帧个数
function verify_frame(str) {
    if (coo == "English") {
        var regex = /^[0-9]+$/;
        if (!regex.test(str)) {
            setMessage("The maximum frame must be a number");
            return false;
        }
        var num = parseInt(str);
        if (num < 1 || num > 256) {
            setMessage("The maximum frame must be within the interval [1,256]");
            return false;
        }
        return true;
    }
    else {
        var regex = /^[0-9]+$/;
        if (!regex.test(str)) {
            setMessage("最大帧必须是数字");
            return false;
        }
        var num = parseInt(str);
        if (num < 1 || num > 256) {
            setMessage("最大帧必须在区间[1,256]内");
            return false;
        }
        return true;
    }
}

//表单验证message提示
function setMessage(str) {
    $("#message").html(str);
}

//message clear
function clearMessage() {
    $("#message").html("");
}

//TP保存
$("#TP_save").click(function () {
    clearMessage();
    var mode = $("#TP_mode").val();
    var deviceId = $("#TP_deviceId").val();
    var timeout = $("#TP_timeout").val();
    var port = $("#port").val();
    var networkCard = $("#networkCard").val();
    //验证
    if (verify_deviceId(deviceId) && verify_timeout(timeout) && verify_port(port)) {
        //ok提交
        var params = deviceId + ';' + timeout + ';' + port + ';' + networkCard + ";10001";
        //      if (networkCard != "") {
        //          params = deviceId + ';' + timeout + ';' + port + ';' + networkCard + ";10001";
        //      }
        if(DEVICE_ID == "" || DEVICE_ID == null){
            if (coo == "English") {
                $("#info").html("Before configuring the BACnet driver, please add the device");
            }else{
                $("#info").html("配置BACnet驱动前请先添加设备");
            }
            $("#maskLayer").show();
            $("#popWindow").show();
        }else {
            $.ajax({
            type: "post",
            url: "cgi-bin/senconf/BacnetConfig.py",
            data: {
                driver: 'T.IDrv.Task:libkbacnet',
                deviceId: DEVICE_ID,
                params: params,
                driverId: DRIVER_ID,
                cmd: "add"
            },
            success: function (result) {
                $("#info").html(result);
                $("#maskLayer").show();
                $("#popWindow").show();
                init();
            },
            error: function () {
                if (coo == "English") {
                    setMessage("Save failed, please try again");
                }
                else {
                    setMessage("保存失败,请重试");
                }
                init();
            }
        });
        } 
    }
});

//MSTP保存
$("#MSTP_save").click(function () {
    clearMessage();
    var mode = $("#MSTP_deviceId").val();
    var deviceId = $("#MSTP_deviceId").val();
    var timeout = $("#MSTP_timeout").val();
    var serialNum = $("#serialNum").val();
    var baudrate = $("#baudrate").val();
    var mac = $("#mac").val();
    var master = $("#master").val();
    var frame = $("#frame").val();
    //验证
    if (verify_deviceId(deviceId) && verify_timeout(timeout) && verify_serialNum(serialNum) && verify_baudrate(baudrate) && verify_mac(mac) && verify_master(master) && verify_mac_master(mac, master) && verify_frame(frame)) {
        //ok提交
        var params = deviceId + ';' + timeout + ';' + serialNum + ';' + baudrate + ';' + mac + ';' + master + ';' + frame + ";10001";
        if(DEVICE_ID == "" || DEVICE_ID == null){
            if (coo == "English") {
                $("#info").html("Before configuring the BACnet driver, please add the device");
            }else{
                $("#info").html("配置BACnet驱动前请先添加设备");
            }
            $("#maskLayer").show();
            $("#popWindow").show();
        }else {
            $.ajax({
                type: "post",
                url: "cgi-bin/senconf/BacnetConfig.py",
                data: {
                    driver: 'T.IDrv.Task:libkbacnetmstp',
                    deviceId: DEVICE_ID,
                    params: params,
                    driverId: DRIVER_ID,
                    cmd: "add"
                },
                success: function (result) {
                    $("#info").html(result);
                    $("#maskLayer").show();
                    $("#popWindow").show();
                    init();
                },
                error: function () {
                if (coo == "English") {
                    setMessage("Save failed, please try again");
                }
                else {
                    setMessage("保存失败,请重试");
                }
                    init();
                }
            });
        }
    }
});

//驱动删除
$("#delete").click(function () {
    if (DRIVER_ID != "" && DRIVER_NAME != "" && DEVICE_ID != "") {
        $.ajax({
            type: "post",
            url: "cgi-bin/senconf/BacnetConfig.py",
            data: {
                deviceId: DEVICE_ID,
                driver: DRIVER_NAME,
                driverId: DRIVER_ID,
                cmd: "delete"
            },
            success: function () {
                if (coo == "English") {
                    $("#info").html("Delete succeeded");
                }
                else {
                    $("#info").html("删除成功");
                }
                $("#maskLayer").show();
                $("#popWindow").show();
                $("#IP").hide();
                $("#MSTP").hide();
                init();
                radioConfig();
            },
            error: function () {
                if (coo == "English") {
                    $("#info").html("Delete failed, please try again");
                }
                else {
                    $("#info").html("删除失败，请重试");
                }
                $("#maskLayer").show();
                $("#popWindow").show();
                init();
            }
        });
    }
});

//显示当前激活的驱动
function setCurrentDriver(n) {
    if (coo == "English") {
        var content = "Currently no active BACnet driver";
        if (n == 'T.IDrv.Task:libkbacnet') {
            content = 'The current activation is:IP';
        } else if (n == 'T.IDrv.Task:libkbacnetmstp') {
            content = 'The current activation is:MS/TP';
        }
        $("#current_driver").html(content);
    }
    else {
        var content = "当前无激活的BACnet驱动";
        if (n == 'T.IDrv.Task:libkbacnet') {
            content = '当前激活的是:IP';
        } else if (n == 'T.IDrv.Task:libkbacnetmstp') {
            content = '当前激活的是:MS/TP';
        }
        $("#current_driver").html(content);
    }
}

//重新载入
function reload() {
    location.reload();
}


function radioConfig() {
    $(".classify").find("[name='mode']").eq(0).show();
    $(".classify").find("[name='mode']").eq(1).show();
    $(".classify").find("[name='mode']").each(function () {
        $(this).attr("checked", false);
    });
}

//下发数据项
function Open_IssuedLayer() {
    document.getElementById("popWindow").style.display = ''
    document.getElementById("IssuedLayer").style.display = ''
    document.getElementById("ConUp1").style.display = ''
    document.getElementById("Hide_IssuedIframe").style.display = 'none'
    document.getElementById("Issued_Button_Confim").style.display = ''
    document.getElementById("Issued_Button_Cancel").style.display = ''
    document.getElementById("Issued_Success_Button_Confim").style.display = 'none'
    //动态图隐藏
    document.getElementById("Loading").style.display = "none";
}

function UpConfigCon() {
    document.getElementById("Loading").style.display = "";
    document.getElementById("ConUp1").style.display = 'none'
    document.getElementById("Hide_IssuedIframe").style.display = "none"
    document.getElementById("Issued_Button_Confim").disabled = true;
    document.getElementById("Issued_Button_Cancel").disabled = true;
    document.getElementById("IssuedForm_YuToXHZhang").action = '../cgi-bin/agent/GiveToAgent.py';
    document.getElementById("IssuedForm_YuToXHZhang").submit();
    var iframe01 = document.getElementById("Hide_IssuedIframe");
    if (iframe01.attachEvent) {
        iframe01.attachEvent("onload", function () {
            setTimeout(function () {
                document.getElementById("Loading").style.display = "none";
                document.getElementById("Issued_Button_Confim").disabled = false;
                document.getElementById("Issued_Button_Cancel").disabled = false;
                document.getElementById("Issued_Button_Confim").style.display = 'none'
                document.getElementById("Issued_Button_Cancel").style.display = 'none'
                document.getElementById("Issued_Success_Button_Confim").style.display = ''
                document.getElementById("Hide_IssuedIframe").style.display = ''
                document.getElementById("ConUp1").style.display = 'none'
            }, 10000)
        });
    } else {
        iframe01.onload = function () {
            setTimeout(function () {
                document.getElementById("Loading").style.display = "none";
                document.getElementById("Issued_Button_Confim").disabled = false;
                document.getElementById("Issued_Button_Cancel").disabled = false;
                document.getElementById("Issued_Button_Confim").style.display = 'none'
                document.getElementById("Issued_Button_Cancel").style.display = 'none'
                document.getElementById("Issued_Success_Button_Confim").style.display = ''
                document.getElementById("Hide_IssuedIframe").style.display = ''
                document.getElementById("ConUp1").style.display = 'none'
            }, 10000)
        };
    }
}