document.getElementById("txtinput").focus();

//check_login
function check() {
    var name = document.getElementById("txtinput").value;
    var pass = document.getElementById("password").value;
    var isLoginSuccess = false;
    var coo = getCookie("AnyLinkLan");

    $.ajax({
        url: "cgi-bin/senconf/userlogin.py",
        type: "post",
        dataType: "json",
        contentType: "application/json",
        data: JSON.stringify({username:name,password:hex_md5(pass)}),
        async: true,
        timeout: 8000,
        success: function (data) {
            if(data.errcode){
                alert("error:"+(data.msg||"unkonw errors 001!"));
                return;
            }
            if( data.code == 200){
                var token = data.data.token
                sessionStorage.AnylinkName = name;
                sessionStorage.AnylinkPass = pass;//hex_md5(pass);
                            //取用户名
                var usr = name;
                
                cookie('token', token, 14)
                //将最后一个用户信息写入到Cookie
                SetLastUser(usr);
                //如果记住密码选项被选中
                if (document.getElementById('savepwd').checked == true) {
                    //取密码值
                    var pwd = pass;
                    var expdate = new Date();
                    expdate.setTime(expdate.getTime() + 14 * (24 * 60 * 60 * 1000));
                    //将用户名和密码写入到Cookie
                    SetCookie(usr, pwd, expdate);
                    // 将是否记住密码的状态记录下来
                    localStorage.setItem('savepwd','1');
                } else {
                    //如果没有选中记住密码,则立即过期
                    ResetCookie();
                    // 将是否记住密码的状态记录下来
                    localStorage.setItem('savepwd','0');
                }
                window.parent.location.href = "../index.html?t="+(new Date()).getTime();

            }else{
                document.getElementById('password').value = ''
                document.getElementById('txtinput').value = ''
                document.getElementById('savepwd').checked = false;
                if (coo == "English") {
                    alert("Incorrect User Name or Password, Please Try Again!")
                } else {
                    alert("用户名或密码输入错误，请重新输入!")
                }
            }
            console.error(data);
            
        },
        error: function (err) {
            alert("exception:"+JSON.stringify(err));
        }
    });

    return;

}


// modified begin by fyj
function check_nouse() {
    var name = document.getElementById("txtinput").value;
    var pass = document.getElementById("password").value;
    var isLoginSuccess = false;
    var coo = getCookie("AnyLinkLan");
    $.get('../conf/Login.xml?t='+(new Date()).getTime(), function(d) {
        $(d).find('LoginInfo').each(function() {
            var $LoginInfo = $(this);
            var User = $LoginInfo.find('UserName').text();
            var password = $LoginInfo.find('Password').text();
            if(name == User && pass == password) {
                isLoginSuccess = true;
            }
        });
        if(isLoginSuccess == true) {
            sessionStorage.AnylinkName = name;
            sessionStorage.AnylinkPass = pass;
            //取用户名
            var usr = name;
            //将最后一个用户信息写入到Cookie
            SetLastUser(usr);
            //如果记住密码选项被选中
            if (document.getElementById('savepwd').checked == true) {
                //取密码值
                var pwd = pass;
                var expdate = new Date();
                expdate.setTime(expdate.getTime() + 14 * (24 * 60 * 60 * 1000));
                //将用户名和密码写入到Cookie
                SetCookie(usr, pwd, expdate);
                // 将是否记住密码的状态记录下来
                localStorage.setItem('savepwd','1');
            } else {
                //如果没有选中记住密码,则立即过期
                ResetCookie();
                // 将是否记住密码的状态记录下来
                localStorage.setItem('savepwd','0');
            }
            window.parent.location.href = "../index.html?t="+(new Date()).getTime();
        }else {
            document.getElementById('password').value = ''
            document.getElementById('txtinput').value = ''
            document.getElementById('savepwd').checked = false;
            if (coo == "English") {
                alert("Incorrect User Name or Password, Please Try Again!")
            } else {
                alert("用户名或密码输入错误，请重新输入!")
            }
        }
    });
}
// modified end

window.onload = function onLoginLoaded() {
    if (isPostBack == "False") {
        GetLastUser();
    }
}

function GetLastUser() {
    var id = "49BAC005-7D5B-4231-8CEA-16939BEACD67"; //GUID标识符
    var usr = GetCookie(id);
    if (usr != null) {
        document.getElementById('txtinput').value = usr;
    } else {
        document.getElementById('txtinput').value = "001";
    }
    GetPwdAndChk();
}
    //点击登录时触发客户端事件

function SetLastUser(usr) {
    var id = "49BAC005-7D5B-4231-8CEA-16939BEACD67";
    var expdate = new Date();
    //当前时间加上两周的时间
    expdate.setTime(expdate.getTime() + 14 * (24 * 60 * 60 * 1000));
    SetCookie(id, usr, expdate);
}
//用户名失去焦点时调用该方法

function GetPwdAndChk() {
    var usr = document.getElementById('txtinput').value;
    var pwd = GetCookie(usr);
    if (pwd != null) {
        document.getElementById('savepwd').checked = true;
        document.getElementById('password').value = pwd;
    } else {
        document.getElementById('savepwd').checked = false;
        document.getElementById('password').value = "";
    }
}

//取Cookie的值
function GetCookie(name) {
    var arg = name + "=";
    var alen = arg.length;
    var clen = document.cookie.length;
    var i = 0;
    while (i < clen) {
        var j = i + alen;
        //alert(j);
        if (document.cookie.substring(i, j) == arg) return getCookieVal(j);
        i = document.cookie.indexOf(" ", i) + 1;
        if (i == 0) break;
    }
    return null;
}
var isPostBack = "<%= IsPostBack %>";

function getCookieVal(offset) {
    var endstr = document.cookie.indexOf(";", offset);
    if (endstr == -1) endstr = document.cookie.length;
    return unescape(document.cookie.substring(offset, endstr));
}

//写入到Cookie
function SetCookie(name, value, expires) {
    var argv = SetCookie.arguments;
    var argc = SetCookie.arguments.length;
    var expires = (argc > 2) ? argv[2] : null;
    var path = (argc > 3) ? argv[3] : null;
    var domain = (argc > 4) ? argv[4] : null;
    var secure = (argc > 5) ? argv[5] : false;
    document.cookie = name + "=" + escape(value) + ((expires == null) ? "" : ("; expires=" + expires.toGMTString())) + ((path == null) ? "" : ("; path=" + path)) + ((domain == null) ? "" : ("; domain=" + domain)) + ((secure == true) ? "; secure" : "");
}

function ResetCookie() {
    var usr = document.getElementById('txtinput').value;
    var expdate = new Date();
    expdate.setTime(expdate.getTime() - 14 * (24 * 60 * 60 * 1000));
    SetCookie(usr, null, expdate);
}

document.onkeydown = function(event) {
    e = event ? event : (window.event ? window.event : null);
    if (e.keyCode == 13) {
        document.getElementById("login").click()
    }
}