#!/usr/bin/python
# -*- coding: UTF-8 -*-

import xml.etree.ElementTree as ET
import sys
import os
import shutil

if len(sys.argv) < 2:
    print 'Error! 请填写DA版本'
    sys.exit(1)

# 将sdmwebs.zip解压到指定的目录
if os.path.exists('/opt/sdmwebs/'):
    shutil.rmtree('/opt/sdmwebs/')

os.system('unzip ./sdmwebs.zip -d /opt/')
os.system('chmod 755 -R /opt/sdmwebs/web/')

daModel = sys.argv[1]
vpnVersion = '1.0.0'
cloudAddress = 's1.anylinkcloud.com'
httpPort = '8686'
mqttPubPort = '1883'
mqttSubPort = '1883'
mqttTls = '0'
apiPort = '8600'
# 0: http, 1: mqtt
protocol = '1'
mqttServer = 's1.anylinkcloud.com'
displayName = daModel
boxHardwareType = 'DA'
RaExtraDataitem = '0'
agent_uploadtype = '1'  # 0: change upload , 1: all upload数据上传模式
agent_alarmmode = '0'  # 告警模块上传

if len(sys.argv) > 15:
    agent_alarmmode = sys.argv[15]
if len(sys.argv) > 14:
    agent_uploadtype = sys.argv[14]
if len(sys.argv) > 13:
    RaExtraDataitem = sys.argv[13]
if len(sys.argv) > 12:
    boxHardwareType = sys.argv[12]
if len(sys.argv) > 11:
    displayName = sys.argv[11]
if len(sys.argv) > 10:
    mqttServer = sys.argv[10]
if len(sys.argv) > 9:
    protocol = sys.argv[9]
if len(sys.argv) > 8:
    vpnVersion = sys.argv[8]
if len(sys.argv) > 7:
    apiPort = sys.argv[7]
if len(sys.argv) > 6:
    mqttTls = sys.argv[6]
if len(sys.argv) > 5:
    mqttSubPort = sys.argv[5]
if len(sys.argv) > 4:
    mqttPubPort = sys.argv[4]
if len(sys.argv) > 3:
    httpPort = sys.argv[3]
if len(sys.argv) > 2:
    cloudAddress = sys.argv[2]

# 如果是Anylink 400 上网模式是 4G, 其余的上网模式是 gateway
networkModePath = '/opt/sdmwebs/web/cgi-bin/config/global_var.py'
fileContent = ''
with open(networkModePath, 'r') as f:
    for line in f.readlines():
        if ('network_mode' in line) and (not('network_model' in line)):
            if '400' in daModel:
                fileContent += "network_mode = '4G'\n"
            else:
                fileContent += "network_mode = 'gateway'\n"
        elif 'agent_uploadtype' in line:
            fileContent += "agent_uploadtype = '%s' \n" % agent_uploadtype
        elif 'agent_alarmmode' in line:
            fileContent += "agent_alarmmode = '%s' \n" % agent_alarmmode
        else:
            fileContent += line

with open(networkModePath, 'w') as f:
    f.write(fileContent)


# 更新vpn的版本
path = '/opt/sdmwebs/web/cgi-bin/vpn/vpn_version.txt'
with open(path, 'w') as f:
    f.write(vpnVersion)

# 获取 Agent版本
agentVersion = ''
p = os.popen('/opt/agent/agentbasic -v', 'r')
agentData = p.read().split(' ')
agentVersion = "V"+agentData[1]+"."+agentData[3][0:-1]

if len(agentVersion) == 0:
    print 'Error! Agent版本获取失败'
    sys.exit(1)

# 获取网关序列号
serialNumber = ''
with open('/etc/devuaid.d', 'rb') as fp:
    fp = open('/etc/devuaid.d', 'rb')
    serialNumber = fp.readlines()[0].strip()

if len(serialNumber) == 0:
    print 'Error! 序列号获取失败'
    sys.exit(1)

# 将变量值更新至Common.xml文件中
common_path = '/opt/sdmwebs/web/conf/Common.xml'
commonTree = ET.parse(common_path)
HardwareModel_node = commonTree.find('HardwareModel')
HardwareModel_node.text = daModel

AgentVersion_node = commonTree.find('AgentVersion')
AgentVersion_node.text = agentVersion

SerialNumber_node = commonTree.find('SerialNumber')
SerialNumber_node.text = serialNumber

CloudAddress_node = commonTree.find('CloudAddress')
CloudAddress_node.text = cloudAddress

HttpPort_node = commonTree.find('HttpPort')
HttpPort_node.text = httpPort

MqttPubPort_node = commonTree.find('MqttPubPort')
MqttPubPort_node.text = mqttPubPort

MqttSubPort_node = commonTree.find('MqttSubPort')
MqttSubPort_node.text = mqttSubPort

MqttSubPort_node = commonTree.find('MqttTls')
MqttSubPort_node.text = mqttTls

ApiPort_node = commonTree.find('ApiPort')
ApiPort_node.text = apiPort

Protocol_node = commonTree.find('Protocol')
if protocol == '0':
    protocol = 'http'
else:
    protocol = 'mqtt'
if Protocol_node is not None:
    Protocol_node.text = protocol

MqttAddress_node = commonTree.find('MqttAddress')
if MqttAddress_node is not None:
    MqttAddress_node.text = mqttServer

HardwareName_node = commonTree.find('HardwareName')
if HardwareName_node is not None:
    HardwareName_node.text = displayName

AnyLinkType_node = commonTree.find('AnyLinkType')
if AnyLinkType_node is not None:
    AnyLinkType_node.text = boxHardwareType

RaExtraDataitem_node = commonTree.find('RaExtraDataitem')
if RaExtraDataitem_node is not None:
    RaExtraDataitem_node.text = RaExtraDataitem

commonTree.write(common_path, xml_declaration='true')

print 'Successfully!'
