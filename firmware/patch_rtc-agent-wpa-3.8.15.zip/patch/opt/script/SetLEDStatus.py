#!/usr/bin/python
# -*- coding: UTF-8 -*-
import os
import sys
import getopt
import time
import socket
import thread
import shutil
import commands
import xml.etree.ElementTree
import logging
from logging.handlers import RotatingFileHandler

FILENAME = sys._getframe().f_code.co_filename
VERSION = "1.0.2"

# args
g_log_level = 400  # debug
g_gpio10_mode = "gps"

AgentState = 0
GPIO_ErrorState = "/sys/class/gpio/gpio25/value"
GPIO_ErrorState_new_status = 0
GPIO_ErrorState_old_status = 0

GPIO_CloudConnectionState = "/sys/class/gpio/gpio24/value"
GPIO_CloudConnectionState_new_status = 0
GPIO_CloudConnectionState_old_status = 0




GPIO_AgentStatus = "/sys/class/gpio/gpio10/value"
GPIO_AgentStatus_new_status = 0
GPIO_AgentStatus_old_status = 0


GPIO_Log_Count = 0

Scr_AnyLink_xml = "/opt/sdmwebs/web/conf/AnyLink.xml"
Scr_AgentConfig_xml = "/opt/agent/AgentConfig.xml"
Scr_ModuleConfig_xml = "/opt/agent/ModuleConfig.xml"

FILE_AgentStatus = "/tmp/agnetstat"
FILE_NetStatus = "/tmp/netstat"
FILE_MobileSignalStrength = "/tmp/netintensity"
FILE_MobileMode = "/tmp/netmode"

CHECK_NETWORK_FRE = 300  # sec
LED_CHECKSELF_TIME = 1  # sec

NET_MODE = ''       # 4G / gateway

# ################### scs #########################

FILE_SCS_Status = "/tmp/scs_status"
# SCS_LED_MODE = [ "m_twinkle" | "m_light"]
SCS_LED_MODE = "m_light"
SCS_LED_TWINKLE_INTERVAL = 0.5  # sec, twinkle interval
SCS_STATUS_CHECK_INTERVAL = 0.5  # sec, scs status check interval
SCS_LED_ACTIVE_RELAY = 6  # sec, scs LED status active relay


def initial_log(log_ame, debug):
    """定义一个RotatingFileHandler，最多备份5个日志文件，每个日志文件最大64K"""
    log = logging.getLogger()
    handler = RotatingFileHandler(log_ame, maxBytes=64 * 1024, backupCount=2)
    formatter = logging.Formatter('%(asctime)s-%(levelname)s: %(message)s')
    handler.setFormatter(formatter)
    ch = logging.StreamHandler()
    ch.setFormatter(formatter)
    log.addHandler(handler)
    log.addHandler(ch)

    if debug is not None:
        log.setLevel(debug)
    else:
        log.setLevel(logging.WARNING)
    return log


def get_version(log):
    log.info(FILENAME + "-" + VERSION)


def Socket2Agent(logger):
    AgentAddr = ('127.0.0.1', 10001)
    socket.setdefaulttimeout(10)
    try:
        client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client.connect(AgentAddr)
    except Exception, e:
        logger.error("Connect to agent failed! %s" % e.message)
        client.close()
        return -1
    client.close()
    return 0


def LightLED(value_path="", status="1"):
    try:
        with open(value_path, 'w') as fd:
            fd.write(status)
        return True, ""
    except Exception, ept:
        return False, repr(ept)


def WriteValue(value_path="", status="1"):
    try:
        with open(value_path, 'w') as fd:
            fd.write(status)
        return True, ""
    except Exception, ept:
        return False, repr(ept)


def ReadValue(value_path=""):
    try:
        res = ""
        with open(value_path, 'r') as fd:
            res = fd.read().strip()
        return res
    except Exception, ept:
        return ""

def run_cmd(cmd):
   
    (status, output) = commands.getstatusoutput(cmd)
    if output != "":
        return output.strip()
    else:
        return ""

       
def process_exists(app_name):
    process_list = run_cmd('ps | grep {0} | grep -v grep'.format(app_name))
    if process_list == "" or process_list == None:
        return False
    else:
        return True


#check agent 10001 tcp port 
def CheckAgent_scoket(logger, Interval):
    if not os.path.isfile(FILE_AgentStatus):
        os.mknod(FILE_AgentStatus)
        WriteValue(FILE_AgentStatus, "0\n")
    old_AgentState = 0
    log_count = 0
    while True:
        try:
            global AgentState
            time.sleep(Interval)
            rec = Socket2Agent(logger)
            if rec == 0:
                AgentState = 1
                WriteValue(FILE_AgentStatus, "1\n")
            else:
                AgentState = 0
                WriteValue(FILE_AgentStatus, "0\n")

            log_count += 1

            if AgentState != old_AgentState or log_count >= 60:
                if AgentState:
                    logger.info("Agent is active")
                else:
                    logger.info("Agent is inactive")

                if log_count >= 60:
                    log_count = 0

            old_AgentState = AgentState

        except Exception, e:
            logger.error("Check agent error:" + e.message)

    thread.exit_thread()



#check agentd,agentbasic process 
def CheckAgent(logger, Interval):
    if not os.path.isfile(FILE_AgentStatus):
        os.mknod(FILE_AgentStatus)
        WriteValue(FILE_AgentStatus, "0\n")
    old_AgentState = 0
    log_count = 0
    rec = 0
    while True:
        try:
            global AgentState
            time.sleep(Interval)
            if process_exists("agentd") and process_exists("agentbasic"):
                rec = 0
            else:
                rec = 1

            if rec == 0:
                AgentState = 1
                WriteValue(FILE_AgentStatus, "1\n")
            else:
                AgentState = 0
                WriteValue(FILE_AgentStatus, "0\n")
                
            run_cmd("echo %d > %s" % (AgentState,GPIO_AgentStatus))

            log_count += 1

            if AgentState != old_AgentState or log_count >= 60:
                if AgentState:
                    logger.info("Agent is active")
                else:
                    logger.info("Agent is inactive")

                if log_count >= 60:
                    log_count = 0

            old_AgentState = AgentState

        except Exception, e:
            logger.error("Check agent error:" + e.message)

    thread.exit_thread()

def Sokcet2Server(logger, server, port):
    try:
        ip_addr = socket.gethostbyname(server)
    except Exception, e:
        logger.warn("get server IP failed, %s" % e.message)
        return -1
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(1)
    try:
        sock.connect((ip_addr, int(port)))
    except Exception, e:
        logger.warn("check connect with server failed, %s" % e.message)
        return -11
    sock.close()
    return 0


def CheckNetwork(logger):
    global NET_MODE
    if not os.path.isfile(FILE_NetStatus):
        os.mknod(FILE_NetStatus)
        fd = open(FILE_NetStatus, "w")
        fd.write("0\n")
        fd.close()
    try:
        tree = xml.etree.ElementTree.parse(Scr_AnyLink_xml)
        nodes = tree.getroot()
        NodeName = nodes.find('AgentConfig/AgentMode')
        agentmode = NodeName.text
        NET_MODE = nodes.find('NetworkInfo/Mode').text
    except Exception, e:
        print "Failed to get the server address, error msg: %s" % repr(e)
        return -1
    # server mode
    if agentmode != "0":
        return 0
    # global server
    try:
        tree = xml.etree.ElementTree.parse(Scr_AgentConfig_xml)
        nodes = tree.getroot()
        NodeName = nodes.find('Protocol')
        protocol = NodeName.text
    except Exception, e:
        print "Failed to get the protocol of agent, error msg: %s" % repr(e)
        return -1
    if protocol == 'mqtt':
        try:
            tree = xml.etree.ElementTree.parse(Scr_ModuleConfig_xml)
            mqtt_node = tree.find('./task/TaskDriver/driver[@n="T.IDrv.Task:libkmqtt"]')
            str2 = mqtt_node.get('config').split(';')
            server = str2[0]
            port = str2[1]
        except Exception, e:
            logger.error("Failed to get the server address from ModuleConfig.xml file, error msg: %s" % repr(e))
            return -1
    else:
        try:
            tree = xml.etree.ElementTree.parse(Scr_AnyLink_xml)
            nodes = tree.getroot()
            NodeName = nodes.find('CloudInfo/Address')
            address = NodeName.text
        except Exception, e:
            logger.error("Failed to get the server address from AnyLink.xml file, error msg: %s" % repr(e))
            return -1
        if ":" in address:
            server = address[:address.index(':')]
            port = address[address.index(':') + 1:]
        else:
            server = address
            NodeName = nodes.find('CloudInfo/Http_port')
            port = NodeName.text

    delay = 10
    count = 0
    logger.debug("Start check network")
    net_status = 0
    old_net_status = 0
    log_count = 0
    while True:
        try:
            if 0 == Sokcet2Server(logger, server, port):
                WriteValue(FILE_NetStatus, "1\n")
                net_status = 1
                if delay < CHECK_NETWORK_FRE:
                    delay = (delay * 2) if ((delay * 2) < CHECK_NETWORK_FRE) else CHECK_NETWORK_FRE
                count = 0
            else:
                net_status = 0
                WriteValue(FILE_NetStatus, "0\n")
                delay = 10
                count = count + delay
                if count >= 1800:
                    logger.warn("reboot system!!!")
                    os.system("sync && shutdown -r now")

            log_count += 1

            if old_net_status != net_status or log_count >= 6:
                if net_status:
                    logger.debug("Network({0}:{1}) is connectable".format(server, port))
                else:
                    logger.warn("Network({0}:{1}) is disconnect !!! ".format(server, port))
                if log_count >= 6:
                    log_count = 0

            old_net_status = net_status
        except Exception, e:
            logger.error("CheckNetwork while, error msg: %s" % repr(e))
            time.sleep(delay)

        time.sleep(delay)

    return 0


def IsActiveMobileMode(mode="", log=None):
    """
    :param log: log
    :param mode: network information
    :return:
    1, 3/4G net mode
    0, others, exception
    """
    ret = 0
    try:
        s_mode = str(mode).strip()
        if len(s_mode) <= 0:
            return 0
        s_mode_l = s_mode.split('\n')[0]
        if len(s_mode_l) <= 0:
            return 0
        # 3/4G
        for m in ['TDSCDMA', 'TD-SCDMA', 'WCDMA', 'CDMA2000', 'HSDPA', 'HSUPA', 'HSPA+',
                  'LTE', 'WiMax']:
            if m in s_mode_l:
                return 1

    except Exception as ept:
        log.warn('detect network mode fail, error msg: %s' % repr(ept))
        ret = 0

    return ret


def IsActiveSignalLED(signal=""):
    ret = 0
    msg = ""
    try:
        if len(signal) <= 0:
            ret = 0
            msg = "signal is emtpy"
            return ret, msg

        signal_val = float(signal)
        if 17 <= signal_val < 99:
            ret = 1
        else:
            ret = 0
            msg = "signal_val(%s) is out of [%d, %d)" % (signal, 17, 99)

    except Exception as ept:
        return 0, repr(ept)

    return ret, msg


def RunLED(log):
    """check status to set LED"""
    global GPIO_CloudConnectionState_new_status, GPIO_CloudConnectionState_old_status
    global GPIO_ErrorState_new_status, GPIO_ErrorState_old_status
    
    global GPIO_Log_Count
    global NET_MODE
    mobile_mode = "0"
    try:
        with open(FILE_NetStatus, "r") as fd:
            net = fd.read().strip()
        GPIO_CloudConnectionState_new_status = 1 if "1" in net else 0
        # LightLED(GPIO_CloudConnectionState, str(GPIO_CloudConnectionState_new_status))
    except Exception, e:
        log.error(FILE_NetStatus + ":" + e.message)

    if GPIO_CloudConnectionState_new_status != GPIO_CloudConnectionState_old_status:
        LightLED(GPIO_CloudConnectionState, str(GPIO_CloudConnectionState_new_status))
        log.debug("Cloud Connection State is {0}".format(GPIO_CloudConnectionState_new_status))
    GPIO_CloudConnectionState_old_status = GPIO_CloudConnectionState_new_status

    if NET_MODE == '4G':
        mobile_signal_strength = "0"
        try:
            with open(FILE_MobileSignalStrength, "r") as fd:
                mobile_signal_strength = fd.read()           
        except Exception, e:
            log.error(FILE_MobileSignalStrength + ":" + e.message)

       

    try:
        GPIO_ErrorState_new_status = 1 if AgentState != 1 else 0
        # LightLED(GPIO_ErrorState, str(GPIO_ErrorState_new_status))
    except Exception, e:
        log.error("Agent status:" + e.message)

    if GPIO_ErrorState_new_status != GPIO_ErrorState_old_status:
        LightLED(GPIO_ErrorState, str(GPIO_ErrorState_new_status))
        log.debug("Agent state: " + str(GPIO_ErrorState_new_status))
    GPIO_ErrorState_old_status = GPIO_ErrorState_new_status

    GPIO_Log_Count += 1
    # flush LED status per 10 * 5 second
    if not (GPIO_Log_Count % 10):
        LightLED(GPIO_CloudConnectionState, str(GPIO_CloudConnectionState_new_status))
        LightLED(GPIO_ErrorState, str(GPIO_ErrorState_new_status))

    if GPIO_Log_Count >= 720:
        GPIO_Log_Count = 0
        log.debug("Cloud Connection State is {0}".format(GPIO_CloudConnectionState_new_status))
        log.debug("Mobile mode:\n" + mobile_mode)
        log.debug("Mobile signal strength: " + mobile_signal_strength)
        log.debug("Agent state: " + str(GPIO_ErrorState_new_status))


def LightLEDFroMode(value_path="", led_mode="", relay=3):
    try:
        interval = SCS_LED_TWINKLE_INTERVAL
        if led_mode == "m_twinkle":
            rty = int(relay / interval)
            n = 0
            status = 1
            while n < rty:
                LightLED(value_path, str(status))
                n += 1
                status = 1 if status == 0 else 0
                time.sleep(interval)

        elif led_mode == "m_light":
            LightLED(value_path, "1")
            time.sleep(relay)
        else:
            return False, "There is not led_mod: {0}".format(led_mode)
        return True, ""
    except Exception, ept:
        return False, repr(ept)


def CheckSelf(times=1):
    LightLED(GPIO_CloudConnectionState, "1")
    LightLED(GPIO_ErrorState, "1")
    

    time.sleep(times)
    LightLED(GPIO_CloudConnectionState, "0")
    LightLED(GPIO_ErrorState, "0")
    



def LightLEDScs(logger, led_mode="", interval=3, mode=""):
    """
    Check communication status, light scs LED
    :param mode: gpio10 mode ,[gps|rs485]
    :param logger:  log
    :param interval:  sec
    """
    if mode != "rs485":
        return
    logger.info("Current gpio10 mode: {0}".format(mode))
    logger.info("Start LightLEDScs, LED_mode: {0}, interval: {1}".format(led_mode, interval))
    while True:
        try:
            if not os.path.exists(FILE_SCS_Status):
                time.sleep(SCS_STATUS_CHECK_INTERVAL)
                continue
            with open(FILE_SCS_Status, "r") as f:
                status = f.read()
              

        except Exception, ept:
            logger.error("LightLEDScs: " + repr(ept))
        time.sleep(SCS_STATUS_CHECK_INTERVAL)


def print_usage():
    print ("""
usage:
    -h, --help
    -l, --level=[100|200|300|400]        choose log level
    --gpio10=[gps|rs485]                 choose gpio10 mode 
    \n""")


def argv_parser(argv):
    global g_log_level, g_gpio10_mode
    opts, args = getopt.getopt(argv[1:], "hl:", ["help", "level=", "gpio10="])
    for o, a in opts:
        if o in ["-h", "--help"]:
            print_usage()
            exit(0)
        elif o in ["-l", "--level"]:
            g_log_level = int(a)
        elif o in ["--gpio10"]:
            g_gpio10_mode = a


def main(log):
    CheckSelf(LED_CHECKSELF_TIME)
    thread.start_new_thread(CheckAgent, (log, 10))
    #thread.start_new_thread(CheckNetwork, (log,))
    thread.start_new_thread(LightLEDScs, (log, SCS_LED_MODE, SCS_LED_ACTIVE_RELAY, g_gpio10_mode))
    while True:
        try:
            RunLED(log)
        except Exception, ept:
            log.error("main: " + repr(ept))
            time.sleep(5)
        time.sleep(5)


# ############################# main block ##############################

if __name__ == '__main__':
    argv_parser(sys.argv)
    if g_log_level == 100:
        logLevel = logging.ERROR
    elif g_log_level == 200:
        logLevel = logging.WARN
    elif g_log_level == 300:
        logLevel = logging.INFO
    else:
        logLevel = logging.DEBUG
    logger = initial_log('/PageFile/SetLEDStatus.log', logLevel)
    get_version(logger)
    main(logger)
    sys.exit(0)
