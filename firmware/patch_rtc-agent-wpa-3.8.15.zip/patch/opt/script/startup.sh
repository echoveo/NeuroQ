#!/bin/sh

# author: kali
# version: 1.0.0
# date: 2022/11/01

cd /opt/script/ && python startup.py >/dev/null 2>&1 &




