#!/usr/bin/python
# -*- coding: UTF-8 -*-

# author: kali
# version: 1.0.0
# date: 2021/10/20

# 对设备做体检，项目如下：
# 1。检查以太网是否正常
import os
import sys
import time
import logging
import psutil
import commands
from logging.handlers import RotatingFileHandler
import xml.etree.ElementTree

FILENAME = sys._getframe().f_code.co_filename
VERSION = "1.0.1"

GPIO_ErrorState = "/sys/class/gpio/gpio25/value"
GPIO_CloudConnectionState = "/sys/class/gpio/gpio24/value"
GPIO_MobileSignalStrength = "/sys/class/gpio/gpio11/value"
GPIO_MobileMode = "/sys/class/gpio/gpio42/value"

# global
Src_AnyLink_xml = "/opt/sdmwebs/web/conf/AnyLink.xml"
gRouteIPAddress = "192.168.101.204"    #路由器ip地址，一般指bridge0的ip地址
gRouteNetMode = "4G"                    #路由器网络模式 "gateway" "4G" "wifi" 就是wan的出口方式
gIsEth0LinkUp = False                   #eth0是否接入网线，第一次接入网线时，
                                        #  如果gRouteNetMode=='gateway' 时需要设置vlan,或者4G,wifi时关闭vlan

def initial_log(log_name, debug):
    """定义一个RotatingFileHandler，最多备份2个日志文件，每个日志文件最大8K"""
    log = logging.getLogger()
    handler = RotatingFileHandler(log_name, maxBytes=1024 * 8, backupCount=2)
    formatter = logging.Formatter('%(asctime)s-%(levelname)s: %(message)s')
    handler.setFormatter(formatter)
    ch = logging.StreamHandler()
    ch.setFormatter(formatter)
    log.addHandler(handler)
    log.addHandler(ch)

    if debug is not None:
        log.setLevel(debug)
    else:
        log.setLevel(logging.WARNING)
    return log


def get_version(log):
    log.info(FILENAME + "-" + VERSION)

def light_led(led, value):
    if os.path.isfile(led):
        with open(led, 'w') as fd:
            fd.write(str(value))


# 从xml中获取路由器的网络配置
def get_route_cfg(log):
    global gRouteIPAddress,gRouteNetMode
    ret = True
    try:        
        tree = xml.etree.ElementTree.parse(Src_AnyLink_xml)
        root = tree.getroot()
        
        netMode_node = root.find('NetworkInfo/Mode')
        if netMode_node is not None:
            gRouteNetMode = netMode_node.text
        router_node = root.find('Router')
        if router_node is not None :
            gRouteIPAddress = router_node.find('IPAddr').text
            if gRouteIPAddress == '' :
                log.error('[get_route_cfg] %s Router.IPAddr not found' % Src_AnyLink_xml)  
                ret = False
            else :  
                ret = True
        else :
            log.error('[get_route_cfg] %s Router node not found' % Src_AnyLink_xml)
            light_led(GPIO_ErrorState, 0)
            ret = False
    except Exception as ept:
        log.error('[get_route_cfg] exception:')
        log.error(repr(ept))
        light_led(GPIO_ErrorState, 0)
        ret = False
        pass
    log.error('[get_route_cfg] %s Router.IPAddr =%s' % (Src_AnyLink_xml,gRouteIPAddress))
    return ret

def ProcessExist(processName):
    (status, output) = commands.getstatusoutput('ps | grep "%s" | grep -v grep' % processName)
    if output == '':
        return False
    else:
        return True

            
# 对以太网做检查
def check_eth0(log):
    ret = True
    try:
        (status, res) = commands.getstatusoutput('ifconfig bridge0 2>&1 | awk -F\'[ :]+\' \'$0 ~ "inet addr"{print $4}\'')
        if res == '':
            log.error('[check_eth0] bridge0 error: ipaddress invalid!')
            ret = False
        bridge0_ip = res
        if gRouteIPAddress != bridge0_ip :
            log.error('[check_eth0] bridge0.ipaddr[%s] != %s[AnyLink.xml]' % (bridge0_ip,gRouteIPAddress))
            ret = False

        (status, res) = commands.getstatusoutput('brctl show | grep bridge0 | grep eth')
        if res == '':
            log.error('[check_eth0] bridge0 brctl error: bridge0 not include eth0 or eth1')
            ret = False

       
    except Exception as ex:
        log.error('[check_eth0] exception:%s' % ex.message)
        ret = False
        time.sleep(10)
    return ret

#恢复bridge0 eth0
def restore_eth0(log):
    log.error('[restore_eth0] restore bridge0')
    os.system("brctl addbr bridge0")    
    os.system("brctl addif bridge0 wlan1")
    os.system("cd /opt/script/ && python SetEthernetConfig_9900.py")

def main(log):
    log.info("health_dialogue start...")
    heart_beat = 0
    get_route_cfg(log)
    time.sleep(10)
    while True:
        time.sleep(15)
        heart_beat = heart_beat + 1
        if heart_beat >= 3600:
            heart_beat = 0
            log.info("health_dialogue is running")
        try:
            if check_eth0(log) == False:
                restore_eth0(log)
                time.sleep(60)

        except Exception as ex:
            log.error(ex.message)
            time.sleep(10)


if __name__ == '__main__':
    logLevel = logging.DEBUG
    if len(sys.argv) > 1:
        level = int(sys.argv[1])
        if level == 100:
            logLevel = logging.ERROR
        elif level == 200:
            logLevel = logging.WARN
        elif level == 300:
            logLevel = logging.INFO
        else:
            logLevel = logging.DEBUG
    logger = initial_log('/PageFile/health_dialogue_9900.log', logLevel)
    get_version(logger)
    main(logger)
    sys.exit(0)
