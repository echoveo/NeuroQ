#!/usr/bin/python
# -*- coding: UTF-8 -*-

# author: kali
# version: 1.0.0
# date: 2021/10/20

# https://github.com/anylinkcloud/firmware/issues/15
# 按下REMOTE开关关闭SSH服务器，松开REMOTE开关打开SSH服务器
# REMOTE 开关 == GPIO-21   按下状态==1 抬起状态==0
import os
import sys
import time
import logging
import psutil
import commands
import xml.etree.ElementTree
from logging.handlers import RotatingFileHandler

FILENAME = sys._getframe().f_code.co_filename
VERSION = "1.0.0"
GPIO_SSH = "/sys/class/gpio/gpio21/value"

Src_AnyLink_xml = "/opt/sdmwebs/web/conf/AnyLink.xml"



def initial_log(log_name, debug):
    """定义一个RotatingFileHandler，最多备份2个日志文件，每个日志文件最大8K"""
    log = logging.getLogger()
    handler = RotatingFileHandler(log_name, maxBytes=1024 * 8, backupCount=2)
    formatter = logging.Formatter('%(asctime)s-%(levelname)s: %(message)s')
    handler.setFormatter(formatter)
    ch = logging.StreamHandler()
    ch.setFormatter(formatter)
    log.addHandler(handler)
    log.addHandler(ch)

    if debug is not None:
        log.setLevel(debug)
    else:
        log.setLevel(logging.WARNING)
    return log


def get_version(log):
    log.info(FILENAME + "-" + VERSION)


def light_led(value_path="", status="1"):
    try:
        with open(value_path, 'w') as fd:
            fd.write(status)
        return True, ""
    except Exception, ept:
        return False, repr(ept)


def initial_gpio(log):
    if not os.path.isfile(GPIO_SSH):        
        os.system("echo 21 > /sys/class/gpio/export")
        os.system("echo in > /sys/class/gpio/gpio21/direction")
    if not os.path.isfile(GPIO_SSH):        
        log.info("GPIO 21 not exist and initial_gpio fail!")

# 这个比较占用cpu
def ProcessExist_v1(processName):
    process_list = psutil.pids()
    try:
        for pid in process_list:
            process = psutil.Process(pid)
            if processName in process.name():
                return True
                #break
    except Exception, e:
        pass
    return False

def ProcessExist(processName):
    (status, output) = commands.getstatusoutput('ps | grep "%s" | grep -v grep' % processName)
    if output == '':
        return False
    else:
        return True

def run_cmd(cmd):   
    (status, output) = commands.getstatusoutput(cmd)
    if output != "":
        return output.strip()
    else:
        return ""

def killall(app_name):
    process_list = run_cmd('ps | grep {0} | grep -v grep'.format(app_name))
    if process_list == "" or process_list == None:
        return False
    process_list = process_list.split('\n')
    for P in process_list:
        items = P.split(' ')
        if len(items)>1 and (app_name in P):
            cmd = 'kill -9 {0}'.format(items[0])
            print '[killall]'+cmd
            os.system(cmd)
    return True


#   配置路由器本身的ip地址和相关信息
#   配置路由器本身
#   目前不用
def start_dnsmasq(log=None):
    """
    set router ethernet config
    :param root: AmyLink.xml root
    :param log: log handler
    :return:
    -1, return Exception
    0, not router mode
    1, router mode
    """
    log.info('Set dhcp for router')
    ret = 0
    try:
        tree = xml.etree.ElementTree.parse(Src_AnyLink_xml)
        root = tree.getroot()
        router_node = root.find('Router')
        if router_node is not None :
            ret = 1
            ip_addr = router_node.find('IPAddr').text
            sub_net_mask = router_node.find('SubNetMask').text
            enable_dhcp = router_node.find('EnableDHCPServer').text
            start_ip = router_node.find('DHCPConfig/StartIP').text
            end_ip = router_node.find('DHCPConfig/EndIP').text
            log.info('router ip address: %s' % ip_addr)
            log.info('router netmask: %s' % sub_net_mask)
            log.info('DHCP enable: %s' % enable_dhcp)
            log.info('router dhcp start ip: %s' % start_ip)
            log.info('router dhcp end ip: %s' % end_ip)


            ip_addr_head, ip_addr_end = str(ip_addr).strip().rsplit('.', 1)
            start_ip_head, start_ip_end = str(start_ip).strip().rsplit('.', 1)
            end_ip_head, end_ip_end = str(end_ip).strip().rsplit('.', 1)

            if ip_addr_head != start_ip_head or ip_addr_head != end_ip_head:
                raise Exception('router config must be in the same segment')
            


            #os.system("ifconfig bridge0 {0} netmask {1}".format(ip_addr, sub_net_mask))
            os.system("kill `ps -ef | grep dnsmasq | grep -v grep | awk '{print $1}'`")
            if enable_dhcp == '1':
                log.info('restart dnsmasq server')
                cmd = "dnsmasq -i {0} -I lo -z --dhcp-range={0},{1},{2},{3},43200 --dhcp-hostsfile=/etc/dhcp_hosts"\
                    "--dhcp-option-force=6,{4} --dhcp-option-force=26,1500 --dhcp-option-force=120,abcd.com"\
                    .format('bridge0', start_ip, end_ip, sub_net_mask, ip_addr)
                [status, res] = commands.getstatusoutput(cmd)
                log.info("status: %s, reply: %s" % (str(status), res))

            try:
                node_WAN = root.find('NetworkInfo/WAN')
                dns = node_WAN.get("dns", default=None)
            except Exception as ept:
                log.error('Get NetworkInfo fail in AnyLink.xml, error msg: %s' % repr(ept))
                return -1
            
            flush_dns_cmd = "grep \"{0}\" /etc/resolv.conf || echo \"nameserver {0}\" >> /etc/resolv.conf". \
                            format(dns)
            with open("/opt/script/flush_dns.sh", "w+") as fd:
                fd.write(flush_dns_cmd)
            os.system(flush_dns_cmd)
            os.system("sync")


    except Exception as ept:
        log.error(repr(ept))
        ret = -1

    return ret

def stop_ssh_service(log):
    if ProcessExist("dropbear"):
        log.info("GPIO ssh button is pressed ,stop ssh service")
        log.info("stop ssh service")
        os.system("/etc/init.d/start_dropbear stop")
        os.system("killall dropbear")
        os.system("killall dropbear")

def start_ssh_service(log):
    if not ProcessExist("dropbear"):  
        log.info("GPIO ssh button is release ,start ssh service")  
        log.info("restart ssh service")
        os.system("/etc/init.d/start_dropbear restart")


def stop_dns_boa(log):
    if ProcessExist("dnsmasq"):
        log.info("stop boa service")
        os.system("/etc/init.d/start_boa stop")
        log.info("stop dnsmasq service")
        os.system("killall dnsmasq")
        os.system("killall dnsmasq")

def start_dns_boa(log):
    if not ProcessExist("dnsmasq"):  
        log.info("GPIO ssh button is release ,start ssh service")  
        log.info("start boa service")
        os.system("/etc/init.d/start_boa start")
        log.info("start dnsmasq start")
        start_dnsmasq(log)
        #os.system("/etc/init.d/start_boa start")
        time.sleep(30)  #wait SetEthernetConfig.py startup
def main(log):
    log.info("GPIO ssh monitor start...")
    heart_beat = 0
  
    while True:
        time.sleep(1)
        heart_beat = heart_beat + 1
        if heart_beat >= 3600:
            heart_beat = 0
            log.info("GPIO ssh monitor is running")
        try:
            
            res = ""
            
            with open(GPIO_SSH, 'r') as fd:
                res = fd.read().strip()

            if res == '0':
                #只有当硬件rmt button没有被按下时，才检查软件状态，当硬件被按下时，硬件优先
                res = run_cmd("test -e  /etc/lockdown.tmp && cat /etc/lockdown.tmp")
                if res == None or res == "":
                    res = '0'

            if res == "1":              
                stop_ssh_service(log)    
                stop_dns_boa(log)
            if res == "0":                
                start_ssh_service(log)
                start_dns_boa(log)
        except Exception as ex:
            log.error(ex.message)
            time.sleep(10)


if __name__ == '__main__':
    logLevel = logging.DEBUG
    if len(sys.argv) > 1:
        level = int(sys.argv[1])
        if level == 100:
            logLevel = logging.ERROR
        elif level == 200:
            logLevel = logging.WARN
        elif level == 300:
            logLevel = logging.INFO
        else:
            logLevel = logging.DEBUG
    logger = initial_log('/PageFile/GPIO-ssh.log', logLevel)
    get_version(logger)
    initial_gpio(logger)
    main(logger)
    sys.exit(0)
