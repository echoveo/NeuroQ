#!/bin/sh

# author: luoshuai
# version: 1.0.3
# date: 2020/8/18

# initial gpio port

echo 10 > /sys/class/gpio/export        # led-RUNNING               OUT LED
echo 11 > /sys/class/gpio/export        # #reset sr9900
echo 20 > /sys/class/gpio/export        # hw-watchdog-signal 1Hz    OUT
echo 21 > /sys/class/gpio/export        # 用为控制ssh功能gpio        IN
echo 22 > /sys/class/gpio/export        # 作为reset按键功能          IN  
echo 23 > /sys/class/gpio/export        # 数据输入 DIN2              IN only
echo 24 > /sys/class/gpio/export        # led-network-online 设备在线        OUT LED
echo 25 > /sys/class/gpio/export        # led-error  发生错误         OUT LED
echo 26 > /sys/class/gpio/export        # 串口485和232模式切换：0-232； 1-485         OUT   todo
echo 42 > /sys/class/gpio/export        # SIMCOM4G power enable
echo 77 > /sys/class/gpio/export        # 隔离数字输入DIN1          IN only
echo 78 > /sys/class/gpio/export        # 充电状态：（充电芯片定义） IN
echo 79 > /sys/class/gpio/export        # 电池状态：0未充满；1充满（充电芯片定义） IN

echo out > /sys/class/gpio/gpio10/direction
echo out > /sys/class/gpio/gpio11/direction
echo out > /sys/class/gpio/gpio20/direction
echo in > /sys/class/gpio/gpio21/direction      
echo in > /sys/class/gpio/gpio22/direction      
echo in > /sys/class/gpio/gpio23/direction 
echo out > /sys/class/gpio/gpio24/direction  
echo out > /sys/class/gpio/gpio25/direction
echo out > /sys/class/gpio/gpio26/direction  
echo out > /sys/class/gpio/gpio42/direction      
echo in > /sys/class/gpio/gpio77/direction      
echo in > /sys/class/gpio/gpio78/direction
echo in > /sys/class/gpio/gpio79/direction

echo 1 > /sys/class/gpio/gpio10/value       #运行中
echo 0 > /sys/class/gpio/gpio11/value;sleep 0.2;echo 1 > /sys/class/gpio/gpio11/value       #reset sr9900
echo 0 > /sys/class/gpio/gpio24/value       #设备不在线
echo 0 > /sys/class/gpio/gpio25/value       #设备无错误
echo 0 > /sys/class/gpio/gpio26/value      #默认为RS-232模式 ttyHS0  todo 
echo 0 > /sys/class/gpio/gpio42/value      #SIMCOM4G off



#cd /opt/script/ && python mount_mmc.py >/dev/null 2>&1 #move to /etc/init.d/anylink_start
#sleep 1

cd /opt/script/ && python env_checker.py
cd /opt/script/ && python factory_test.py >/dev/null 2>&1 &

#sleep 1
cd /opt/script/ && python SetEthernetConfig_9900.py >/dev/null 2>&1 &
#sleep 1
cd /opt/script/ && python Sync_service.py >/dev/null 2>&1 &
cd /opt/script/ && python Crontabs.py >/dev/null 2>&1 &
cd /opt/script/ && python Ntpdate.py >/dev/null 2>&1 &

sleep 15
if [ -c /dev/ttyUSB0 ]
then
     echo "The dev ttyUSB0 exist"
else
     echo "The dev ttyUSB0 doesn't exist"
     if [ -c /dev/ttyUSB1 ]
     then
         ln -s /dev/ttyUSB1 /dev/ttyUSB0
     fi
fi

cd /opt/agent/ && python watchdog.py >/dev/null 2>&1 &
cd /opt/agentd/ && python watchdogd.py >/dev/null 2>&1 &
sleep 1

cd /opt/script/ && python SetLEDStatus.py --gpio10=gps >/dev/null 2>&1 &
cd /opt/script/ && python checknet.py --gpio10=gps >/dev/null 2>&1 &
cd /opt/script/ && python Reset.py >/dev/null 2>&1 &
cd /opt/script/ && python gpio21_ssh.py >/dev/null 2>&1 &
cd /opt/script/ && python AutoAPMode.py >/dev/null 2>&1 &
cd /opt/script/ && python webSvr.py >/dev/null 2>&1 &




