#!/bin/sh

# author: luoshuai
# version: 1.0.2

root_path=$(cd `dirname $0`;pwd)

led_mode='gps'
if [ $# -ge 1 ];then
	led_mode=$1
fi

voltage_mode='12v'
if [ $# -ge 2 ];then
	voltage_mode=$2
fi

script_path="/opt/script"


cd ${root_path} && unzip -o script.zip && rm -rf script.zip

[[ -d ${script_path} ]] || mkdir -p ${script_path}
cp -rf ${root_path}/script/* ${script_path}/ && sync
chmod -R 777 ${script_path}/*


if [[ ${led_mode} = 'gps' ]]; then
	sed -i '/SetLEDStatus.py/c\cd /opt/script/ && python SetLEDStatus.py --gpio10=gps >/dev/null 2>&1 &' ${script_path}/startup.sh && sync
else
	sed -i '/SetLEDStatus.py/c\cd /opt/script/ && python SetLEDStatus.py --gpio10=rs485 >/dev/null 2>&1 &' ${script_path}/startup.sh && sync
fi

# deploy others
if [ -d ${script_path}/others ]; then
    chmod +x ${script_path}/others/deploy.sh
    cd ${script_path}/others && sh ./deploy.sh
    rm -rf ${script_path}/others
else
    echo -e "warning, not found others"
fi

sync
exit 0
