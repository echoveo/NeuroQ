#!/usr/bin/python
# -*- coding: UTF-8 -*-

# author: kali
# version: 1.0.0
# date: 2021/10/20

# https://github.com/anylinkcloud/firmware/issues/15
# 按下REMOTE开关关闭SSH服务器，松开REMOTE开关打开SSH服务器
# REMOTE 开关 == GPIO-21   按下状态==1 抬起状态==0
import os
import sys
import time
import logging
import psutil
import commands
from logging.handlers import RotatingFileHandler

FILENAME = sys._getframe().f_code.co_filename
VERSION = "1.0.0"
def initial_log(log_name, debug):
    """定义一个RotatingFileHandler，最多备份2个日志文件，每个日志文件最大8K"""
    log = logging.getLogger()
    handler = RotatingFileHandler(log_name, maxBytes=1024 * 8, backupCount=2)
    formatter = logging.Formatter('%(asctime)s-%(levelname)s: %(message)s')
    handler.setFormatter(formatter)
    ch = logging.StreamHandler()
    ch.setFormatter(formatter)
    log.addHandler(handler)
    log.addHandler(ch)

    if debug is not None:
        log.setLevel(debug)
    else:
        log.setLevel(logging.WARNING)
    return log


def get_version(log):
    log.info(FILENAME + "-" + VERSION)


if __name__ == '__main__':
    logLevel = logging.DEBUG
    lock_state = 1
    if len(sys.argv) > 1:
        lock_state = int(sys.argv[1])
    logger = initial_log('/PageFile/lockdown.log', logLevel)    
    os.system("echo %d > /etc/lockdown.tmp;sync" % (lock_state))
    logger.info("lock_state=%d" % (lock_state))

    sys.exit(0)
