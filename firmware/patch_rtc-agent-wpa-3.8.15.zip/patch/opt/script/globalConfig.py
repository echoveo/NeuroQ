#!/usr/bin/python
# -*- coding: UTF-8 -*-
import os
import sys
import commands
import subprocess
import json

VERSION = "1.0.0"

'''
HardwareName:
        NeuroQ-200 第一版NeuroQ硬件EC20 +  以太网AR8337
        NeuroQ-300 第二版NeuroQ硬件EC20 +  以太网SR9900
'''
shell_HardwareName = "sed -n '/HardwareName/{s/.*<HardwareName>//;s/<\/HardwareName.*//;p;}' /opt/sdmwebs/web/conf/AnyLink.xml"
shell_AgentVersion = "sed -n '/AgentVersion/{s/.*<AgentVersion>//;s/<\/AgentVersion.*//;p;}' /opt/sdmwebs/web/conf/AnyLink.xml"


#读取配置文件
def config(cfg='config.json'):
    global g_conf,g_deploy_path,g_deploy_target,g_factory_test_mainPY
    if g_conf != None:
        return g_conf
    load_conf = None
    with open(cfg,'r') as load_f:
        load_conf = json.load(load_f)
        
    g_conf=load_conf
    g_conf["deploy_target"]=g_deploy_target
    g_conf['deploy_path']=g_deploy_path
    g_conf['working_path']="{0}/{1}".format(g_deploy_target,g_deploy_path)
    g_conf['mainPY']="{0}".format(g_factory_test_mainPY)
    g_conf['factory_test_running_path']="{0}/{1}/{2}".format(g_deploy_target,g_deploy_path,g_factory_test_mainPY)
    return g_conf

def getConfig():
    hardwareConfig = None
    HardwareName = "NeuroQ-200"
    AgentVersion = "V3.8.6"
    with open('/opt/script/hardwareConfig.json','r') as load_f:
        hardwareConfig = json.load(load_f)
    '''
    hardwareConfig = {  'HardwareName':HardwareName,
                        'GPIO_OUT':[[11,1],[37,1]],#GPIO_OUT =  [port,default] 
                        'GPIO_IN':[[12,1],[13,1]],
                        'ETHERNET':{'type':'SR9900','using':"enabled","PORT_DEFINE":"LL"},#SR9900,AR8337,LL,LW,WL 等定义
                        'WIFI':{'type':'FC20','using':"enabled"},#using = [enabled|autodetect|disabled] 
                        '4G':{'type':'SIMCOM','using':"disabled",'APN':"None"},#type=[internal:内部4G模块|SIMCOM 使用simcom模块]
                        'CANBUS':{'type':"uart",'using':"autodetect"},
                        'ADC':{'type':"uart",'using':"enabled"},    
                        'WIFIAH':{'type':"TX-huge",'using':"autodetect"},    
                        'health_dialogue_list':['ETHERNET','4G','CANBUS','ADC','WIFIAH','WIFI'] #哪些设备参与周期性的健康检查
                        }
    '''
    softwareConfig = {
                        'AgentVersion':AgentVersion
                    }
    try:
        (status, output) = commands.getstatusoutput(shell_HardwareName)
        if output != '' and output != None:
            hardwareConfig['HardwareName'] = output
        (status, output) = commands.getstatusoutput(shell_AgentVersion)
        if output != '' and output != None:
            softwareConfig['AgentVersion'] = output
    except Exception as ept:
        pass
    return (hardwareConfig,softwareConfig)


if __name__ == '__main__':
    print getConfig()
