#!/usr/bin/python
# -*- coding: UTF-8 -*-
import os
import sys
import time
import commands
import re
import xml.etree.ElementTree
'''
v1.4.0 
Added by Chenxi Shi on 2019-12-2 (last modified 2019-12-2)
Add a function that returns if connection is failed because of authentication
# This function launch a subprocess '/usr/sbin/wpa_cli' with param '-i wlan0'
# The result is saved in file /opt/script/WiFi/wpa_error.txt
# Results: 'not scanned' | 'psk err' | 'other' | 'success' | '/usr/sbin/wpa_cli boot error'
'''
import subprocess
import pty
import select

Src_AnyLink_xml = "/opt/sdmwebs/web/conf/AnyLink.xml"
                   
VERSION = '1.4.0'

ssid_conf_list = []
scan_ap_info_list = []
bssid_dir = {}
frequency_select = '0'
wifi_dhcp_conf = {"DHCP":"YES",
                'static_ip':'192.168.100.127',
                "static_netmask":"255.255.255.0",
                "static_gateway":"192.168.100.1",
                "static_DNS_list":["8.8.8.8","208.67.222.222"]
                }
g_hidden_ssid = None
class WpaCli:
    def __init__(self):
        self.master_fd, self.slave_fd = pty.openpty()
        self.last_error = -999
        try:
            self.proc = subprocess.Popen(['/usr/sbin/wpa_cli', '-i', 'wlan0'],
            stdin=subprocess.PIPE, stdout=self.slave_fd, stderr=None, close_fds=True)
        except Exception as e:
            logger.error(str(e), exc_info=True)
            self.last_error = -99
            logger.error("wpa_cli boot error")
            #with open('/opt/script/WiFi/wpa_error.txt', 'w') as f:
            #    f.write('/usr/sbin/wpa_cli boot error')
            #    f.flush()

    def get_error_message(self):
        buf = ''
        while 1:  # read until 'end'
            ready, _, _ = select.select([self.master_fd], [], [], 0.1)
            if ready:
                temp = os.read(self.master_fd, 512)
                if not temp or len(temp) == 0:
                    break
                buf += temp
            else:
                break
        if '4-Way Handshake failed' in buf:  # psk error
            self.last_error = -1
            return -1
        else:
            self.last_error = 0
            return 0  # don't care status below
        # if 'CTRL-EVENT-CONNECTED' in buf: # connect success
        # return 0
        # if 'CTRL-EVENT-SCAN-RESULTS' in buf: # no devices nearby
        # return 1

    def save_error_to_file(self):
        logger.error('psk err' if self.last_error == -1 else 'other')
        #with open('/opt/script/WiFi/wpa_error.txt', 'w') as f:
        #    f.write('psk err' if self.last_error == -1 else 'other')
        #    f.flush()

    def destroy(self):
        global logger
        try:
            self.proc.stdin.write('quit\n')
        except Exception as e:
            logger.error('except when /usr/sbin/wpa_cli terminated: ' + str(e))
        finally:
            try:
                self.proc.terminate()
                self.proc.poll()
            except Exception as e:
                logger.error('except when /usr/sbin/wpa_cli terminated: ' + str(e))

class StaticIP_Model:
    def __init__(self,interface):
        self.__interface = interface
    
    def set_params(self,ip,netmask,gateway,dns):
        self.__ip = ip
        self.__netmask = netmask
        self.__gateway = gateway
        self.__dnsList = dns

    @property
    def ip(self):
        return self.__ip

    @property
    def netmask(self):
        return self.__netmask

    @property
    def gateway(self):
        return self.__gateway

    @property
    def dns(self):
        return self.__dns
        
    def run(self):
        try:
            logger.info('start config static_ip')
            os.system('/sbin/ifconfig %s %s netmask %s' % (self.__interface,self.__ip,self.__netmask)) #set ip+netmask
            os.system('/sbin/route add default gw %s dev %s' % (self.__gateway,self.__interface)) #set gateway
            os.system('echo -n > /etc/resolv.conf') #set dns
            for dns in self.__dnsList:
                os.system('echo nameserver %s >> /etc/resolv.conf' % (dns))
        except Exception, e:
            return -1

    def display(self):
        logger.info('obtain ip model=staticIP,ip:%s,netmask:%s,gateway:%s,dns:%s' % (self.__ip,self.__netmask,self.__gateway,self.__dnsList))


class Dhcp_Model:
    def __init__(self,interface):
        self.__interface = interface
        
    def run(self):
        try:
            logger.info('start dhcp')
            os.system('/sbin/udhcpc -i %s &' % self.__interface)
        except Exception, e:
            return -1
        
    def display(self):
        logger.info('obtain ip model=DHCP')


############################### functions ##############################
def init_logger():
    import logging
    from logging.handlers import RotatingFileHandler
    global logger
    logger = logging.getLogger()
    try:
        Rthandler = RotatingFileHandler('/PageFile/wifi.log', mode='a', maxBytes=32 * 1024, backupCount=5)
        formatter = logging.Formatter('%(asctime)s %(levelname)s----%(message)s')
        Rthandler.setFormatter(formatter)
        logger.addHandler(Rthandler)

        ch = logging.StreamHandler()       
        ch.setFormatter(formatter)                                                                    
        logger.addHandler(ch)   

        logger.setLevel(logging.INFO)
      
        logger.info('FC20 wifi module %s' % VERSION)
    except Exception, e:
        #when mmc card is corrupted(ext4_lookup inode error) switch file to wifi-second.log
        Rthandler = RotatingFileHandler('/PageFile/wifi-sec.log', mode='a', maxBytes=32 * 1024, backupCount=5)
        formatter = logging.Formatter('%(asctime)s %(levelname)s----%(message)s')
        Rthandler.setFormatter(formatter)
        logger.addHandler(Rthandler)
        logger.setLevel(logging.INFO)
        logger.info('FC20 wifi module %s' % VERSION)
    return 0


def running_wpa():
    import psutil
    while True:
        process_name = []
        process_list = psutil.pids()
        try:
            for pid in process_list:
                process = psutil.Process(pid)
                process_name.append(process.name())
            break
        except Exception, e:
            time.sleep(5)
            continue
    if 'wpa_supplicant' in process_name:
        return 0
    else:
        return -1


def killall(app_name):
    (status, process_list) = commands.getstatusoutput('ps | grep {0} | grep -v grep'.format(app_name))
    if process_list == "" or process_list == None:
        return False
    process_list = process_list.split('\n')
    for P in process_list:
        items = P.split(' ')
        if len(items)>1 and (app_name in P):
            cmd = 'kill -9 {0}'.format(items[0])
            print '[killall]'+cmd
            os.system(cmd)
    return True 


def start_wpa_supplicant():
    killall("wpa_supplicant")
    if running_wpa() != 0:
        logger.info('start wpa_supplicant ...')
        # 如果是FC20 不支持-Dwext
        #os.system('/usr/sbin/wpa_supplicant -Dwext -B -iwlan0 -c/opt/script/WiFi/wpa_supplicant.conf')
        os.system('/usr/sbin/wpa_supplicant -B -iwlan0 -c/opt/script/WiFi/wpa_supplicant.conf')
    else:
        logger.info('wpa_supplicant reload configure...')
        (status, res) = commands.getstatusoutput('/usr/sbin/wpa_cli -i wlan0 reconfigure')
        if res != 'OK':
            logger.error("wpa_supplicant reload configure fail:%s" % res)
            return -1
        time.sleep(5)

#ethernet,WiFi WAN 有不同的配置文件 
def __get_anylink_conf():
    global wifi_dhcp_conf,frequency_select
    #frequency_select
    #"0:nothing to do/1:2.4G preferred/2:5G preferred/3:2.4G only/4:5Gonly"
    try:

        frequency_select = '0'
        dhcp = True
        with open(Src_AnyLink_xml,'r') as fd:
            data = fd.read()
        root = xml.etree.ElementTree.fromstring(data)
        wifi = root.find('Wifi')
        if wifi != None and len(wifi.findall('W_FREQUENCY_SELECT')) !=0:
            frequency_select = wifi.find('W_FREQUENCY_SELECT').text
        W_DHCP_root = wifi.find('W_DHCP')
        if W_DHCP_root == None:
            wifi_dhcp_conf['DHCP']=True
        else:
            wifi_dhcp_conf['DHCP'] = W_DHCP_root.text == 'YES'
        
        if not wifi_dhcp_conf['DHCP']:
            if len(wifi.findall('W_StaticIP_IP')) ==0 or len(wifi.findall('W_StaticIP_NETMASK')) ==0 or len(wifi.findall('W_StaticIP_GATEWAY')) ==0 or len(wifi.findall('./W_StaticIP_DNS/W_StaticIP_DNS_Address')) ==0:
                logger.info('static ip param is not complete')
                wifi_dhcp_conf['DHCP']=True
            else:
                wifi_dhcp_conf['static_ip'] = wifi.find('W_StaticIP_IP').text
                wifi_dhcp_conf['static_netmask'] = wifi.find('W_StaticIP_NETMASK').text
                wifi_dhcp_conf['static_gateway'] = wifi.find('W_StaticIP_GATEWAY').text
                wifi_dhcp_conf['static_DNS_list'] = [dns.text for dns in wifi.findall('./W_StaticIP_DNS/W_StaticIP_DNS_Address')]
        
    except Exception, e:
        logger.error('func __get_anylink_conf:%s' % str(e))
        wifi_dhcp_conf['DHCP']=True

    return wifi_dhcp_conf

def wlan_dhcp_cfg():
    try:
        dhcp_cfg = __get_anylink_conf()
        tree = xml.etree.ElementTree.parse(Src_AnyLink_xml)
        root = tree.getroot()
    except Exception as ept:   
        logger.error('Get NetworkInfo fail in AnyLink.xml, error msg: %s' % repr(ept))     
        pass
    try:
        #node_name = root.find('NetworkInfo/WAN')
        ip_addr = dhcp_cfg['static_ip']
        ip_mask = dhcp_cfg['static_netmask']
        gate_way = dhcp_cfg['static_gateway']
        dns_list = dhcp_cfg['static_DNS_list']
        dhcp = dhcp_cfg['DHCP']
    except Exception as ept:
        logger.error('Get NetworkInfo fail in AnyLink.xml, error msg: %s' % repr(ept))
        return -1
    '''
        if None in [eth0_ip_addr, eth0_ip_mask, eth0_gate_way, eth0_dns, eth0_dhcp]:
            logger.error('Get NetworkInfo fail in AnyLink.xml, there is None information')
            return -1
    '''
    #logger.info("IP:%s" % ip_addr)
    #logger.info("Mask:%s" % ip_mask)
    #logger.info("Gateway:%s" % gate_way)
    #logger.info("DNS:%s" % dns_list)
    #logger.info("DHCP:%s" % dhcp)
    if dhcp == True :
        os.system("udhcpc -i wlan0 -s /etc/udhcpc.d/50default &")
    else:
        os.system("/sbin/ifconfig wlan0 {0} netmask {1}".format(ip_addr, ip_mask))
        (status, output) = commands.getstatusoutput("/sbin/route | grep default | awk '{ print $2}'")    
        if output != '':
            os.system("/sbin/route del default gw {0} ".format(output))
        os.system("/sbin/route add default gw {0} dev wlan0 metric 10".format(gate_way))
        flush_dns_cmd=""
        for dns in dns_list:
            flush_dns_cmd += "grep \"{0}\" /etc/resolv.conf || echo \"nameserver {0}\" >> /etc/resolv.conf \n". \
                    format(dns)
        #os.system('echo nameserver %s >> /etc/resolv.conf' % (dns))

        
        with open("/opt/script/flush_dns.sh", "w+") as fd:
            fd.write(flush_dns_cmd)
            os.system(flush_dns_cmd)
            os.system("sync")

##conect use bssid
def set_bssid_and_connect():
    global ssid_conf_list
    global bssid_dir
    try:
        network_id = 0
        for ssid in ssid_conf_list:
#set bssid
            for bssid in bssid_dir[ssid]:
                connect_status = False
                os.system('/bin/killall udhcpc;/usr/bin/killall udhcpc')
                (status, res) = commands.getstatusoutput('/usr/sbin/wpa_cli -i wlan0 set_network %d ssid "''"' % (network_id))
                if res != 'OK':
                    logger.error("connect essid fail:%s" % res)
                    return -1
                (status, res) = commands.getstatusoutput('/usr/sbin/wpa_cli -i wlan0 bssid %d %s' % (network_id,bssid))
                if res != 'OK':
                    logger.error("set bssid fail:%s" % res)
                    return -1
#connect
                logger.info("try to connect ssid :%s, bssid:%s" % (ssid,bssid))
                (status, res) = commands.getstatusoutput('/usr/sbin/wpa_cli -i wlan0 select_network %d ' % (network_id))
                if 'OK' != res:
                    logger.error("select network fail:%s" % res)
                    return -1

                #(status, res) = commands.getstatusoutput('/usr/sbin/wpa_cli -i wlan0 reassociate')
                #if 'OK' != res:
                #    logger.error("reassociate ap fail:%s" % res)
                #    return -1

                (status, res) = commands.getstatusoutput('/usr/sbin/wpa_cli -i wlan0 disable_network %d && /usr/sbin/wpa_cli -i wlan0 enable_network %d' % (network_id,network_id))
                if 'OK\nOK' != res:
                    logger.error("restart network fail:%s" % res)
                    return -1
#check connect results
                cli = WpaCli()  # added by chenxi shi
                for i in xrange(10):
                    with open('/sys/class/net/wlan0/operstate', 'r') as fd:
                        operstate = fd.read()
                    if not 'up' in operstate:
                        if -1 == cli.get_error_message():  # wifi password error # added by chenxi shi
                            logger.info('authentication failed: password error')
                            cli.save_error_to_file()
                            break
                        else:
                            cli.save_error_to_file()
                        time.sleep(2)
                        continue
                    else:
                        logger.info('authentication success')
                        with open('/opt/script/WiFi/wpa_error.txt', 'w') as f:
                            f.write('success')  # add by chenxi shi
                            f.flush()
                            connect_status = True
                        #os.system('/sbin/udhcpc -i wlan0 &')
                        wlan_dhcp_cfg()
                        os.system('/usr/sbin/wpa_cli -i wlan0 status')
                        time.sleep(90)
                        break
                cli.destroy()  # added by chenxi shi
                if(connect_status != True):
                    logger.info('connect AP failed')
                    continue
#check netstate
                with open('/tmp/netstat', 'r') as fd:
                    netstat = fd.read()
                if '1' in netstat:
                    logger.info('check net_state is connected')
                    return True
                else:
                    logger.info('connect AP success ,check net_state not connected')
            network_id = network_id + 1
    except Exception, e:
        logger.info('set_bssid_and_connect,ex:%s' % repr(e))
        return -1


class ap_info:
    def __init__(self,essid,bssid,siglevel,frequency,channel='0'):
        self.essid = essid
        self.bssid = bssid
        self.siglevel = siglevel
        self.frequency = float(frequency)/1000000000
        self.channel = int(channel)

    def get_essid(self):
        return self.essid

    def get_bssid(self):
        return self.bssid

    def get_siglevel(self):
        return self.siglevel

    def get_frequency(self):
        if( int(self.channel) > 16 ):
            return 5
        else:
            return 2
        #return self.frequency

    def display(self):
        logger.info('ap_info ssid :%s,  bssid:%s,  Signallevel:%s,  frequency:%f GHZ,   channel=%d' % (self.essid,self.bssid,self.siglevel,self.frequency,self.channel))


##list order by signal strength
def get_bssid_dir():
    global ssid_conf_list
    global scan_ap_info_list
    global bssid_dir
    global frequency_select
    try:
        bssid_dir = {}
        bssid_dir = bssid_dir.fromkeys(ssid_conf_list)
        for ssid in ssid_conf_list:
            bssid_list = []
            siglevel_dir = {}
            siglevel_dir_2G = {}
            siglevel_dir_5G = {}
            logger.info('matching for ssid:%s' % ssid)
#2G preferred/5G preferred
            if frequency_select == '1' or frequency_select == '2':
                #get {bssid:strength} dir
                for ap_info in scan_ap_info_list:
                    if ssid == ap_info.get_essid():
                        ap_info.display()
                        if int(ap_info.get_frequency()) == 2:
                            siglevel_dir_2G.update({ap_info.get_bssid():int(ap_info.get_siglevel())})
                        elif int(ap_info.get_frequency()) == 5:
                            siglevel_dir_5G.update({ap_info.get_bssid():int(ap_info.get_siglevel())})
                #be sorted
                results_2G = sorted(siglevel_dir_2G.items(), key=lambda x:x[1], reverse=True)
                results_5G = sorted(siglevel_dir_5G.items(), key=lambda x:x[1], reverse=True)
                if frequency_select == '1':
                    logger.info('frequency_select is 2.4G preferred,2.4G bssid list:%s,5G bssid_list:%s' % (results_2G,results_5G))
                    bssid_list = [res[0] for res in results_2G] + [res[0] for res in results_5G]
                elif frequency_select == '2':
                    logger.info('frequency_select is 5G preferred,5G bssid_list:%s,2.4G bssid list:%s' % (results_5G,results_2G))
                    bssid_list = [res[0] for res in results_5G] + [res[0] for res in results_2G]

#nothing to do/2.4G only/5G only
            else:
                #get {bssid:strength} dir
                for ap_info in scan_ap_info_list:
                    if ssid == ap_info.get_essid():
                        ap_info.display()
                        if frequency_select == '3' and int(ap_info.get_frequency()) == 5:
                            logger.info("frequency_select is 2.4G only,this info is abandoned")
                            continue
                        elif frequency_select == '4' and int(ap_info.get_frequency()) == 2:
                            logger.info("frequency_select is 5G only,this info is abandoned")
                            continue
                        siglevel_dir.update({ap_info.get_bssid():int(ap_info.get_siglevel())})
                #be sorted
                results = sorted(siglevel_dir.items(), key=lambda x:x[1], reverse=True)
                bssid_list = [res[0] for res in results]
            bssid_dir[ssid] = bssid_list

        logger.info('get scan bssid_list according conf ssid_list:%s' % bssid_dir)
    except Exception, e:
        return -1

def get_frequency_select_xml():
    global frequency_select
    try:
        tree = xml.etree.ElementTree.parse(Src_AnyLink_xml)
        root = tree.getroot()
        frequency_select = root.find('Wifi/W_FREQUENCY_SELECT').text
    except Exception as ept:   
        logger.error('Get Wifi/W_FREQUENCY_SELECT fail in AnyLink.xml, error msg: %s' % repr(ept))     
        return -1
    

def get_frequency_select_conf():
    global frequency_select
#frequency_select
#"0:nothing to do/    1:2.4G preferred/     2:5G preferred/    3:2.4G only/    4:5G only"
    try:
        with open('/opt/script/WiFi/frequency_select.conf', 'r') as fd:
            frequency_select = fd.read()
    except Exception, e:
        logger.error('Get frequency_select fail from frequency_select.conf' )     
        return -1

def get_ssid_conf():
    global ssid_conf_list,g_hidden_ssid
    try:
        while(True):
            ssid_conf_list = []
            with open('/opt/script/WiFi/wpa_supplicant.conf', 'r') as fd:
                for line in fd.readlines():
                    if 'ssid="' in line:
                        ssid = line[line.index('ssid="') + 6:]
                        ssid = ssid[:ssid.index('"')]
                        ssid_conf_list.append(ssid)
                        logger.info('get conf ssid %s' % ssid)
                        #os.system('iwlist wlan0 scanning essid "%s"' % ssid) #find hide ssid
                        g_hidden_ssid = ssid
                if(len(ssid_conf_list)!=0):
                    return ssid_conf_list
    except Exception, e:
        return -1


def getwifilist(WifiIf="wlan0"):
    ''' write wifi info to a json file'''

    cmd = 'iwlist ' + WifiIf + ' scanning > /tmp/wifi-scan.list'
    if g_hidden_ssid != None:
        cmd = 'iwlist ' + WifiIf + (' scanning essid "%s" > /tmp/wifi-scan.list' % g_hidden_ssid)
        logger.info("run cmd=%s" % cmd)
    os.system(cmd)

    l = []
    with open('/tmp/wifi-scan.list', 'r') as f:
        l = f.readlines()
    l = parse_wifi_info(l)

    
    return l

def parse_wifi_info(_list):
    
    li = list()
    d = dict()
    ssids = dict()
    try:
        for l in _list:
            data = l.strip()
            #print "data=%s" % data
            if data.startswith('Cell'):
                d = dict()
                bssid = data[data.index(':') + 2:] 
                d['BSSID'] = bssid
            elif data.startswith('ESSID'):
                ssid = data[data.index(':') + 2:-1]
                if ssids.has_key(ssid):
                    continue
                ssids[ssid] = True
                d['SSID'] = ssid
                li.append(d)
            elif data.startswith('Encryption key'):
                buf = data[data.index(':') + 1:]
                d['Encryption key'] = buf
            elif data.startswith('Quality='):
                Signallevel = data[data.index('Quality=') + 8:data.index('/')]
                d['Signallevel'] = Signallevel
            elif data.startswith('Channel:'):
                Channel = data[data.index('Channel:') + 8:]
                d['Channel'] = Channel
    except Exception as e:
        logger.error('parse_wifi_info ex:%s' % repr(e))
        pass
    return li

def get_ssid_scan():
    global scan_ap_info_list
    scan_ap_info_list = []
    logger.info("get_ssid_scan start")
    #print "asfasdfasdfasdfasdf"
    try:
        wlist = getwifilist()
        all_ssid = []
        for ap in wlist:
            all_ssid.append(ap['SSID'])
            
            scan_ap_info_list.append(ap_info(ap['SSID'],ap['BSSID'],ap['Signallevel'],0.0,ap['Channel']))
            logger.info('get scan ap_info2 :%s,  bssid:%s,  Signallevel:%s, Channel=%s' % (ap['SSID'],ap['BSSID'],ap['Signallevel'],ap['Channel']))
            #scan_ap_info_list.append(ap_info(ap.essid,ap.bssid,ap.quality.getSignallevel(),ap.frequency.getFrequency()))
            #logger.info('get scan ap_info :%s,  bssid:%s,  Signallevel:%s,  frequency:%f GHz' % (ap.essid,ap.bssid,ap.quality.getSignallevel(),float(ap.frequency.getFrequency())/1000000000))
        return all_ssid
    except Exception, e:
        logger.error('get_ssid_scan ex:%s' % repr(e))
        return -1
    

def get_ssid_scan_ori():
    
    from pythonwifi.iwlibs import Wireless, Iwrange, getNICnames
    global scan_ap_info_list
    scan_ap_info_list = []
    wifi = Wireless('wlan0')
    all_ssid = []
    try:
        iwrange = Iwrange(wifi.ifname)
    except IOError, (error_number, error_string):
        return -1
    try:
        results = wifi.scan()
    except IOError, (error_number, error_string):
        return -1
    if (len(results) == 0):
        return -1
    try:
        (num_channels, frequencies) = wifi.getChannelInfo()
        for ap in results:
            all_ssid.append(ap.essid)
            scan_ap_info_list.append(ap_info(ap.essid,ap.bssid,ap.quality.getSignallevel(),ap.frequency.getFrequency()))
            logger.info('get scan ap_info :%s,  bssid:%s,  Signallevel:%s,  frequency:%f GHz' % (ap.essid,ap.bssid,ap.quality.getSignallevel(),float(ap.frequency.getFrequency())/1000000000))
        return all_ssid
    except Exception, e:
        return -1


def get_link_info(ifname):
    import socket, fcntl, struct
    from pythonwifi.iwlibs import Wireless
    try:
        wifi = Wireless('wlan0')
        logger.info('ssid is %s,bssid is %s, @ %s' % (wifi.getEssid(),wifi.getAPaddr(), wifi.getFrequency()))
    except Exception, e:
        return -1
    try:
        with open('/proc/net/wireless', 'r') as fd:
            for line in fd.readlines():
                if 'wlan0:' in line:
                    level = line.split()[3]
                    logger.info('signal level is %s' % level)
    except Exception, e:
        return -1
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        ifaddr = fcntl.ioctl(sock.fileno(), 0x8915, struct.pack('256s', ifname[:15]))
        logger.info('lease of %s obtained' % socket.inet_ntoa(ifaddr[20:24]))
    except Exception, e:
        return -1
    return 0

# 停止wifi 关闭驱动和电源
def stop_wifi():
    os.system('/etc/init.d/wlan stop')
    return 0

# 设置访问外网转发
def set_ip_forward():
    os.system('iptables -F')
    os.system('iptables -t nat -F')
    os.system('echo 1 > /proc/sys/net/ipv4/ip_forward')
    os.system('iptables -t nat -A POSTROUTING -o wlan0 -j MASQUERADE')
    return 0

def load_wifi_driver():
    retry = 5
    n = 0
    while n < retry:
        try:
            #time.sleep(2)
            os.system('/etc/init.d/wlan start')
            time.sleep(1)
            (status, output) = commands.getstatusoutput('/sbin/ifconfig -a | grep "wlan0"')    
            if output == '':
                logger.info('load_wifi_driver fail retry times=%d' % n)
            else:
                logger.info('load_wifi_driversuccess')
                return True
            n += 1
        except Exception as ept:
            n += 1
            logger.error('load_wifi_driver fail, error msg: %s' % repr(ept))
            time.sleep(3)
        else:
            return False
    return False

def main():
    import gc
    import commands
    init_logger()
    
    (status, output) = commands.getstatusoutput('/sbin/ifconfig -a | grep "wlan0"')
    if output == '':
        # if wlan0 not exist;load wifi driver
       if load_wifi_driver() == False:
           logger.info('load wifi driver fail! exit')
           return -1
           
    (status, output) = commands.getstatusoutput('/sbin/ifconfig | grep "wlan0"')
    if output == '':
        os.system('/sbin/ifconfig wlan0 up')
        time.sleep(1)
    (status, output) = commands.getstatusoutput('/usr/sbin/iw dev wlan0 set power_save off')
    if status != 0:
        logger.info('set power_save off fail: %s' % output)
    else:
        logger.info('set power_save off')
    time.sleep(1)   #等待网卡稳定
    while True:
        gc.collect()

        ssid_in_range = False
#get user conf
        conf_ssid = get_ssid_conf()
#get ap scan results
        scan_ssid = get_ssid_scan()
        if conf_ssid != -1 and scan_ssid != -1:
            for ssid in conf_ssid:
                if ssid in scan_ssid:
                    ssid_in_range = True
                    break
        else:
            with open('/opt/script/WiFi/wpa_error.txt', 'w') as f:  # save not scanned # added by chenxi shi
                f.write('not scanned')
                f.flush()
            time.sleep(90)
            continue

        if ssid_in_range:
            logger.info('\033[33mreconnect to wireless router...\033[0m')
            start_wpa_supplicant()
            get_frequency_select_conf()
            get_frequency_select_xml()  #从xml中读取频率选择参数 AnyLink.xml => Wifi/W_FREQUENCY_SELECT
            get_bssid_dir()
            res = set_bssid_and_connect()
            if res == True:
                set_ip_forward()
                get_link_info('wlan0')
                time.sleep(90)
                while True:
                    with open('/tmp/netstat', 'r') as fd:
                        netstat = fd.read()
                    if '1' in netstat:
                        time.sleep(90)
                        continue
                    else:
                        logger.info('network is not connected in uaual check')
                        break
            else:
                time.sleep(5)
        else:
            logger.info('ssid is not in scanning range ...') # added by chenxi shi
            with open('/opt/script/WiFi/wpa_error.txt', 'w') as f:  # save not scanned # added by chenxi shi
                f.write('not scanned')
                f.flush()
            time.sleep(90)
    return 0


############################## main block ##############################
if __name__ == '__main__':
    main()
    sys.exit(0)
