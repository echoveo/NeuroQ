#!/usr/bin/python
# -*- coding: UTF-8 -*-
import os
import sys
import commands
import logging
from logging.handlers import RotatingFileHandler
import time
import subprocess
from  hardwareConfig import adc
from  hardwareConfig import net_ethernet
from  hardwareConfig import ttyUSB

import globalConfig
VERSION = "1.0.0"
NAME = "hardware device hardware_checker"
#g_opts = {'type':"uart",'using':"enabled"}
g_globalConfig = None

g_logger = None
LOG_TAG = "hardware_checker"
LOG_ERROR = 9
LOG_INFO = 0

def initial_log(log_name, debug):
    """定义一个RotatingFileHandler，最多备份2个日志文件，每个日志文件最大64K"""
    log = logging.getLogger()
    handler = RotatingFileHandler(log_name, maxBytes=1024 * 8, backupCount=2)
    formatter = logging.Formatter('%(asctime)s-%(levelname)s: %(message)s')
    handler.setFormatter(formatter)
    ch = logging.StreamHandler()
    ch.setFormatter(formatter)
    log.addHandler(handler)
    log.addHandler(ch)

    if debug is not None:
        log.setLevel(debug)
    else:
        log.setLevel(logging.WARNING)
    return log
		
def log(msg,error=LOG_INFO):
    if g_logger != None:
        if error == LOG_ERROR:
            g_logger.error('[%s]%s' % (LOG_TAG,msg) )
        else:
            g_logger.info('[%s]%s'% ( LOG_TAG,msg) )

#配置adc模块 globalConfig用于得到硬件类型
def init(globalConfig = None,logger=None):
    global g_globalConfig,g_logger
    g_globalConfig = globalConfig
    g_logger = logger
    ret = True
    adc.init(globalConfig,logger)
    net_ethernet.init(globalConfig,logger)
    ttyUSB.init(globalConfig,logger)
    return ret

#autodetect 模块 probe
#ADC 通过usb to serial连接无法被复位
def autodetect(opts):
    if g_globalConfig == None:
        return (False,{"msg":"出错"}); 
    
    return (True,{"msg":"successful"})

#使能或者关闭模块
def enable(enabled):
    ret = True
    return ret

#复位设备
def reset():
    ret = True
    return ret

#健康检查 运行时的健康检查，只在运行时调用
def check():

    #log('check enter.')
    if g_globalConfig == None :
        return True
    (hardwareConfig,softwareConfig) = g_globalConfig
    ret_check = True
    
    for check_module_name in hardwareConfig['health_check_list']:
        if check_module_name == 'ETHERNET':
            ret_check = net_ethernet.check()
        if check_module_name == 'ADC':
            ret_check = adc.check()
        if check_module_name == 'ttyUSB':
            ret_check = ttyUSB.check()
        if ret_check == False:
            return ret_check

    return ret_check

#出厂测试用
'''
return: {ret:True|False,msg:""}
'''
def factory_test():
    ret = True
    return ret

#获取硬件设备信息
def info():
    return {'VERSION':VERSION,'NAME':NAME}


if __name__ == '__main__':
    logLevel = logging.DEBUG
    loop_times = 99999999
    if len(sys.argv) > 1:
        level = int(sys.argv[1])
        if level == 100:
            logLevel = logging.ERROR
        elif level == 200:
            logLevel = logging.WARN
        elif level == 300:
            logLevel = logging.INFO
        else:
            logLevel = logging.DEBUG
    (hardwareConfig,softwareConfig) = globalConfig.getConfig()
    logger = initial_log('/PageFile/hardware_checker.log', logLevel)
    if hardwareConfig == None:
        log("hardwareConfig is None")
        sys.exit(1)
    
    

    if hardwareConfig['HardwareName'] != 'NeuroQ-300':
        print( "HardwareName = %s run ttyUSB check" % (hardwareConfig['HardwareName']))
        ttyUSB.init(globalConfig.getConfig(),logger)
        ttyUSB.check()
        sys.exit(1)

    
    init(globalConfig.getConfig(),logger)
    
    while loop_times > 0:
        try:
            #log('hardware check begin loops=%d' % (loop_times))
            ret_check = check()
            if ret_check == False:
                log('hardware check return False .halt and reboot system!')
                os.system("reboot");
            
            time.sleep(20)
            loop_times = loop_times-1
        except Exception as ept:
            loop_times = loop_times-1
            log('hardware exception, error msg: %s' % repr(ept))
            time.sleep(20)

    sys.exit(0)
