#!/usr/bin/python
# -*- coding: UTF-8 -*-
import os
import sys
import commands
import subprocess
import time

'''专用'''
g_LAN_name=None
g_WAN_name=None
filename_dialogue = "/tmp/net_ethernet.check"
'''专用'''

VERSION = "1.0.0"
NAME = "adc"

#g_opts = {'type':"uart",'using':"enabled"}
g_globalConfig = None

g_logger = None
LOG_TAG = "net_ethernet"
LOG_ERROR = 9
LOG_INFO = 0
def log(msg,error=LOG_INFO):
    if g_logger != None:
        if error == LOG_ERROR:
            g_logger.error('[%s]%s' % (LOG_TAG,msg) )
        else:
            g_logger.info('[%s]%s'% ( LOG_TAG,msg) )

#配置adc模块 globalConfig用于得到硬件类型
def init(globalConfig = None,logger=None):
    global g_globalConfig,g_logger
    g_globalConfig = globalConfig
    g_logger = logger
    ret = True
    #log("init enter")
    if g_globalConfig == None:
        log("init fail exit: g_globalConfig is None")
        return False
    
    (hardwareConfig,softwareConfig) = g_globalConfig

    if not 'ETHERNET' in hardwareConfig:
        log("init fail exit: ETHERNET is None")
        return False

    opts_ETHERNET = hardwareConfig['ETHERNET']
    if opts_ETHERNET['type'] != 'SR9900':
        log("init fail exit: type != SR9900")
        return False

    #配置gpio 模式
    (status, gpio11_direction) = commands.getstatusoutput('cat /sys/class/gpio/gpio11/direction')
    if gpio11_direction != 'out':
        log('init gpio11 output mode')
        os.system("echo 11 > /sys/class/gpio/export;echo out > /sys/class/gpio/gpio11/direction")
    #log("init exit. ret=%d" % (ret))
    return ret

#autodetect 模块 probe
def autodetect(opts=None):
    ret = True
    global g_LAN_name,g_WAN_name
    ret = True
    g_LAN_name = 'eth0'
    g_WAN_name = 'eth1'

    for i in range(6):
        eth_name = "eth%d"%(i)
        #/sys/bus/usb/devices/1-1.3.3:2.0/net/  LAN
        #/sys/bus/usb/devices/1-1.1:2.0/net/ 测试代码中的LAN
        (status, g_LAN_name) = commands.getstatusoutput("test -e /sys/bus/usb/devices/1-1.3.3:2.0/net/%s/address && echo '%s'"%(eth_name,eth_name))            
        if g_LAN_name == eth_name:
            break
    for i in range(6):
        eth_name = "eth%d"%(i)
        #/sys/bus/usb/devices/1-1.2:2.0/net   WAN
        #/sys/bus/usb/devices/1-1.2:2.0/net   测试代码中的WAN
        (status, g_WAN_name) = commands.getstatusoutput("test -e /sys/bus/usb/devices/1-1.2:2.0/net/%s/address && echo '%s'"%(eth_name,eth_name))            
        if g_WAN_name == eth_name:
            break
           
    
    log("LAN=%s;WAN=%s" % (g_LAN_name,g_WAN_name) ) 
    if g_LAN_name == None or g_LAN_name == "":
        ret = False
        log('queryLAN_WAN_index fail, LAN invalid',LOG_ERROR)
        
    if g_WAN_name == None or g_WAN_name == "":
        ret = False
        log('queryLAN_WAN_index fail, WAN invalid',LOG_ERROR)

    if g_LAN_name != None and g_LAN_name == g_WAN_name:
        ret = False    
        log('queryLAN_WAN_index fail, WAN == LAN ',LOG_ERROR)
    
    if ret:
        #将usb id号保存起来，以方便dialogue进行查询 
        os.system("lsusb | grep '0fe6:9900' | awk -F '[:| ]' '{print($3,$4)}' > %s" % (filename_dialogue))

    return (ret,{"LAN":g_LAN_name,"WAN":g_WAN_name})
#使能或者关闭模块
def enable(enabled):
    ret = True
    if enabled:
        ret = reset()
    else:
        os.system("echo 0 > /sys/class/gpio/gpio11/value")
    return ret

#复位设备
def reset():
    ret = True
    retry = 9
    n = 0
    num_ar9900 = 0  #usb网卡个数
    #打开gpio11 使能usb网卡电源 
    #os.system("[[ -d /sys/class/gpio/gpio11 ]] && echo 'gpio11 OK' || echo 11 > /sys/class/gpio/export;echo out > /sys/class/gpio/gpio11/direction;echo 1 > /sys/class/gpio/gpio11/value " )
    #reset sr9900
    #os.system(" echo 11 > /sys/class/gpio/export;echo out > /sys/class/gpio/gpio11/direction;echo 0 > /sys/class/gpio/gpio11/value;sleep 0.2;echo 1 > /sys/class/gpio/gpio11/value " )
    #time.sleep(1.5)
    log('reset enter')
    while n < retry:
        try:            
            #检查两个usb网卡是否存在
            (status, output) = commands.getstatusoutput('lsusb | grep 9900 | wc -l')            
            if output != '':
                num_ar9900 = int(output)
                log('startEth0Loop number of ar9900 = %d'%(num_ar9900))
               
            if num_ar9900 >= 2:
                log('startEth0Loop ar9900 load it begin')
                os.system("test `lsmod | grep usbnet | wc -l` -ne 1 && insmod /lib/modules/3.18.20/kernel/drivers/net/usb/usbnet.ko" )
                os.system("test `lsmod | grep 'cdc_ether' | wc -l` -ne 2 && insmod /lib/modules/3.18.20/kernel/drivers/net/usb/cdc_ether.ko" )
                log('startEth0Loop ar9900 load it end')
                break
            if num_ar9900 <= 1:
                os.system("echo 0 > /sys/class/gpio/gpio11/value;sleep 0.5;echo 1 > /sys/class/gpio/gpio11/value") #reset device
                time.sleep(1.5)
            n += 1
            time.sleep(0.2)
        except Exception as ept:
            n += 1
            log('startEth0Loop fail, error msg: %s' % repr(ept),LOG_ERROR)
            time.sleep(1)
    if num_ar9900 >= 2:
        (ret,ret_info) = autodetect()
    else:
        ret = false
    if ret == True:        
        os.system("ifconfig %s up" % (g_LAN_name))
        os.system("ifconfig %s up" % (g_WAN_name))
        

    log('reset exit.')

    return ret


#健康检查 运行时的健康检查，只在运行时调用
def check():
    ret = True
    #log('check enter.')
    (status, output) = commands.getstatusoutput("test -e %s && echo 'file exist'" % ( filename_dialogue ) )       
    if output == '' or output == None:
        #log('%s not exist.' % (filename_dialogue))
        (ret,ret_info) = autodetect()    #生成filename_dialogue
        if not ret:
            log('check fail!.autodetect() return false.')
            return false

    (status, output_new) = commands.getstatusoutput("lsusb | grep '0fe6:9900' | awk -F '[:| ]' '{print($3,$4)}'" )       
    (status, output_old) = commands.getstatusoutput("cat %s" % (filename_dialogue) )
    if output_new != output_old:     
        log('previous usbid =%s' %(output_old))
        log('new usbid =%s' %(output_new))
        log('check test fail!')
        return False  
    #log('check exit.ret=%d'%(ret))
    return ret

#出厂测试用
'''
return: {ret:True|False,msg:""}
'''
def factory_test():
    ret = True
    return ret

#获取硬件设备信息
def info():
    return {'VERSION':VERSION,'NAME':NAME,'LAN':g_LAN_name,'WAN':g_WAN_name}


if __name__ == '__main__':
    reset()
    print dialogue()
    sys.exit(0)