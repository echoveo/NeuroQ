#!/usr/bin/python
# -*- coding: UTF-8 -*-
import os
import sys
import commands
import subprocess

VERSION = "1.0.0"
NAME = "canbus"
filename_dialogue = "/tmp/canbus.check"
#g_opts = {'type':"uart",'using':"enabled"}
g_globalConfig = None
g_logger = None
LOG_TAG = "canbus"
LOG_ERROR = 9
LOG_INFO = 0
def log(msg,error=LOG_INFO):
    if g_logger != None:
        if error == LOG_ERROR:
            g_logger.error('[%s]%s' % (LOG_TAG,msg) )
        else:
            g_logger.info('[%s]%s'% ( LOG_TAG,msg) )

#配置adc模块 globalConfig用于得到硬件类型
def init(globalConfig = None,logger=None):
    global g_globalConfig,g_logger
    g_globalConfig = globalConfig
    g_logger = logger
    ret = True
    
    return ret

#autodetect 模块 probe
#ADC 通过usb to serial连接无法被复位
def autodetect(opts):
    
    ret = True
    
    return (ret,{"msg":"success"})

#使能或者关闭模块
def enable(enabled):
    ret = True
    return ret

#复位设备
def reset():
    ret = True
    return ret

#健康检查 运行时的健康检查，只在运行时调用
def check():
    ret = True
    log('check enter.')
  
    log('check exit.')
    return ret

#出厂测试用
'''
return: {ret:True|False,msg:""}
'''
def factory_test():
    ret = True
    return ret

#获取硬件设备信息
def info():
    return {'VERSION':VERSION,'NAME':NAME}


