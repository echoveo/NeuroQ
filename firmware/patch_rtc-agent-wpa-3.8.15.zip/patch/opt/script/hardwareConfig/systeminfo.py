#!/usr/bin/python
# -*- coding: UTF-8 -*-
import os
import sys
import commands
import subprocess
import xml.etree.ElementTree as ET
import time

VERSION = "1.0.0"
NAME = "systeminfo"
filename_dialogue = "/tmp/systeminfo.check"
#g_opts = {'type':"uart",'using':"enabled"}
g_globalConfig = None
g_logger = None
LOG_TAG = "systeminfo"
LOG_ERROR = 9
LOG_INFO = 0
def log(msg,error=LOG_INFO):
    if g_logger != None:
        if error == LOG_ERROR:
            g_logger.error('[%s]%s' % (LOG_TAG,msg) )
        else:
            g_logger.info('[%s]%s'% ( LOG_TAG,msg) )

def checkXMLFile(path_xml,check_node=None):
    
    try_times=2
    while try_times>0:
        try:
            ET_xml = ET.parse(path_xml)
            if check_node!=None :
                c_node = ET_xml.find(check_node)
                if  c_node != None:
                    return True
            else:               
                return True
        except Exception as ept:
            pass
        try_times = try_times-1
        time.sleep(0.3)
    return False

#配置adc模块 globalConfig用于得到硬件类型
def init(globalConfig = None,logger=None):
    global g_globalConfig,g_logger
    g_globalConfig = globalConfig
    g_logger = logger
    ret = True

    return ret

#autodetect 模块 probe
#ADC 通过usb to serial连接无法被复位
def autodetect(opts=None):
    ret = True

    sys_info={}
    (status, output) = commands.getstatusoutput("date -u;uptime")
    sys_info["uptime"] = output
    (status, output) = commands.getstatusoutput("ls /dev/ttyUSB*")
    sys_info["ttyUSB"] = output
    (status, output) = commands.getstatusoutput("lsusb")
    sys_info["lsusb"] = output

    #temperature
    (status, output_t0) = commands.getstatusoutput("cat /sys/devices/virtual/thermal/thermal_zone0/temp")
    (status, output_t1) = commands.getstatusoutput("cat /sys/devices/virtual/thermal/thermal_zone1/temp")
    (status, output_t4) = commands.getstatusoutput("cat /sys/devices/virtual/thermal/thermal_zone4/temp")
    (status, output_t6) = commands.getstatusoutput("cat /sys/devices/virtual/thermal/thermal_zone6/temp")
    sys_info["temperature"] = "t0:%s,t1:%s,t4:%s,t6:%s" % (output_t0,output_t1,output_t4,output_t6)

    #checknet
    (status, output) = commands.getstatusoutput("route | grep 'default' | awk '{print $2}'")
    if output != None:
        (status, output) = commands.getstatusoutput("ping -c 2 %s" % (output))
        sys_info["ping_gateway"] = output
    else:
        sys_info["ping_gateway"] = "ping gateway fail! gateway is empty"

    
    #check AnyLink.xml
    ret = checkXMLFile('/opt/sdmwebs/web/conf/AnyLink.xml','BasicInfo')
    if ret:
        sys_info["AnyLink_XML"] = "pass"
    else:
        sys_info["AnyLink_XML"] = "check error!!"
    
    #check Config.xml
    ret = checkXMLFile('/opt/agent/ModuleConfig.xml','model')
    if ret:
        sys_info["ModuleConfig_XML"] = "pass"
    else:
        sys_info["ModuleConfig_XML"] = "check error!!"


    (status, output) = commands.getstatusoutput("ping 8.8.8.8 -c 2")
    sys_info["ping"] = output
    (status, output) = commands.getstatusoutput("ifconfig")
    sys_info["ifconfig"] = output
    (status, output) = commands.getstatusoutput("route")
    sys_info["route"] = output
    (status, output) = commands.getstatusoutput("netstat -lnp")
    sys_info["netstat"] = output
    (status, output) = commands.getstatusoutput("arp")
    sys_info["arp"] = output

    (status, output) = commands.getstatusoutput("df -h | grep -v 'tmpfs'")
    sys_info["df"] = output
    (status, output) = commands.getstatusoutput("free -h")
    sys_info["free"] = output
    (status, output) = commands.getstatusoutput("ps")
    sys_info["ps"] = output
    (status, output) = commands.getstatusoutput("top -n 1")
    sys_info["top"] = output
        
    (status, output) = commands.getstatusoutput("ls /dev/rtc*")
    sys_info["rtc"] = output
    (status, output) = commands.getstatusoutput("lsmod")
    sys_info["lsmod"] = output
    (status, output) = commands.getstatusoutput("cat /etc/factory.mode")
    sys_info["factory_mode"] = output

    (status, output) = commands.getstatusoutput('/opt/script/pppd/ec20_data_call --at_csq')
    sys_info["ec20_4G"] = output
    
    
    return (ret,sys_info)

#使能或者关闭模块
def enable(enabled):
    ret = True
    return ret

#复位设备
def reset():
    ret = True
    return ret

#健康检查 运行时的健康检查，只在运行时调用
def check():
    ret = True
    log('check enter.')
  
    log('check exit.')
    return ret

#出厂测试用
'''
return: {ret:True|False,msg:""}
'''
def factory_test():
    ret = True
    return ret

#获取硬件设备信息
def info():
    return {'VERSION':VERSION,'NAME':NAME}


