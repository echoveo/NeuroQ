#!/usr/bin/python
# -*- coding: UTF-8 -*-
import os
import time
import sys
import commands
import subprocess

VERSION = "1.0.0"
NAME = "net_wifi"
filename_dialogue = "/tmp/net_wifi.check"
#g_opts = {'type':"uart",'using':"enabled"}
g_globalConfig = None
g_logger = None
LOG_TAG = "net_wifi"
LOG_ERROR = 9
LOG_INFO = 0
def log(msg,error=LOG_INFO):
    if g_logger != None:
        if error == LOG_ERROR:
            g_logger.error('[%s]%s' % (LOG_TAG,msg) )
        else:
            g_logger.info('[%s]%s'% ( LOG_TAG,msg) )



def load_wifi_driver():
    retry = 5
    n = 0
    while n < retry:
        try:
            #time.sleep(2)

            (status, output) = commands.getstatusoutput('/sbin/ifconfig -a | grep "wlan0"')    
            if output == '':
                log('load_wifi_driver fail retry times=%d' % n)
                os.system('/etc/init.d/wlan start')
                time.sleep(1)
            else:
                log('load_wifi_driversuccess')
                return True
            n += 1
        except Exception as ept:
            n += 1
            log('load_wifi_driver fail, error msg: %s' % repr(ept))
            time.sleep(3)
        else:
            return False
    return False



#配置adc模块 globalConfig用于得到硬件类型
def init(globalConfig = None,logger=None):
    global g_globalConfig,g_logger
    g_globalConfig = globalConfig
    g_logger = logger
    ret = True

    return ret

#autodetect 模块 probe
#ADC 通过usb to serial连接无法被复位
def autodetect(opts=None):
    ret = True
    ret_msg = {}
    ret_load_driver = load_wifi_driver()
    if not ret_load_driver:
        return (False,{"msg":'load wifi driver fail!'})
    
    os.system('/sbin/ifconfig wlan0 up')
    (status,output) = commands.getstatusoutput("test -e /sys/devices/7824900.sdhci/mmc_host/mmc0/mmc0:0001 && echo 'sdio'")
    if output != None:
        ret_msg['dev_type'] = output
    else:
        return (False,{"msg":'load wifi driver fail! sdio device not found!'})
        
    (status, output) = commands.getstatusoutput('iwlist wlan0 scanning | grep ESSID')  
    if output != None:
        ret_msg['scan_list'] = output
    else:
        ret_msg["scan_list"] = "no result!"
    (status, output) = commands.getstatusoutput('wpa_cli status')  
    if output != None:
        ret_msg['wpa_cli'] = output
    else:
        ret_msg["wpa_cli"] = "no result!"
    

    return (ret,ret_msg)

#使能或者关闭模块
def enable(enabled):
    ret = True
    return ret

#复位设备
def reset():
    ret = True
    return ret

#健康检查 运行时的健康检查，只在运行时调用
def check():
    ret = True
    log('check enter.')
  
    log('check exit.')
    return ret

#出厂测试用
'''
return: {ret:True|False,msg:""}
'''
def factory_test():
    ret = True
    return ret

#获取硬件设备信息
def info():
    return {'VERSION':VERSION,'NAME':NAME}


