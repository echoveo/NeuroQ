#! /usr/bin/env python
# -*- coding: utf-8 -*-

import sys
import time
import serial

import binascii
import platform
import threading
import getopt
import traceback

g_port='/dev/ttyUSB0'  
g_baudrate='9600' 
g_bytesize='8' 
g_parity='N'  
g_stopbits='1'
g_hexmode=True
g_crc16=False

def crc16(data, cnt):
    crc_16 = 0xffff
    for i in range(0, cnt):
        crc_16 ^= data[i]
        for j in range(0, 8):
            if 1 == (crc_16 & 0x01):
                crc_16 = (crc_16 >> 1) ^ 0xA001
            else:
                crc_16 = crc_16 >> 1
    return crc_16

if platform.system() == "Windows":
    from  serial.tools import list_ports
else:
    import glob, os, re

class SerialHelper(object):
    def __init__(self, Port="COM6", BaudRate="9600", ByteSize="8", Parity="N", Stopbits="1",crc=False):
        '''
        初始化一些参数
        '''
        self.port = Port
        self.baudrate = BaudRate
        self.bytesize = ByteSize
        self.parity = Parity
        self.stopbits = Stopbits
        self.threshold_value = 1
        self.receive_data = ""
        self.crc = crc
        self._serial = None
        self._is_connected = False

    def connect(self, timeout=2):
        '''
        连接设备
        '''
        self._serial = serial.Serial()
        self._serial.port = self.port
        self._serial.baudrate = self.baudrate
        self._serial.bytesize = int(self.bytesize)
        self._serial.parity = self.parity
        self._serial.stopbits = int(self.stopbits)
        self._serial.timeout = timeout

        try:
            self._serial.open()
            if self._serial.isOpen():
                self._is_connected = True
        except Exception as e:
            self._is_connected = False
        return self._is_connected 

    def disconnect(self):
        '''
        断开连接
        '''
        if self._serial:
            self._serial.close()

    def write(self, data, isHex=False):
        if not self._is_connected:
            return
        '''
        发送数据给串口设备
        '''
        data_tmp = data
        if self._is_connected:
            if isHex:
                data_tmp = binascii.unhexlify(data_tmp)
            if g_crc16 or self.crc:
                bdata = bytearray(data_tmp) 
                crc = crc16(bdata,len(bdata)) 
                bys = bytearray() 
                bdata.append(crc & 0xFF)
                bdata.append((crc >> 8) & 0xFF)
                #print("send: %s"%(binascii.hexlify(bdata)))
                self._serial.write(bytes(bdata))
            else:
                #print("send: %s"%(binascii.hexlify(data_tmp)))
                self._serial.write(bytes(data_tmp))

    def read(self,len=8):
        if self._is_connected:
            try:
                #number = self._serial.inWaiting()
                data = self._serial.read(len)
                if data:
                    return data
            except Exception as e:
                exstr = traceback.format_exc()
                log_msg = "[serial read] exception={},stack={}".format(str(e),exstr)
        return None

    def on_connected_changed(self, func):
        '''
        set serial connected status change callback
        '''
        tConnected = threading.Thread(target=self._on_connected_changed, args=(func, ))
        tConnected.setDaemon(True)
        tConnected.start()

    def _on_connected_changed(self, func):
        '''
        set serial connected status change callback
        '''
        self._is_connected_temp = False
        while True:
            if platform.system() == "Windows":
                for com in list_ports.comports():
                    if com[0] == self.port:
                        self._is_connected = True
                        break
            elif platform.system() == "Linux":        
                self._is_connected = True

            if self._is_connected_temp != self._is_connected:
                func(self._is_connected)
            self._is_connected_temp = self._is_connected
            time.sleep(0.8)

    def on_data_received(self, func):
        '''
        set serial data recieved callback
        '''
        tDataReceived = threading.Thread(target=self._on_data_received, args=(func, ))
        tDataReceived.setDaemon(True)
        tDataReceived.start()
    
    def _on_data_received(self, func):
        '''
        set serial data recieved callback
        '''
        while True:
            if self._is_connected:
                try:
                    number = self._serial.inWaiting()
                    if number > 0:
                        data = self._serial.read(number)
                        if data:
                            func(data)
                except Exception as e:
                    exstr = traceback.format_exc()
                    log_msg = "[serial read] exception={},stack={}".format(str(e),exstr)
                    #self._is_connected = False
                    #self._serial = None
                    break

    def find_usb_tty(self, vendor_id=None, product_id=None):
        '''
        查找Linux下的串口设备
        '''
        tty_devs = list()
        for dn in glob.glob('/sys/bus/usb/devices/*') :
            try:
                vid = int(open(os.path.join(dn, "idVendor" )).read().strip(), 16)
                pid = int(open(os.path.join(dn, "idProduct")).read().strip(), 16)
                if  ((vendor_id is None) or (vid == vendor_id)) and ((product_id is None) or (pid == product_id)) :
                    dns = glob.glob(os.path.join(dn, os.path.basename(dn) + "*"))
                    for sdn in dns :
                        for fn in glob.glob(os.path.join(sdn, "*")) :
                            if  re.search(r"\/ttyUSB[0-9]+$", fn) :
                                tty_devs.append(os.path.join("/dev", os.path.basename(fn)))
            except Exception as ex:
                pass
        return tty_devs



def print_usage():
    print ("""
usage:
    version:v 1.0.1
    --help. -h
    eg1. python serialHelper.py --port=/dev/ttyUSB0  --baudrate=9600 --bytesize=8 --parity=N  --stopbits=1 --hexmode=true --crc16=true
    """)

def argv_parser(argv):
    global g_port,g_baudrate,g_bytesize,g_parity,g_stopbits,g_hexmode,g_crc16
    try:
        opts_list, args = getopt.getopt(argv[1:], 'hp:b:B:P:s:m:C:', ["help", "port=","baudrate=", "bytesize=","parity=","stopbits=","hexmode=","crc16="])
        for o, a in opts_list:
            if o in ("-h", "--help"):
                print_usage()
                exit(0)         
            elif o in ("-p", "--port"):
                g_port = str(a).strip()
            elif o in ("-b", "--baudrate"):
                g_baudrate = str(a).strip()
            elif o in ("-b", "--bytesize"):
                g_bytesize = str(a).strip()
            elif o in ("-b", "--parity"):
                g_parity = str(a).strip()
            elif o in ("-b", "--stopbits"):
                g_stopbits = str(a).strip()
            elif o in ("-C", "--crc16"):
                tm = str(a).strip()
                if tm == 'true': 
                    g_crc16 = True
                else:
                    g_crc16 = False

            elif o in ("-m", "--hexmode"):
                pa = str(a).strip()                  
                if pa == 'true':
                    g_hexmode = True                  
                else:
                    g_hexmode = False                  

        return True, ""
    except Exception, ept:
        return False, repr(ept)

myserial=None

def myserial_on_connected_changed(is_connected):
    if is_connected:
        print("Connected")
        myserial.connect()
        myserial.on_data_received(myserial_on_data_received)
    else:
        print("DisConnected")

def myserial_on_data_received( data):
    if g_hexmode:
        print("rx[Hex]:",binascii.hexlify(data))
    else:
        print("rx[Asc]:",data)

if __name__ == '__main__':
    a_res, a_err = argv_parser(sys.argv)
    myserial = SerialHelper(Port=g_port, BaudRate=g_baudrate, ByteSize=g_bytesize, Parity=g_parity, Stopbits=g_stopbits)
    myserial.on_connected_changed(myserial_on_connected_changed)

    count = 0
    while True:
        print "input:"
        s = raw_input()
        if s == 'exit':
            sys.exit(0)
        myserial.write(s,g_hexmode)
        
        time.sleep(1)
        count += 1
