#!/usr/bin/python
# -*- coding: UTF-8 -*-
import os
import sys
import commands
import subprocess

VERSION = "1.0.0"
NAME = "gpio"
filename_dialogue = "/tmp/gpio.check"
#g_opts = {'type':"uart",'using':"enabled"}
g_globalConfig = None
g_logger = None
LOG_TAG = "gpio"
LOG_ERROR = 9
LOG_INFO = 0
def log(msg,error=LOG_INFO):
    if g_logger != None:
        if error == LOG_ERROR:
            g_logger.error('[%s]%s' % (LOG_TAG,msg) )
        else:
            g_logger.info('[%s]%s'% ( LOG_TAG,msg) )

#配置adc模块 globalConfig用于得到硬件类型
def init(globalConfig = None,logger=None):
    global g_globalConfig,g_logger
    g_globalConfig = globalConfig
    g_logger = logger
    ret = True

    return ret

#autodetect 模块 probe
#ADC 通过usb to serial连接无法被复位
def autodetect(opts=None):
    ret = True
    gpio_def_table = [  {"port":10,"description":"led-RUNNING"},
                        {"port":11,"description":"SR9900 power ctrl"},
                        {"port":20,"description":"gpio20"},
                        {"port":21,"description":"remote(ssh) ctrl button"},
                        {"port":22,"description":"reset button"},
                        {"port":23,"description":"DIN2"},
                        {"port":24,"description":"led-network online"},
                        {"port":25,"description":"led-error"},
                        {"port":26,"description":"gpio26"},
                        {"port":38,"description":"wifi-FC20 power ctrl"},
                        {"port":42,"description":"SIMCOM-4G power ctrl"},
                        {"port":77,"description":"DIN1"},
                        {"port":78,"description":"gpio78"},
                        {"port":79,"description":"gpio79"},
                    ]
    ret_gpio_info = []
    for gpio_def in gpio_def_table:
        gpio_info={}
        (status, output) = commands.getstatusoutput('cat /sys/class/gpio/gpio%d/direction' % (gpio_def["port"]))
        gpio_info["port"] = "gpio%d" % (gpio_def["port"])
        gpio_info["direction"] = output
        gpio_info["description"] = gpio_def["description"]
        (status, output) = commands.getstatusoutput('cat /sys/class/gpio/gpio%d/value' % (gpio_def["port"]))
        gpio_info["value"] = output
        ret_gpio_info.append(gpio_info)

    return (ret,ret_gpio_info)

#使能或者关闭模块
def enable(enabled):
    ret = True
    return ret

#复位设备
def reset():
    ret = True
    return ret

#健康检查 运行时的健康检查，只在运行时调用
def check():
    ret = True
    log('check enter.')
  
    log('check exit.')
    return ret

#出厂测试用
'''
return: {ret:True|False,msg:""}
'''
def factory_test():
    ret = True
    return ret

#获取硬件设备信息
def info():
    return {'VERSION':VERSION,'NAME':NAME}


