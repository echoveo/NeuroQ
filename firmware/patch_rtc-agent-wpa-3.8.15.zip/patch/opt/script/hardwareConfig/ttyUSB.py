#!/usr/bin/python
# -*- coding: UTF-8 -*-
import os
import sys
import commands
import subprocess
import time

'''专用'''
g_USB0_name=None
g_USB1_name=None
filename_dialogue = "/tmp/ttyUSB.check"
'''专用'''

VERSION = "1.0.0"
NAME = "ttyUSB"

#g_opts = {'type':"uart",'using':"enabled"}
g_globalConfig = None

g_logger = None
LOG_TAG = "ttyUSB"
LOG_ERROR = 9
LOG_INFO = 0
def log(msg,error=LOG_INFO):
    if g_logger != None:
        if error == LOG_ERROR:
            g_logger.error('[%s]%s' % (LOG_TAG,msg) )
        else:
            g_logger.info('[%s]%s'% ( LOG_TAG,msg) )
    else:
        print msg
#配置adc模块 globalConfig用于得到硬件类型
def init(globalConfig = None,logger=None):
    global g_globalConfig,g_logger
    g_globalConfig = globalConfig
    g_logger = logger
    ret = True
    #log("init enter")
    if g_globalConfig == None:
        log("init fail exit: g_globalConfig is None")
        return False
    
    (hardwareConfig,softwareConfig) = g_globalConfig

    if not 'ttyUSB' in hardwareConfig:
        log("init fail exit: ttyUSB is not in config")
        return False

    opts_ttyUSB = hardwareConfig['ttyUSB']
   
  
    return ret

#autodetect 模块 probe
def autodetect(opts=None):
    ret = True
    global g_USB_name
    ret = True
    g_USB0_name = 'ttyUSB0'
    g_USB1_name = 'ttyUSB1'
    (hardwareConfig,softwareConfig) = g_globalConfig
    for i in range(6):
        ttyusb_name = "ttyUSB%d"%(i)
        #/sys/bus/usb/devices/1-1.3.3:2.0/net/  LAN
        #/sys/bus/usb/devices/1-1.1:2.0/net/ 测试代码中的LAN
        #default is NeuroQ-200 
        (status, g_USB0_name) = commands.getstatusoutput("test -e /sys/bus/usb/devices/1-1.1:1.0/%s/port_number && echo '%s'"%(ttyusb_name,ttyusb_name))            
        if hardwareConfig['HardwareName'] == 'NeuruQ-300':
            (status, g_USB0_name) = commands.getstatusoutput("test -e /sys/bus/usb/devices/1-1.3.3:2.0/net/%s/address && echo '%s'"%(ttyusb_name,ttyusb_name))            
        if g_USB0_name == ttyusb_name:
            break
    for i in range(6):
        ttyusb_name = "ttyUSB%d"%(i)
        #/sys/bus/usb/devices/1-1.2:2.0/net   WAN
        #/sys/bus/usb/devices/1-1.2:2.0/net   测试代码中的WAN
        (status, g_USB1_name) = commands.getstatusoutput("test -e /sys/bus/usb/devices/1-1.2:1.0/%s/port_number && echo '%s'"%(ttyusb_name,ttyusb_name))            
        if hardwareConfig['HardwareName'] == 'NeuruQ-300':
            (status, g_USB1_name) = commands.getstatusoutput("test -e /sys/bus/usb/devices/1-1.2:2.0/net/%s/address && echo '%s'"%(ttyusb_name,ttyusb_name))            
        if g_USB1_name == ttyusb_name:
            break
           
    
    log("ttyUSB0=%s;ttyUSB1=%s" % (g_USB0_name,g_USB1_name) ) 
    os.system("rm -f /dev/ttyUSBP1;rm -f /dev/ttyUSBP2")
    if g_USB0_name == None or g_USB0_name == "":
        ret = False
        log('query ttyUSB0 index fail, ttyUSB0 invalid',LOG_ERROR)
    else:
        os.system("ln -s /dev/%s /dev/ttyUSBP1" % (g_USB0_name) )

    if g_USB1_name == None or g_USB1_name == "":
        ret = False
        log('query ttyUSB1 fail, ttyUSB1 invalid',LOG_ERROR)
    else:
        os.system("ln -s /dev/%s /dev/ttyUSBP2" % (g_USB1_name) )        

    if g_USB0_name != None and g_USB0_name == g_USB1_name:
        ret = False    
        log('query ttyUSB fail, g_USB0_name == g_USB1_name ',LOG_ERROR)
    

    #soft link to ttyUSB0 and ttyUSB1
    
    

    return (ret,{"ttyUSB0":g_USB0_name,"ttyUSB1":g_USB1_name})
#使能或者关闭模块
def enable(enabled):
    ret = True
    if enabled:
        ret = reset()
   
    return ret

#复位设备
def reset():
    ret = True
  
    log('reset enter')

    log('reset exit.')

    return ret


#健康检查 运行时的健康检查，只在运行时调用
def check():
    ret = True   
    autodetect()
    return ret

#出厂测试用
'''
return: {ret:True|False,msg:""}
'''
def factory_test():
    ret = True
    return ret

#获取硬件设备信息
def info():
    return {'VERSION':VERSION,'NAME':NAME,'ttyUSB0':g_USB0_name,'ttyUSB1':g_USB1_name}


if __name__ == '__main__':
    reset()
    print autodetect({})
    sys.exit(0)