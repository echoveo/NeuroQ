本目录内存放处理 硬件配置的代码
所有配置项来自script/globalConfig.py getConfig() 的返回
todo 开发中。。。
