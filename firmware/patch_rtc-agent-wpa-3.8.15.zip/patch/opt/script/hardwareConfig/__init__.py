#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
version 1.0.1
author:kali@neobv.com

"""


try:
    import adc
    import net_ethernet
    import canbus
    import gpio
    import net_4g
    import net_wifi
    import net_wifiah
    import systeminfo
except ImportError:
    print("xxx could not be loaded; the sockets will not be cooperative.")



