#!/usr/bin/python
# -*- coding: UTF-8 -*-
import os
import sys
import commands
import subprocess
import binascii
import time
from serialHelper import SerialHelper

VERSION = "1.0.0"
NAME = "adc"
filename_dialogue = "/tmp/adc.check"
#g_opts = {'type':"uart",'using':"enabled"}
g_globalConfig = None
g_ADC_serialport = None


g_logger = None
LOG_TAG = "adc"
LOG_ERROR = 9
LOG_INFO = 0
def log(msg,error=LOG_INFO):
    if g_logger != None:
        if error == LOG_ERROR:
            g_logger.error('[%s]%s' % (LOG_TAG,msg) )
        else:
            g_logger.info('[%s]%s'% ( LOG_TAG,msg) )

#配置adc模块 globalConfig用于得到硬件类型
def init(globalConfig = None,logger=None):
    global g_globalConfig,g_logger
    g_globalConfig = globalConfig
    g_logger = logger
    ret = True
    
    return ret

#autodetect 模块 probe
#ADC 通过usb to serial连接无法被复位
def autodetect(opts=None):
    global g_ADC_serialport
    ret = True
    g_ADC_serialport = 'ttyUSB0'
    
    ret_msg = {}
    for i in range(6):
        ADC_serialport = "ttyUSB%d"%(i)
        #/sys/bus/usb/devices/1-1.3.2:1.0/ttyUSB0/port_number  ttyUSB        
        (status, g_ADC_serialport) = commands.getstatusoutput("test -e /sys/bus/usb/devices/1-1.3.2:1.0/%s/port_number && echo '%s'"%(ADC_serialport,ADC_serialport))            
        if g_ADC_serialport == ADC_serialport:
            break
    
    #log("adc serial port=%s" % (g_ADC_serialport) ) 
    if g_ADC_serialport == None:
        ret = False
        log('query adc serialport fail, ttyUSB invalid',LOG_ERROR)
    else:
        ret_msg['serialport'] = g_ADC_serialport
    if ret:
        #测试前需要把agentbasic kill掉，否则可能占着ttyUSB0
        os.system("killall agentbasic")
        #将usb id号保存起来，以方便dialogue进行查询 
        os.system("lsusb | grep '1a86:7523' | awk -F '[:| ]' '{print($3,$4)}' > %s" % (filename_dialogue))
        #test ADC serial 
        myserial = SerialHelper('/dev/'+g_ADC_serialport,'9600', '8', 'N', "1",True)
        send_datas = ["010600000023","01060002000F","010600010001","0103000f0002"]
        #send_datas = ["0103000f0002"]
        try:            
            ret = myserial.connect(0.5)            
            if ret:
                ret_msg['connect_to_serial'] = True
                ret_msg["test_datas"] = []
                for send_data in send_datas:
                    
                    myserial.write(send_data,True)
                    #time.sleep(0.7)
                    test_data = ""
                    ret_data = myserial.read(128)
                    if ret_data != None:
                        test_data = "send:[%s] recv:[%s]" % (send_data,binascii.hexlify(ret_data))
                    else:
                        ret = False
                        test_data = "send:[%s] recv:[time out]" % (send_data)
                    ret_msg["test_datas"].append(test_data)
                myserial.disconnect()
            else:
                ret_msg['connect_to_serial'] = False    
        except Exception as ept:
            ret_msg['exception'] = repr(ept)
            log("serial exception:%s" % (repr(ept)) )
            if ret:
                myserial.disconnect()
            

    return (ret,ret_msg)

#使能或者关闭模块
def enable(enabled):
    ret = True
    return ret

#复位设备
def reset():
    ret = True
    return ret

#健康检查 运行时的健康检查，只在运行时调用
def check():
    ret = True
    #log('check enter.')
    (status, output) = commands.getstatusoutput("test -e %s && echo 'file exist'" % ( filename_dialogue ) )       
    if output == '' or output == None:
        #log('%s not exist.' % (filename_dialogue))
        (ret,ret_info) = autodetect()    #生成filename_dialogue
        if not ret:
            log('check fail!.autodetect() return false.')
            return False


    (status, output_new) = commands.getstatusoutput("lsusb | grep '1a86:7523' | awk -F '[:| ]' '{print($3,$4)}'" )       
    (status, output_old) = commands.getstatusoutput("cat %s" % (filename_dialogue) )
    if output_new != output_old:     
        log('previous usbid =%s' %(output_old))
        log('new usbid =%s' %(output_new))
        log('check test fail!')
        return False  
    #log('check exit.ret=%d'%(ret))
    return ret

#出厂测试用
'''
return: {ret:True|False,msg:""}
'''
def factory_test():
    ret = True
    return ret

#获取硬件设备信息
def info():
    return {'VERSION':VERSION,'NAME':NAME}


