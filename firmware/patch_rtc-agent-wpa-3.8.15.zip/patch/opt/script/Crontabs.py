#!/usr/bin/python
# -*- coding: utf-8 -*-

# author: luoshuai
# version: 1.0.0
# date: 2020/7/10

import os
import sys
import shutil


def main():
    # Create crontabs folder
    if not os.path.exists("/var/spool/cron/crontabs"):
        os.makedirs("/var/spool/cron/crontabs")
    shutil.copy("/opt/script/root", "/var/spool/cron/crontabs/")

    # start crond
    os.system("/sbin/crond -b")
    return 0


if __name__ == '__main__':
    main()
    sys.exit(0)
