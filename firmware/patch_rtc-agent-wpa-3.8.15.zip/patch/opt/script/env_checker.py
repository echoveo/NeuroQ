#!/usr/bin/python
# -*- coding: UTF-8 -*-

# author: kali
# version: 1.0.0
# date: 2022/03/30

# 有时候/tmp目录没有生效
# 应该是init.d/populate-volatile.sh这个程序执行发生什么异常了
# 程序会连续3次检查/tmp目录是否存在，如果不存在而且无效，执行sh /etc/volatile.cache 完成/tmp目录的建立 
import os
import sys
import time
import logging
import psutil
import commands
import xml.etree.ElementTree as ET
from logging.handlers import RotatingFileHandler

FILENAME = sys._getframe().f_code.co_filename
VERSION = "1.0.0"





def initial_log(log_name, debug):
    """定义一个RotatingFileHandler，最多备份2个日志文件，每个日志文件最大8K"""
    log = logging.getLogger()
    handler = RotatingFileHandler(log_name, maxBytes=1024 * 8, backupCount=2)
    formatter = logging.Formatter('%(asctime)s-%(levelname)s: %(message)s')
    handler.setFormatter(formatter)
    ch = logging.StreamHandler()
    ch.setFormatter(formatter)
    log.addHandler(handler)
    log.addHandler(ch)

    if debug is not None:
        log.setLevel(debug)
    else:
        log.setLevel(logging.WARNING)
    return log


def get_version(log):
    log.info(FILENAME + "-" + VERSION)

def run_cmd(cmd):   
    (status, output) = commands.getstatusoutput(cmd)
    if output != "":
        return output.strip()
    else:
        return ""

def light_led(value_path="", status="1"):
    try:
        with open(value_path, 'w') as fd:
            fd.write(status)
        return True, ""
    except Exception, ept:
        return False, repr(ept)



def ProcessExist(processName):
    (status, output) = commands.getstatusoutput('ps | grep "%s" | grep -v grep' % processName)
    if output == '':
        return False
    else:
        return True


def create_tmp(log):
    log.info("force run /etc/volatile.cache!!!")
    os.system("sh /etc/volatile.cache")

#check_dir_tmp 检查tmp目录是否存在
def check_dir_tmp(log):
    is_okay = False
    loop_times = 3
    while loop_times>0:
        loop_times -= 1
        os.system("echo 1 > /tmp/t_e_s_t.valid")
        if os.path.exists("/tmp/t_e_s_t.valid"):
            os.system("rm /tmp/t_e_s_t.valid")
            is_okay = True
            break
        else:
            create_tmp(log)
        time.sleep(0.3)

    if not is_okay:
        os.system("/sbin/reboot")

'''
check AnyLink.xml 
file_A = /opt/sdmwebs/web/conf/AnyLink.xml
file_B = /mnt/mmc/backup/conf/AnyLink.xml

1. 检查file_B是否存在 如果不存在，并且file_A 是有效的，进行一次备份
2. 检查md5(file_B)  md5(file_A) 是否一致
   检查valid(file_B) valid(file_A)
   if(!valid(file_A)){
       if( valid(file_B) ) copy -f file_B file_A
   }
   if( !valid(file_B) ){
       if( valid(file_A) ) copy -f file_A file_B
   }
   if( md5(file_B) != md5(file_A) ){
       if( valid(file_A) ){
           copy -f file_A file_B
       }
   }
   if(!valid(file_A)){
       report_errors(LED_ERROR flashing)
   }
'''
def check_AnyLinkXML(log):
    file_A = '/opt/sdmwebs/web/conf/AnyLink.xml'
    file_B = '/mnt/mmc/backup/conf/AnyLink.xml'

    if not os.path.exists('/mnt/mmc/backup/conf'):
        run_cmd('mkdir -p /mnt/mmc/backup/conf')

    if not checkXMLFile(file_A):
        log.error("Config file %s invalid." % (file_A))
        if  checkXMLFile(file_B):
            run_cmd('cp -f %s %s' % (file_B,file_A))
            log.info("Restore file from %s to %s." % (file_B,file_A))
   
    if not checkXMLFile(file_B) :
        log.error("Config file %s invalid." % (file_B))
        if checkXMLFile(file_A):
            run_cmd("cp -f %s %s" % (file_A,file_B))
            log.info("Backup file from %s to %s."%(file_A,file_B))

    if file_md5(file_B) != file_md5(file_A):
        log.error("Config file md5(%s) != md5(%s)." % (file_B,file_A))
        if  checkXMLFile(file_A):
            run_cmd("cp -f %s %s" % (file_A,file_B))
            log.info("Backup file from %s to %s." % (file_A,file_B))
        
    
    if not checkXMLFile(file_A):
        log.error("Config file %s invalid!!!. system halt! report errors" % (file_A))
        report_errors()
    

def report_errors():
    cmd_err = "cd /opt/script && python led_ctrl.py --opts=led1,9,1:led2,9,1:led3,9,1:led4,9,1 &"
    os.system(cmd_err)

def checkXMLFile(path_xml,check_node=None):
    try_times=3
    while try_times>0:
        try:
            ET_xml = ET.parse(path_xml)
            if check_node!=None :
                c_node = ET_xml.find(check_node)
                if  c_node != None:
                    return True
            else:               
                return True
        except Exception as ept:
            pass
        try_times = try_times-1
        time.sleep(0.3)
    return False

def file_md5(filename):
    return run_cmd("/bin/md5sum %s | awk '{print $1}'" % (filename))

def init_serialPort():
    try:
        anylink_tree = ET.parse('/opt/sdmwebs/web/conf/AnyLink.xml')
        root = anylink_tree.getroot()

        serial_port1_node = root.find('SystemSetting/SerialPort1')
        cgi_serial_port1 = serial_port1_node.text 
        
        if cgi_serial_port1 == "RS232":
            run_cmd("echo 0 > /sys/class/gpio/gpio26/value")
        elif cgi_serial_port1 == "RS485":
            run_cmd("echo 1 > /sys/class/gpio/gpio26/value")
    except Exception as ept:
            pass 
def main(log):
    check_dir_tmp(log)
    check_AnyLinkXML(log)
    init_serialPort()


if __name__ == '__main__':
    logLevel = logging.DEBUG
    if len(sys.argv) > 1:
        level = int(sys.argv[1])
        if level == 100:
            logLevel = logging.ERROR
        elif level == 200:
            logLevel = logging.WARN
        elif level == 300:
            logLevel = logging.INFO
        else:
            logLevel = logging.DEBUG
    logger = initial_log('/PageFile/env_checker.log', logLevel)
    get_version(logger)
    main(logger)
    sys.exit(0)
