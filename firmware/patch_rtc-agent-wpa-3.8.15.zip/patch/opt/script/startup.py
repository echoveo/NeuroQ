#!/usr/bin/python
# -*- coding: UTF-8 -*-
'''
由/opt/script/startup.sh调用
脚本的入口文件boot.py
读取globalConfig.py的配置信息
根据硬件配置，启动不同的配置程序
'''
import os
import sys
import time
import commands
import xml.etree.ElementTree as ET
import logging
from logging.handlers import RotatingFileHandler
import globalConfig
FILENAME = sys._getframe().f_code.co_filename
VERSION = "1.0.0"

def initial_log(log_name, debug):
    """定义一个RotatingFileHandler，最多备份2个日志文件，每个日志文件最大64K"""
    log = logging.getLogger()
    try:
        handler = RotatingFileHandler(log_name, maxBytes=64 * 1024, backupCount=2)
        formatter = logging.Formatter('%(asctime)s-%(levelname)s: %(message)s')
        handler.setFormatter(formatter)
        ch = logging.StreamHandler()
        ch.setFormatter(formatter)
        log.addHandler(handler)
        log.addHandler(ch)
        
        if debug is not None:
            log.setLevel(debug)
        else:
            log.setLevel(logging.WARNING)
        log.info('begin...')
    except Exception, e:
        #when mmc card is corrupted(ext4_lookup inode error) switch file to wifi-second.log
        handler = RotatingFileHandler('/PageFile/boot-sec.log', maxBytes=64 * 1024, backupCount=2)
        formatter = logging.Formatter('%(asctime)s-%(levelname)s: %(message)s')
        handler.setFormatter(formatter)
        ch = logging.StreamHandler()
        ch.setFormatter(formatter)
        log.addHandler(handler)
        log.addHandler(ch)
        
        if debug is not None:
            log.setLevel(debug)
        else:
            log.setLevel(logging.WARNING)
        log.info('begin... (MMC corrupted)')
    return log

#check and rewrite "HardwareName" to Anylink.xml 
shell_HardwareName = "sed -n '/HardwareName/{s/.*<HardwareName>//;s/<\/HardwareName.*//;p;}' /opt/sdmwebs/web/conf/AnyLink.xml"
def rewrite_anylink_xml(log,hardware_name):
    (status, output) = commands.getstatusoutput(shell_HardwareName)
    if output != '' and output != None:
        if hardware_name != output:
            # 将变量值更新至Common.xml文件中
            common_path = '/opt/sdmwebs/web/conf/Common.xml'
            commonTree = ET.parse(common_path)
            HardwareModel_node = commonTree.find('HardwareModel')
            HardwareModel_node.text = hardware_name

            HardwareName_node = commonTree.find('HardwareName')
            if HardwareName_node is not None:
                HardwareName_node.text = hardware_name
            commonTree.write(common_path, xml_declaration='true')

            # 将变量值更新至AnyLink.xml文件中
            AnyLink_path = '/opt/sdmwebs/web/conf/AnyLink.xml'
            AnyLink_path_backup = '/opt/sdmwebs/web/conf/AnyLink_backup.xml'
            AnyLink_path_tmp = '/tmp/AnyLink_tmp_up.xml'
            os.system('cp -f %s %s' % (AnyLink_path,AnyLink_path_backup))
            os.system('cp -f %s %s' % (AnyLink_path,AnyLink_path_tmp))
            AnyLinkTree = ET.parse(AnyLink_path_tmp)
            HardwareModel_node = AnyLinkTree.find('BasicInfo/HardwareModel')
            HardwareModel_node.text = hardware_name

            HardwareName_node = AnyLinkTree.find('BasicInfo/HardwareName')
            if HardwareName_node is not None:
                HardwareName_node.text = hardware_name

            AnyLinkTree.write(AnyLink_path_tmp, xml_declaration='true')
            os.system('cp -f %s %s;sync' % (AnyLink_path_tmp,AnyLink_path))

#read hardware [SGM41510] using i2c
def check_hardware_version(log):
    (status, output) = commands.getstatusoutput("/opt/script/SGM41510_i2c_test off | grep 'reg fail'")
    if output != '' and output != None:
        #is NeuroQ-200
        rewrite_anylink_xml(log,"NeuroQ-200")
    else:
        #is NeuroQ-300
        rewrite_anylink_xml(log,"NeuroQ-300")

def main(log):
    ret = True
    check_hardware_version(log)
    (hardwareConfig,softwareConfig) = globalConfig.getConfig()
    if hardwareConfig['HardwareName'] == 'NeuroQ-200':
        #旧的硬件，直接执行原来的启动脚本，以保持兼容，同时旧的硬件不再继续开发，只保持必要的更新 todo
        log.info('start startup-NeuroQ-200.sh')
        os.system('cd /system/anylink/script/ && ./startup-NeuroQ-200.sh >/dev/null 2>&1')
    elif hardwareConfig['HardwareName'] == 'NeuroQ-300':
        log.info('start startup-NeuroQ-300.sh')
        os.system('cd /system/anylink/script/ && ./startup-NeuroQ-300.sh >/dev/null 2>&1')
    return ret

# ############################# main block ##############################

if __name__ == '__main__':
    logLevel = logging.DEBUG
    if len(sys.argv) > 1:
        level = int(sys.argv[1])
        if level == 100:
            logLevel = logging.ERROR
        elif level == 200:
            logLevel = logging.WARN
        elif level == 300:
            logLevel = logging.INFO
        else:
            logLevel = logging.DEBUG
    logger = initial_log('/PageFile/startup.log', logLevel)
    if main(logger):
        sys.exit(1)
    else:
        sys.exit(0)