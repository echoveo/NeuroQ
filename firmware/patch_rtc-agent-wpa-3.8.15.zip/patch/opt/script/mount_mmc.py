#!/usr/bin/python
# -*- coding: UTF-8 -*-

# author: kali
# version: 1.0.0
# date: 2021/12/07

# 格式化mmc 并加载到 /mnt/mmc目录下
# 将/PageFile 目录链接到 /mnt/mmc/PageFile目录下
# 将/system/anylink/anylink_log 目录链接到 /mnt/mmc/anylink_log目录下
import os
import sys
import time
import psutil
import commands

FILENAME = sys._getframe().f_code.co_filename
VERSION = "1.0.2"

def get_version(log):
    print FILENAME + "-" + VERSION


def ProcessExist(processName):
    (status, output) = commands.getstatusoutput('ps | grep "%s" | grep -v grep' % processName)
    if output == '':
        return False
    else:
        return True

def main():
    (status, output) = commands.getstatusoutput("blkid /dev/mmcblk0 | grep 'ext4'")
    heart_beat = 0
  
    if output == '':
        os.system("mkfs.ext4 /dev/mmcblk0")
    os.system("mkdir -p /mnt/mmc")
    os.system("mount /dev/mmcblk0 /mnt/mmc")
    #将/system/anylink/anylink_log 目录链接到 /mnt/mmc/anylink_log目录下

    os.system("mkdir -p /mnt/mmc/anylink_log")
    #backup exist files
    if not os.path.islink('/system/anylink/anylink_log') and os.path.isdir('/system/anylink/anylink_log'):
        os.system('cp /system/anylink/anylink_log/* /mnt/mmc/anylink_log/ -rf')
    
    os.system("rm /system/anylink/anylink_log -rf;ln -s /mnt/mmc/anylink_log /system/anylink/anylink_log;sync")
    
    #将/PageFileMMC 软件链接到 /mnt/mmc/PageFile 目录
    os.system("mkdir -p /mnt/mmc/PageFile")
    os.system("rm /PageFile;ln -s /mnt/mmc/PageFile /PageFile;sync")

if __name__ == '__main__':
    main()
    sys.exit(0)
