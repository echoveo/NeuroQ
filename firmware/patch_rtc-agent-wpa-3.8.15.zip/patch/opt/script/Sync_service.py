#!/usr/bin/env python
# -*- coding: utf-8 -*- 

import sys
import os
import socket
import time
import threading

import logging
from logging.handlers import RotatingFileHandler

gHeartBeat = False
gMaxNotChangeCount = 25
logger = logging.getLogger()


def initial_log(log_name, debug):
    """定义一个RotatingFileHandler，最多备份5个日志文件，每个日志文件最大1M"""
    global logger
    handler = RotatingFileHandler(log_name, maxBytes=8 * 1024, backupCount=1)
    formatter = logging.Formatter('%(asctime)s-%(levelname)s: %(message)s')
    handler.setFormatter(formatter)
    ch = logging.StreamHandler()
    ch.setFormatter(formatter)
    logger.addHandler(handler)
    logger.addHandler(ch)

    if debug >= 400:
        logger.setLevel(logging.DEBUG)
    elif debug >= 300:
        logger.setLevel(logging.INFO)
    elif debug >= 200:
        logger.setLevel(logging.WARNING)
    elif debug >= 100:
        logger.setLevel(logging.ERROR)
    elif debug >= 0:
        logger.setLevel(logging.CRITICAL)
    else:
        logger.setLevel(logging.WARNING)


def Sync():
    global gHeartBeat, gMaxNotChangeCount
    # logger.info("start a sync thread...")
    localFlag = gHeartBeat
    count = gMaxNotChangeCount
    while True:
        try:
            time.sleep(1)
            if localFlag == gHeartBeat:
                count = count + 1
            else:
                localFlag = gHeartBeat
                count = 0
            if count > gMaxNotChangeCount:
                # logger.info("no heartbeat...")
                continue

            # logger.info("start sync...")
            os.system("sync")
            # os.system("echo 12345")
            # logger.info("finish sync...")
        except Exception as ex:
            logger.error("Sync thread error: %s" % ex)


def main():
    global gHeartBeat

    t = threading.Thread(target=Sync)
    t.start()

    ip_port = ('127.0.0.1', 9999)
    back_log = 5
    buffer_size = 1024
    ser = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # 套接字类型AF_INET, socket.SOCK_STREAM   tcp协议，基于流式的协议
    ser.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)  # 对socket的配置重用ip和端口号
    ser.bind(ip_port)
    ser.listen(back_log)
    while 1:
        con, address = ser.accept()
        while True:
            try:
                msg = con.recv(buffer_size)
                if (msg is not None) and (len(msg) > 0):
                    # logger.info('messeage:%s' % msg.decode('utf-8'))
                    gHeartBeat = bool(1 - gHeartBeat)
                else:
                    con.close()
            except Exception as ex:
                con.close()
                # logger.error(ex)
                break
    ser.close()


if __name__ == "__main__":
    if os.path.isdir("/PageFile/"):
        initial_log("/PageFile/Sync_service.log", 400)
    else:
        initial_log("Sync_service.log", 400)
    main()
