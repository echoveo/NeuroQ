#!/usr/bin/python
# -*- coding: UTF-8 -*-

# author: kali
# version: 1.0.0
# date: 2021/12/22

# 检查接入的U盘中是否有/media/usb1/factory_test/config.json 这个文件，如果有
# 启动生产测试
# 通过上述检查后 以/media/usb/IEProApCfg.conf为配置文件，运行Wifi-AP
# /media/usb/IEProApCfg.conf为配置文件 样例见本代码最后部分
import os
import sys
import time
import logging
import psutil
import commands
import signal
from gpio import Controller, OUTPUT, INPUT, RISING,BOTH,FALLING

from logging.handlers import RotatingFileHandler

FILENAME = sys._getframe().f_code.co_filename
VERSION = "1.0.0"
FACTEST_PATH = "/media/usb1/factory_test"
FACTEST_CFG_PATH = "{0}/config.json".format(FACTEST_PATH)

FACTEST_DEPLOY_PATH="/usrdata/factory_test"

def initial_log(log_name, debug):
    """定义一个RotatingFileHandler，最多备份2个日志文件，每个日志文件最大8K"""
    log = logging.getLogger()
    handler = RotatingFileHandler(log_name, maxBytes=1024 * 8, backupCount=2)
    formatter = logging.Formatter('%(asctime)s-%(levelname)s: %(message)s')
    handler.setFormatter(formatter)
    ch = logging.StreamHandler()
    ch.setFormatter(formatter)
    log.addHandler(handler)
    log.addHandler(ch)

    if debug is not None:
        log.setLevel(debug)
    else:
        log.setLevel(logging.WARNING)
    return log


def get_version(log):
    log.info(FILENAME + "-" + VERSION)


def light_led(value_path="", status="1"):
    try:
        with open(value_path, 'w') as fd:
            fd.write(status)
        return True, ""
    except Exception, ept:
        return False, repr(ept)



# 这个比较占用cpu
def ProcessExist_v1(processName):
    process_list = psutil.pids()
    try:
        for pid in process_list:
            process = psutil.Process(pid)
            if processName in process.name():
                return True
                #break
    except Exception, e:
        pass
    return False

def ProcessExist(processName):
    (status, output) = commands.getstatusoutput('ps | grep "%s" | grep -v grep' % processName)
    if output == '':
        return False
    else:
        return True


def run_cmd(cmd,wait=True):
    if wait==False:
        os.system(cmd)
    else:
        
        (status, output) = commands.getstatusoutput(cmd)
        if output != "":
            return output.strip()
        else:
            return ""
        #return os.popen(cmd, 'r').read().strip()

def killall(app_name):
    process_list = run_cmd('ps | grep {0} | grep -v grep'.format(app_name))
    if process_list == "" or process_list == None:
        return False
    process_list = process_list.split('\n')
    for P in process_list:
        items = P.split(' ')
        if len(items)>1 and (app_name in P):
            os.system('kill -9 {0}'.format(items[0]))
    return True         

#U盘脚本文件固定在U盘根目录 factory_test目录下
#测试环境的安装目录，固定在 /usrdata/factory_test 目录下
#测试结果日志目录，固定在/usrdata/factory_test/log目录下
def deploy(src_path):
    #deploy_path = "/usrdata"
    #deploy_target = "factory_test"
    target_path = FACTEST_DEPLOY_PATH #"{0}/{1}".format(deploy_target,deploy_path)
    if target_path.strip() == "":
        return False
        #raise Exception,"const deploy_path is null"
    if not os.path.exists(src_path):
        return False
        #raise Exception,"{0} not exist ".format(src_path)

    os.system("rm {0}/* -rf".format(target_path))
    os.system("mkdir -p {0}".format(target_path))
    os.system("cp {0}/* {1} -rf".format(src_path,target_path))
    os.system("cd {0} && chmod +x -R *".format(target_path))
    os.system("sync")
    return True
#执行测试程序
def run_factory_test(config_filename="config.json"):  
    working_path = FACTEST_DEPLOY_PATH
    mainPY = "main.py"
    factory_test_running_path = "{0}/{1}".format(working_path,mainPY)
    if not os.path.exists(factory_test_running_path):
        return False
        #raise Exception,"{0} not exist ".format(factory_test_running_path)
    
    #检查重入
    killall(mainPY)
    
    os.system("cd {0} && python ./{1} --cfg={2}".format(working_path,mainPY,config_filename))
    time.sleep(0.5)
    return True
def start_factory_test(log,config_filename="config.json"):
    #global FACTEST_PATH
    log.info("start_factory_test ")  
    log.info("deploy")
    deploy(FACTEST_PATH)
    run_factory_test(config_filename=config_filename)
    log.info("start...")
        
    time.sleep(1)

#当rmt 按键3秒内被连续按了6次（按下，抬起算两次） 后启动测试（无需U盘）
def test_RMT_button():
    print "aaaaaaaaaaaaa"

def ctrl_c(signalnum,   frame):
    # 如果用sys.exit()会报系统异常达不到直接结束程序的效果。
    # 因为sys.exit()触发的是系统异常，Exception只能捕获由代码触发的异常。
    # 即使如此也不推荐使用sys.exit来结束进程，
    # 因为Ctrl-C退出的时候需要按三次才能完全退出（和进程数无关）
	print "ctrl + C"
	Controller.stop()
	os._exit(0)


#检查出厂模式，如果未测试通过，红灯快闪, 表示设备处理于功能未确定状态
def check_factory_mode(log):
    errors=0
    factory_mode = run_cmd('cat /etc/factory.mode | grep stage')
    log.info( "device factory mode = {} ".format(factory_mode))
    if factory_mode == None:
        log.info("/etc/factory.mode is empty,set factory_mode=init default")
        factory_mode = "stage=init"
    if not "test_pass" in factory_mode :
        print "device factory stage=init ,must be factory test"
        errors+=1    
    else:
        print "device factory {}".format(factory_mode)
    
    if errors>0:
        cmd_err = "cd /opt/script && python led_ctrl.py --opts=led1,0,0:led2,0,0:led3,0,0:led4,9,1 &"
        os.system(cmd_err)
        time.sleep(5)

button_click_times=[]
is_6_button_flag=False  #用户是否连续按了6次按键
pre_state=0
last_gpio_value_timestamp = time.time()
def main(log):
    log.info("factory_test monitor start...")
    heart_beat = 0
    signal.signal(signal.SIGINT, ctrl_c) # 捕获singint信号，交给ctrl_c处理
    signal.signal(signal.SIGTERM, ctrl_c)
    Controller.available_pins = [21]
    
    
    def gpio_pin_changed(number, state):
        global button_click_times,is_6_button_flag,pre_state,last_gpio_value_timestamp
        #print("Pin '%d' changed to %d state" % (number, state))
        if number == 21 and state != pre_state:
            pre_state = state
            if time.time()-last_gpio_value_timestamp >0.25:
                last_gpio_value_timestamp = time.time()
                button_click_times.append({"timestamp":time.time()})
                print("Pin '%d' changed to %d state" % (number, state))
        array_len = len(button_click_times)
        idx=0
        for item in button_click_times:
            if button_click_times[array_len-1]['timestamp'] - item['timestamp'] <= 3.5 \
                and array_len-idx>=6:
                #Controller.stop()
                is_6_button_flag=True
                print "click 6 times"
                break;
            idx+=1
        if array_len >= 7:
            button_click_times = button_click_times[2:7]
        
    
    pin = Controller.alloc_pin(21, INPUT, gpio_pin_changed, BOTH)
    check_factory_mode(log)
    while True:
        time.sleep(1)
        heart_beat = heart_beat + 1
        if heart_beat >= 3600:
            heart_beat = 0
            log.info("factory_test  monitor is running")
        try:
            res = ""
            if os.path.isfile(FACTEST_CFG_PATH) or is_6_button_flag==True:              
                #log.info("%s exist and valid" % FACTEST_CFG_PATH)
                Controller.stop()
                if is_6_button_flag==True:
                    start_factory_test(log=log,config_filename="config_self_detect.json")
                else:
                    start_factory_test(log=log,config_filename="config.json")
                sys.exit(0) #退出程序，否则会重入

        except Exception as ex:
            log.error(ex.message)
            time.sleep(3)


if __name__ == '__main__':
    logLevel = logging.DEBUG
    if len(sys.argv) > 1:
        level = int(sys.argv[1])
        if level == 100:
            logLevel = logging.ERROR
        elif level == 200:
            logLevel = logging.WARN
        elif level == 300:
            logLevel = logging.INFO
        else:
            logLevel = logging.DEBUG
    logger = initial_log('/PageFile/factory_test.log', logLevel)
    get_version(logger)   
    main(logger)
    sys.exit(0)



