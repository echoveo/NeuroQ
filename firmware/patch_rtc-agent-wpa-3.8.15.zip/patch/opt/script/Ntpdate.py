#!/usr/bin/python
# -*- coding: utf-8 -*-

__author__ = 'luoshuai'
__version__ = '1.0.3'
__date__ = '2020/12/15'

import os
import sys
import time
import psutil
import random
import commands
import xml.etree.ElementTree
import logging
from logging.handlers import RotatingFileHandler

NTP_DATE_SUCCESS = 0
NTP_DATE_FAIL = -1

DEFAULT_SYS_DATE = "2020-1-1"
DEFAULT_SERVER_ADDR = "us-s1.anylink.io"


SRC_ANYLINK_XML = "/opt/sdmwebs/web/conf/AnyLink.xml"
SRC_MODULECONFIG_XML = "/opt/agent/ModuleConfig.xml"

#SRC_NTPD_ADDRESS = ['1.pool.ntp.org', '2.pool.ntp.org', '1.cn.pool.ntp.org', '2.cn.pool.ntp.org']
SRC_NTPD_ADDRESS = ['1.pool.ntp.org', '2.pool.ntp.org']


def init_logger():
    logger = logging.getLogger()
    handler = RotatingFileHandler('/PageFile/ntplog.log', mode='a', maxBytes=8 * 1024, backupCount=1)
    formatter = logging.Formatter('%(asctime)s %(levelname)s----%(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)
    return logger


# ############################## functions ##############################
def ntp_time(ntp_server, log):
    try:
        (status, output) = commands.getstatusoutput('ntpdate %s' % str(ntp_server))
        if 'adjust time server' in output or 'step time server' in output:
            log.info(output)
            return NTP_DATE_SUCCESS
        else:
            raise Exception("no found \"adjust time server\" or \"step time server\" in \"%s\"" % str(output))
    except Exception, e:
        log.error(repr(e))
        return NTP_DATE_FAIL


def kill_ntpd(log):
    process_list = psutil.pids()
    try:
        for pid in process_list:
            process = psutil.Process(pid)
            if 'ntpd' in process.name():
                cmd = 'kill -9 %d' % pid
                os.system(cmd)
                break
    except Exception, e:
        log.error(repr(e))


def get_server_address(log):
    try:
        al_tree = xml.etree.ElementTree.parse(SRC_ANYLINK_XML)
        al_nodes = al_tree.getroot()
        agent_protocol = al_nodes.find('AgentConfig/Protocol').text
        if str(agent_protocol).strip() == "http":
            server_address = al_nodes.find('CloudInfo/Address').text
        elif str(agent_protocol).strip() == "mqtt":
            mc_tree = xml.etree.ElementTree.parse(SRC_MODULECONFIG_XML)
            mqtt_node = mc_tree.find('./task/TaskDriver/driver[@n="T.IDrv.Task:libkmqtt"]')
            mqtt_config = mqtt_node.get('config').split(';')
            server_address = mqtt_config[0]
        else:
            server_address = DEFAULT_SERVER_ADDR
    except Exception, e:
        log.error("bad address, error msg %s" % repr(e))
        server_address = DEFAULT_SERVER_ADDR
    return server_address


def set_default_date(log):
    try:
        now_time = time.localtime()
        if now_time.tm_year < 1970:
            #fix issue: Some times,system date = 1930,cause datetime() return  negative.
            os.system("date \"{0}\" &".format(DEFAULT_SYS_DATE))
            log.info('set default date %s' % DEFAULT_SYS_DATE)
    except Exception as ept:
        log.error('set default date fail, error msg: %s' % repr(ept))


def check_time(log):
    try:
        for server in SRC_NTPD_ADDRESS:
            if ntp_time(server, log) == NTP_DATE_SUCCESS:
                log.info('update time success, current time is %s on server(%s)' % (time.strftime('%Y-%m-%d %H:%M:%S'),
                                                                                    server))
                return NTP_DATE_SUCCESS
            else:
                log.error('timing servers(%s) can not be used ...' % server)
                time.sleep(10)
        # set_default_date(log)
        # return NTP_DATE_FAIL
        raise Exception("no timing servers can be used ...")
    except Exception as ept:
        log.error('update time fail, error msg: %s' % repr(ept))
        # set_default_date(log) 为了保证checknet.py的时间稳定，去掉default_date的设置
        return NTP_DATE_FAIL


def check_self(argv):
    name = os.path.split(argv[0])[1]
    cmd = "ps -ef | grep -v grep | grep -w %s" % name
    (status, output) = commands.getstatusoutput(cmd)
    # print "(status, output) = (%s, %s)" % (status, output)
    count = 0
    for line in str(output).split():
        if name in line:
            count += 1

    if count > 1:
        raise Exception("process(%s) existed !" % name)


def initial_ntpd_address(log):
    server_address = DEFAULT_SERVER_ADDR
    try:
        server_address = get_server_address(log)
    except Exception as ept:
        server_address = DEFAULT_SERVER_ADDR
        log.error('initial ntpd address fail, error msg: %s' % repr(ept))
    finally:
        SRC_NTPD_ADDRESS.insert(0, server_address)


def main(mode=""):
    log = init_logger()
    log.info("Enter ntpdate-%s" % __version__)
    if mode == 'delay':
        delay = random.randint(1, 3600)
        log.info('start ntpdate after %d seconds' % delay)
        time.sleep(delay)
    log.info('start ntpdate')
    kill_ntpd(log)
    initial_ntpd_address(log)
    while True:
        if NTP_DATE_SUCCESS == check_time(log):
            os.system("[ -c /dev/rtc1 ] && hwclock -f /dev/rtc1 --utc --systohc")
            break
        else:
            time.sleep(30)
    return 0


# ############################# main block ##############################
if __name__ == '__main__':
    try:
        para = ""
        if len(sys.argv) > 1:
            para = sys.argv[1]
        # check_self(sys.argv)
        main(para)
    except Exception as e:
        print repr(e)

    sys.exit(0)

