#!/usr/bin/python
# -*- coding: utf-8 -*-
# version 1.3.0 w.h. increase log file size to 100KB

import os, sys
import socket
import ssl
import time
import xml.etree.ElementTree as ET

import paho.mqtt.client as mqtt
from datetime import datetime
import logging
import logging.handlers
import os
import commands


Src_AnyLink_xml = "/opt/sdmwebs/web/conf/AnyLink.xml"

logger = 0
ssl.match_hostname = lambda cert, hostname: True
DEFAULT_SYS_DATE = "2020-1-1"
MAX_CHECKNET_TIMES = 15

def init_logger():
    from logging.handlers import RotatingFileHandler
    global logger
    logger = logging.getLogger()
    rthandler = RotatingFileHandler('/PageFile/checknet.log', mode='a', maxBytes=100 * 1024, backupCount=1)
    formatter = logging.Formatter('%(asctime)s %(levelname)s----%(message)s')
    rthandler.setFormatter(formatter)
    logger.addHandler(rthandler)
    logger.setLevel(logging.INFO)
    return 0

def run_cmd(cmd):   
    (status, output) = commands.getstatusoutput(cmd)
    if output != "":
        return output.strip()
    else:
        return ""

def ProcessExist(processName):
    (status, output) = commands.getstatusoutput('ps | grep "%s" | grep -v grep' % processName)
    if output == '':
        return False
    else:
        return True

def killall(app_name):
    process_list = run_cmd('ps | grep {0} | grep -v grep'.format(app_name))
    if process_list == "" or process_list == None:
        return False
    process_list = process_list.split('\n')
    for P in process_list:
        items = P.split(' ')
        if len(items)>1 and (app_name in P):
            cmd = 'kill -9 {0}'.format(items[0])
            print '[killall]'+cmd
            os.system(cmd)
    return True

#waiting until date>2020-01-01
def waiting_default_date(log):
    while True:
        try:
            now_time = time.localtime()
            if now_time.tm_year >= 2020:
                break            
        except Exception as ept:
            log.error('wait default date fail, error msg: %s' % repr(ept))
        
        time.sleep(3)

class MqttNetCheck(object):
    def __init__(self):
        self.__topic = '/check/net/' + get_serial_no()
        self.__msg = '1'
        self.__host = ''
        self.__port = ''
        self._err_msg = ''
        self.__is_mqtts = False
        self._res = False

    def __get_mqtt_info(self):
        config_tree = ET.parse("/opt/agent/ModuleConfig.xml")
        mqtt_node = config_tree.find('./task/TaskDriver/driver[@n="T.IDrv.Task:libkmqtt"]')
        mqtt_config = mqtt_node.get('config').split(';')
        # mqtt_config[-2]为是否启用tls加密，1为启用
        self.__is_mqtts = bool(int(mqtt_config[-2]))
        self.__host = mqtt_config[0]
        self.__port = int(mqtt_config[1])

    def __on_connect(self, client, userdata, flags, rc):
        res = True
        if 0 == rc:
            try:
                client.subscribe(self.__topic)
                msg = client.publish(self.__topic, self.__msg, qos=1, retain=True)

            except Exception, e:
                res = False
                self._err_msg = "connect(%s): " % str(rc) + e.message
        else:
            res = False
            tip = "connect(%s): " % str(rc)
            if 1 == rc:
                self._err_msg = tip + "incorrect protocol version"
            elif 2 == rc:
                self._err_msg = tip + "invalid client id"
            elif 3 == rc:
                self._err_msg = tip + "server is not active"
            elif 4 == rc:
                self._err_msg = tip + "incorrect user or password"
            elif 5 == rc:
                self._err_msg = tip + "unable to verify "
            else:
                self._err_msg = tip + "unknown error"

        logger.debug("mqtt rc: %d" % rc)

        if not res:
            client.disconnect()

    def __on_message(self, client, userdata, msg):
        if str(msg.payload) == self.__msg and msg.topic == self.__topic:
            self._res = True
        else:
            self._res = False
            self._err_msg = "receive: unexpected message"
        client.disconnect()

    def __on_disconnect(self, client, userdata, rc):
        client.connected_flag = False
        client.disconnect_flag = True
        client.loop_stop()

    def __mqtt_connect(self):
        self.__get_mqtt_info()
        try:
            client_id = time.strftime('%d%H%M%S', time.localtime(time.time())) + '/' + get_serial_no()
            client = mqtt.Client(client_id)
            client.on_connect = self.__on_connect
            client.on_message = self.__on_message
            client.on_disconnect = self.__on_disconnect
            if self.__is_mqtts:
                client.tls_set(ca_certs='/opt/agent/pkis/MQTT/ca.cert', certfile='/opt/agent/pkis/MQTT/client.cert',
                               keyfile='/opt/agent/pkis/MQTT/client.key',
                               tls_version=ssl.PROTOCOL_TLSv1_2)
                client.tls_insecure_set(True)
            client.connect(self.__host, self.__port, 60)

            rc = 0
            count = 0
            while rc == 0:
                rc = client.loop(20)
                count += 1
                if count == 15:
                    rc = 1

        except Exception, e:
            self._res = False
            msg = ""
            for arg in e.args:
                msg += str(arg) + ", "
            self._err_msg = msg[:-2]

    def run(self):
        self.__mqtt_connect()
        if self._res != 1:
            logger.warning("mqtt: res=%d msg=%s" % (self._res, self._err_msg))
        else:
            logger.debug("mqtt: res=%d msg=%s" % (self._res, self._err_msg))
        return self._res


class HttpNetCheck(object):
    def __init__(self):
        self.__host = ''
        self.__port = ''
        self.__res = False
        self._err_msg = ''

    def __get_http_info(self):
        try:
            anylink_tree = ET.parse("/opt/sdmwebs/web/conf/AnyLink.xml")
            address = anylink_tree.find('CloudInfo/Address').text.strip()
            if ":" in address:
                self.__host = address.split(":")[0]
                self.__port = int(address.split(":")[1])
            else:
                self.__host = address
                self.__port = anylink_tree.find('CloudInfo/Http_port').text.strip()
        except Exception as e:
            self._err_msg = repr(e)
            self.__res = False

    def run(self):
        self.__get_http_info()
        try:
            ip_addr = socket.gethostbyname(self.__host)
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(5)
            sock.connect((ip_addr, int(self.__port)))
        except Exception as e:
            sock.close()
            self._err_msg = repr(e)
            self.__res = False
        else:
            self.__res = True

        if self.__res != 1:
            logger.warning("http: res=%d msg=%s" % (self.__res, self._err_msg))
        else:
            logger.debug("http: res=%d msg=%s" % (self.__res, self._err_msg))
        return self.__res


def get_serial_no():
    with open('/etc/devuaid.d', 'rb') as fp:
        serial_no = fp.readlines()[0].strip()
        return serial_no


def get_protocol():
    agent_conf_tree = ET.parse("/opt/agent/AgentConfig.xml")
    current_protocol = agent_conf_tree.find('Protocol').text
    return current_protocol


class NetCheck(object):
    @staticmethod
    def assert_reboot(seconds, count):
        return seconds >= 1200 and count > MAX_CHECKNET_TIMES

    @staticmethod
    def count(status, count):
        if status:
            return 0
        else:
            return count + 1

    @staticmethod
    def delay(status, delay):
        if status:
            r_delay = delay * 1.5
            if r_delay > 300:
                r_delay = 300
        else:
            r_delay = 10
        return r_delay

'''
when 4G online,QCMAP_ConnectionManager restart dnsmasq and reset dhcp address pool using /etc/mobileap_cfg.xml
this function reset dhcp address pool using /opt/sdmwebs/web/conf/AnyLink.xml
'''
def check_dnsmasq():
    #ps -A | grep -v 'grep'|grep dnsmasq | grep '192.168.101.20,192.168.101.60'
    #get setting from AnyLink.xml
    try:
        tree = ET.parse(Src_AnyLink_xml)
        root = tree.getroot()
        router_node = root.find('Router')
        ip_addr = router_node.find('IPAddr').text
        sub_net_mask = router_node.find('SubNetMask').text
        enable_dhcp = router_node.find('EnableDHCPServer').text
        start_ip = router_node.find('DHCPConfig/StartIP').text
        end_ip = router_node.find('DHCPConfig/EndIP').text
        if enable_dhcp == '1':
            cmd = "ps -A | grep -v 'grep'|grep dnsmasq | grep '%s,%s'" % (start_ip,end_ip)
            ret_cmd = run_cmd(cmd)
            if ret_cmd == "" or ret_cmd == None:
                logger.info('check_dnsmasq: restart dnsmasq' )
                #restart dnsmasq
                killall('dnsmasq')
                cmd = "dnsmasq -i {0} -I lo -z --dhcp-range={0},{1},{2},{3},43200 --dhcp-hostsfile=/etc/dhcp_hosts"\
                    "--dhcp-option-force=6,{4} --dhcp-option-force=26,1500 --dhcp-option-force=120,abcd.com"\
                    .format('bridge0', start_ip, end_ip, sub_net_mask, ip_addr)
                [status, res] = commands.getstatusoutput(cmd)
                logger.info("status: %s, reply: %s" % (str(status), res))


        '''
        log.info('router ip address: %s' % ip_addr)
        log.info('router netmask: %s' % sub_net_mask)
        log.info('DHCP enable: %s' % enable_dhcp)
        log.info('router dhcp start ip: %s' % start_ip)
        log.info('router dhcp end ip: %s' % end_ip)
        '''
    except Exception as ept:
        logger.error('check_dnsmasq:' + repr(ept) )


def main():
    init_logger()
    delay = 60
    count = 0
    #waiting_default_date(logger)
    start_time = datetime.now()
    status=False
    while True:
        try:
            now = datetime.now()
            
            logger.debug("c=%d d=%d" % (count, delay))
            protocol = get_protocol()
            if protocol == "mqtt":
                mqtt_check = MqttNetCheck()
                status = mqtt_check.run()
            else:
                http_check = HttpNetCheck()
                status = http_check.run()
            with open("/tmp/netstat", "w") as fd:
                fd.write("%s\n" % str(int(status)))

            count = NetCheck.count(status, count)
            delay = NetCheck.delay(status, delay)

            if status:
                start_time = now
            else:
                seconds = (datetime.now() - start_time).seconds
                # w.h. using time only will cause immature reboot when time is wrong,
                # using count only will depend on timeout, so combine them together
                # if seconds >= 1200 and count > 30:
                if NetCheck.assert_reboot(seconds, count):
                    logger.error("reboot, count=%d" % count)
                    os.system("/sbin/reboot")

            time.sleep(delay)
            check_dnsmasq()
        except Exception, ept:
            logger.error("main: " + repr(ept))


if __name__ == "__main__":
    main()
    sys.exit(0)
