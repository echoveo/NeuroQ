#!/bin/sh
if [ -n "$1" ];then
	if [ $1 -gt 0 ];then
		while true
		do
			ret=`ps -ef|grep "ec20_data_call"|grep -v "grep"|wc -l`
			if [ $ret -eq 0 ]
			then
				road=$(readlink -f "$(dirname "$0")")
				$road/ec20_data_call
			fi
			sleep 10
		done
	else
		killall "ec20_data_call"
	fi
fi