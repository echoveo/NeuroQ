#!/usr/bin/python
# -*- coding: UTF-8 -*-

# author: luoshuai
# version: 1.0.0
# date: 2020/7/10

#https://github.com/anylinkcloud/firmware/issues/16
#Hold reset button for 5 seconds, box will reset LAN port IP address to factory default (192.168.101.204)
#Hold reset button for 20 seconds, box will remove settings in AnyLink.xml and ModuleConfig.xml and reset these two files to factory default.

import os
import sys
import time
import logging
from logging.handlers import RotatingFileHandler

FILENAME = sys._getframe().f_code.co_filename
VERSION = "1.0.1"

GPIO_RESET = "/sys/class/gpio/gpio22/value"
# FactoryConfigFileScript = "/opt/sdmwebs/web/cgi-bin/init/init.py"

GPIO_ErrorState = "/sys/class/gpio/gpio25/value"
GPIO_CloudConnectionState = "/sys/class/gpio/gpio24/value"





def initial_log(log_name, debug):
    """定义一个RotatingFileHandler，最多备份2个日志文件，每个日志文件最大8K"""
    log = logging.getLogger()
    handler = RotatingFileHandler(log_name, maxBytes=1024 * 8, backupCount=2)
    formatter = logging.Formatter('%(asctime)s-%(levelname)s: %(message)s')
    handler.setFormatter(formatter)
    ch = logging.StreamHandler()
    ch.setFormatter(formatter)
    log.addHandler(handler)
    log.addHandler(ch)

    if debug is not None:
        log.setLevel(debug)
    else:
        log.setLevel(logging.WARNING)
    return log


def get_version(log):
    log.info(FILENAME + "-" + VERSION)


def reset_host_name(root):
    """保存hostname信息"""
    try:
        hostname = ''
        root.set('hostname', hostname)
    except Exception as e:
        print e


def light_led(value_path="", status="1"):
    try:
        with open(value_path, 'w') as fd:
            fd.write(status)
        return True, ""
    except Exception, ept:
        return False, repr(ept)


def light_all_led(status="1"):
    light_led(GPIO_CloudConnectionState, status)
    light_led(GPIO_ErrorState, status)



# run led before reboot
def run_led():
    light_all_led(status="0")
    light_all_led(status="1")
    time.sleep(0.5)
    light_all_led(status="0")
    time.sleep(0.5)
    light_all_led(status="1")
    time.sleep(0.5)
    light_all_led(status="0")


def reset_factory_config(log):
    log.info("Reset factory configure")
    run_led()
    os.system("cd /opt/sdmwebs/web/cgi-bin/init/ && python init.py")
    os.system("echo 0 > /etc/lockdown.tmp")
    os.system("sync && /sbin/shutdown -r now")


#hold reset button for 5 seconds,reset Lan ip to 192.168.101.204
def reset_lan_default(log):
    log.info("Reset Lan to default")
    run_led()
    os.system("cd /opt/sdmwebs/web/cgi-bin/init/ && python init.py reset_lan_ip")



def main(log):
    log.info("reset monitor start...")
    heart_beat = 0
    count = 0
    while True:
        time.sleep(1)
        heart_beat = heart_beat + 1
        if heart_beat >= 3600:
            heart_beat = 0
            log.info("reset monitor is running")
        try:
            res = ""
            with open(GPIO_RESET, 'r') as fd:
                res = fd.read().strip()

            if res == "0":
                log.info("reset button is pressed")
                count = count + 1
                if count >= 15:
                    log.info("reset factory configure")
                    reset_factory_config(log)
                    count = 0

            if res == "0":
                log.info("reset button is pressed")
                count = count + 1
                if count == 5:
                    log.info("reset factory Lan IP to default")
                    reset_lan_default(log)
                    count = 6

            if (res == "1") and (count > 0):
                if count >= 15:
                    log.info("reset factory configure")
                    reset_factory_config(log)
                    count = 0
                else:
                    log.info("reset time is not arrive, reset count flag")
                    count = 0
        except Exception as ex:
            log.error(ex.message)
            time.sleep(10)


if __name__ == '__main__':
    logLevel = logging.DEBUG
    if len(sys.argv) > 1:
        level = int(sys.argv[1])
        if level == 100:
            logLevel = logging.ERROR
        elif level == 200:
            logLevel = logging.WARN
        elif level == 300:
            logLevel = logging.INFO
        else:
            logLevel = logging.DEBUG
    logger = initial_log('/PageFile/Reset.log', logLevel)
    get_version(logger)
    main(logger)
    sys.exit(0)
