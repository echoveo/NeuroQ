#!/usr/bin/python
# -*- coding: UTF-8 -*-
import json
import commands

from bottle import route, request,run
import globalConfig
from hardwareConfig import adc
from hardwareConfig import net_ethernet
from hardwareConfig import net_wifi
from hardwareConfig import gpio
from hardwareConfig import systeminfo


def response_error(code,msg):
    return json.dumps({"errcode":code,"msg":msg})

def response_excepiton(msg):
    return json.dumps({"errcode":501,"msg":'excepiton:%s'%(msg)})

def response_data(data):
    return json.dumps({"code":200,"data":data})

@route('/globalConfig', method='GET')
def WEBAPI_globalConfig():
    try:
        (H,S) = globalConfig.getConfig()
        return response_data({"hardwareConfig":H,"softwareConfig":S})
    except Exception as ept:
        return response_excepiton(repr(ept))
        

#host:port/hw_autodetect?device=ethernet
@route('/hw_autodetect', method='GET')
def WEBAPI_hw_autodetect():
    ret = True
    info = None
    try:
        if request.query.device == 'ethernet':
            (ret,info) = net_ethernet.autodetect()
            if ret:
                (status, output) = commands.getstatusoutput("ifconfig %s | grep HWaddr | awk  '{print $5}'" % (info['WAN']))      
                info['WAN-MAC'] = output
        elif request.query.device == 'adc':
            (ret,info) = adc.autodetect()
        elif request.query.device == 'wifi':
            (ret,info) = net_wifi.autodetect()
        elif request.query.device == 'gpio':
            (ret,info) = gpio.autodetect()     
        elif request.query.device == 'systeminfo':
            (ret,info) = systeminfo.autodetect()        
        else:
            return response_error(1000,"exp. http://host:8080/hw_autodetect?device=ethernet   query params: device = [adc | ethernet]")
        return response_data({"ret":ret,"info":info})
    except Exception as ept:
        return response_excepiton(repr(ept))
    

run(host='127.0.0.1', port=8080)