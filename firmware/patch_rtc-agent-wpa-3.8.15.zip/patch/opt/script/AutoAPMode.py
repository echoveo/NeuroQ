#!/usr/bin/python
# -*- coding: UTF-8 -*-

# author: kali
# version: 1.0.0
# date: 2021/10/20

# 检查接入的U盘中是否有/media/usb/IEProApCfg.conf 这个文件，如果有
# 检查是否有 IEProApMode 关键字，
# 通过上述检查后 以/media/usb/IEProApCfg.conf为配置文件，运行Wifi-AP
# /media/usb/IEProApCfg.conf为配置文件 样例见本代码最后部分
import os
import sys
import time
import logging
import psutil
import xml.etree.ElementTree
import commands
from logging.handlers import RotatingFileHandler

FILENAME = sys._getframe().f_code.co_filename
VERSION = "1.0.2"
USB_APCFG_PATH = "/media/usb1/IEProApCfg.conf"
Src_AnyLink_xml = "/opt/sdmwebs/web/conf/AnyLink.xml"

def initial_log(log_name, debug):
    """定义一个RotatingFileHandler，最多备份2个日志文件，每个日志文件最大8K"""
    log = logging.getLogger()
    handler = RotatingFileHandler(log_name, maxBytes=1024 * 8, backupCount=2)
    formatter = logging.Formatter('%(asctime)s-%(levelname)s: %(message)s')
    handler.setFormatter(formatter)
    ch = logging.StreamHandler()
    ch.setFormatter(formatter)
    log.addHandler(handler)
    log.addHandler(ch)

    if debug is not None:
        log.setLevel(debug)
    else:
        log.setLevel(logging.WARNING)
    return log


def get_version(log):
    log.info(FILENAME + "-" + VERSION)


def light_led(value_path="", status="1"):
    try:
        with open(value_path, 'w') as fd:
            fd.write(status)
        return True, ""
    except Exception, ept:
        return False, repr(ept)



# 这个比较占用cpu
def ProcessExist_v1(processName):
    process_list = psutil.pids()
    try:
        for pid in process_list:
            process = psutil.Process(pid)
            if processName in process.name():
                return True
                #break
    except Exception, e:
        pass
    return False

def ProcessExist(processName):
    (status, output) = commands.getstatusoutput('ps | grep "%s" | grep -v grep' % processName)
    if output == '':
        return False
    else:
        return True

def load_wifi_driver(log):
    retry = 5
    n = 0
    while n < retry:
        try:
            time.sleep(2)
            os.system('/etc/init.d/wlan start')
            time.sleep(5)
            (status, output) = commands.getstatusoutput('/sbin/ifconfig -a | grep "wlan0"')    
            if output == '':
                log.info('load_wifi_driver fail retry times=%d' % n)
            else:
                log.info('load_wifi_driver success')
                return True
            n += 1
        except Exception as ept:
            n += 1
            log.error('load_wifi_driver fail, error msg: %s' % repr(ept))
            time.sleep(3)
        else:
            return False
    return False

def stop_AP(log):
    if ProcessExist("hostapd"):
        log.info("AutoAPMode ,stop Wifi-AP")
        os.system("brctl delif bridge0 wlan1")
        os.system("killall hostapd")
        os.system("ifconfig wlan1 down;iw dev wlan1 del")
        log.info("AutoAPMode ,stop Wifi-AP finished")
        time.sleep(3)
        
def start_AP(log):
    if not ProcessExist("hostapd"):  
        log.info("AutoAPMode ,start Wifi-AP")  
        (status, output) = commands.getstatusoutput('/sbin/ifconfig -a | grep "wlan0"')
        if output == '':
            # if wlan0 not exist;load wifi driver
            if load_wifi_driver(log) == False:
                log.info('load wifi driver fail! exit')
                return -1
            
        (status, output) = commands.getstatusoutput('/sbin/ifconfig | grep "wlan0"')
        if output == '':
            os.system('/sbin/ifconfig wlan0 up')
            time.sleep(3)

        os.system("iw phy phy0 interface add wlan1 type managed")
        os.system("ifconfig wlan1 up")
        os.system("hostapd %s &" % USB_APCFG_PATH)
        os.system("brctl addif bridge0 wlan1")
        log.info("AutoAPMode ,start Wifi-AP finished")
        time.sleep(3)

def start_DHCP(log):
    if ProcessExist("dnsmasq") == False:
        log.info('start dnsmasq server')
        
        tree = xml.etree.ElementTree.parse(Src_AnyLink_xml)
        root = tree.getroot()
        router_node = root.find('Router')
        ip_addr = router_node.find('IPAddr').text
        sub_net_mask = router_node.find('SubNetMask').text
        enable_dhcp = router_node.find('EnableDHCPServer').text
        start_ip = router_node.find('DHCPConfig/StartIP').text
        end_ip = router_node.find('DHCPConfig/EndIP').text
        cmd = "dnsmasq -i {0} -I lo -z --dhcp-range={0},{1},{2},{3},43200 --dhcp-hostsfile=/etc/dhcp_hosts"\
            "--dhcp-option-force=6,{4} --dhcp-option-force=26,1500 --dhcp-option-force=120,abcd.com"\
            .format('bridge0', start_ip, end_ip, sub_net_mask, ip_addr)
        [status, res] = commands.getstatusoutput(cmd)
        log.info("status: %s, reply: %s" % (str(status), res))

def main(log):
    log.info("AutoAPMode monitor start...")
    heart_beat = 0
  
    while True:
        time.sleep(3)
        heart_beat = heart_beat + 1
        if heart_beat >= 3600:
            heart_beat = 0
            log.info("AutoAPMode  monitor is running")
        try:
            res = ""
            if os.path.isfile(USB_APCFG_PATH):
                (status, output) = commands.getstatusoutput('cat %s -a | grep "IEProApMode"' % USB_APCFG_PATH)
                if output != "":
                    #log.info("%s exist and valid" % USB_APCFG_PATH)
                    start_AP(log)
                    start_DHCP(log)
            else:
                stop_AP(log)

        except Exception as ex:
            log.error(ex.message)
            time.sleep(10)


if __name__ == '__main__':
    logLevel = logging.DEBUG
    if len(sys.argv) > 1:
        level = int(sys.argv[1])
        if level == 100:
            logLevel = logging.ERROR
        elif level == 200:
            logLevel = logging.WARN
        elif level == 300:
            logLevel = logging.INFO
        else:
            logLevel = logging.DEBUG
    logger = initial_log('/PageFile/AutoAPMode.log', logLevel)
    get_version(logger)   
    main(logger)
    sys.exit(0)



#example config file ; paste below contents to "/media/usb/IEProApCfg.conf"

# ##### hostapd configuration file ##############################################
# # Empty lines and lines starting with # are ignored
# # IEProApMode
# interface=wlan1

# bridge=bridge0

# driver=nl80211

# logger_syslog=-1
# logger_syslog_level=2
# logger_stdout=-1
# logger_stdout_level=2


# ctrl_interface=/var/run/hostapd

# ctrl_interface_group=0


# ssid=IEProCfg_1


# country_code=US



# hw_mode=g

# channel=11

# beacon_int=100

# dtim_period=2

# macaddr_acl=0
# ignore_broadcast_ssid=0

# wmm_enabled=1
# wmm_ac_bk_cwmin=4
# wmm_ac_bk_cwmax=10
# wmm_ac_bk_aifs=7
# wmm_ac_bk_txop_limit=0
# wmm_ac_bk_acm=0
# wmm_ac_be_aifs=3
# wmm_ac_be_cwmin=4
# wmm_ac_be_cwmax=10
# wmm_ac_be_txop_limit=0
# wmm_ac_be_acm=0
# wmm_ac_vi_aifs=2
# wmm_ac_vi_cwmin=3
# wmm_ac_vi_cwmax=4
# wmm_ac_vi_txop_limit=94
# wmm_ac_vi_acm=0
# wmm_ac_vo_aifs=2
# wmm_ac_vo_cwmin=2
# wmm_ac_vo_cwmax=3
# wmm_ac_vo_txop_limit=47
# wmm_ac_vo_acm=0

# ieee80211n=1

# obss_interval=10

# eap_server=1

# wpa=2

# wpa_passphrase=11223344


# wpa_key_mgmt=WPA-PSK

# wpa_pairwise=CCMP

# wpa_group_rekey=600