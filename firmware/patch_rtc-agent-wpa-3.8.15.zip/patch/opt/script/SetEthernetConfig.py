#!/usr/bin/python
# -*- coding: UTF-8 -*-
import os
import sys
import time
import socket
import thread
import shutil
import commands
import xml.etree.ElementTree
import logging
import psutil
import subprocess
import datetime

from logging.handlers import RotatingFileHandler

FILENAME = sys._getframe().f_code.co_filename
VERSION = "1.0.6"

ETH_WAN_MODE='FIXED-WL'     #wan口模式   FIXED-WL:以太网固定为WAN+LAN 无论wifi，或者4G是什么模式
                        #            AUTO-WL:当wan为4G，或者wifi模式时， 以太网切换为双LAN模式


FORCE_WIFI_OPEN = True      #是否强制wifi打开

#wifi模块路径
scriptConfig_path = "/opt/script/ScriptConfig.xml"
#Wifi连接脚本名称
WifiScript = 'wpa_module.py'
#wifi模块名称
WifiModule = 'FC20'
#模块对应文件目录
WifiModuleDir = '/opt/script/WiFi/FC20'
#Wifi连接配置文件
WifiConf = '/opt/script/WiFi/FC20/wpa_supplicant.conf'
#无线网卡名
WifiIf = 'wlan0'

Src_AnyLink_xml = "/opt/sdmwebs/web/conf/AnyLink.xml"
Tmp_AnyLink_xml = "/tmp/Tmp_AnyLink.xml"

AgentState = 0
GPIO_ErrorState = "/sys/class/gpio/gpio25/value"
GPIO_CloudConnectionState = "/sys/class/gpio/gpio24/value"
GPIO_MobileSignalStrength = "/sys/class/gpio/gpio11/value"
GPIO_MobileMode = "/sys/class/gpio/gpio42/value"


dhcp_trans = {"YES": "dhcp", "NO": "static"}


def initial_log(log_name, debug):
    """定义一个RotatingFileHandler，最多备份2个日志文件，每个日志文件最大64K"""
    log = logging.getLogger()
    try:
        handler = RotatingFileHandler(log_name, maxBytes=64 * 1024, backupCount=2)
        formatter = logging.Formatter('%(asctime)s-%(levelname)s: %(message)s')
        handler.setFormatter(formatter)
        ch = logging.StreamHandler()
        ch.setFormatter(formatter)
        log.addHandler(handler)
        log.addHandler(ch)
        
        if debug is not None:
            log.setLevel(debug)
        else:
            log.setLevel(logging.WARNING)
        log.info('begin...')
    except Exception, e:
        #when mmc card is corrupted(ext4_lookup inode error) switch file to wifi-second.log
        handler = RotatingFileHandler('/PageFile/SetEthernetConfig-sec.log', maxBytes=64 * 1024, backupCount=2)
        formatter = logging.Formatter('%(asctime)s-%(levelname)s: %(message)s')
        handler.setFormatter(formatter)
        ch = logging.StreamHandler()
        ch.setFormatter(formatter)
        log.addHandler(handler)
        log.addHandler(ch)
        
        if debug is not None:
            log.setLevel(debug)
        else:
            log.setLevel(logging.WARNING)
        log.info('begin... (MMC corrupted)')
    return log


def get_version(log):
    log.info(FILENAME + "-" + VERSION)


def light_led(led, value):
    if os.path.isfile(led):
        with open(led, 'w') as fd:
            fd.write(str(value))

#获取wifi配置
def get_wifi_cfg():
    global scriptConfig_path, WifiScript, WifiModuleDir, WifiConf, WifiIf, WifiModule
    try:
        
        scriptTree = xml.etree.ElementTree.parse(scriptConfig_path) 

        scriptWifiNode = scriptTree.find('WiFi')

        WifiModuleDirNode = scriptWifiNode.find('WifiModuleDir')
        WifiModuleDir = WifiModuleDirNode.text

        WifiScriptNode = scriptWifiNode.find('WifiScript')
        WifiScript = WifiScriptNode.text

        WifiDirNode = scriptWifiNode.find('WifiDir')
        WifiDir = WifiDirNode.text

        WifiConfNode = scriptWifiNode.find('WifiConf')
        WifiConf = WifiConfNode.text
        WifiConf = WifiModuleDir + WifiConf
        

        WifiIfNode = scriptWifiNode.find('WifiIf')
        WifiIf = WifiIfNode.text

        WifiModuleNode = scriptWifiNode.find('WifiModule')
        WifiModule = WifiModuleNode.text
    except Exception as ept:
        pass

# ###################### ethernet config start ##########################
def dial_4g(log=None):
    try:
        log.info('Start dial up for 4G mode')
        cmd = "/opt/script/pppd/pppd_control.sh 1 >/dev/null 2>&1 &"
        os.system(cmd)
        os.system('iptables -t nat -A POSTROUTING -o rmnet_data0 -j MASQUERADE')
    except Exception as e:
        print (repr(e))

##发现emac处于suspend状态时，重新上电
def powerup_qcom_emac(log=None):
    log.info('powerup_qcom_emac enter')
    (status, output) = commands.getstatusoutput("cat /sys/devices/7c40000.qcom,emac/power/runtime_status")
    if output != "active":
        log.info('powerup_qcom_emac runtime_status is powerdown , active it')
        os.system("echo 'on' >| /sys/devices/7c40000.qcom,emac/power/control")     
        time.sleep(3)
    log.info('powerup_qcom_emac leave')

def powerauto_qcom_emac(log=None):
    log.info('powerauto_qcom_emac enter')
    (status, output) = commands.getstatusoutput("/sys/devices/7c40000.qcom,emac/power/control")
    if output != "auto":
        log.info('powerauto_qcom_emac runtime_control not equal auto ,set it to auto')
        os.system("echo 'auto' >| /sys/devices/7c40000.qcom,emac/power/control")     
        time.sleep(1)
    log.info('powerauto_qcom_emac leave')    
#   配置qca8337 vlan模式，LW eth0.1=Lan eth0.2=Wan
#
#
def config_vlan(log=None):
    powerup_qcom_emac(log)
    os.system("echo \"c LW\">/sys/kernel/debug/qca8337/vlan")
    os.system("vconfig add eth0 1")
    os.system("vconfig add eth0 2")
    os.system("vconfig set_flag eth0.1 1 1")
    os.system("vconfig set_flag eth0.2 1 1")
    os.system("ifconfig eth0 0.0.0.0")
    os.system("ifconfig eth0.1 0.0.0.0")
    os.system("ifconfig eth0.1 down")
    os.system("ifconfig eth0.2 down")
    os.system("brctl delif bridge0 eth0")
    os.system("brctl delif bridge0 eth0.2")
    os.system("brctl addif bridge0 eth0.1")
    os.system("ifconfig eth0.1 up")
    os.system("ifconfig eth0.2 up")
    powerauto_qcom_emac(log)
    #time.sleep(1)
    #os.system("echo \"c LW\">/sys/kernel/debug/qca8337/vlan")
    return 0

#   删除qca8337 vlan模式，qca8337进入默认switch模式
#
#
def config_del_vlan(log=None):
    os.system('echo "d">/sys/kernel/debug/qca8337/vlan')
    os.system("brctl delif bridge0 eth0.1")
    os.system("brctl delif bridge0 eth0.2")
    os.system('vconfig rem eth0.1')
    os.system('vconfig rem eth0.2')
    os.system('brctl addif bridge0 eth0')
    os.system('ifconfig eth0 down')
    os.system('ifconfig eth0 up')
    return 0

def isProcessRunning(name):
    (status, output) = commands.getstatusoutput('ps | grep "%s" | grep -v grep' % name)
    if output == '':
        return False
    else:
        return True

def execute_command(cmdstring, timeout=None):
    if timeout:
        end_time = datetime.datetime.now() + datetime.timedelta(seconds=timeout)
    timeout_tmp=timeout
    #sub = subprocess.Popen(cmdstring, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,stdin=subprocess.PIPE, bufsize=4096, shell=True)
    sub = subprocess.Popen(cmdstring, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, bufsize=4096, shell=True)
 
    while True:
        if sub.poll() is not None:
            break
        time.sleep(0.1)
        
        if timeout_tmp!=None and timeout_tmp<=0.0:
            #if end_time <= datetime.datetime.now():
            print "cmd=",cmdstring ,'is timeout kill it'
            sub.kill()
            return ""   #TIME_OUT
        timeout_tmp-=0.1
    #print "[execute_command]",cmdstring
    #print "[execute_command]","sub=",sub.stdout
    if sub.stdout == None:
        return ""
    else:
        return str(sub.stdout.read()).strip()
def run_cmd(cmd,wait=True,wait_timeout=10):
    if wait==False:
        os.system(cmd)
    else:
        return execute_command(cmdstring=cmd,timeout=wait_timeout)

def killall(app_name):
    process_list = run_cmd('ps | grep {0} | grep -v grep'.format(app_name))
    if process_list == "" or process_list == None:
        return False
    process_list = process_list.split('\n')
    for P in process_list:
        items = P.split(' ')
        if len(items)>1 and (app_name in P):
            cmd = 'kill -9 {0}'.format(items[0])
            print '[killall]'+cmd
            os.system(cmd)
    return True 

#检查eth0是否已经加载  注意检查/etc/init.d/start_emac_le 里是否注释掉set -e 忽略错误
def startEth0Loop(log):
    retry = 20
    n = 0
    while n < retry:
        try:            
            #检查eth0是否存在
            (status, output) = commands.getstatusoutput('/sbin/ifconfig -a | grep "eth0"')
            if output != '':
                log.info('startEth0Loop eth0 is loaded')
                time.sleep(3)
                break
            else:
                log.info('startEth0Loop eth0 is not loaded,load it begin')
                os.system("/etc/init.d/start_emac_le start" )
                log.info('startEth0Loop eth0 is not loaded,load it end')
            n += 1
            time.sleep(3)
        except Exception as ept:
            n += 1
            if log is not None:
                log.error('startEth0Loop fail, error msg: %s' % repr(ept))
            time.sleep(3)

#启动wifi并检查状态，如果状态不正常，会重复启动
def startWpaIfNotExistLoop(log):
    retry = 20
    n = 0
    while n < retry:
        try:
            startWpaIfNotExist(log)
            #检查wlan0 wpa_module is running
            (status, output) = commands.getstatusoutput('/sbin/ifconfig -a | grep "wlan0"')
            if isProcessRunning(WifiScript) == True and output != '':
                log.info('process %s is running' % WifiScript)
                break
            else:
                log.info('process %s is not running,first kill it' % WifiScript)
                os.system("killall %s" % WifiScript)
                log.info('process %s is not running,restart it' % WifiScript)
            n += 1
            time.sleep(3)
        except Exception as ept:
            n += 1
            if log is not None:
                log.error('startWpaIfNotExistLoop fail, error msg: %s' % repr(ept))
            time.sleep(3)
       
    

# 启动wifi
#
#
def startWpaIfNotExist(log):
    get_wifi_cfg()
    time.sleep(1)   #等待一些脚本进程退出，否则很容易导致psutil报进程找不到的异常 ，等待wlan可以进入加载状态，这很重要
    process_list = psutil.pids()
    isExist = False
    try:
        isExist = isProcessRunning(WifiScript)
        # for pid in process_list:
        #     try:
        #         process = psutil.Process(pid)
        #         if WifiScript in process.name():
        #             isExist = True
        #             break
        #     except Exception, e01:
        #         log.error('psutil.Process(pid) ex:' % repr(e01))
        #         pass
        if isExist == False:
            wait_seconds=0
            (status, output) = commands.getstatusoutput('/sbin/ifconfig -a | grep "wlan0"')
            if output == '':
                #如果wifi 驱动未加载，需要sleep一段时间，以等待加载成功
                wait_seconds = 12
            WifiScriptFullPath = WifiModuleDir + WifiScript
            cmdStr = WifiScriptFullPath + ' &'
            os.system(cmdStr)
            if wait_seconds>0:
                log.info('waiting for wifi device boot-up') 
                time.sleep(wait_seconds)
        else:
            log.info('process wpa_module.py is running,nothing to do ') 
        
    except Exception, e:
        log.error('startWpaIfNotExist ex:%s' % repr(e))
        pass    


'''
mode=WL  WAN+LAN
mode=LL  LAN+LAN
default mode=WL
'''
def config_eth(mode,wan_ip_addr,wan_ip_mask,wan_gate_way,wan_dns,wan_dhcp,log):
    if mode =='WL':
        config_vlan(log)
        if wan_dhcp == 'YES' :
            os.system("killall udhcpc")
            os.system("udhcpc -i eth0.2 -s /etc/udhcpc.d/50default &")
        else:
            os.system("/sbin/ifconfig eth0.2 {0} netmask {1}".format(wan_ip_addr, wan_ip_mask))
            os.system("/sbin/route add default gw {0} dev eth0.2 metric 10".format(wan_gate_way))
            flush_dns_cmd = "grep \"{0}\" /etc/resolv.conf || echo \"nameserver {0}\" >> /etc/resolv.conf". \
                format(wan_dns)
            with open("/opt/script/flush_dns.sh", "w+") as fd:
                fd.write(flush_dns_cmd)
            os.system(flush_dns_cmd)
            os.system("sync")
            
        os.system('echo 1 > /proc/sys/net/ipv4/ip_forward')
        os.system('iptables -t nat -A POSTROUTING -o eth0.2 -j MASQUERADE')
    elif mode =='LL':
        config_del_vlan(log)


#   配置网络WAN
#   1。当wan_type = 'gateway' 时 vlan=LW eth0.2为wan口，设备以有线方式连接外网 eth0.1并入bridge0
#   2。当wan_type = '4G' 时 无 vlan，qca8337进入 switch模式，设备以4G连接外网 eth0并入bridge0 
#   3. 当wan_type = 'wifi' 时 无vlan,qca8337进入 switch模式，设备以4G连接外网 eth0并入bridge0 
#
def config_WAN(root=None,wan_type='gateway',log=None):
    try:
        node_name = root.find('NetworkInfo/WAN')
        eth0_ip_addr = node_name.get("ip", default=None)
        eth0_ip_mask = node_name.get("mask", default=None)
        eth0_gate_way = node_name.get("gateway", default=None)
        eth0_dns = node_name.get("dns", default=None)
        eth0_dhcp = node_name.get("dhcp", default=None)
    except Exception as ept:
        log.error('Get NetworkInfo fail in AnyLink.xml, error msg: %s' % repr(ept))
        return -1

    if None in [eth0_ip_addr, eth0_ip_mask, eth0_gate_way, eth0_dns, eth0_dhcp]:
        log.error('Get NetworkInfo fail in AnyLink.xml, there is None information')
        return -1
    
    log.info("IP:%s" % eth0_ip_addr)
    log.info("Mask:%s" % eth0_ip_mask)
    log.info("Gateway:%s" % eth0_gate_way)
    log.info("DNS:%s" % eth0_dns)
    log.info("DHCP:%s" % eth0_dhcp)

    try:
        #eth_mode='WL'
        os.system('iptables -F')
        os.system('iptables -t nat -F')
        if ETH_WAN_MODE=='FIXED-WL':
            if wan_type == 'gateway':
                config_eth(mode="WL",wan_ip_addr=eth0_ip_addr,wan_ip_mask=eth0_ip_mask,wan_gate_way=eth0_gate_way,wan_dns=eth0_dns,wan_dhcp=eth0_dhcp,log=log)
            elif wan_type == '4G':
                print "in {0} mode 4G".format(wan_type)
                dial_4g(log)
                config_eth(mode="WL",wan_ip_addr=eth0_ip_addr,wan_ip_mask=eth0_ip_mask,wan_gate_way=eth0_gate_way,wan_dns=eth0_dns,wan_dhcp=eth0_dhcp,log=log)
                startWpaIfNotExistLoop(log) #4G状态下，我们也打开wifi,让wifi永远工作
            elif wan_type == 'wifi':
                print "in {0} mode WIFI".format(wan_type)            
                config_eth(mode="WL",wan_ip_addr=eth0_ip_addr,wan_ip_mask=eth0_ip_mask,wan_gate_way=eth0_gate_way,wan_dns=eth0_dns,wan_dhcp=eth0_dhcp,log=log)
                startWpaIfNotExistLoop(log)
            
        elif ETH_WAN_MODE=='AUTO-WL':
            if wan_type == 'gateway':
                config_eth(mode="WL",wan_ip_addr=eth0_ip_addr,wan_ip_mask=eth0_ip_mask,wan_gate_way=eth0_gate_way,wan_dns=eth0_dns,wan_dhcp=eth0_dhcp,log=log)
            elif wan_type == '4G':
                print "in {0} mode 4G".format(wan_type)
                dial_4g(log)
                config_eth(mode="LL",wan_ip_addr=eth0_ip_addr,wan_ip_mask=eth0_ip_mask,wan_gate_way=eth0_gate_way,wan_dns=eth0_dns,wan_dhcp=eth0_dhcp,log=log)
            elif wan_type == 'wifi':
                print "in {0} mode WIFI".format(wan_type)            
                config_eth(mode="LL",wan_ip_addr=eth0_ip_addr,wan_ip_mask=eth0_ip_mask,wan_gate_way=eth0_gate_way,wan_dns=eth0_dns,wan_dhcp=eth0_dhcp,log=log)
                startWpaIfNotExistLoop(log)
    except Exception, e:
        log.error("eth0 set error: %s" % repr(e))
        return -1
    return 0


# ###################### ethernet config end ############################





def check_mobileap_cfg(ip_addr, sub_net_mask, enable_dhcp, start_ip, end_ip, log, path="/etc/mobileap_cfg.xml"):
    try:
        tree = xml.etree.ElementTree.parse(path)
        root = tree.getroot()
        ap_root = root.find('MobileAPCfg/MobileAPLanCfg')
        if ap_root is None:
            return 0

        if_edit = 0
        node = ap_root.find('APIPAddr')
        if ip_addr != node.text:
            node.text = str(ip_addr)
            if_edit = 1

        node = ap_root.find('SubNetMask')
        if sub_net_mask != node.text:
            node.text = str(sub_net_mask)
            if_edit = 1

        node = ap_root.find('EnableDHCPServer')
        if enable_dhcp != node.text:
            node.text = str(enable_dhcp)
            if_edit = 1

        if enable_dhcp == "1":
            node = ap_root.find('DHCPCfg/StartIP')
            if start_ip != node.text:
                node.text = str(start_ip)
                if_edit = 1

            node = ap_root.find('DHCPCfg/EndIP')
            if end_ip != node.text:
                node.text = str(end_ip)
                if_edit = 1

        if if_edit == 1:
            log.info("set new config:\nip_addr: %s\nsub_net_mask: %s\nenable_dhcp: %s\nstart_ip: %s\nend_ip: %s"
                     % (ip_addr, sub_net_mask, enable_dhcp, start_ip, end_ip))
            tree.write(path)
            os.system('sync')
    except Exception as ept:
        log.error("check mobileap_cfg.xml fail, error msg: %s" % repr(ept))
        return 0

    return if_edit

#   配置路由器本身的ip地址和相关信息
#   配置路由器本身
#   目前不用
def config_router(root=None, log=None):
    """
    set router ethernet config
    :param root: AmyLink.xml root
    :param log: log handler
    :return:
    -1, return Exception
    0, not router mode
    1, router mode
    """
    log.info('Set dhcp for router')
    ret = 0
    try:
        router_node = root.find('Router')
        if router_node is not None :
            ret = 1
            ip_addr = router_node.find('IPAddr').text
            sub_net_mask = router_node.find('SubNetMask').text
            enable_dhcp = router_node.find('EnableDHCPServer').text
            start_ip = router_node.find('DHCPConfig/StartIP').text
            end_ip = router_node.find('DHCPConfig/EndIP').text
            log.info('router ip address: %s' % ip_addr)
            log.info('router netmask: %s' % sub_net_mask)
            log.info('DHCP enable: %s' % enable_dhcp)
            log.info('router dhcp start ip: %s' % start_ip)
            log.info('router dhcp end ip: %s' % end_ip)

            check_mobileap_cfg(ip_addr, sub_net_mask, enable_dhcp, start_ip, end_ip, log)
            #ip_addr, sub_net_mask, enable_dhcp, start_ip, end_ip, log, path="/etc/mobileap_cfg.xml"

            ip_addr_head, ip_addr_end = str(ip_addr).strip().rsplit('.', 1)
            start_ip_head, start_ip_end = str(start_ip).strip().rsplit('.', 1)
            end_ip_head, end_ip_end = str(end_ip).strip().rsplit('.', 1)

            if ip_addr_head != start_ip_head or ip_addr_head != end_ip_head:
                raise Exception('router config must be in the same segment')
            #if not (0 <= int(ip_addr_end) < int(start_ip_end) < int(end_ip_end) <= 255):
            #    raise Exception('router config must be: 0 <= ip addr < start ip < end ip <= 255')
            
            #从/etc/init_ip中获取地址 这是测试程序写进的，测试完毕后需要删除
            (status, output) = commands.getstatusoutput('test -f /etc/init_ip && cat /etc/init_ip')
            if output != "":
                ip_addr = output.strip()

            os.system("ifconfig bridge0 {0} netmask {1}".format(ip_addr, sub_net_mask))
            os.system("kill `ps -ef | grep dnsmasq | grep -v grep | awk '{print $1}'`")
            if enable_dhcp == '1':
                log.info('restart dnsmasq server')
                cmd = "dnsmasq -i {0} -I lo -z --dhcp-range={0},{1},{2},{3},43200 --dhcp-hostsfile=/etc/dhcp_hosts"\
                    "--dhcp-option-force=6,{4} --dhcp-option-force=26,1500 --dhcp-option-force=120,abcd.com"\
                    .format('bridge0', start_ip, end_ip, sub_net_mask, ip_addr)
                [status, res] = commands.getstatusoutput(cmd)
                log.info("status: %s, reply: %s" % (str(status), res))

            try:
                node_WAN = root.find('NetworkInfo/WAN')
                dns = node_WAN.get("dns", default=None)
            except Exception as ept:
                log.error('Get NetworkInfo fail in AnyLink.xml, error msg: %s' % repr(ept))
                return -1
            
            flush_dns_cmd = "grep \"{0}\" /etc/resolv.conf || echo \"nameserver {0}\" >> /etc/resolv.conf". \
                            format(dns)
            with open("/opt/script/flush_dns.sh", "w+") as fd:
                fd.write(flush_dns_cmd)
            os.system(flush_dns_cmd)
            os.system("sync")


    except Exception as ept:
        log.error(repr(ept))
        ret = -1

    return ret


def initial_xml(log=None):
    retry = 3
    n = 0
    while n < retry:
        try:
            if os.path.isfile(Src_AnyLink_xml):
                shutil.copyfile(Src_AnyLink_xml, Tmp_AnyLink_xml)
                os.system('sync')
            else:
                log.error('There is not file %s' % Src_AnyLink_xml)
        except Exception as ept:
            n += 1
            if log is not None:
                log.error('Initial AnyLink.xml fail, error msg: %s' % repr(ept))
            time.sleep(3)
        else:
            return 0
    return -1


def set_default_network(log):
    log.warn('default: ifconfig bridge0 192.168.101.204 netmask 255.255.255.0')
    os.system('ifconfig bridge0 192.168.101.204 netmask 255.255.255.0')
    log.warn('default: qca8337 in switch mode')
    config_del_vlan(log)
    # default, dial up for 4G mode
    log.warn('default: dial up for 4G mode')
    dial_4g(log)
    #cmd = "/opt/script/pppd/pppd_control.sh 1 >/dev/null 2>&1 &"
    #os.system(cmd)

def config_network(root=None, mode=None, log=None):
    log.info('Set mode for %s' % str(mode))

    #if mode == 'wifi':
    startEth0Loop(log)      #检查eth0是否已经加载
    config_router(root,log) #dhcp,本机地址，dns等
    return config_WAN(root, mode, log)

#检查网络是否处于loopback模式
#loopback是指用一条网线将两个口对接起来，在这种模式下
def firstcheck_loopback(log):
    log.warn('[firstcheck_loopback] begin...')
    startEth0Loop(log)
    os.system("echo 'on' >| /sys/devices/7c40000.qcom,emac/power/control")
    os.system("sleep 1")
    os.system("echo \"c LW\">/sys/kernel/debug/qca8337/vlan")
    os.system("sleep 1")
    os.system("vconfig add eth0 1")
    os.system("vconfig add eth0 2")
    os.system("ifconfig eth0.1 hw ether 00:A4:0B:10:00:20")
    os.system("ifconfig eth0.2 hw ether 00:A4:0B:10:00:21")
    os.system("vconfig set_flag eth0.1 1 1")
    os.system("vconfig set_flag eth0.2 1 1")

    os.system("ifconfig eth0.1 192.168.102.2")
    os.system("ifconfig eth0.2 192.168.101.3")
    os.system("ifconfig eth0 down")
    os.system("ifconfig eth0 up")
    os.system("ifconfig eth0.1 up")
    os.system("ifconfig eth0.2 up")

    killall("testrawsocket")
    os.system("python testrawsocket.py --client &")
    os.system("sleep 3")
    ret = run_cmd("python testrawsocket.py --server | grep loopback_mode")
    check_result=False
    if ret != "":
        log.warn('[firstcheck_loopback] in loopback mode')
        #在生产检测的loopback模式中        
        check_result = True
    else:
        check_result = False
    killall("testrawsocket")
    log.warn('[firstcheck_loopback] end')
    return check_result

#检查出厂模式，如果未测试通过，红灯快闪, 表示设备处理于功能未确定状态
#返回True:表示生成检测成功 返回False：表示未经过生产检测 
def check_factory_mode(log,mode):
    errors=0
    factory_mode = run_cmd('cat /etc/factory.mode | grep stage')
    log.info( "[SetEthernetConfig]device factory mode = {} ".format(factory_mode))
    if factory_mode == None:
        #log.info("/etc/factory.mode is empty,set factory_mode=init default")
        factory_mode = "stage=init"
    if not mode in factory_mode :
        print "[SetEthernetConfig]device factory stage=init ,must be factory test"
        errors+=1    
    else:
        print "[SetEthernetConfig]device factory {}".format(factory_mode)
    
    if errors>0:
        return False
    else:
        return True

def main(log):
    ret = 0
    get_version(log)
    root = None
    mode = None

    #首先检查是否在生产模式下
    if  check_factory_mode(log,"test_pass") == False:
        if firstcheck_loopback(log) == True:
            #生产模式下直接退出默认网卡配置模式
            return True

    #启动ql_manager_server
    os.system("/etc/init.d/start_ql_manager_server_le start")

    while True:
        try:
            tree = xml.etree.ElementTree.parse(Src_AnyLink_xml)
            root = tree.getroot()
            mode = root.find('NetworkInfo/Mode').text
        except Exception as ept:
            log.error(repr(ept))
            light_led(GPIO_ErrorState, 0)
            set_default_network(log)  # default ethernet
            ret = -1
            break
        
        if mode == '4G':
            mode = '4G'
        else:
            if FORCE_WIFI_OPEN:
                mode="wifi"
        

        if config_network(root, mode=mode, log=log):
            light_led(GPIO_ErrorState, 0)
            ret = -1
        break

    os.system("sync")
    #启动健康检查
    killall("health_dialogue.py")
    os.system("cd /opt/script/ && python health_dialogue.py >/dev/null 2>&1 &")
    os.system("/etc/init.d/start_boa start")
    killall("hardware_checker.py")
    os.system("cd /opt/script/ && python hardware_checker.py >/dev/null 2>&1 &")
    return ret


# ############################# main block ##############################

if __name__ == '__main__':
    logLevel = logging.DEBUG
    if len(sys.argv) > 1:
        level = int(sys.argv[1])
        if level == 100:
            logLevel = logging.ERROR
        elif level == 200:
            logLevel = logging.WARN
        elif level == 300:
            logLevel = logging.INFO
        else:
            logLevel = logging.DEBUG
    logger = initial_log('/PageFile/SetEthernetConfig.log', logLevel)
    if main(logger):
        sys.exit(1)
    else:
        sys.exit(0)
