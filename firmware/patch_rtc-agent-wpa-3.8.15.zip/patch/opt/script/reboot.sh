#!/bin/sh

# author:   luoshuai
# version:  1.0.1
# date:     2020/12/8

run(){
  # random sleep 0 ~ 10000 s
  sleep $((RANDOM %10000))
  # wait for sync done before shutdown
  sync
  /sbin/shutdown -r now
}

run