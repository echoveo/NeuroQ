﻿
math = require("math")

D_CAT   = "DEMO"
DRIVER  = AeDriver.new()
--ITEM    = AeItem.new()



function IDrv_Proc(drv,item,count)
	
	for i=0,count-1,1 do
		DRIVER:getitem(item,i)
		
		--drv:logmsg(D_CAT,300,"item name:"..item:getname())
		--drv:logmsg(D_CAT,300,"item id:"..item:getid())
		--drv:logmsg(D_CAT,300,"item type:"..item:gettype())
		--drv:logmsg(D_CAT,300,"item config:"..item:getconfig())
			
		--double
		if item:gettype() == 1 then
			item:setnumbervalue(0, math.random())
		end
		DRIVER:sleepms(10)
		--int
		if item:gettype() == 2 then
			item:setboolvalue(0, ((math.random()%2~=0 and 1) or 0))
		end
		DRIVER:sleepms(10)
		--string
		if item:gettype() == 3 then
			item:setstringvalue(0, ((math.random()%2~=0 and "demo1") or "demo0"))
		end
			
		item:setquality(1)
		DRIVER:postdata(item)
	end
		
	--[[DRIVER:postmessage(2,"this is lua test.")
		
	DRIVER:logmsg(D_CAT,300,"lua driver is running.")
		
	DRIVER:logmsg(D_CAT,200,"lua driver is running, load 2 again.")
		
	DRIVER:logmsg(D_CAT,100,"lua state :"..DRIVER:isrunning())--]]
		
	--DRIVER:logmsg(D_CAT,100,"lua state mem count: "..collectgarbage("count"))
	print("==================lua state mem count: "..collectgarbage("count"))

	local ret = DRIVER:sleep(1)	

end



--IDrv API
--设备驱动主函数，函数不可阻塞
function IDrv_Init()
	
	
	return 1
	
end


--IDrv API
--设备驱动主函数，函数不可阻塞，异常情况写文件日志，或发送消息日志
function IDrv_Start()

    --初始化区
	--to do

	--print(DRIVER:itemcount())

	print(DRIVER:getconfig())
	
	--DRIVER:logmsg(D_CAT,100,"lua state :"..DRIVER:isrunning())
	math.randomseed(os.time())
	
	--获取数据项个数
	local count = DRIVER:itemcount()
	--创建新数据，此数据项可重复使用，且可以用于任何类型的数据项
	--local item = AeItem.new()
    local ITEM    = AeItem.new()

    --驱动循环工作区
	--to do
	
	--示例，具体实现自由组织
	for i=0,count-1,1 do
		DRIVER:getitem(ITEM,i)
		
		--DRIVER:logmsg(D_CAT,300,"item name:"..ITEM:getname())
		--DRIVER:logmsg(D_CAT,300,"item id:"..ITEM:getid())
		--DRIVER:logmsg(D_CAT,300,"item type:"..ITEM:gettype())
		--DRIVER:logmsg(D_CAT,300,"item config:"..ITEM:getconfig())
			
		--double
		if ITEM:gettype() == 1 then
			ITEM:setnumbervalue(0, math.random())
		end
		DRIVER:sleepms(10)
		
		--int
		if ITEM:gettype() == 2 then
			ITEM:setboolvalue(0, ((math.random()%2~=0 and 1) or 0))
		end
		DRIVER:sleepms(10)
		
		--string
		if ITEM:gettype() == 3 then
			ITEM:setstringvalue(0, ((math.random()%2~=0 and "demo1") or "demo0"))
		end
			
		ITEM:setquality(1)
		ITEM:settimestamp()
		DRIVER:postdata(ITEM)
	end
		
	--DRIVER:postmessage(2,"this is lua test.")	
	--DRIVER:logmsg(D_CAT,300,"lua driver is running.")
	--DRIVER:logmsg(D_CAT,200,"lua driver is running, load 2 again.")
	--DRIVER:logmsg(D_CAT,100,"lua state :"..DRIVER:isrunning())
	--drv:logmsg(D_CAT,100,"lua state mem count: "..collectgarbage("count"))
		
	--print("lua state mem count: "..collectgarbage("count"))

	--local ret = DRIVER:sleep(1)
	--IDrv_Proc(drv,item,count)

	return 0
	
end


--IDrv API
--设备驱动销毁函数，函数不可阻塞
function IDrv_Destroy()

	--销毁lua资源
	--todo

    return 1
	
end


--IDrv API
--设备驱动控制回调函数，函数不可阻塞
function IDrv_Control(command)

    local resp = "{resp:no response ================================== }"
	if type(command) ~= "string" then
		return 0
	end
	
	DRIVER:logmsg(D_CAT,100,"control cmd :"..command)

	--执行控制命令
	--todo

    return resp
	
end


