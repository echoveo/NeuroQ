#
#watchdog -- linux version 1.1.0
#


import socket
import select
import time
import os
import string
import sys
import signal
import threading
import httplib
import urllib


BRUN    = True
HOST    = '127.0.0.1'
PORT    = 11001
BUFSIZE = 1024  #1KB
FREQ    = 120
TIMER   = 0
CPID    = -1
BSTOP   = False
TIMEOUT = 20
RESTART_AGENT = 'rq:restart-agentbasic'
GETHOSTADDR   = 'rq:getaddrinfo-'
HOSTNAME = ''
HOSTPORT = 0
HOSTADDR = None

ADDR = (HOST, PORT)

def OnSigChild(a,b):
    try:
        #to nothing
        time.sleep(1)
    except:
        print 'unkown error OnSigChild.'
    finally:
        BSTOP = False

def StartAgent():
    try:
        AGENT = sys.path[0] + '/agentbasic'
        global CPID
        CPID = os.fork()
        if 0 == CPID:
            global BRUN 
            BRUN = False
            pid = os.fork()
            if 0 == pid:
                os.system(AGENT)
            else:
                print 'grandchild process pid = %d.' %pid
                print "child process will exit."
        else:
            print 'child process pid = %d.' %CPID
            result = os.waitpid(CPID, 0);
            print "child process(%d) exit." %CPID
            print 'start agent successful.'
    except Exception, e:
        print e
        print 'start agent failed.'

def StopAgent():
    try:
        START   = 65
        PROCESS = 'agentbasic'
        LOGFILE = 'process.log'
        os.system('ps aux | grep %s > %s' % (PROCESS, LOGFILE))
        fPid = open(LOGFILE, 'r')
        cmds = fPid.readlines()
        fPid.close()
        for line in cmds:
            print line
            pid = line.split()[0] #linux index = 1, arm linux index = 0
            print pid
            try:
                os.kill(string.atoi(pid), 9)
            except Exception, e:
                print e
        
    except Exception, e:
        print e
        print 'stop agent failed.'
    finally:
        global BSTOP
        if len(cmds) > 2:
            BSTOP = True

def RestartAgent():
    try:
        #start agent
        StopAgent()
        #sleep 1s
        time.sleep(1)
        #stop agent
        StartAgent()
    except:
        print 'restart agent failed.'

def SendRestartResponse(sock):
    try:
        sock.send( RESTART_AGENT + '=1' );
    except Exception, e:
        print  e
        print 'send restart agent response failed.'
        
class ResolveThread(threading.Thread):
    def __init__(self,host,port):
        self.host = host
        self.port = port
        threading.Thread.__init__(self)
        
    def SetHost(self,host,port):
        if self.host != host:
            global HOSTADDR
            HOSTADDR = None
        self.host = host
        self.port = port
        print host + ':' + port
 
    def run(self):
        global HOSTADDR
        while True==BRUN:
            try:
                if self.host != None and self.port != None:
                    res=socket.getaddrinfo(self.host,self.port,socket.AF_INET,socket.SOCK_STREAM)
                    for re in res:
                        HOSTADDR = re[4][0]
                        print 'host addr:'
                        print HOSTADDR
                        break
                
            except Exception, e:
                print self.host, e
            #sleep
            if HOSTADDR == None:
                time.sleep(1)
            else:
                i = 0
                while (i<300):
                    i += 1
                    time.sleep(2)
                    if HOSTADDR == None:
                        break
            
def GetHostAndPort(url):
    try:
        idx = url.index(':')
        return (url[:idx],url[idx+1:])
    except Exception, e:
        print url, e
    return (None,None)
        
def SendHostIPResponse(sock):
    try:
        global HOSTADDR
        sock.send( GETHOSTADDR + HOSTADDR );
        print GETHOSTADDR + HOSTADDR
    except Exception, e:
        print  e
        print 'send host ip response failed.'
        
def UpdateWifi():
    params = urllib.urlencode({'wifi_cmd': 'refresh'})
    headers = {"Content-Type": "application/x-www-form-urlencoded",
                "Accept": "*/*"}
    conn = httplib.HTTPConnection("127.0.0.1")
    conn.request("POST", "/cgi-bin/wifi/wifi.py", params, headers)
    response = conn.getresponse()
    print response.status, response.reason
    data = response.read()
    print data
    conn.close()

def main_loop():
    try:
        global ADDR
        global BUFSIZE
        global TIMER
        signal.signal(signal.SIGCHLD, OnSigChild)
        svrSock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        svrSock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR,1)
        svrSock.bind(ADDR)
        svrSock.listen(5)
        RFDS = [svrSock]
    
        hResolve  = ResolveThread(None,None)
        hResolve.start()
    
        while True==BRUN:
            rs,ws,es = select.select(RFDS,[],[],1)
            for r in rs:
                if r is svrSock:
                    cliSock,cAddr = svrSock.accept()
                    while BRUN:
                        data = cliSock.recv(BUFSIZE)
                        if data:
                            print data
                            if data == RESTART_AGENT:
                                SendRestartResponse(cliSock)
                                RestartAgent()
                                TIMER = time.time()
                            elif data.startswith(GETHOSTADDR) == True:
                                (rhost,rport) = GetHostAndPort(data[len(GETHOSTADDR):])
                                hResolve.SetHost(rhost,rport)
                                SendHostIPResponse(cliSock)
                                TIMER = time.time()
                            else:
                                TIMER = time.time()
                        cliSock.close()
                        break;
                    cliSock.close()
            nTime = time.time()
            if TIMER < (nTime - FREQ):
                RestartAgent()
                TIMER = nTime
            
            print 'sleep 1s, %f - %f' %(TIMER, nTime)
        svrSock.close()
    except Exception, e:
        print e

if __name__=="__main__":
    while True==BRUN:
        main_loop()
        time.sleep(1)
