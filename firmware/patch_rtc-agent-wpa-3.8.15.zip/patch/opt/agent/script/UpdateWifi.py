#!/usr/bin/python
# -*- coding: UTF-8 -*-

import os
import sys
import time
import xml.etree.ElementTree


def UpdateWifi():
    #Get wifi NetworkInfo
    try:
        cPath  = '/opt/script/ScriptConfig.xml'
        fpath  = '/opt/script/RT3070/wpa_supplicant.conf'
        try:
            ctree     = xml.etree.ElementTree.parse(cPath)
            cnodes    = ctree.getroot()
            nWifiDir  = cnodes.find('WiFi/WifiDir').text
            nWifiConf = cnodes.find('WiFi/WifiConf').text
            fpath     = nWifiDir + nWifiConf
        except Exception, e:
            print e
            print "Failed to read ScriptConfig.xml!"
            fpath  = '/opt/script/RT3070/wpa_supplicant.conf'

        fpath  = '/opt/script/WiFi/wpa_supplicant.conf'	#add by kali
        print fpath
        #Set wpa_supplicant.conf
        tree   = xml.etree.ElementTree.parse("/opt/sdmwebs/web/conf/AnyLink.xml")
        nodes  = tree.getroot()
        
        hf     = open(fpath,'w')

        nwifis = nodes.find('Wifi/W_Remote/W_List')

        if nwifis is None:
            ssid   = nodes.find('Wifi/W_SSID').text
            psk    = nodes.find('Wifi/W_Password').text
            hf.write('ctrl_interface=/var/run/wpa_supplicant')
            hf.write('\n')
            if psk is None or len(psk) <= 0:
                hf.write('network={\n')
                hf.write('        ssid="' + ssid + '"\n')
                hf.write('        key_mgmt=NONE\n')
                hf.write('}\n')
            else:
                hf.write('ap_scan=1\n')
                hf.write('update_config=1\n\n')
                hf.write('network={\n')
                hf.write('        ssid="' + ssid + '"\n')
                hf.write('        psk="'  + psk  + '"\n')
                hf.write('}\n')
        else:
            hf.write('ctrl_interface=/var/run/wpa_supplicant\n')
            hf.write('update_config=1\n\n')
            for nwifi in nwifis:
                try:
                    ssid   = nwifi.find('W_SSID').text
                    if ssid is None:
                        continue
                    psk    = nwifi.find('W_Password').text
                    if psk is None or len(psk) <= 0:
                        hf.write('network={\n')
                        hf.write('        ssid="' + ssid + '"\n')
                        hf.write('        scan_ssid=1\n')
                        hf.write('        key_mgmt=NONE\n')
                        hf.write('}\n')
                    else:
                        hf.write('network={\n')
                        hf.write('        ssid="' + ssid + '"\n')
                        hf.write('        scan_ssid=1\n')
                        hf.write('        psk="'  + psk  + '"\n')
                        hf.write('}\n')
                except Exception, e:
                    print e
                    print "Failed to get wifi NetworkInfo!"
        hf.close()
        os.system('chmod +x ' + fpath);
        os.system('/sbin/reboot');
    except Exception, e:
        print e
        print "Failed to set wifi NetworkInfos!"
        return 0    
    return 1

############################## main block ##############################

if __name__ == '__main__':
    ret = UpdateWifi()
    sys.exit(ret)
