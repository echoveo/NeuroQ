#!/usr/bin/python
# -*- coding: UTF-8 -*-

import os
import sys
import time
import thread
import shutil
import commands
import xml.etree.ElementTree


def UpdateLan():
	#Get ethernet NetworkInfo
	#IE盒子LAN口和WAN共用eth0
	try:
		tree = xml.etree.ElementTree.parse("/opt/sdmwebs/web/conf/AnyLink.xml")
		nodes = tree.getroot()
		NodeName = nodes.find('NetworkInfo')
		Nport = NodeName.get("muti", default=None)
	except Exception, e:
		print Exception,":",e
		print "Failed to get ethernet NetworkInfo!"
		return 0
	if "YES" in Nport:
		try:
			tree        = xml.etree.ElementTree.parse("/opt/sdmwebs/web/conf/AnyLink.xml")
			nodes       = tree.getroot()
			NodeName    = nodes.find('NetworkInfo/LAN')
			Eth1IPAddr  = NodeName.get("ip", default=None)
			Eth1Mask    = NodeName.get("mask", default=None)
			Eth1GateWay = NodeName.get("gateway", default=None)
			Eth1DNS     = NodeName.get("dns", default=None)
			Eth1DHCP    = NodeName.get("dhcp", default=None)
			if "YES" in Eth1DHCP:
				os.system("/sbin/udhcpc -i eth0 -t 3 -q &")
			elif "NO" in Eth1DHCP:
				os.system("/sbin/ifconfig eth0 %s netmask %s"%(Eth1IPAddr, Eth1Mask))
				#os.system("/sbin/route add default gw %s eth1"%Eth1GateWay)
		except Exception, e:
			print Exception,":",e
			print "Failed to set ethernet NetworkInfo!"
			return 0
	return 1

############################## main block ##############################

if __name__ == '__main__':
	ret = UpdateLan()
	sys.exit(ret)
