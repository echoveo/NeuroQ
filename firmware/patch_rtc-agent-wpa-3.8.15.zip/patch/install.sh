#var
BACKUP_DIR="/usrdata/backup/usa-14"
SOFT_VERSION="3.8.11"

echo "add patch ${SOFT_VERSION}"
#stop watch dog
echo "stop watch dog"
ps -ef | grep checknet.py | grep -v grep && kill `ps -ef | grep checknet.py | grep -v grep | awk '{print $1}'`
ps -ef | grep SetLEDStatus.py | grep -v grep && kill `ps -ef | grep SetLEDStatus.py | grep -v grep | awk '{print $1}'`
#ps -ef | grep watchdogd.py | grep -v grep && kill `ps -ef | grep watchdogd.py | grep -v grep | awk '{print $1}'`
#ps -ef | grep watchdog.py | grep -v grep && kill `ps -ef | grep watchdog.py | grep -v grep | awk '{print $1}'`
ps -ef | grep Reset.py | grep -v grep && kill `ps -ef | grep Reset.py | grep -v grep | awk '{print $1}'`
ps -ef | grep health_dialogue.py | grep -v grep && kill `ps -ef | grep health_dialogue.py | grep -v grep | awk '{print $1}'`

#ps -ef | grep agentd | grep -v grep && kill `ps -ef | grep agentd | grep -v grep | awk '{print $1}'`
#ps -ef | grep agentbasic | grep -v grep && kill `ps -ef | grep agentbasic | grep -v grep | awk '{print $1}'`

#backup 
rm -rf ${BACKUP_DIR}
mkdir -p ${BACKUP_DIR}
mkdir -p ${BACKUP_DIR}/opt/script/WiFi
test -e /opt/script/WiFi/wpa_supplicant.conf && cp -f /opt/script/WiFi/wpa_supplicant.conf ${BACKUP_DIR}/opt/script/WiFi/
mkdir -p ${BACKUP_DIR}/etc
cp -f /etc/devuaid.d ${BACKUP_DIR}/etc/

[ ! -f /etc/lockdown.tmp ] && echo 0 > /etc/lockdown.tmp

mkdir -p ${BACKUP_DIR}/opt/sdmwebs/web/conf
cp  -f /opt/sdmwebs/web/conf/AnyLink.xml ${BACKUP_DIR}/opt/sdmwebs/web/conf

mkdir -p ${BACKUP_DIR}/opt/agent
cp  -f /opt/agent/ModuleConfig.xml ${BACKUP_DIR}/opt/agent

sync

#dos2unix
find -name '*.sh' | xargs -n 1 dos2unix
find -name '*.py' | xargs -n 1 dos2unix
find -name '*.conf' | xargs -n 1 dos2unix
find -name '*.json' | xargs -n 1 dos2unix

#install
echo "install sftp"
cp ./usr/libexec/sftp-server	/usr/libexec/sftp-server
chmod +x /usr/libexec/sftp-server
echo "install usb storage"
cp  -f ./etc/mdev.conf	/etc/mdev.conf
cp -f ./etc/mdev/automountusb1.sh /etc/mdev/automountusb1.sh
cp -f ./etc/mdev/automountusb2.sh /etc/mdev/automountusb2.sh
chmod +x /etc/mdev/*.sh

echo "install usb to serial"
mkdir -p /lib/modules/3.18.20/kernel/drivers/usb/serial
cp -rf ./ko/usbserial.ko /lib/modules/3.18.20/kernel/drivers/usb/serial
cp -rf ./ko/ftdi_sio.ko /lib/modules/3.18.20/kernel/drivers/usb/serial
cp -rf ./ko/cp210x.ko /lib/modules/3.18.20/kernel/drivers/usb/serial
sync
echo "install rtc driver"
[ ! -d /lib/modules/3.18.20/kernel/drivers/rtc ] && mkdir -p /lib/modules/3.18.20/kernel/drivers/rtc
[ ! -f /lib/modules/3.18.20/kernel/drivers/rtc/rtc-bm8563.ko ] && cp -rf ./ko/rtc-bm8563.ko /lib/modules/3.18.20/kernel/drivers/rtc/rtc-bm8563.ko


echo "install /opt/script"
cp -rf ./opt/script/* /opt/script/
chmod -R +x  /opt/script/
echo -e "insmod /lib/modules/3.18.20/kernel/drivers/usb/serial/usbserial.ko \n" >>/opt/script/startup.sh
echo -e "insmod /lib/modules/3.18.20/kernel/drivers/usb/serial/ftdi_sio.ko \n" >>/opt/script/startup.sh
echo -e "insmod /lib/modules/3.18.20/kernel/drivers/usb/serial/cp210x.ko \n" >>/opt/script/startup.sh
sync


echo "install webUI"
cp -rf ./opt/sdmwebs/web/* /opt/sdmwebs/web/
chmod -R +x  /opt/sdmwebs/web/

echo "install factory_test"
mkdir -p /usrdata/factory_test
cp -rf ./usrdata/factory_test/* /usrdata/factory_test/
chmod -R +x  /usrdata/factory_test/

echo "install agent"
cp -rf ./opt/agent/* /opt/agent/
chmod -R +x  /opt/agent/
cp -f ./opt/agent/libdADC.so.1.1.1	/opt/agent/libdADC.so.1.1.1
chmod +x /opt/agent/libdADC.so.1.1.1
rm /opt/agent/libdADC.so;ln -s /opt/agent/libdADC.so.1.1.1 /opt/agent/libdADC.so;chmod +x /opt/agent/libdADC.so
cp -f ./opt/agent/libTUsbtenki.so.1.0.4	/opt/agent/libTUsbtenki.so.1.0.4
chmod +x /opt/agent/libTUsbtenki.so.1.0.4
rm /opt/agent/libTUsbtenki.so;ln -s /opt/agent/libTUsbtenki.so.1.0.4 /opt/agent/libTUsbtenki.so;chmod +x /opt/agent/libTUsbtenki.so
test -e /opt/agent/libDModbus.so && rm /opt/agent/libDModbus.so;ln -s /opt/agent/libDModbus.so.1.4.3 /opt/agent/libDModbus.so;chmod +x /opt/agent/libDModbus.so
test -e /opt/agent/libDVWRSymphony.so && rm /opt/agent/libDVWRSymphony.so;ln -s /opt/agent/libDVWRSymphony.so.1.0.2 /opt/agent/libDVWRSymphony.so;chmod +x /opt/agent/libDVWRSymphony.so
test -e /opt/agent/libTMultitronProShakingIncubator.so && rm /opt/agent/libTMultitronProShakingIncubator.so;ln -s /opt/agent/libTMultitronProShakingIncubator.so.1.0.1 /opt/agent/libTMultitronProShakingIncubator.so;chmod +x /opt/agent/libTMultitronProShakingIncubator.so

echo "install agentd"
cp -rf ./opt/agentd/* /opt/agentd/
chmod -R +x  /opt/agentd/

echo "install checknet.py & paho.mqtt"
cp -rf ./usr/lib/python2.7/site-packages/paho /usr/lib/python2.7/site-packages/
chmod -R +x  /usr/lib/python2.7/site-packages/paho/
cp -rf ./usr/lib/python2.7/lib-dynload/_ssl.so /usr/lib/python2.7/lib-dynload/_ssl.so
cp -rf ./usr/lib/python2.7/ssl.py /usr/lib/python2.7/ssl.py
chmod +x  /usr/lib/python2.7/lib-dynload/_ssl.so
chmod +x  /usr/lib/python2.7/ssl.py

sync

echo "install dropbear"
cp -f ./usr/sbin/dropbear	/usr/sbin/dropbear
cp -f ./usr/bin/scp	/usr/bin/scp
chmod +x /usr/sbin/dropbear
chmod +x /usr/bin/scp

echo "install anylink.ver"
cp  -f ./etc/anylink.ver	/etc/anylink.ver
sync

echo "install timezone DB"
cp -rf ./usr/share/zoneinfo /usr/share/zoneinfo
sync

echo "install wpa_supplicant"
cp -rf ./usr/lib/libssl.so.3 /usr/lib/libssl.so.3
cp -rf ./usr/lib/libcrypto.so.3 /usr/lib/libcrypto.so.3
cp -rf ./usr/sbin/wpa_supplicant /usr/sbin/wpa_supplicant
chmod +x /usr/sbin/wpa_supplicant
echo "update wpa_supplicant1.0 to wpa_supplicant2.0" > /etc/wpa_supplicant_update.log
sync

echo "disable boa logs"
cp -f ./etc/boa/boa.conf    /etc/boa/boa.conf

#restore 
echo "restore "
test -e ${BACKUP_DIR}/opt/script/WiFi/wpa_supplicant.conf && cp -f  ${BACKUP_DIR}/opt/script/WiFi/wpa_supplicant.conf /opt/script/WiFi/wpa_supplicant.conf 
cp -f ${BACKUP_DIR}/etc/devuaid.d  /etc/devuaid.d 
cp  -f ${BACKUP_DIR}/opt/sdmwebs/web/conf/AnyLink.xml /opt/sdmwebs/web/conf/AnyLink.xml 
cp  -f ${BACKUP_DIR}/opt/agent/ModuleConfig.xml /opt/agent/ModuleConfig.xml 
sync

echo "modify version info: Anylink.xml Common.xml"
python ./changeNeuroQModel.py
sync

echo "fixed ethernet macaddress issue: "
cp -rf ./etc/init.d/* /etc/init.d/
chmod -R +x  /etc/init.d/

sync


#remove debug flag
echo "remove init_ip"
test -e /etc/init_ip && rm /etc/init_ip

sed -i '/114.114.114.114/d' /etc/resolv.conf

sed -i "s/network_wan_dhcp = 'NO'/network_wan_dhcp = 'YES'/g" /opt/sdmwebs/web/cgi-bin/config/global_var.py

echo "create /etc/factory.mode"
echo -e "# init :                after usb firmware downloaded\n" > /etc/factory.mode
echo -e "# test_running :        factory test in running\n" >> /etc/factory.mode
echo -e "# test_fail :           factory test fail\n" >> /etc/factory.mode
echo -e "# test_pass :           factory test pass\n" >> /etc/factory.mode
echo -e "stage=test_pass\n" >> /etc/factory.mode
echo -e "date=" $(date +"%Y-%m-%d %H:%M:%S") "\n" >> /etc/factory.mode
echo -e "manufacturer=patch_${SOFT_VERSION}\n" >> /etc/factory.mode
echo -e "version=${SOFT_VERSION}\n" >> /etc/factory.mode
echo -e "patch ${SOFT_VERSION}\n" >> /etc/patch.list
sync

#echo "change user[root] password to @ny&Link016"
#echo -e "@ny&Link016\n@ny&Link016" | passwd root 2&>1
#sync

echo "finished"
cat ./changelist

# for OTA update.py
echo "UPDATE_SUCCESS"   
 