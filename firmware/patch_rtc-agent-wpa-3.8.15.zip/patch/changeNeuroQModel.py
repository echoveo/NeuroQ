#!/usr/bin/python
# -*- coding: UTF-8 -*-
import xml.etree.ElementTree as ET
import sys
import os
import shutil
import time

__VERSION = "0.0.5"

NeuroQHardwareName="NeuroQ-200"
NeuroQHardwareModel="NeuroQ-200"
NeuroAnyLinkType="NeuroQ"
NeuroSoftVersion="3.8.15"


class reusexml:
    '''使用xml'''
    xml_tree = None
    filepath = ''

    def __init__(self, filepath):
        '''获取cookie'''
        if 'HTTP_COOKIE' in os.environ:
            cookie_string = os.environ.get('HTTP_COOKIE')
            c = Cookie.SimpleCookie()
            c.load(cookie_string)
            data = c['AnyLinkLan'].value

        if os.path.exists(filepath):
            self.xml_tree = ET.parse(filepath)
            self.filepath = filepath
        else:
            if data == "English":
                print filepath + "Not exist"
            else:
                print filepath + "不存在"
            sys.exit(0)

    def getElement(self, tag):
        node = self.xml_tree.find(tag)
        return node

    def createElement(self, ftag, stag, val=None):
        element = ET.Element(stag)
        if val != None:
            element.text = val
        ftag.append(element)

    def getTagVal(self, tag):
        '''获取xml中tag的值'''
        node = self.xml_tree.find(tag)
        if node is not None:
            return node.text
        else:
            return -1

    def setTagVal(self, tag, val):
        '''获取cookie'''
        if 'HTTP_COOKIE' in os.environ:
            cookie_string = os.environ.get('HTTP_COOKIE')
            c = Cookie.SimpleCookie()
            c.load(cookie_string)
            data = c['AnyLinkLan'].value
        '''设置xml中tag的值'''
        node = self.xml_tree.find(tag)
        if node is not None:
            node.text = val
        else:
            if data == "English":
                print "Unfound node" + tag
            else:
                print "未找到节点" + tag

    def savexml(self):
        '''保存xml'''
        self.xml_tree.write(self.filepath, encoding='utf-8')
        # self.xml_tree.write(self.filepath,
        #                     encoding='utf-8',
        #                     xml_declaration='true')

    def displayxml(self):
        '''展示xml'''
        ET.dump(self.xml_tree)




#check xml file valid 
def checkXMLFile(path_xml,check_node=None):
    try_times=3
    while try_times>0:
        try:
            ET_xml = ET.parse(path_xml)
            if check_node!=None :
                c_node = AnyLinkTree.find(check_node)
                if  c_node != None:
                    return True
            else:               
                return True
        except Exception as ept:
            pass
        try_times = try_times-1
        time.sleep(0.3)
    return False

# 将变量值更新至Common.xml文件中
common_path = '/opt/sdmwebs/web/conf/Common.xml'
commonTree = ET.parse(common_path)
HardwareModel_node = commonTree.find('HardwareModel')
HardwareModel_node.text = NeuroQHardwareModel

HardwareName_node = commonTree.find('HardwareName')
if HardwareName_node is not None:
    HardwareName_node.text = NeuroQHardwareName

AnyLinkType_node = commonTree.find('AnyLinkType')
if AnyLinkType_node is not None:
    AnyLinkType_node.text = NeuroAnyLinkType

SoftVersion_node = commonTree.find('SoftVersion')

if SoftVersion_node is not None:
    SoftVersion_node.text = NeuroSoftVersion

commonTree.write(common_path, xml_declaration='true')

# 将变量值更新至AnyLink.xml文件中
AnyLink_path = '/opt/sdmwebs/web/conf/AnyLink.xml'
AnyLink_path_backup = '/opt/sdmwebs/web/conf/AnyLink_backup.xml'
AnyLink_path_tmp = '/tmp/AnyLink_tmp_up.xml'

if not checkXMLFile(AnyLink_path):
    print AnyLink_path,"invalid"
    print "try restore xml from ",AnyLink_path_backup
    if checkXMLFile(AnyLink_path_backup) :
        os.system('cp -f %s %s' % (AnyLink_path_backup,AnyLink_path))        
        print "restore xml from ",AnyLink_path_backup,"success"
    else:
        print "restore xml from ",AnyLink_path_backup,"fail, backup file not exists"
        print "P1-UPDATE-FAIL"
        sys.exit(1)

os.system('cp -f %s %s' % (AnyLink_path,AnyLink_path_backup))
os.system('cp -f %s %s' % (AnyLink_path,AnyLink_path_tmp))

AnyLinkTree = ET.parse(AnyLink_path_tmp)
HardwareModel_node = AnyLinkTree.find('BasicInfo/HardwareModel')
HardwareModel_node.text = NeuroQHardwareModel

HardwareName_node = AnyLinkTree.find('BasicInfo/HardwareName')
if HardwareName_node is not None:
    HardwareName_node.text = NeuroQHardwareName

AnyLinkType_node = AnyLinkTree.find('BasicInfo/AnyLinkType')
if AnyLinkType_node is not None:
    AnyLinkType_node.text = NeuroAnyLinkType

SoftVersion_node = AnyLinkTree.find('BasicInfo/SoftVersion')
if SoftVersion_node is not None:
    SoftVersion_node.text = NeuroSoftVersion

# 修改dns 到8.8.8.8
dns_usa = '8.8.8.8'
WAN_node = AnyLinkTree.find('NetworkInfo/WAN')
if WAN_node is not None:
    WAN_node.attrib['dns']=dns_usa
    #WAN_node["dns"].value=dns_usa

LAN_node = AnyLinkTree.find('NetworkInfo/LAN')
if LAN_node is not None:
    LAN_node.attrib['dns']=dns_usa
    #LAN_node["dns"].value=dns_usa


'''
#写入DeviceConfigUI 标记
DriverConfigUI_node = AnyLinkTree.find('BasicInfo/DriverConfigUI')
if DriverConfigUI_node is not None:
    DriverConfigUI_node.text = "0"
else:
    #create node
    DriverConfigUI_node = ET.Element("DriverConfigUI")
    DriverConfigUI_node.text="0"
    BasicInfo_node = AnyLinkTree.find('BasicInfo')
    if BasicInfo_node != None:
        BasicInfo_node.append(DriverConfigUI_node)
'''


AnyLinkTree.write(AnyLink_path_tmp, xml_declaration='true')




os.system('cp -f %s %s;sync' % (AnyLink_path_tmp,AnyLink_path))

#更新/opt/agent/AgentConfig.xml 里面的<Debug>设置成100
AgentConfig_path = '/opt/agent/AgentConfig.xml'
AgentConfig_path_tmp = '/tmp/AgentConfig.xml.tmp'
os.system('cp -f %s %s' % (AgentConfig_path,AgentConfig_path_tmp))

AgentTree = ET.parse(AgentConfig_path_tmp)

Debug_node = AgentTree.find('Debug')
if Debug_node is not None:
    Debug_node.text = "100"





AgentTree.write(AgentConfig_path_tmp, xml_declaration='true')

os.system('cp -f %s %s;sync' % (AgentConfig_path_tmp,AgentConfig_path))
#os.system('rm -f %s ' % (AnyLink_path_tmp))

if not checkXMLFile(AnyLink_path):
    print AnyLink_path,"invalid, recheck"
    print "after: try restore xml from ",AnyLink_path_backup
    if checkXMLFile(AnyLink_path_backup) :
        os.system('cp -f %s %s' % (AnyLink_path_backup,AnyLink_path))        
        print "after: restore xml from ",AnyLink_path_backup,"success"        
    else:
        print "after: restore xml from ",AnyLink_path_backup,"fail, backup file not exists"
    print "P1-UPDATE-FAIL"
os.system('sync')

