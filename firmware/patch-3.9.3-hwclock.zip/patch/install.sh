#!/bin/sh
# Patch 3.9.3 for NeuroQ firmware 3.9.2: restore RTC time at boot.
#
# /etc/init.d/hwclock.sh ships with CRLF line endings in 3.9.2, so its
# "hwclock --hctosys" fails and the battery-backed RTC is never loaded into the
# system clock. This installer replaces it with the known-good copy (identical to
# firmware 3.8.15) and sets the firmware version to 3.9.3. It only runs on 3.9.2.
#
# Installed by Advanced > Firmware Update, which runs this script and treats
# "UPDATE_SUCCESS" in the output as success. Every change is backed up first and
# rolled back if any step fails.
#
# ROOT can be set to a sandbox directory for testing; it is empty on a real box.

FROM_VERSIONS="3.9.2 3.9.02"
TO_VERSION="3.9.3"
PATCH_NAME="patch_3.9.3-hwclock"
REF_MD5="d22d8ab07d6336e43f74585fb33b3dc6"

ROOT=${ROOT:-}
HWCLOCK="$ROOT/etc/init.d/hwclock.sh"
CONF="$ROOT/opt/sdmwebs/web/conf"
ANYLINK="$CONF/AnyLink.xml"
COMMON="$CONF/Common.xml"
LOCK="$CONF/AnyLink.xml.lock"
REPAIR_COPY="$ROOT/mnt/mmc/backup/conf/AnyLink.xml"
PAYLOAD="./etc/init.d/hwclock.sh"
BACKUP_DIR="$ROOT/mnt/mmc/backup/hotfix-hwclock-crlf"
STAMP=$(date +%Y%m%d%H%M%S)
CR=$(printf '\r')
BACKUPS=""          # "target|backup" pairs, restored on failure

cd "$(dirname "$0")" || exit 1
echo "add patch $PATCH_NAME (firmware $FROM_VERSIONS -> $TO_VERSION)"

md5_of()     { md5sum "$1" | cut -d' ' -f1; }
version_of() { sed -n 's/.*<SoftVersion>\([^<]*\)<\/SoftVersion>.*/\1/p' "$1" | head -1; }

refuse() {          # nothing has been changed yet
    echo "ERROR: $1"
    echo "Patch NOT installed. Nothing was changed."
    exit 1
}

rollback() {        # undo every change made so far
    echo "ERROR: $1"
    for pair in $BACKUPS; do
        cp -p "${pair#*|}" "${pair%%|*}" && echo "restored ${pair%%|*}"
    done
    sync
    echo "Patch NOT installed. All changes were rolled back."
    exit 1
}

backup() {          # backup <file>; remembers it for rollback
    b="$BACKUP_DIR/$(basename "$1").$STAMP"
    cp -p "$1" "$b" || rollback "cannot back up $1"
    BACKUPS="$BACKUPS $1|$b"
    echo "backup saved to ${b#$ROOT}"
}

set_version() {     # set_version <xml file>: SoftVersion -> TO_VERSION, atomically
    f=$1; tmp="$f.patch.$$"
    old=$(version_of "$f")
    cp -p "$f" "$tmp" || rollback "cannot copy $f"
    sed -i "s#<SoftVersion>$old</SoftVersion>#<SoftVersion>$TO_VERSION</SoftVersion>#" "$tmp"
    # exactly one line may differ, and it must carry the new version
    if [ "$(version_of "$tmp")" != "$TO_VERSION" ] ||
       [ "$(grep -c . "$tmp")" != "$(grep -c . "$f")" ] ||
       [ "$(grep -v '<SoftVersion>' "$tmp" | md5sum)" != "$(grep -v '<SoftVersion>' "$f" | md5sum)" ]; then
        rm -f "$tmp"; rollback "version update check failed for $f"
    fi
    mv "$tmp" "$f" || { rm -f "$tmp"; rollback "cannot replace $f"; }
    echo "set ${f#$ROOT} SoftVersion $old -> $TO_VERSION"
}

# ---------------------------------------------------------------- checks (no changes)

[ -f "$ANYLINK" ] || refuse "${ANYLINK#$ROOT} not found"
current=$(version_of "$ANYLINK")
echo "firmware version on this box: ${current:-unknown}"

if [ "$current" = "$TO_VERSION" ] && [ -f "$HWCLOCK" ] && [ "$(md5_of "$HWCLOCK")" = "$REF_MD5" ]; then
    echo "patch $TO_VERSION is already applied; nothing to change."
    echo "UPDATE_SUCCESS"
    exit 0
fi

allowed=no
for v in $FROM_VERSIONS; do [ "$current" = "$v" ] && allowed=yes; done
[ "$allowed" = yes ] || refuse "this patch is only for firmware 3.9.2 (this box has ${current:-unknown})"

[ -f "$PAYLOAD" ] || refuse "package is missing $PAYLOAD"
[ "$(md5_of "$PAYLOAD")" = "$REF_MD5" ] || refuse "package file $PAYLOAD is damaged (md5 mismatch)"
[ -f "$HWCLOCK" ] || refuse "${HWCLOCK#$ROOT} not found"
[ -f "$COMMON" ] || refuse "${COMMON#$ROOT} not found"
[ -n "$(version_of "$COMMON")" ] || refuse "no SoftVersion in ${COMMON#$ROOT}"

# ---------------------------------------------------------------- 1. fix hwclock.sh

mkdir -p "$BACKUP_DIR" || refuse "cannot create ${BACKUP_DIR#$ROOT}"
echo "current hwclock.sh: md5 $(md5_of "$HWCLOCK"), $(grep -c "$CR" "$HWCLOCK") line(s) with CRLF"

if [ "$(md5_of "$HWCLOCK")" = "$REF_MD5" ]; then
    echo "hwclock.sh is already correct"
else
    backup "$HWCLOCK"
    stripped=$(tr -d '\r' < "$HWCLOCK" | md5sum | cut -d' ' -f1)
    if [ "$stripped" = "$REF_MD5" ]; then
        cp "$PAYLOAD" "$HWCLOCK.new" && chmod 755 "$HWCLOCK.new" && mv "$HWCLOCK.new" "$HWCLOCK" ||
            rollback "cannot install hwclock.sh"
        echo "installed reference hwclock.sh"
    else
        sed -i "s/$CR\$//" "$HWCLOCK"
        echo "hwclock.sh differs from the reference; removed CRLF line endings only"
    fi
    if [ "$(grep -c "$CR" "$HWCLOCK")" != 0 ] || ! sh -n "$HWCLOCK"; then
        rollback "hwclock.sh verification failed"
    fi
    echo "verified: hwclock.sh has Unix line endings (md5 $(md5_of "$HWCLOCK"))"
fi

# ---------------------------------------------------------------- 2. version -> 3.9.3

backup "$ANYLINK"
backup "$COMMON"
# AnyLink.xml is shared with the web UI; take its writer lock
exec 9>>"$LOCK"
flock 9 || rollback "cannot lock ${LOCK#$ROOT}"
set_version "$ANYLINK"
flock -u 9
set_version "$COMMON"
# the repair copy is only updated if it was current (same old version)
if [ -f "$REPAIR_COPY" ] && [ "$(version_of "$REPAIR_COPY")" = "$current" ]; then
    backup "$REPAIR_COPY"
    set_version "$REPAIR_COPY"
fi
sync

echo "patch $PATCH_NAME $current->$TO_VERSION $(date '+%Y-%m-%d %H:%M:%S')" >> "$ROOT/etc/patch.list"
sync

echo "finished. Reboot the box to activate the fix."
cat ./changelist

# for FirmwareUpdate.py / OTA update.py
echo "UPDATE_SUCCESS"
