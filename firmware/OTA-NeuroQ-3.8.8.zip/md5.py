import base64
import hashlib
import sys

with open(sys.argv[1], "rb") as f:
    file_hash = hashlib.md5()
    chunk = f.read(8192)
    while chunk:
        file_hash.update(chunk)
        chunk = f.read(8192)

print(base64.b64encode(file_hash.digest()))
